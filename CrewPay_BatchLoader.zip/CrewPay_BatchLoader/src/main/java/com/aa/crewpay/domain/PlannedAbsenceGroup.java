/**
 *
 */
package com.aa.crewpay.domain;

import java.util.Date;

import com.aa.crewpay.constant.enums.PositionCodeType;

/**
 * @author muthusba
 *
 */
public class PlannedAbsenceGroup {

	/**
	 * Attribute to hold the absence start date.
	 */
	private Date absenceStartDate;

	/**
	 * Attribute to hold the Crew Member Removal Reason Code.
	 */
	private Integer removalReasonCode;

	/**
	 * Attribute to hold the absence start date.
	 */
	private Date absenceEndDate;

	/**
	 * Attribute to hold the adjust Mins.
	 */
	private Integer adjdMins;

	/**
	 * Attribute to hold the open indicator.
	 */
	private boolean openInd;

	/**
	 * Attribute to hold the actual start Minutes.
	 */
	private Integer actualStartMins;

	/**
	 * Attribute to hold the actual end Minutes.
	 */
	private Integer actualEndMins;

	/**
	 * Attribute to hold the Reason Code.
	 */
	private Integer reasonCode;

	/**
	 * Attribute to hold the high equipment type code.
	 */
	private String highEqpTypeCode;

	/**
	 * Attribute to hold the position code.
	 */
	private PositionCodeType positionCode;

	/**
	 * Attribute to hold the filler S1.
	 */
	private Long fillS1;

}
