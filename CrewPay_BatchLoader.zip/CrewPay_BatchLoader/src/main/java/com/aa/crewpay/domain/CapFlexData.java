/**
 *
 */
package com.aa.crewpay.domain;

import java.util.Date;

/**
 * @author muthusba
 *
 */
public class CapFlexData {

	/**
	 * Attribute to hold the xCapClx property.
	 */
	private Integer xCapFlx;

	/**
	 * Attribute to hold the Flex Balance Minutes.
	 */
	private Integer flexBal;

	/**
	 * Attribute to hold the Flex Transfer amount.
	 */
	private Integer flexTranAmt;

	/**
	 * Attribute to hold the Flex Transfer date.
	 */
	private Date flexTranDate;

	/**
	 * Attribute to hold the CAP Balance Minutes.
	 */
	private Integer capBal;

	/**
	 * Attribute to hold the CAP Transfer amount.
	 */
	private Integer capTranAmt;

	/**
	 * Attribute to hold the CAP Transfer date.
	 */
	private Date capTranDate;

	/**
	 * Attribute to hold the CAP Borrowed amount.
	 */
	private Integer capBorrowedAmt;

	/**
	 * Attribute to hold the filler1
	 */
	private Integer fillS1;

}
