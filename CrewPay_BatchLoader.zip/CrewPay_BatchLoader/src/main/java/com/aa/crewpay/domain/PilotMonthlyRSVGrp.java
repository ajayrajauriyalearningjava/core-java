/**
 * 
 */
package com.aa.crewpay.domain;

/**
 * @author muthusba
 *
 */
public class PilotMonthlyRSVGrp {

	private boolean currentStatusInd;
	
	private Integer currentDailyCred;
}
