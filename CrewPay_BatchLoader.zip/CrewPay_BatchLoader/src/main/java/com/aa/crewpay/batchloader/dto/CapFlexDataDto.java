/**
 *
 */
package com.aa.crewpay.batchloader.dto;

/**
 * @author muthusba
 *
 */
public class CapFlexDataDto {

	/**
	 * Attribute to hold the xCapClx property.
	 */
	private Integer xCapFlx;

	/**
	 * Attribute to hold the Flex Balance Minutes.
	 */
	private Integer flexBal;

	/**
	 * Attribute to hold the Flex Transfer amount.
	 */
	private Integer flexTranAmt;

	/**
	 * Attribute to hold the Flex Transfer date.
	 */
	private Integer flexTranDate;

	/**
	 * Attribute to hold the CAP Balance Minutes.
	 */
	private Integer capBal;

	/**
	 * Attribute to hold the CAP Transfer amount.
	 */
	private Integer capTranAmt;

	/**
	 * Attribute to hold the CAP Transfer date.
	 */
	private Integer capTranDate;

	/**
	 * Attribute to hold the CAP Borrowed amount.
	 */
	private Integer capBorrowedAmt;

	/**
	 * Attribute to hold the filler1
	 */
	private Integer fillS1;

}
