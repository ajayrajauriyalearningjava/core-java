/**
 *
 */
package com.aa.crewpay.batchloader.dto;

/**
 * @author muthusba
 *
 */
public class MiscCreditExpenseDto {

	/**
	 * XMISCXP
	 */
	private Integer miscExpenseDate;

	/**
	 * 2 character equip code i.e., "AE" , "35" used when the miscellaneous
	 * credit was input
	 */
	private String equipmentCode;

	/**
	 * 3 numeric character miscellaneous credit reason code " 68" = "1-1 CPA "
	 * so a negative number (these codes are in the add reason code table in
	 * FOS) ; Misc Credits in the add reason code table can be from 1-255 but
	 * there are FOS processes that create misc credits starting from 300 which
	 * represent prem pay minutes associated with flight legs where the F/A
	 * position is defined a prem pay in the JQC* record in FOS (example in cell
	 * J15, look under column heading PP and GA) or the reason code can be zero
	 * if the 06 record is for miscellaneous expenses (FOS entry NK)
	 *
	 */
	private Integer reasonCode;

	/**
	 * "2 numeric position code used when the miscellaneous credit was input"
	 *
	 */
	private Integer cmPositionCode;

	private Integer miscCreditMins;

	/**
	 * Looks like the value is "0" if the type record is a misc credit and "1"
	 * if the type record is misc expenses ?Need to determine
	 */
	private boolean miscCreditTypeInd;

	private Integer miscNightPayMins;

	private String odlCity;

	private Integer halfDayCount;

	/**
	 * TODO - mapping Misc Credit Slot number
	 */
	private Integer miscCreditSlotNo;

	private Long fillS1;

	private Integer fillS2;

}
