package com.aa.crewpay.batchloader;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemStream;
import org.springframework.batch.item.ItemStreamException;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.batch.item.file.FlatFileItemReader;

import com.aa.crewpay.batchloader.dto.BaseDTO;
import com.aa.crewpay.batchloader.dto.CrewMemberDto;
import com.aa.crewpay.batchloader.dto.DutyPeriodDataDto;
import com.aa.crewpay.batchloader.dto.LegDataDto;
import com.aa.crewpay.batchloader.dto.SequenceDataDto;



public class CrewReader implements ItemReader<BaseDTO>, ItemStream {

	private FlatFileItemReader<BaseDTO> delegate;
	
	private CrewMemberDto crewMemberDto;
	/*private SequenceDataDto curremtSequenceDataDto;
	private DutyPeriodDataDto currentDutyPeriodDataDto;
	private LegDataDto currentLegDataDto;*/
	
	private static int readCount = 0;
	
	private static final Logger log = LoggerFactory.getLogger(CrewReader.class);
	
	@Override
	public CrewMemberDto read() throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {		

		CrewMemberDto returnCrewMemberDto = null;
		SequenceDataDto curremtSequenceDataDto = null;
		DutyPeriodDataDto currentDutyPeriodDataDto = null;
		LegDataDto currentLegDataDto = null;
		
		BaseDTO line = null;
		String prefix = null;
		
		do {
			try {

                line = this.delegate.read();
                if(line == null) {
            		returnCrewMemberDto = crewMemberDto;
            		crewMemberDto = null;
                	return returnCrewMemberDto;
                }
                prefix = line.getRecordCode();
                
                switch (prefix) {
                
	                case "01":
	                	if(crewMemberDto==null) {
	                		crewMemberDto = (CrewMemberDto)line;
	                	} else {
	                		readCount();
	                		
	                		returnCrewMemberDto = crewMemberDto;
	                		crewMemberDto = (CrewMemberDto)line;
	                		return returnCrewMemberDto;
	                	}
	                    break;
	                    
	                case "02":	                	
	                	curremtSequenceDataDto = (SequenceDataDto)line;
	                	crewMemberDto.addSequence(curremtSequenceDataDto);
	                	break;
	                	
	                case "03":	                	
	                	currentDutyPeriodDataDto = (DutyPeriodDataDto)line;	                	
	                	curremtSequenceDataDto.addDutyPeriod(currentDutyPeriodDataDto);	                	
	                	break;
	                	
	                case "04":	                	
	                	currentLegDataDto = (LegDataDto)line;	                	
	                	currentDutyPeriodDataDto.addLegData(currentLegDataDto);	                	
	                	break;
                }
			} catch (Exception e) {
				log.error("Exception in CrewMemberDtoReader->read() : " + e);
				do {
					prefix = line.getRecordCode();
				} while(prefix != "01");
			}
		} while (line != null);

		return null;
	}

	
	private void readCount() {
		readCount++;
		log.info("Read count in Reader " + readCount);
	}

	public FlatFileItemReader<BaseDTO> getDelegate() {
		return delegate;
	}

	public void setDelegate(FlatFileItemReader<BaseDTO> delegate) {
		this.delegate = delegate;
	}
	
	@Override
	public void close() throws ItemStreamException {
		this.delegate.close();
	}

	@Override
	public void open(ExecutionContext executionContext) throws ItemStreamException {
		this.delegate.open(executionContext);
	}

	@Override
	public void update(ExecutionContext executionContext) throws ItemStreamException {
		this.delegate.update(executionContext);
	}

}

