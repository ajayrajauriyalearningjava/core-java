package com.aa.crewpay.batchloader.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.aa.crewpay.domain.CrewMember;
public interface CrewMemberRepository extends JpaRepository<CrewMember, Long> {
	
	
}
