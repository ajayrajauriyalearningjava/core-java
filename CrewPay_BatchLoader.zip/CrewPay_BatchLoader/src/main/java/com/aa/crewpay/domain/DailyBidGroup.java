/**
 * 
 */
package com.aa.crewpay.domain;

import com.aa.crewpay.constant.enums.CreditPayType;
import com.aa.crewpay.constant.enums.DomIntlCodeType;
import com.aa.crewpay.constant.enums.ReserveCodeType;

/**
 * @author muthusba
 *
 */
public class DailyBidGroup {

	/**
	 * PF. Sequence number i.e., "   15545"; written to each day involved in the
	 * sequence
	 */
	private Integer seqNo;

	/**
	 * PF. Number of days in sequence i.e., "04"; value is written to each day
	 * involved in the sequence identified in field SEQ_NO.
	 */
	private Integer SeqDaysQty;

	private DutyFreeDayCode dutyFreeDayCode;

	/**
	 * 11/01/11-should be ZERO's since no data is passed from FOS
	 */
	private Integer relfPositionCode;

	/**
	 * 11/01/11-should be "1" if the cockpit Relief or Reserve bit is on in FOS
	 */
	private boolean rsvrRelfBidInd;

	/**
	 * F. FA: "1"=READY, "2"=CALL IN; FA ONLY; pulled RSV for CA and FO but all
	 * zeros
	 */
	private ReserveCodeType crsvType;

	/**
	 * 11/01/11-should be "1" if the FOS bit indicating has a sequence end and
	 * another begin on this day
	 */
	private boolean dualSeqDayInd;

	/**
	 * Credit = "1", Pay = "5", Credit & Pay = "6" so maybe the COMMERCIAL SIDE
	 * ONLY PASSES THE 1 and 6 SINCE THIS IS A CREDIT INDR
	 */
	private CreditPayType rsvrCrType;

	/**
	 * F. "1" or "0"; "1" WHEN FA=PT, "1" FOR THE HALF OF MONTH THAT IS OFF ALL
	 * DO (DAY OFF) INDICATE PT ?Need to determine
	 */
	private boolean firUnpdVacInd;

	/**
	 * "PF. ""1""; NOT A PICTURE FROM START OF MONTH PI = MOVABLE DUTY FREE -
	 * WILL HAVE ""1"" CAN'T TELL X2, M2, G2 DAYS APART FA = AVBL DAY "
	 */
	private boolean avalblDayInd;

	private DomIntlCodeType domIntlCode;

	/**
	 * PF. 3 numeric character for removal reason code (see GJR*P or *F for
	 * corresponding 2 character code); = "100" on the F/A Parttime days
	 */
	private Integer absenceCode;
	
	/**
	 * TODO - Enumeration
	 * "PF. 2 numeric character diplayed on the NA See Py
	 * Status Code worksheet tab"
	 * 
	 */
	private Integer payStateCode;
	
	private ReserveStatusGroup  rsvrStatGrp;
	
	private boolean standbyCallOutInd;
	
	/**
	 * For PI will be "5" on day that pay compensation puts in that the
	 * crewmember are in training, will not be exactly the days in training and
	 * not everyon will have been input (only entered if the pilot will receive
	 * more dollars for the minumum training pay than for the removed sequence
	 * or rsv day (daily rate)
	 */
	private boolean pilotPayrollCode;	 
}
