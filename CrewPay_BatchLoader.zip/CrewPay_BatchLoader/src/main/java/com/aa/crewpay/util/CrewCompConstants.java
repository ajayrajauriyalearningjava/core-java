package com.aa.crewpay.util;

public interface CrewCompConstants {
	
	String PROPERTIES_FILENAME = "CrewPayLoad.properties";
}