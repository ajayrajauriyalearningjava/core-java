/**
 * 
 */
package com.aa.crewpay.constant.enums;

/**
 * <code>CKAType</code> class holds the CKAType constants.
 * <p>
 *
 * @author muthusba
 */
public enum CKAType {

	/**
	 * 
	 */
	X("X"),

	/**
	 * 
	 */
	L("L"),
	
	/**
	 * 
	 */
	O("O");

	/**
	 * Attribute to hold the CKA <code>type</code>.
	 */
	private String type;

	/**
	 * <code>Parameterized constructor.</code>
	 * <p>
	 * 
	 * @param pType
	 *            the new value of the <code>type</code> property.
	 */
	CKAType(String pType) {
		type = pType;
	}

	/**
	 * Gets the <code>type</code> property.
	 * <p>
	 * 
	 * @return the current value of the <code>type</code> property.
	 */
	public String getType() {
		return this.type;
	}

	/**
	 * Gives the string format of enumerated <code>CKAType</code>.
	 * <p>
	 * 
	 * @return the current value of the <code>CKAType</code>.
	 */
	public String value() {
		return this.name();
	}
}
