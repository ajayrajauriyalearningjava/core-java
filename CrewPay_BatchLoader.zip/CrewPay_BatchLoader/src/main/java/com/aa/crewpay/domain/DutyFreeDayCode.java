package com.aa.crewpay.domain;

public class DutyFreeDayCode {

	/**
	 * Count of the DFP associated with the day. For example if the DFP is a
	 * 48 and starts on the 2nd day then the 2nd day = "1" and the 3rd day = "2"
	 * (If DFP's change after award then the change is represented)
	 */
	private Integer dayOfDFPer;

	private Integer ttlDaysInDFPer;
}
