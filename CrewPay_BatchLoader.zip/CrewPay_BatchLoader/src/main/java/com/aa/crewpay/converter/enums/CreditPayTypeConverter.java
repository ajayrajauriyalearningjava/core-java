package com.aa.crewpay.converter.enums;

import javax.persistence.AttributeConverter;

import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.aa.crewpay.constant.enums.CreditPayType;

@Component
public class CreditPayTypeConverter implements AttributeConverter<CreditPayType, Integer> {

	@Override
	public Integer convertToDatabaseColumn(CreditPayType attribute) {
		if(attribute != null)
			return attribute.getType();
		else
			return null;
	}

	@Override
	public CreditPayType convertToEntityAttribute(Integer dbData) {
		switch (dbData) {
			case 1: return CreditPayType.CREDIT;
			case 5: return CreditPayType.PAY;
			case 6: return CreditPayType.PAY_AND_CREDIT;
		}
		return null;
	}

}
