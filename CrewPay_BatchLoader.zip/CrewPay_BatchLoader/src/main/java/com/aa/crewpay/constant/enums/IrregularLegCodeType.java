/**
 *
 */
package com.aa.crewpay.constant.enums;

/**
 * @author muthusba
 *
 */
public enum IrregularLegCodeType {

	/**
	 * '0' - OK.
	 */
	OK(0),

	/**
	 * '1' - GROUND INTERUPT
	 */
	GROUND_INTERUPT(1),

	/**
	 * '2' - AIR INTERUPT
	 */
	AIR_INTERUPT(2),

	/**
	 * '3' - DIVERTED
	 */
	DIVERTED(3);

	/**
	 * Attribute to hold the IrregularLegCode <code>type</code>.
	 */
	private Integer type;

	/**
	 * <code>Parameterized constructor.</code>
	 * <p>
	 *
	 * @param pType
	 *            the new value of the <code>type</code> property.
	 */
	IrregularLegCodeType(Integer pType) {
		type = pType;
	}

	/**
	 * Gets the <code>type</code> property.
	 * <p>
	 *
	 * @return the current value of the <code>type</code> property.
	 */
	public int getType() {
		return this.type;
	}

	/**
	 * Gives the string format of enumerated <code>IrregularLegCodeType</code>.
	 * <p>
	 *
	 * @return the current value of the <code>IrregularLegCodeType</code>.
	 */
	public String value() {
		return this.name();
	}
}
