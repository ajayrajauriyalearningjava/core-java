package com.aa.crewpay.batchloader;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.aa.crewpay.batchloader.repo.CrewMemberRepository;
import com.aa.crewpay.domain.CrewMember;

@Component("CrewWriter")
public class CrewWriter implements ItemWriter<CrewMember> {

	@Autowired
	private CrewMemberRepository crewMemberRepository;

	private static final Logger log = LoggerFactory.getLogger(CrewWriter.class);
	
	@Override
	public void write(List<? extends CrewMember> items) throws Exception {
		
		log.info("***********************	PersonWriter->write()	**********************");
		
		for (CrewMember crewMember : items) {
			log.info("Saving Person : " + ((CrewMember)crewMember).toString());
			crewMemberRepository.save( (CrewMember)crewMember );
		}		
		log.info("***********************							**********************");
	}
}
