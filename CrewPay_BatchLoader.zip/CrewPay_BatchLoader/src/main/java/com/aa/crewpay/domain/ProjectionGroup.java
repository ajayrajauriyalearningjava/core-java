/**
 *
 */
package com.aa.crewpay.domain;

import com.aa.crewpay.constant.enums.DomIntlCodeType;

/**
 * @author muthusba
 *
 */
public class ProjectionGroup {

	/**
	 * Attribute to hold the crew member contract date. ex:YYYYMM
	 *
	 */
	private Integer contractDate;

	private DomIntlCodeType domIntlCode;

	private PilotGroup captainGrp;

	private PilotGroup firstOfficerGrp;

	private Integer faMaxScheduleHrsQty;

	private boolean faFlexMOInd;
}
