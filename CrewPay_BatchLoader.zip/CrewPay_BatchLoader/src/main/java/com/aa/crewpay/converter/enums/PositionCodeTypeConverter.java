package com.aa.crewpay.converter.enums;

import javax.persistence.AttributeConverter;

import org.springframework.stereotype.Component;

import com.aa.crewpay.constant.enums.PositionCodeType;

@Component
public class PositionCodeTypeConverter implements AttributeConverter<PositionCodeType, Integer> {

	@Override
	public Integer convertToDatabaseColumn(PositionCodeType attribute) {
		if(attribute != null)
			return attribute.getType();
		else
			return null;
	}

	@Override
	public PositionCodeType convertToEntityAttribute(Integer dbData) {
		switch (dbData) {
			case 1: return PositionCodeType.CA;
			case 2: return PositionCodeType.FO;
			case 3: return PositionCodeType.FE;
			case 4: return PositionCodeType.IO;
			case 5: return PositionCodeType.RE;
			case 6: return PositionCodeType.FB;
			case 7: return PositionCodeType.FC;
			case 8: return PositionCodeType.RC;
			case 9: return PositionCodeType.XA;
			case 10: return PositionCodeType.XO;
			case 11: return PositionCodeType.XE;
			case 22: return PositionCodeType.FA1;
			case 23: return PositionCodeType.FA2;
			case 24: return PositionCodeType.FA3;
			case 25: return PositionCodeType.FA4;
			case 26: return PositionCodeType.FA5;
			case 27: return PositionCodeType.FA6;
			case 28: return PositionCodeType.FA7;
			case 29: return PositionCodeType.FA8;
			case 30: return PositionCodeType.FA9;
			case 31: return PositionCodeType.FA10;
			case 32: return PositionCodeType.FA11;
			case 33: return PositionCodeType.FA12;
			case 34: return PositionCodeType.FA13;
			case 35: return PositionCodeType.FA14;
			case 36: return PositionCodeType.FA15;
			case 37: return PositionCodeType.FA16;
			case 38: return PositionCodeType.VM;
			case 39: return PositionCodeType.VM1;
			case 40: return PositionCodeType.VM2;
			case 58: return PositionCodeType.VM3;
			case 59: return PositionCodeType.FA99;
			case 60: return PositionCodeType.FA95;
			case 61: return PositionCodeType.FA96;
			case 62: return PositionCodeType.FA97;
			case 63: return PositionCodeType.FA98;
		}
		return null;
	}

}
