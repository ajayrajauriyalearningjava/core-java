/**
 * 
 */
package com.aa.crewpay.domain;

import java.util.Date;

import com.aa.crewpay.constant.enums.DomIntlCodeType;
import com.aa.crewpay.constant.enums.PositionCodeType;

/**
 * @author muthusba
 *
 */
public class BidStatusGroup {

	/**
	 * 2 numeric character that corresponds to a specific 3 character crew base
	 * i.e., "04" = "DFW"
	 */
	private Integer seqCrewBase;

	/**
	 * 2 numeric character position code, i.e. "01" = CA
	 */
	private PositionCodeType positionCode;

	/**
	 * 2 character equipment code, i.e., "35" = S80
	 */
	private Integer equipmentCode;

	/**
	 * "D" or "I"
	 */
	private DomIntlCodeType domIntlCode;

	/**
	 * effective Date - YYYYMMDD
	 */
	private Date effDate;

	/**
	 * Number of months crewmwmber is locked in to the current 4/2 part bid
	 * status?Need to determine
	 */
	private Integer lockedInMonQty;

}
