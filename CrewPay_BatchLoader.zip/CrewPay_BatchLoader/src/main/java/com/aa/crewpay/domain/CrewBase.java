/**
 *
 */
package com.aa.crewpay.domain;

/**
 * @author muthusba
 *
 */
public class CrewBase {

	private Integer seqCrewBaseNo;

	private String crewBaseCode;

	private ProjectionGroup pltPrjnGrp;

	private Long filler1;
}
