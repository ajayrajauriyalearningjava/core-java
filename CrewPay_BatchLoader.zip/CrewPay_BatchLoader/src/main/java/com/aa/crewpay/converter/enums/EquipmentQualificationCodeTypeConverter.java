package com.aa.crewpay.converter.enums;

import javax.persistence.AttributeConverter;

import org.springframework.stereotype.Component;

import com.aa.crewpay.constant.enums.EquipmentQualificationCodeType;

@Component
public class EquipmentQualificationCodeTypeConverter implements AttributeConverter<EquipmentQualificationCodeType, String> {

	@Override
	public String convertToDatabaseColumn(EquipmentQualificationCodeType attribute) {
		if(attribute != null)
			return attribute.getType();
		else
			return null;
	}

	@Override
	public EquipmentQualificationCodeType convertToEntityAttribute(String dbData) {
		switch (dbData) {
			case "P": return EquipmentQualificationCodeType.PRIOR;
			case "*": return EquipmentQualificationCodeType.CURRENT;
			case "M": return EquipmentQualificationCodeType.PRIOR_MANUAL_DEL;
			case "L": return EquipmentQualificationCodeType.CURRENT_AND_NEED_LINECHECK;
			case "R": return EquipmentQualificationCodeType.CURRENT_RESTRICTED;
		}
		return null;
	}

}
