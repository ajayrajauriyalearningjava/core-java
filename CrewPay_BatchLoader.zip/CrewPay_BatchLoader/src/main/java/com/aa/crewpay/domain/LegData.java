/**
 *
 */
package com.aa.crewpay.domain;

import com.aa.crewpay.constant.enums.IrregularLegCodeType;
import com.aa.crewpay.constant.enums.PositionCodeType;

/**
 * @author muthusba
 *
 */
public class LegData {

	private Integer xcmfLeg;

	/**
	 * Scheduled Date & Time note: no scheduleEndDate
	 */
	private DateTimeRange scheduledDT;

	/**
	 * ReScheduled Date & Time note: no rescheduleEndDate
	 */
	private DateTimeRange reScheduledDT;

	/**
	 * Actual Date & Time note: no actualEndDate
	 */
	private DateTimeRange actualDT;

	/*	*//**
			 * SEQ SCHEDULED START DATE: YYYYMMDD
			 */
	/*
	 * private Date scheduleStartDate;
	 *
	 *//**
		 * RESCHEDULED START DATE OF SEQUENCE: YYYYMMDD This is driven by a
		 * manual sign in time that has been entered into the crewmember's
		 * sequence on the 1st duty period. If it exists, this field gets
		 * populated.
		 *
		 */
	/*
	 * private Date rescheduledStartDate;
	 *
	 *//**
		 * ACTUAL START DATE OF SEQUENCE: YYYYMMDD
		 */
	/*
	 * private Date actualStartDate;
	 *
	 *//**
		 * SCHEDULED START MINS OF SEQUENCE. THIS IS THE SCHEDULED GMT ON WHICH
		 * AN ACTIVITY OR EVENT IS SCHEDULED TO START : MMMM. Note: The
		 * difference between this SCHD_STR_MNS in record 02 versus that in
		 * record 04 is the 1hrs sign-in difference.
		 *
		 */
	/*
	 * private Integer scheduledStartMins;
	 *
	 *//**
		 * RESCHEDULED START MINS OF SEQUENCE. Note: if there is a RESCHEDULED
		 * START DATE then there is a RESCHEDULED START MINS populated. THIS IS
		 * THE RSCHD GMT ON WHICH AN ACTIVITY OR EVENT IS RESCHEDULED TO START :
		 * MMMM
		 */
	/*
	 * private Integer reScheduledStartMins;
	 *
	 *//**
		 * ACTUAL START MINS OF SEQUENCE. THIS IS THE ACTUAL GMT ON WHICH AN
		 * ACTIVITY OR EVENT ACTUALLY STARTED : MMMM THERE ARE VALUES IN ACTUAL
		 * DATE AND MINS FOR REMOVED SEQUENCE, JUST EQUALS SCHEDULED. It fills
		 * in the actual anyway, even though the sequence has been removed off
		 * of the crewmember's schedule, so they use the SCHD value to fill in
		 * the ACTL value.
		 */
	/*
	 * private Integer actualStartMins;
	 *
	 *//**
		 * THIS IS RELATIVE TO THE SCHEDULED START MINS ABOVE
		 */
	/*
	 * private Integer scheduledEndMins;
	 *
	 *//**
		 * THIS IS RELATIVE TO THE RESCHEDULED START MINS ABOVE
		 */
	/*
	 * private Integer reScheduledEndMins;
	 *
	 *//**
		 * THIS IS RELATIVE TO THE ACTUAL START MINS ABOVE
		 *//*
		 * private Integer actualEndMins;
		 */

	/**
	 * this field uses a 5 digit value i.e. flight 963 DFW GRU is stored as
	 * "00963"
	 *
	 */
	private Integer flightNo;

	/**
	 * City Code (DFW) this field can be 5 spaces
	 */
	private String departureStation;

	/**
	 * GMT is captured for actual departure, so if scheduled to depart before
	 * daylight savings time change, and actually departs after then if do std
	 * (standard?) logic to determine local scheduled departure will be 1 hour
	 * off. The GMT adjustment for DFW on 4/23 was 300 minutes.
	 *
	 */
	private Integer startGMTAdjmtMins;

	private boolean duplicateDepartureStationInd;

	private String arrivalStation;

	/**
	 * This is the GMT adjustment for the arrival station. For 4/23 in GRU the
	 * adjustment was 180 minutes.
	 *
	 */
	private Integer endGMTAdjmtMins;

	private boolean duplicateArrivalStationInd;

	private String scheduleEqpCode;

	/**
	 * "= 0 UNTIL FLOWN OR =0 IF D/H "AE" WAS DISPLAYED SINCE THE FLIGHT HAD
	 * FLOWN"
	 *
	 */
	private String actualEqpCode;

	/**
	 * ADD TO FRONT OF DEPT FOR NITEPAY, LANG PAY, & ACTBLK TO MATCH NA, SEQ ACT
	 * BLK
	 *
	 */
	private Integer atcGateDlaMins;

	private boolean cancelledLegInd;

	private boolean flightLegStubInd;

	/**
	 * 0 = OK, 1 = GROUND INTERUPT, 2 = AIR INTERUPT, 3 = DIVERTED
	 */
	private IrregularLegCodeType irregLegCode;

	private String languageRqmtCode1;

	private String languageRqmtCode2;

	private String languageRqmtCode3;

	private boolean carryOverInd;

	/**
	 * "IF 'RPT' THEN NEED TO DELETE THE SCHED MINS FROM SEQ_DH_MINS 'FTG'
	 * INDICATES PILOT WENT FATIGUED MID SEQ. SET TO (000)"
	 *
	 * TODO enumeration
	 */
	private String deadheadLegCode;

	private boolean removedCrdActivityInd;

	private boolean originalSchduleInd;

	private Integer firstLegCode;

	private Integer lastLegCode;

	private boolean aplblLegInd;

	private PositionCodeType positionCode;

	private Integer assignmentReasonCode;

	private Integer removalReasonCode;

	private Integer dutyPeriodNo;

	/**
	 * Failed Continuity Indicator
	 */
	private boolean failedContinuityInd;

	private boolean supervisorOpenFlightInd;

	private boolean supervisorCMDisplacementInd;

	private Integer deiGateDlaMins;

	private boolean hostelCancelInd;

	private boolean mixTripInd;

	private Integer midMonthBlkTimeAdj;

	private Integer rcdGateDlaMins;

	// @Convert(converter=BooleanToYNConverter.class)
	private boolean ckaLegInd;

	private String tailNumber;

	private Integer divGateDlaMins;

	/**
	 * TODO - enumeration
	 */
	private String mealCode;

	private Integer fillS1;

	private Long fillS2;

}
