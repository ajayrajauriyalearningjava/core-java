/**
 *
 */
package com.aa.crewpay.domain;

import java.util.List;

/**
 * @author muthusba
 *
 */
public class DutyPeriodData {

	/**
	 * SEQUENTIAL NUMBER
	 */
	private Integer sequentialNo;

	/**
	 * DUTY PERIOD NUMBER.
	 *
	 */
	private Integer dutyPeriodNo;

	private boolean noapplicableLegInd;

	private boolean shrtDutyPeriodInd;

	/**
	 * Scheduled Date & Time
	 */
	private DateTimeRange scheduledDT;

	/**
	 * ReScheduled Date & Time
	 */
	private DateTimeRange reScheduledDT;

	/**
	 * Actual Date & Time
	 */
	private DateTimeRange actualDT;

	/*	*//**
			 * SEQ SCHEDULED START DATE: YYYYMMDD
			 */
	/*
	 * private Date scheduleStartDate;
	 *
	 *//**
		 * RESCHEDULED START DATE OF SEQUENCE: YYYYMMDD This is driven by a
		 * manual sign in time that has been entered into the crewmember's
		 * sequence on the 1st duty period. If it exists, this field gets
		 * populated.
		 *
		 */
	/*
	 * private Date rescheduledStartDate;
	 *
	 *//**
		 * ACTUAL START DATE OF SEQUENCE: YYYYMMDD
		 */
	/*
	 * private Date actualStartDate;
	 *
	 *//**
		 * SCHEDULED START MINS OF SEQUENCE. THIS IS THE SCHEDULED GMT ON WHICH
		 * AN ACTIVITY OR EVENT IS SCHEDULED TO START : MMMM. Note: The
		 * difference between this SCHD_STR_MNS in record 02 versus that in
		 * record 04 is the 1hrs sign-in difference.
		 *
		 */
	/*
	 * private Integer scheduledStartMins;
	 *
	 *//**
		 * RESCHEDULED START MINS OF SEQUENCE. Note: if there is a RESCHEDULED
		 * START DATE then there is a RESCHEDULED START MINS populated. THIS IS
		 * THE RSCHD GMT ON WHICH AN ACTIVITY OR EVENT IS RESCHEDULED TO START :
		 * MMMM
		 */
	/*
	 * private Integer reScheduledStartMins;
	 *
	 *//**
		 * ACTUAL START MINS OF SEQUENCE. THIS IS THE ACTUAL GMT ON WHICH AN
		 * ACTIVITY OR EVENT ACTUALLY STARTED : MMMM THERE ARE VALUES IN ACTUAL
		 * DATE AND MINS FOR REMOVED SEQUENCE, JUST EQUALS SCHEDULED. It fills
		 * in the actual anyway, even though the sequence has been removed off
		 * of the crewmember's schedule, so they use the SCHD value to fill in
		 * the ACTL value.
		 */
	/*
	 * private Integer actualStartMins;
	 *
	 *//**
		 * SCHEDULED END DATE OF SEQUENCE: YYYYMMDD
		 */
	/*
	 * private Date scheduledEndDate;
	 *
	 *//**
		 * RESCHEDULED END DATE OF SEQUENCE: YYYYMMDD
		 */
	/*
	 * private Date reScheduledEndDate;
	 *
	 *//**
		 * ACTUAL END DATE OF SEQUENCE: YYYYMMDD
		 */
	/*
	 * private Date actualEndDate;
	 *
	 *//**
		 * THIS IS RELATIVE TO THE SCHEDULED START MINS ABOVE
		 */
	/*
	 * private Integer scheduledEndMins;
	 *
	 *//**
		 * THIS IS RELATIVE TO THE RESCHEDULED START MINS ABOVE
		 */
	/*
	 * private Integer reScheduledEndMins;
	 *
	 *//**
		 * THIS IS RELATIVE TO THE ACTUAL START MINS ABOVE
		 *//*
		 * private Integer actualEndMins;
		 */

	/**
	 * THIS IS THE GMT TIME IN MINUTES FOR THE SCHEDULED START MINS 300 five
	 * hour adjustment for ORD time
	 */
	private Integer startGMTAdjmtMins;

	/**
	 * THIS IS THE GMT TIME IN MINUTES FOR THE SCHEDULED END MINS 240 four hour
	 * adjustment for TPA time
	 */
	private Integer endGMTAdjmtMins;

	/**
	 * GREATER OF ALL THE SCHEDULED AND ACTUAL LEGS 155 this number is divided
	 * by 60 to equal 2.35 flight hours
	 */
	private Integer legGreaterMins;

	/**
	 * -. FLY TIME THIS IS THE SCHEDULED VALUE OF ALL THE LEGS 155 this number
	 * is divided by 60 to equal 2.35 flight hours
	 */
	private Integer scheduledGateToGateMins;

	/**
	 * _� <-INCLUDES RCD, DEI, ATC. THIS IS THE TOTAL ACTUAL FLYING OF ALL THE
	 * LEGS. IT'S INCLUDED DUE TO PAY PURPOSES.
	 *
	 * 155 this number is divided by 60 to equal 2.35 flight hours
	 */
	private Integer actualGateToGateMins;

	/**
	 * -. E TIME SCHEDULED
	 */
	private Integer scheduledDutyPerCRMins;

	/**
	 * _� ACTUAL E TIME
	 */
	private Integer actualDutyPerCRMins;

	/**
	 * Minutes; total duty period deadhead minutes; deadhead minutes are always
	 * scheduled not actual
	 *
	 */
	private Integer deadHeadMins;

	/**
	 * Minutes; scheduled duty period off duty layover minutes
	 *
	 */
	private Integer schdOffDutyLayoverMins;

	/**
	 * Minutes; actual duty period off duty layover minutes
	 *
	 */
	private Integer actualOffDutyLayoverMins;

	/**
	 * Off duty time related to the specific duty period. "0" = Starts this
	 * month but does not carry over into next month; "1" = Starts this month
	 * and carries over into next month
	 *
	 */
	private boolean carryoverInd;

	/**
	 * "Off duty time related to the specific duty period ""0"" = Does not
	 * involves next month; ""1"" = involves next month"
	 *
	 */
	private boolean DPNextMonthInd;

	private Integer shrtDPFlyMins;

	private Integer shrtDPCRMins;

	private boolean intlDPPayInd;

	/**
	 * "DFW  "; Off duty layover city1
	 */
	private String offdutyLayoverCity1;

	/**
	 * "04"; Off duty layover half day counts associated with he layover city1
	 */
	private Integer offdutyLayoverHalfDayCount1;

	/**
	 * "DFW  "; Off duty layover city2
	 */
	private String offdutyLayoverCity2;

	/**
	 * "04"; Off duty layover half day counts associated with he layover city2
	 */
	private Integer offdutyLayoverHalfDayCount2;

	private Integer DPSigininYear;

	private Integer DPSigininMonth;

	private Integer DPSigininDay;

	private Integer DPSigininTime;

	private Integer fillS1;

	private Long fillS2;

	private Integer fillS3;

	private List<LegData> legs;
}
