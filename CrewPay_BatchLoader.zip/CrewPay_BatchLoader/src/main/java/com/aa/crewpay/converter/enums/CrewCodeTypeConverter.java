package com.aa.crewpay.converter.enums;

import javax.persistence.AttributeConverter;

import org.springframework.stereotype.Component;

import com.aa.crewpay.constant.enums.CrewCodeType;

@Component
public class CrewCodeTypeConverter implements AttributeConverter<CrewCodeType, Integer> {

	@Override
	public Integer convertToDatabaseColumn(CrewCodeType attribute) {
		if(attribute != null)
			return attribute.getType();
		else
			return null;
	}

	@Override
	public CrewCodeType convertToEntityAttribute(Integer dbData) {
		switch (dbData) {
			case 0: return CrewCodeType.PILOTS;
			case 4: return CrewCodeType.FLIGHTENGINEER;
			case 6: return CrewCodeType.FLIGHTATTENDANT;
			case 8: return CrewCodeType.FLIGHTATTENDANTADMIN;
		}
		return null;
	}

}
