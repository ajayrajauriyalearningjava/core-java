/**
 *
 */
package com.aa.crewpay.domain;

import java.util.Date;

/**
 * @author muthusba
 *
 */
public class ContractualMonth {

	/**
	 * Attribute to hold the contractual Month YYYYYMM.
	 */
	private Integer contractMonth;

	/**
	 * Attribute to hold the airlineCode.
	 */
	private String airlineCode;

	/**
	 * Attribute to hold the current contractual period indicator.
	 */
	private boolean currentContractPeriodInd;

	/**
	 * Attribute to hold the contract start date1.
	 */
	private Date contractStartDate1;

	/**
	 * Attribute to hold the contract end date1.
	 */
	private Date contractEndDate1;

	/**
	 * Attribute to hold the number of contract days1.
	 */
	private Integer numberOfContractDay1;

	/**
	 * Attribute to hold the crew member root fill1.
	 */
	private String cmRootFill1;

	/**
	 * Attribute to hold the contract start date2.
	 */
	private Date contractStartDate2;

	/**
	 * Attribute to hold the contract end date2.
	 */
	private Date contractEndDate2;

	/**
	 * Attribute to hold the number of contract days2.
	 */
	private Integer numberOfContractDay2;

	/**
	 * Attribute to hold the crew member root fill2.
	 */
	private String cmRootFill2;

	/**
	 * Attribute to hold the FMCM DP01 fill.
	 */
	private String fmcmDP01Fill;
}
