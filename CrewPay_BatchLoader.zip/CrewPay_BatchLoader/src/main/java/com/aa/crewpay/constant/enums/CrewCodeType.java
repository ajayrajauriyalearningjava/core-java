/**
 * 
 */
package com.aa.crewpay.constant.enums;

/**
 * @author muthusba
 *
 */
public enum CrewCodeType {

	/**
	 * '0' - PILOTS.
	 */
	PILOTS(0),

	/**
	 * '4' - FLIGHT ENGINEER
	 */
	FLIGHTENGINEER(4),
	
	/**
	 * '6' - FLIGHT ATTENDANT 
	 */
	FLIGHTATTENDANT(6),
	
	/**
	 * '6' - FLIGHT ATTENDANT ADMIN 
	 */
	FLIGHTATTENDANTADMIN(8);

	/**
	 * Attribute to hold the Domestic/International <code>type</code>.
	 */
	private Integer type;

	/**
	 * <code>Parameterized constructor.</code>
	 * <p>
	 * 
	 * @param pType
	 *            the new value of the <code>type</code> property.
	 */
	CrewCodeType(Integer pType) {
		type = pType;
	}

	/**
	 * Gets the <code>type</code> property.
	 * <p>
	 * 
	 * @return the current value of the <code>type</code> property.
	 */
	public int getType() {
		return this.type;
	}

	/**
	 * Gives the string format of enumerated <code>CrewCodeType</code>.
	 * <p>
	 * 
	 * @return the current value of the <code>CrewCodeType</code>.
	 */
	public String value() {
		return this.name();
	}
}
