/**
 * 
 */
package com.aa.crewpay.domain;

import java.util.Date;

import com.aa.crewpay.constant.enums.CrewCodeType;
import com.aa.crewpay.constant.enums.DomIntlCodeType;

/**
 * @author muthusba
 *
 */
public class EmployeeDetail {

	/**
	 * Attribute to hold the crew member contract date. ex:YYYYMM
	 * 
	 */
	private Integer contractDate;
	
	/**
	 * Attribute to hold the crew member contract load date. ex:YYYYMMDD
	 * 
	 */
	private Date loadDate;

	/**
	 * Attribute to hold the airline code. Ex: AA
	 */
	private String airlineCode;
	
	/**
	 * Attribute to hold the Domestic International code.
	 */
	private DomIntlCodeType domIntlCode;

	/**
	 * Attribute to hold the Crew Type code.
	 */
	private CrewCodeType crewTypeCode;
	
	/**
	 * Attribute to hold the employee Number 
	 */
	private Integer employeeNumber;

	/**
	 * @return the contractDate
	 */
	public Integer getContractDate() {
		return contractDate;
	}

	/**
	 * @param contractDate the contractDate to set
	 */
	public void setContractDate(Integer contractDate) {
		this.contractDate = contractDate;
	}

	/**
	 * @return the loadDate
	 */
	public Date getLoadDate() {
		return loadDate;
	}

	/**
	 * @param loadDate the loadDate to set
	 */
	public void setLoadDate(Date loadDate) {
		this.loadDate = loadDate;
	}

	/**
	 * @return the airlineCode
	 */
	public String getAirlineCode() {
		return airlineCode;
	}

	/**
	 * @param airlineCode the airlineCode to set
	 */
	public void setAirlineCode(String airlineCode) {
		this.airlineCode = airlineCode;
	}

	/**
	 * @return the domIntlCode
	 */
	public DomIntlCodeType getDomIntlCode() {
		return domIntlCode;
	}

	/**
	 * @param domIntlCode the domIntlCode to set
	 */
	public void setDomIntlCode(DomIntlCodeType domIntlCode) {
		this.domIntlCode = domIntlCode;
	}

	/**
	 * @return the crewTypeCode
	 */
	public CrewCodeType getCrewTypeCode() {
		return crewTypeCode;
	}

	/**
	 * @param crewTypeCode the crewTypeCode to set
	 */
	public void setCrewTypeCode(CrewCodeType crewTypeCode) {
		this.crewTypeCode = crewTypeCode;
	}

	/**
	 * @return the employeeNumber
	 */
	public Integer getEmployeeNumber() {
		return employeeNumber;
	}

	/**
	 * @param employeeNumber the employeeNumber to set
	 */
	public void setEmployeeNumber(Integer employeeNumber) {
		this.employeeNumber = employeeNumber;
	}
	
}
