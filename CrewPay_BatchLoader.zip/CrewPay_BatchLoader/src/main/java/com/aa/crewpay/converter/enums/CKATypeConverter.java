package com.aa.crewpay.converter.enums;

import javax.persistence.AttributeConverter;

import org.springframework.stereotype.Component;

import com.aa.crewpay.constant.enums.CKAType;

@Component
public class CKATypeConverter implements AttributeConverter<CKAType, String> {

	@Override
	public String convertToDatabaseColumn(CKAType attribute) {
		if(attribute != null)
			return attribute.getType();
		else
			return null;
	}

	@Override
	public CKAType convertToEntityAttribute(String dbData) {
		switch (dbData) {
			case "X": return CKAType.X;
			case "L": return CKAType.L;
			case "O": return CKAType.O;
		}
		return null;
	}

}
