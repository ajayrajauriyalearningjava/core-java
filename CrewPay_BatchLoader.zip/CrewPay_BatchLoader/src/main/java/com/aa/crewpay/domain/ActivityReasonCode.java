/**
 *
 */
package com.aa.crewpay.domain;

/**
 * @author muthusba
 *
 */
public class ActivityReasonCode {

	private Integer contractMonth;

	private String airlineCode;

	private Integer activityCode;

	private Integer activityReasonNo;

	private String activityReasonCode;

	private String groupCode;

	private boolean removalPayInd;

	private boolean removalCreditInd;

	private Integer payCode;

	private String descriptionCode;

	private Integer procInd;

	private Integer removalInd;

	private Integer aseqInd;

	private Integer asegInd;

	private Integer evalInd;

	private Integer pabsInd;

	private Integer seqrInd;

	private Integer paystPI;

	private Integer crsnCode;

	private Integer famsRemoval;

	private Integer paystFA;

	private Integer sklvInd;

	private String filler;

}
