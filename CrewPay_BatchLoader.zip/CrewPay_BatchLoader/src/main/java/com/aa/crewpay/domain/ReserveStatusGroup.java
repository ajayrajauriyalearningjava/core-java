/**
 * 
 */
package com.aa.crewpay.domain;

import com.aa.crewpay.constant.enums.PositionCodeType;

/**
 * @author muthusba
 *
 */
public class ReserveStatusGroup {

	/**
	 * 2 character equipment code, i.e., ""35"" = S80; the equipment reserve
	 * list the employee will show up on
	 */
	private String equipmentCode;
	
	/**
	 * 2 numeric character position code, i.e. "01" = CA
	 */
	private PositionCodeType positionCode;
	
}
