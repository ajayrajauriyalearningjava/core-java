/**
 * 
 */
package com.aa.crewpay.constant.enums;

/**
 * SelectionReasonCodeType associated with the crewmembers monthly bid award
 * status.
 * 
 * @author muthusba
 */
public enum SelectionReasonCodeType {

	/**
	 * 'N' - ACTIVE.
	 */
	ACTIVE("N"),

	/**
	 * 'I' - INACTIVE
	 */
	INACTIVE("I"),

	/**
	 * 'S' - SUPERVISOR
	 * 
	 */
	SUPERVISOR("S");

	/**
	 * Attribute to hold the Selection Reason Code <code>type</code>.
	 */
	private String type;

	/**
	 * <code>Parameterized constructor.</code>
	 * <p>
	 * 
	 * @param pType
	 *            the new value of the <code>type</code> property.
	 */
	SelectionReasonCodeType(String pType) {
		type = pType;
	}

	/**
	 * Gets the <code>type</code> property.
	 * <p>
	 * 
	 * @return the current value of the <code>type</code> property.
	 */
	public String getType() {
		return this.type;
	}

	/**
	 * Gives the string format of enumerated
	 * <code>SelectionReasonCodeType</code>.
	 * <p>
	 * 
	 * @return the current value of the
	 *         <code>SelectionReasonCodeType</code>.
	 */
	public String value() {
		return this.name();
	}

}
