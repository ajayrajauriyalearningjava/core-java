/**
 *
 */
package com.aa.crewpay.batchloader.dto;

import java.util.ArrayList;
import java.util.List;

/**
 * @author muthusba
 *
 */
public class SequenceDataDto extends BaseDTO {

	/**
	 * SEQ SCHEDULED START DATE: YYYYMMDD
	 */

	private Integer scheduleStartDate;

	private Integer seqNo;

	/**
	 * SEQUENCE REASSIGNMENT NUMBER GROUPING OF SEQUENCES ORIGINALLY SCHEDULE
	 * AND REASSIGNED. HAS VALUE ONLY ON THIS MONTH SEQ, NOT CARRYOVER - If it's
	 * a carryover from APR into MAY, the sequence in the APR FCRM will have a
	 * value but the MAY FCRM will not.
	 */
	private Integer reassignmentNo;

	/**
	 * SEQ REMOVAL CODE
	 */
	private Integer removalReasonCode;

	/**
	 * SEQUENCE LEVEL NUMBER FOR REMOVED SEQUENCE - This is the Trip Trade Level
	 * number which appears on both added and removed sequences to show that
	 * they are "married" to each other.
	 */
	private Integer levelNumberRemoved;

	/**
	 * RESCHEDULED START DATE OF SEQUENCE: YYYYMMDD This is driven by a manual
	 * sign in time that has been entered into the crewmember's sequence on the
	 * 1st duty period. If it exists, this field gets populated.
	 *
	 */

	private Integer rescheduledStartDate;

	/**
	 * ACTUAL START DATE OF SEQUENCE: YYYYMMDD
	 */

	private Integer actualStartDate;

	/**
	 * SCHEDULED START MINS OF SEQUENCE. THIS IS THE SCHEDULED GMT ON WHICH AN
	 * ACTIVITY OR EVENT IS SCHEDULED TO START : MMMM. Note: The difference
	 * between this SCHD_STR_MNS in record 02 versus that in record 04 is the
	 * 1hrs sign-in difference.
	 *
	 */

	private Integer scheduledStartMins;

	/**
	 * RESCHEDULED START MINS OF SEQUENCE. Note: if there is a RESCHEDULED START
	 * DATE then there is a RESCHEDULED START MINS populated. THIS IS THE RSCHD
	 * GMT ON WHICH AN ACTIVITY OR EVENT IS RESCHEDULED TO START : MMMM
	 */

	private Integer reScheduledStartMins;

	/**
	 * ACTUAL START MINS OF SEQUENCE. THIS IS THE ACTUAL GMT ON WHICH AN
	 * ACTIVITY OR EVENT ACTUALLY STARTED : MMMM THERE ARE VALUES IN ACTUAL DATE
	 * AND MINS FOR REMOVED SEQUENCE, JUST EQUALS SCHEDULED. It fills in the
	 * actual anyway, even though the sequence has been removed off of the
	 * crewmember's schedule, so they use the SCHD value to fill in the ACTL
	 * value.
	 */

	private Integer actualStartMins;

	/**
	 * SCHEDULED END DATE OF SEQUENCE: YYYYMMDD
	 */

	private Integer scheduledEndDate;

	/**
	 * RESCHEDULED END DATE OF SEQUENCE: YYYYMMDD
	 */

	private Integer reScheduledEndDate;

	/**
	 * ACTUAL END DATE OF SEQUENCE: YYYYMMDD
	 */

	private Integer actualEndDate;

	/**
	 * THIS IS RELATIVE TO THE SCHEDULED START MINS ABOVE
	 */

	private Integer scheduledEndMins;

	/**
	 * THIS IS RELATIVE TO THE RESCHEDULED START MINS ABOVE
	 */

	private Integer reScheduledEndMins;

	/**
	 * THIS IS RELATIVE TO THE ACTUAL START MINS ABOVE
	 */
	private Integer actualEndMins;

	/**
	 * THIS IS THE GMT TIME IN MINUTES FOR THE SCHEDULED START MINS
	 */
	private Integer startGMTAdjmtMins;

	/**
	 * THIS IS THE GMT TIME IN MINUTES FOR THE SCHEDULED END MINS
	 */
	private Integer endGMTAdjmtMins;

	/**
	 * APPEARS TO BE BID SHEET DAYS. NUMBER OF DAYS REQUIRED TO COMPLETE THIS
	 * SET OF FLIGHT LEGS.
	 */
	private Integer segOprgDaysQty;

	private Integer seqCrewBase;

	/**
	 * HIGH EQUIPMENT TYPE CODE - 2 DIGIT CODE Ex: 'AF'
	 */
	private String highEqpTypeCode;

	/**
	 * DOMESTIC OR INTERNATIONAL CODE: "D" OR "I"
	 */
	private String domIntlCode;

	/**
	 * Will have 1 on Seq part of denied bid line (SEQ RMV = 146, 147) SPECIFIES
	 * WHETHER OR NOT A SEQUENCE HAS ANY LEGS WHICH HAVE NOT BEEN CANCELLED. 0 =
	 * NO 1= YES.
	 *
	 */
	private boolean noAplbeLegInd;

	/**
	 * MISSING DATA INDICATOR This specifies whether or not a sequence is
	 * missing one or more of the leg times. 0=No Data Missing 1=Data missing
	 *
	 */
	private boolean missingDataInd;

	/**
	 * FAILED CONTINUITY INDICATOR
	 */
	private boolean failedContinuityInd;

	private Integer segStateCode;

	private boolean changeOverInd;

	private boolean carryOverInd;

	/**
	 * WE THINK THIS TURNS ON WHEN IT'S A VM POS, BUT WE HAVE A SEQUENCE
	 * POSITION LATER AND WE JUST USE THAT TO FIND OUT WHAT POSITION IT IS.
	 *
	 */
	private boolean varMangInd;

	/**
	 * SPECIFIES WHETHER THE CORRESPONDING ITEM IS TAXABLE. 1=ITEM IS TAXABLE 2=
	 * ITEM IS NOT TAXABLE
	 *
	 * TODO -- enumeration ??
	 */
	private String taxInd;

	/**
	 * NUMBER OF DUTY PERIODS IN SEQUENCE, INCLUDING ANY REMOVED OR CANCELLED
	 * DUTY PERIODS. (Implies that it comes from the allocation and doesn't get
	 * updated)
	 */
	private Integer dutyPeriodQty;

	/**
	 * NUMBER OF LEGS IN SEQUENCE, INCLUDING ANY DEADHEAD, REMOVED OR CANCELLED
	 * LEGS. (Implies that it comes from the allocation and doesn't get updated)
	 */
	private Integer SegLegQty;

	/**
	 * REPLACED CHANGEOVER SEQUENCE NUMBER - identifies the sequence number that
	 * was replaced due to a changeover.
	 */
	private Integer replacedChgOverSeqNo;

	/**
	 * POSITION CODE IS A NUMBERIC VALUE THAT COMES FROM TABLE. EX: 01 = CA, 22=
	 * #1 FA
	 *
	 */
	private Integer positionCode;

	/**
	 * GREATER OF ALL THE SCHEDULED AND ACTUAL LEGS
	 *
	 */
	private Integer legGreaterMins;

	/**
	 * -. FLY TIME THIS IS THE SCHEDULED VALUE OF ALL THE LEGS
	 *
	 */
	private Integer scheduledGateToGateMins;

	/**
	 * _� <-INCLUDES RCD, DEI, ATC. THIS IS THE TOTAL ACTUAL FLYING OF ALL THE
	 * LEGS. IT'S INCLUDED DUE TO PAY PURPOSES.
	 *
	 */
	private Integer actualGateToGateMins;

	/**
	 * -. E TIME SCHEDULED
	 */
	private Integer scheduledDutyPerCRMins;

	/**
	 * _� ACTUAL E TIME
	 */
	private Integer actualDutyPerCRMins;

	/**
	 * -. F TIME SCHEDULED
	 */
	private Integer scheduledSeqCRMins;

	/**
	 * _� <-THIS INCLUDES 8F TIME, WHICH IS CREDITED, SO ADDING THIS INTO SEQVAL
	 * WILL NOT MATCH DECS WHEN THERE IS 8F. ACTUAL F TIME.
	 *
	 */
	private Integer actualSeqCRMins;

	/**
	 * - RPT ! THE REPORT TIME IN THE SEQUENCE IS INCLUDED IN THIS FIELD (The
	 * flight shows RPT in the dhd field instead of AA for the DHD airline)
	 */
	private Integer deadHeadMins;

	/**
	 * NITEPAY2; hours actually flown between hours of 2400 and 0559;
	 */
	private Integer schdNightPayMins;

	/**
	 * NITEPAY1; hours actually flown between hours of 2045 and 2359;
	 *
	 */
	private Integer nightPayMins;

	/**
	 * REASSINGMENT PAY MINS - THE NBR OF MINS A FLT ATT WILL BE CREDITED ABOVE
	 * THOSE FOR ACTUAL WORK PERFORMED WEN REMOVED FROM ONE WORK ASSIGNMENT AND
	 * REASSIGNED TO ANOTHER OF LESSER VALUE. (It implies that this would show
	 * on the flown sequence only).
	 *
	 */
	private Integer reassignPayMins;

	/**
	 * CAN'T TRUST THIS TO BE 1 FOR SEQ W/ADD CODE OF ZERO (ORIGINAL SCHEDULE)
	 * SPECIFIES WHETHER A GIVEN SEQUENCE WAS GENERATED FROM THE ORIGINAL FLT
	 * ALLOCATION SCHEDULE (BID LINE) OR WAS CREATED LATER BY FLT OPERATIONS. 0
	 * = UNSCHEDULE 1=ORIG ALLOCATION.
	 *
	 */
	private boolean originalSchInd;

	/**
	 * specifies whether an activity is still on their schedule and not removed
	 * or cancelled or reassigned. 0=Not currently schedule 1= currently
	 * scheduled
	 *
	 */
	private boolean currentSchActyInd;

	/**
	 * SEQUENCE CONTRACTUAL PATH INDICATOR 0=FOR SUPVSR FLYING, 6=PAY ONLY, 1=
	 * CREDIT ONLY, 7=PAY AND CREDIT
	 *
	 */
	private Integer seqControlPathInd;

	/**
	 * "SEQUENCE CONTRACTUAL PATH INDICATOR 0=FOR SUPVSR FLYING, 6=PAY ONLY, 1=
	 * CREDIT ONLY, 7=PAY AND CREDIT "
	 *
	 */
	private Integer seqActualPathInd;

	/**
	 * SEQ ADD CODE. if = 0, then was originally allocated to the FA in the bid
	 * line. Translate this with the GJA table. IF a FA sequence and the add
	 * code = 0, and the rmvl code = 146 or 147, then this was not on their
	 * original schedule. It was a "denied" bid and these were the sequences in
	 * the denied bid.
	 *
	 */
	private Integer assignmentReasonCode;

	/**
	 * INDICATES WHETHER A SEQUENCE INCLUDES ANY FLIGHT LEGS THAT WERE
	 * REASSIGNMENTS. Y=YES N=NO
	 */
	private String partialReassignmentInd;

	/**
	 * "This is whether the sequence has been removed and will be credited. EX:
	 * VC. =0 IF NOT CREDITED, =1 IF CREDITED"
	 *
	 */
	private boolean removedCreditActivityInd;

	/**
	 * SUPERVISOR OPEN SEQUENCE INDICATOR - indicates whether a supervisor is
	 * flying a sequence that came from open time.
	 *
	 */
	private boolean supervisorOpenSeqInd;

	/**
	 * SHORT DUTY PERIOD FLYING MINUTES - THE TTL NUMBER OF MINS A CREWMEMBER
	 * HAS FLOWN BASED ON A SHORT DUTY PERIOD REFER TO CONTRACTUAL AGREEMENT B/W
	 * AA PILOTS AND ALPA, ATR 21E, ITEM 2.
	 *
	 */
	private Integer shortDutyPeriodFlyMins;

	/**
	 * SHORT DUTY PERIOD CREDIT MINUTES - THE TTL NUMBER OF MINS A CREWMEMBER IS
	 * CREDITED BASED ON A SHORT DUTY PERIOD REFER TO CONTRACTUAL AGREEMENT B/W
	 * AA PILOTS AND ALPA, ATR 21E, ITEM 2.
	 *
	 */
	private Integer shortDutyPeriodCreditMins;

	/**
	 * Number of variable mins scheduled for flt leg.
	 *
	 */
	private Integer variableFlyMins;

	/**
	 * FLIGHT ENGINEER APPROVED A INDICATOR. (We think this was for A scale pay
	 * rates)
	 */
	private String FEPrimaryApprovedInd;

	/**
	 * PILOT APPROVED A INDICATOR. (We think this was for A scale pay rates)
	 */
	private String pilotPrimaryApprovedInd;

	/**
	 * FLIGHT ENGINEER APPROVED B INDICATOR. (We think this was for B scale pay
	 * rates)
	 */
	private String FESecondaryApprovedInd;

	/**
	 * PILOT APPROVED B INDICATOR. (We think this was for B scale pay rates)
	 */
	private String pilotSecondaryApprovedInd;

	/**
	 * BLOCKED FOR IE
	 */
	private String blockedInd;

	/**
	 * IF ON THEN G TIME IS HIGHER THAN F TIME, SO VALUE IN F TIME WILL INCLUDE
	 * G TIME - SCHEDULED
	 */
	private String scheduledCRMinsInd;

	/**
	 * IF ON THEN G TIME IS HIGHER THAN F TIME, SO VALUE IN F TIME WILL INCLUDE
	 * G TIME - ACTUAL
	 *
	 */
	private String actualCRMinsInd;

	/**
	 * UNBLOCKED FOR IE
	 */
	private String unblockedInd;

	/**
	 * SEQUENCE LEVEL NUMBER FOR ADDED SEQUENCE - This is the Trip Trade Level
	 * number which appears on both added and removed sequences to show that
	 * they are "married" to each other.
	 */
	private Integer levelNoAddSeq;

	/**
	 * USED FOR EXPENSES-NOT F TIME CALC, SOME SPECIAL CASES HAVE MINUTES NOT
	 * INCLUDED FOR EXPENSES. TAFB IS ZERO FOR REMOVED SEQ. IS 0 FOR SAM FA ACT
	 * SEQ TAFB = SEQ_TAFB +AND SUP FLYING. MAX(0,(SSEQEND-ASEQEND)); ON HSS
	 * DISPLAY, THIS FIELD IS ON THE TAXABLE EXP LINE, NOT THE TAFB LINE.
	 *
	 */
	private Integer SeqTAFBMins;

	/**
	 * VMC DEADHEAD MINS IN THE ORIGINATING MONTH
	 *
	 */
	private Integer vmcDeadheadMinsOrigMth;

	/**
	 * VMC DEADHEAD MINS IN THE CARRYOVER MONTH
	 *
	 */
	private Integer vmcDeadheadMinsCarryoverMth;

	/**
	 * SOMETHING ABOUT PAY MAX MIN?
	 */
	private Integer seqRemoval75Mins;

	/**
	 * ORIGINAL VALUE AT TIME OF INITIAL LOAD. ONLY ON SEQUENCES THAT WERE THERE
	 * AT THE TIME OF THE INITIAL LOAD. SO NOT THERE FOR CREW SCHEDULE-BUILT
	 * SEQUENCES.
	 *
	 */
	private Integer originalSeqVal;

	/**
	 * ORIGINAL START DATE AT TIME OF INITIAL LOAD. ONLY ON SEQUENCES THAT WERE
	 * THERE AT THE TIME OF THE INITIAL LOAD. SO NOT THERE FOR CREW
	 * SCHEDULE-BUILT SEQUENCES.
	 *
	 */
	private Integer originalSeqStartDate;

	/**
	 * ORIGINAL SEQ START TIME AT TIME OF INITIAL LOAD. ONLY ON SEQUENCES THAT
	 * WERE THERE AT THE TIME OF THE INITIAL LOAD. SO NOT THERE FOR CREW
	 * SCHEDULE-BUILT SEQUENCES.
	 *
	 */
	private Integer originalSeqStartTime;

	/**
	 * THE PARTITION WHERE THE SEQ CAME FROM. AA OR TW
	 *
	 */
	private String operAirline;

	/**
	 * FOR A CARRYOVER SEQ, THIS IS THE VALUE OF THE SEQ IN THE PREV MONTH.
	 * SCHEDULED, NOT ACTUAL.
	 *
	 */
	private Integer previousMnthSeqValue;

	/**
	 * FOR A CARRYOVER SEQ, THIS IS THE VALUE OF THE SEQ IN THE NEXT MONTH.
	 * SCHEDULED, NOT ACTUAL.
	 *
	 */
	private Integer nextMnthSeqValue;

	private String homeBaseRest;

	private Long fillS1;

	private Long fillS2;

	private List<DutyPeriodDataDto> dutyPeriods;

	/**
	 * @return the scheduleStartDate
	 */
	public Integer getScheduleStartDate() {
		return scheduleStartDate;
	}

	/**
	 * @param scheduleStartDate the scheduleStartDate to set
	 */
	public void setScheduleStartDate(Integer scheduleStartDate) {
		this.scheduleStartDate = scheduleStartDate;
	}

	/**
	 * @return the seqNo
	 */
	public Integer getSeqNo() {
		return seqNo;
	}

	/**
	 * @param seqNo the seqNo to set
	 */
	public void setSeqNo(Integer seqNo) {
		this.seqNo = seqNo;
	}

	/**
	 * @return the reassignmentNo
	 */
	public Integer getReassignmentNo() {
		return reassignmentNo;
	}

	/**
	 * @param reassignmentNo the reassignmentNo to set
	 */
	public void setReassignmentNo(Integer reassignmentNo) {
		this.reassignmentNo = reassignmentNo;
	}

	/**
	 * @return the removalReasonCode
	 */
	public Integer getRemovalReasonCode() {
		return removalReasonCode;
	}

	/**
	 * @param removalReasonCode the removalReasonCode to set
	 */
	public void setRemovalReasonCode(Integer removalReasonCode) {
		this.removalReasonCode = removalReasonCode;
	}

	/**
	 * @return the levelNumberRemoved
	 */
	public Integer getLevelNumberRemoved() {
		return levelNumberRemoved;
	}

	/**
	 * @param levelNumberRemoved the levelNumberRemoved to set
	 */
	public void setLevelNumberRemoved(Integer levelNumberRemoved) {
		this.levelNumberRemoved = levelNumberRemoved;
	}

	/**
	 * @return the rescheduledStartDate
	 */
	public Integer getRescheduledStartDate() {
		return rescheduledStartDate;
	}

	/**
	 * @param rescheduledStartDate the rescheduledStartDate to set
	 */
	public void setRescheduledStartDate(Integer rescheduledStartDate) {
		this.rescheduledStartDate = rescheduledStartDate;
	}

	/**
	 * @return the actualStartDate
	 */
	public Integer getActualStartDate() {
		return actualStartDate;
	}

	/**
	 * @param actualStartDate the actualStartDate to set
	 */
	public void setActualStartDate(Integer actualStartDate) {
		this.actualStartDate = actualStartDate;
	}

	/**
	 * @return the scheduledStartMins
	 */
	public Integer getScheduledStartMins() {
		return scheduledStartMins;
	}

	/**
	 * @param scheduledStartMins the scheduledStartMins to set
	 */
	public void setScheduledStartMins(Integer scheduledStartMins) {
		this.scheduledStartMins = scheduledStartMins;
	}

	/**
	 * @return the reScheduledStartMins
	 */
	public Integer getReScheduledStartMins() {
		return reScheduledStartMins;
	}

	/**
	 * @param reScheduledStartMins the reScheduledStartMins to set
	 */
	public void setReScheduledStartMins(Integer reScheduledStartMins) {
		this.reScheduledStartMins = reScheduledStartMins;
	}

	/**
	 * @return the actualStartMins
	 */
	public Integer getActualStartMins() {
		return actualStartMins;
	}

	/**
	 * @param actualStartMins the actualStartMins to set
	 */
	public void setActualStartMins(Integer actualStartMins) {
		this.actualStartMins = actualStartMins;
	}

	/**
	 * @return the scheduledEndDate
	 */
	public Integer getScheduledEndDate() {
		return scheduledEndDate;
	}

	/**
	 * @param scheduledEndDate the scheduledEndDate to set
	 */
	public void setScheduledEndDate(Integer scheduledEndDate) {
		this.scheduledEndDate = scheduledEndDate;
	}

	/**
	 * @return the reScheduledEndDate
	 */
	public Integer getReScheduledEndDate() {
		return reScheduledEndDate;
	}

	/**
	 * @param reScheduledEndDate the reScheduledEndDate to set
	 */
	public void setReScheduledEndDate(Integer reScheduledEndDate) {
		this.reScheduledEndDate = reScheduledEndDate;
	}

	/**
	 * @return the actualEndDate
	 */
	public Integer getActualEndDate() {
		return actualEndDate;
	}

	/**
	 * @param actualEndDate the actualEndDate to set
	 */
	public void setActualEndDate(Integer actualEndDate) {
		this.actualEndDate = actualEndDate;
	}

	/**
	 * @return the scheduledEndMins
	 */
	public Integer getScheduledEndMins() {
		return scheduledEndMins;
	}

	/**
	 * @param scheduledEndMins the scheduledEndMins to set
	 */
	public void setScheduledEndMins(Integer scheduledEndMins) {
		this.scheduledEndMins = scheduledEndMins;
	}

	/**
	 * @return the reScheduledEndMins
	 */
	public Integer getReScheduledEndMins() {
		return reScheduledEndMins;
	}

	/**
	 * @param reScheduledEndMins the reScheduledEndMins to set
	 */
	public void setReScheduledEndMins(Integer reScheduledEndMins) {
		this.reScheduledEndMins = reScheduledEndMins;
	}

	/**
	 * @return the actualEndMins
	 */
	public Integer getActualEndMins() {
		return actualEndMins;
	}

	/**
	 * @param actualEndMins the actualEndMins to set
	 */
	public void setActualEndMins(Integer actualEndMins) {
		this.actualEndMins = actualEndMins;
	}

	/**
	 * @return the startGMTAdjmtMins
	 */
	public Integer getStartGMTAdjmtMins() {
		return startGMTAdjmtMins;
	}

	/**
	 * @param startGMTAdjmtMins the startGMTAdjmtMins to set
	 */
	public void setStartGMTAdjmtMins(Integer startGMTAdjmtMins) {
		this.startGMTAdjmtMins = startGMTAdjmtMins;
	}

	/**
	 * @return the endGMTAdjmtMins
	 */
	public Integer getEndGMTAdjmtMins() {
		return endGMTAdjmtMins;
	}

	/**
	 * @param endGMTAdjmtMins the endGMTAdjmtMins to set
	 */
	public void setEndGMTAdjmtMins(Integer endGMTAdjmtMins) {
		this.endGMTAdjmtMins = endGMTAdjmtMins;
	}

	/**
	 * @return the segOprgDaysQty
	 */
	public Integer getSegOprgDaysQty() {
		return segOprgDaysQty;
	}

	/**
	 * @param segOprgDaysQty the segOprgDaysQty to set
	 */
	public void setSegOprgDaysQty(Integer segOprgDaysQty) {
		this.segOprgDaysQty = segOprgDaysQty;
	}

	/**
	 * @return the seqCrewBase
	 */
	public Integer getSeqCrewBase() {
		return seqCrewBase;
	}

	/**
	 * @param seqCrewBase the seqCrewBase to set
	 */
	public void setSeqCrewBase(Integer seqCrewBase) {
		this.seqCrewBase = seqCrewBase;
	}

	/**
	 * @return the highEqpTypeCode
	 */
	public String getHighEqpTypeCode() {
		return highEqpTypeCode;
	}

	/**
	 * @param highEqpTypeCode the highEqpTypeCode to set
	 */
	public void setHighEqpTypeCode(String highEqpTypeCode) {
		this.highEqpTypeCode = highEqpTypeCode;
	}

	/**
	 * @return the domIntlCode
	 */
	public String getDomIntlCode() {
		return domIntlCode;
	}

	/**
	 * @param domIntlCode the domIntlCode to set
	 */
	public void setDomIntlCode(String domIntlCode) {
		this.domIntlCode = domIntlCode;
	}

	/**
	 * @return the noAplbeLegInd
	 */
	public boolean isNoAplbeLegInd() {
		return noAplbeLegInd;
	}

	/**
	 * @param noAplbeLegInd the noAplbeLegInd to set
	 */
	public void setNoAplbeLegInd(boolean noAplbeLegInd) {
		this.noAplbeLegInd = noAplbeLegInd;
	}

	/**
	 * @return the missingDataInd
	 */
	public boolean isMissingDataInd() {
		return missingDataInd;
	}

	/**
	 * @param missingDataInd the missingDataInd to set
	 */
	public void setMissingDataInd(boolean missingDataInd) {
		this.missingDataInd = missingDataInd;
	}

	/**
	 * @return the failedContinuityInd
	 */
	public boolean isFailedContinuityInd() {
		return failedContinuityInd;
	}

	/**
	 * @param failedContinuityInd the failedContinuityInd to set
	 */
	public void setFailedContinuityInd(boolean failedContinuityInd) {
		this.failedContinuityInd = failedContinuityInd;
	}

	/**
	 * @return the segStateCode
	 */
	public Integer getSegStateCode() {
		return segStateCode;
	}

	/**
	 * @param segStateCode the segStateCode to set
	 */
	public void setSegStateCode(Integer segStateCode) {
		this.segStateCode = segStateCode;
	}

	/**
	 * @return the changeOverInd
	 */
	public boolean isChangeOverInd() {
		return changeOverInd;
	}

	/**
	 * @param changeOverInd the changeOverInd to set
	 */
	public void setChangeOverInd(boolean changeOverInd) {
		this.changeOverInd = changeOverInd;
	}

	/**
	 * @return the carryOverInd
	 */
	public boolean isCarryOverInd() {
		return carryOverInd;
	}

	/**
	 * @param carryOverInd the carryOverInd to set
	 */
	public void setCarryOverInd(boolean carryOverInd) {
		this.carryOverInd = carryOverInd;
	}

	/**
	 * @return the varMangInd
	 */
	public boolean isVarMangInd() {
		return varMangInd;
	}

	/**
	 * @param varMangInd the varMangInd to set
	 */
	public void setVarMangInd(boolean varMangInd) {
		this.varMangInd = varMangInd;
	}

	/**
	 * @return the taxInd
	 */
	public String getTaxInd() {
		return taxInd;
	}

	/**
	 * @param taxInd the taxInd to set
	 */
	public void setTaxInd(String taxInd) {
		this.taxInd = taxInd;
	}

	/**
	 * @return the dutyPeriodQty
	 */
	public Integer getDutyPeriodQty() {
		return dutyPeriodQty;
	}

	/**
	 * @param dutyPeriodQty the dutyPeriodQty to set
	 */
	public void setDutyPeriodQty(Integer dutyPeriodQty) {
		this.dutyPeriodQty = dutyPeriodQty;
	}

	/**
	 * @return the segLegQty
	 */
	public Integer getSegLegQty() {
		return SegLegQty;
	}

	/**
	 * @param segLegQty the segLegQty to set
	 */
	public void setSegLegQty(Integer segLegQty) {
		SegLegQty = segLegQty;
	}

	/**
	 * @return the replacedChgOverSeqNo
	 */
	public Integer getReplacedChgOverSeqNo() {
		return replacedChgOverSeqNo;
	}

	/**
	 * @param replacedChgOverSeqNo the replacedChgOverSeqNo to set
	 */
	public void setReplacedChgOverSeqNo(Integer replacedChgOverSeqNo) {
		this.replacedChgOverSeqNo = replacedChgOverSeqNo;
	}

	/**
	 * @return the positionCode
	 */
	public Integer getPositionCode() {
		return positionCode;
	}

	/**
	 * @param positionCode the positionCode to set
	 */
	public void setPositionCode(Integer positionCode) {
		this.positionCode = positionCode;
	}

	/**
	 * @return the legGreaterMins
	 */
	public Integer getLegGreaterMins() {
		return legGreaterMins;
	}

	/**
	 * @param legGreaterMins the legGreaterMins to set
	 */
	public void setLegGreaterMins(Integer legGreaterMins) {
		this.legGreaterMins = legGreaterMins;
	}

	/**
	 * @return the scheduledGateToGateMins
	 */
	public Integer getScheduledGateToGateMins() {
		return scheduledGateToGateMins;
	}

	/**
	 * @param scheduledGateToGateMins the scheduledGateToGateMins to set
	 */
	public void setScheduledGateToGateMins(Integer scheduledGateToGateMins) {
		this.scheduledGateToGateMins = scheduledGateToGateMins;
	}

	/**
	 * @return the actualGateToGateMins
	 */
	public Integer getActualGateToGateMins() {
		return actualGateToGateMins;
	}

	/**
	 * @param actualGateToGateMins the actualGateToGateMins to set
	 */
	public void setActualGateToGateMins(Integer actualGateToGateMins) {
		this.actualGateToGateMins = actualGateToGateMins;
	}

	/**
	 * @return the scheduledDutyPerCRMins
	 */
	public Integer getScheduledDutyPerCRMins() {
		return scheduledDutyPerCRMins;
	}

	/**
	 * @param scheduledDutyPerCRMins the scheduledDutyPerCRMins to set
	 */
	public void setScheduledDutyPerCRMins(Integer scheduledDutyPerCRMins) {
		this.scheduledDutyPerCRMins = scheduledDutyPerCRMins;
	}

	/**
	 * @return the actualDutyPerCRMins
	 */
	public Integer getActualDutyPerCRMins() {
		return actualDutyPerCRMins;
	}

	/**
	 * @param actualDutyPerCRMins the actualDutyPerCRMins to set
	 */
	public void setActualDutyPerCRMins(Integer actualDutyPerCRMins) {
		this.actualDutyPerCRMins = actualDutyPerCRMins;
	}

	/**
	 * @return the scheduledSeqCRMins
	 */
	public Integer getScheduledSeqCRMins() {
		return scheduledSeqCRMins;
	}

	/**
	 * @param scheduledSeqCRMins the scheduledSeqCRMins to set
	 */
	public void setScheduledSeqCRMins(Integer scheduledSeqCRMins) {
		this.scheduledSeqCRMins = scheduledSeqCRMins;
	}

	/**
	 * @return the actualSeqCRMins
	 */
	public Integer getActualSeqCRMins() {
		return actualSeqCRMins;
	}

	/**
	 * @param actualSeqCRMins the actualSeqCRMins to set
	 */
	public void setActualSeqCRMins(Integer actualSeqCRMins) {
		this.actualSeqCRMins = actualSeqCRMins;
	}

	/**
	 * @return the deadHeadMins
	 */
	public Integer getDeadHeadMins() {
		return deadHeadMins;
	}

	/**
	 * @param deadHeadMins the deadHeadMins to set
	 */
	public void setDeadHeadMins(Integer deadHeadMins) {
		this.deadHeadMins = deadHeadMins;
	}

	/**
	 * @return the schdNightPayMins
	 */
	public Integer getSchdNightPayMins() {
		return schdNightPayMins;
	}

	/**
	 * @param schdNightPayMins the schdNightPayMins to set
	 */
	public void setSchdNightPayMins(Integer schdNightPayMins) {
		this.schdNightPayMins = schdNightPayMins;
	}

	/**
	 * @return the nightPayMins
	 */
	public Integer getNightPayMins() {
		return nightPayMins;
	}

	/**
	 * @param nightPayMins the nightPayMins to set
	 */
	public void setNightPayMins(Integer nightPayMins) {
		this.nightPayMins = nightPayMins;
	}

	/**
	 * @return the reassignPayMins
	 */
	public Integer getReassignPayMins() {
		return reassignPayMins;
	}

	/**
	 * @param reassignPayMins the reassignPayMins to set
	 */
	public void setReassignPayMins(Integer reassignPayMins) {
		this.reassignPayMins = reassignPayMins;
	}

	/**
	 * @return the originalSchInd
	 */
	public boolean isOriginalSchInd() {
		return originalSchInd;
	}

	/**
	 * @param originalSchInd the originalSchInd to set
	 */
	public void setOriginalSchInd(boolean originalSchInd) {
		this.originalSchInd = originalSchInd;
	}

	/**
	 * @return the currentSchActyInd
	 */
	public boolean isCurrentSchActyInd() {
		return currentSchActyInd;
	}

	/**
	 * @param currentSchActyInd the currentSchActyInd to set
	 */
	public void setCurrentSchActyInd(boolean currentSchActyInd) {
		this.currentSchActyInd = currentSchActyInd;
	}

	/**
	 * @return the seqControlPathInd
	 */
	public Integer getSeqControlPathInd() {
		return seqControlPathInd;
	}

	/**
	 * @param seqControlPathInd the seqControlPathInd to set
	 */
	public void setSeqControlPathInd(Integer seqControlPathInd) {
		this.seqControlPathInd = seqControlPathInd;
	}

	/**
	 * @return the seqActualPathInd
	 */
	public Integer getSeqActualPathInd() {
		return seqActualPathInd;
	}

	/**
	 * @param seqActualPathInd the seqActualPathInd to set
	 */
	public void setSeqActualPathInd(Integer seqActualPathInd) {
		this.seqActualPathInd = seqActualPathInd;
	}

	/**
	 * @return the assignmentReasonCode
	 */
	public Integer getAssignmentReasonCode() {
		return assignmentReasonCode;
	}

	/**
	 * @param assignmentReasonCode the assignmentReasonCode to set
	 */
	public void setAssignmentReasonCode(Integer assignmentReasonCode) {
		this.assignmentReasonCode = assignmentReasonCode;
	}

	/**
	 * @return the partialReassignmentInd
	 */
	public String getPartialReassignmentInd() {
		return partialReassignmentInd;
	}

	/**
	 * @param partialReassignmentInd the partialReassignmentInd to set
	 */
	public void setPartialReassignmentInd(String partialReassignmentInd) {
		this.partialReassignmentInd = partialReassignmentInd;
	}

	/**
	 * @return the removedCreditActivityInd
	 */
	public boolean isRemovedCreditActivityInd() {
		return removedCreditActivityInd;
	}

	/**
	 * @param removedCreditActivityInd the removedCreditActivityInd to set
	 */
	public void setRemovedCreditActivityInd(boolean removedCreditActivityInd) {
		this.removedCreditActivityInd = removedCreditActivityInd;
	}

	/**
	 * @return the supervisorOpenSeqInd
	 */
	public boolean isSupervisorOpenSeqInd() {
		return supervisorOpenSeqInd;
	}

	/**
	 * @param supervisorOpenSeqInd the supervisorOpenSeqInd to set
	 */
	public void setSupervisorOpenSeqInd(boolean supervisorOpenSeqInd) {
		this.supervisorOpenSeqInd = supervisorOpenSeqInd;
	}

	/**
	 * @return the shortDutyPeriodFlyMins
	 */
	public Integer getShortDutyPeriodFlyMins() {
		return shortDutyPeriodFlyMins;
	}

	/**
	 * @param shortDutyPeriodFlyMins the shortDutyPeriodFlyMins to set
	 */
	public void setShortDutyPeriodFlyMins(Integer shortDutyPeriodFlyMins) {
		this.shortDutyPeriodFlyMins = shortDutyPeriodFlyMins;
	}

	/**
	 * @return the shortDutyPeriodCreditMins
	 */
	public Integer getShortDutyPeriodCreditMins() {
		return shortDutyPeriodCreditMins;
	}

	/**
	 * @param shortDutyPeriodCreditMins the shortDutyPeriodCreditMins to set
	 */
	public void setShortDutyPeriodCreditMins(Integer shortDutyPeriodCreditMins) {
		this.shortDutyPeriodCreditMins = shortDutyPeriodCreditMins;
	}

	/**
	 * @return the variableFlyMins
	 */
	public Integer getVariableFlyMins() {
		return variableFlyMins;
	}

	/**
	 * @param variableFlyMins the variableFlyMins to set
	 */
	public void setVariableFlyMins(Integer variableFlyMins) {
		this.variableFlyMins = variableFlyMins;
	}

	/**
	 * @return the fEPrimaryApprovedInd
	 */
	public String getFEPrimaryApprovedInd() {
		return FEPrimaryApprovedInd;
	}

	/**
	 * @param fEPrimaryApprovedInd the fEPrimaryApprovedInd to set
	 */
	public void setFEPrimaryApprovedInd(String fEPrimaryApprovedInd) {
		FEPrimaryApprovedInd = fEPrimaryApprovedInd;
	}

	/**
	 * @return the pilotPrimaryApprovedInd
	 */
	public String getPilotPrimaryApprovedInd() {
		return pilotPrimaryApprovedInd;
	}

	/**
	 * @param pilotPrimaryApprovedInd the pilotPrimaryApprovedInd to set
	 */
	public void setPilotPrimaryApprovedInd(String pilotPrimaryApprovedInd) {
		this.pilotPrimaryApprovedInd = pilotPrimaryApprovedInd;
	}

	/**
	 * @return the fESecondaryApprovedInd
	 */
	public String getFESecondaryApprovedInd() {
		return FESecondaryApprovedInd;
	}

	/**
	 * @param fESecondaryApprovedInd the fESecondaryApprovedInd to set
	 */
	public void setFESecondaryApprovedInd(String fESecondaryApprovedInd) {
		FESecondaryApprovedInd = fESecondaryApprovedInd;
	}

	/**
	 * @return the pilotSecondaryApprovedInd
	 */
	public String getPilotSecondaryApprovedInd() {
		return pilotSecondaryApprovedInd;
	}

	/**
	 * @param pilotSecondaryApprovedInd the pilotSecondaryApprovedInd to set
	 */
	public void setPilotSecondaryApprovedInd(String pilotSecondaryApprovedInd) {
		this.pilotSecondaryApprovedInd = pilotSecondaryApprovedInd;
	}

	/**
	 * @return the blockedInd
	 */
	public String getBlockedInd() {
		return blockedInd;
	}

	/**
	 * @param blockedInd the blockedInd to set
	 */
	public void setBlockedInd(String blockedInd) {
		this.blockedInd = blockedInd;
	}

	/**
	 * @return the scheduledCRMinsInd
	 */
	public String getScheduledCRMinsInd() {
		return scheduledCRMinsInd;
	}

	/**
	 * @param scheduledCRMinsInd the scheduledCRMinsInd to set
	 */
	public void setScheduledCRMinsInd(String scheduledCRMinsInd) {
		this.scheduledCRMinsInd = scheduledCRMinsInd;
	}

	/**
	 * @return the actualCRMinsInd
	 */
	public String getActualCRMinsInd() {
		return actualCRMinsInd;
	}

	/**
	 * @param actualCRMinsInd the actualCRMinsInd to set
	 */
	public void setActualCRMinsInd(String actualCRMinsInd) {
		this.actualCRMinsInd = actualCRMinsInd;
	}

	/**
	 * @return the unblockedInd
	 */
	public String getUnblockedInd() {
		return unblockedInd;
	}

	/**
	 * @param unblockedInd the unblockedInd to set
	 */
	public void setUnblockedInd(String unblockedInd) {
		this.unblockedInd = unblockedInd;
	}

	/**
	 * @return the levelNoAddSeq
	 */
	public Integer getLevelNoAddSeq() {
		return levelNoAddSeq;
	}

	/**
	 * @param levelNoAddSeq the levelNoAddSeq to set
	 */
	public void setLevelNoAddSeq(Integer levelNoAddSeq) {
		this.levelNoAddSeq = levelNoAddSeq;
	}

	/**
	 * @return the seqTAFBMins
	 */
	public Integer getSeqTAFBMins() {
		return SeqTAFBMins;
	}

	/**
	 * @param seqTAFBMins the seqTAFBMins to set
	 */
	public void setSeqTAFBMins(Integer seqTAFBMins) {
		SeqTAFBMins = seqTAFBMins;
	}

	/**
	 * @return the vmcDeadheadMinsOrigMth
	 */
	public Integer getVmcDeadheadMinsOrigMth() {
		return vmcDeadheadMinsOrigMth;
	}

	/**
	 * @param vmcDeadheadMinsOrigMth the vmcDeadheadMinsOrigMth to set
	 */
	public void setVmcDeadheadMinsOrigMth(Integer vmcDeadheadMinsOrigMth) {
		this.vmcDeadheadMinsOrigMth = vmcDeadheadMinsOrigMth;
	}

	/**
	 * @return the vmcDeadheadMinsCarryoverMth
	 */
	public Integer getVmcDeadheadMinsCarryoverMth() {
		return vmcDeadheadMinsCarryoverMth;
	}

	/**
	 * @param vmcDeadheadMinsCarryoverMth the vmcDeadheadMinsCarryoverMth to set
	 */
	public void setVmcDeadheadMinsCarryoverMth(Integer vmcDeadheadMinsCarryoverMth) {
		this.vmcDeadheadMinsCarryoverMth = vmcDeadheadMinsCarryoverMth;
	}

	/**
	 * @return the seqRemoval75Mins
	 */
	public Integer getSeqRemoval75Mins() {
		return seqRemoval75Mins;
	}

	/**
	 * @param seqRemoval75Mins the seqRemoval75Mins to set
	 */
	public void setSeqRemoval75Mins(Integer seqRemoval75Mins) {
		this.seqRemoval75Mins = seqRemoval75Mins;
	}

	/**
	 * @return the originalSeqVal
	 */
	public Integer getOriginalSeqVal() {
		return originalSeqVal;
	}

	/**
	 * @param originalSeqVal the originalSeqVal to set
	 */
	public void setOriginalSeqVal(Integer originalSeqVal) {
		this.originalSeqVal = originalSeqVal;
	}

	/**
	 * @return the originalSeqStartDate
	 */
	public Integer getOriginalSeqStartDate() {
		return originalSeqStartDate;
	}

	/**
	 * @param originalSeqStartDate the originalSeqStartDate to set
	 */
	public void setOriginalSeqStartDate(Integer originalSeqStartDate) {
		this.originalSeqStartDate = originalSeqStartDate;
	}

	/**
	 * @return the originalSeqStartTime
	 */
	public Integer getOriginalSeqStartTime() {
		return originalSeqStartTime;
	}

	/**
	 * @param originalSeqStartTime the originalSeqStartTime to set
	 */
	public void setOriginalSeqStartTime(Integer originalSeqStartTime) {
		this.originalSeqStartTime = originalSeqStartTime;
	}

	/**
	 * @return the operAirline
	 */
	public String getOperAirline() {
		return operAirline;
	}

	/**
	 * @param operAirline the operAirline to set
	 */
	public void setOperAirline(String operAirline) {
		this.operAirline = operAirline;
	}

	/**
	 * @return the previousMnthSeqValue
	 */
	public Integer getPreviousMnthSeqValue() {
		return previousMnthSeqValue;
	}

	/**
	 * @param previousMnthSeqValue the previousMnthSeqValue to set
	 */
	public void setPreviousMnthSeqValue(Integer previousMnthSeqValue) {
		this.previousMnthSeqValue = previousMnthSeqValue;
	}

	/**
	 * @return the nextMnthSeqValue
	 */
	public Integer getNextMnthSeqValue() {
		return nextMnthSeqValue;
	}

	/**
	 * @param nextMnthSeqValue the nextMnthSeqValue to set
	 */
	public void setNextMnthSeqValue(Integer nextMnthSeqValue) {
		this.nextMnthSeqValue = nextMnthSeqValue;
	}

	/**
	 * @return the homeBaseRest
	 */
	public String getHomeBaseRest() {
		return homeBaseRest;
	}

	/**
	 * @param homeBaseRest the homeBaseRest to set
	 */
	public void setHomeBaseRest(String homeBaseRest) {
		this.homeBaseRest = homeBaseRest;
	}

	/**
	 * @return the fillS1
	 */
	public Long getFillS1() {
		return fillS1;
	}

	/**
	 * @param fillS1 the fillS1 to set
	 */
	public void setFillS1(Long fillS1) {
		this.fillS1 = fillS1;
	}

	/**
	 * @return the fillS2
	 */
	public Long getFillS2() {
		return fillS2;
	}

	/**
	 * @param fillS2 the fillS2 to set
	 */
	public void setFillS2(Long fillS2) {
		this.fillS2 = fillS2;
	}

	/**
	 * @return the dutyPeriods
	 */
	public List<DutyPeriodDataDto> getDutyPeriods() {
		return dutyPeriods;
	}

	/**
	 * @param dutyPeriods the dutyPeriods to set
	 */
	public void setDutyPeriods(List<DutyPeriodDataDto> dutyPeriods) {
		this.dutyPeriods = dutyPeriods;
	}

	/**
	 * @param dutyPeriod the dutyPeriod to add
	 */
	public void addDutyPeriod(DutyPeriodDataDto dutyPeriod) {
		if(this.dutyPeriods == null){
			this.dutyPeriods = new ArrayList<DutyPeriodDataDto>();
		}
		this.dutyPeriods.add(dutyPeriod);
	}
	
}
