/**
 * 
 */
package com.aa.crewpay.domain;

import com.aa.crewpay.constant.enums.DomIntlCodeType;
import com.aa.crewpay.constant.enums.PositionCodeType;

/**
 * @author muthusba
 *
 */
public class MonthlySellingGroup {

	/**
	 * "2 numeric position code associated with the crewmembers monthly bid award; For F/A RSV "
	 * "RD"" this code is ""00"" (since we do not use call-in the code can not
	 * be validated) @See PositionCodeType"
	 * 
	 */
	private PositionCodeType crewMemberPositionCode;

	/**
	 * "D" or "I" division associated with the crewmembers monthly bid award
	 */
	private DomIntlCodeType domIntlCode;

}
