package com.aa.crewpay.batchloader;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.step.skip.SkipPolicy;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;

import com.aa.crewpay.batchloader.dto.BaseDTO;
import com.aa.crewpay.domain.CrewMember;

@Configuration
@EnableBatchProcessing
public class BatchConfiguration {

    @Autowired
    public JobBuilderFactory jobBuilderFactory;

    @Autowired
    public StepBuilderFactory stepBuilderFactory;

    @Autowired
    private JobExecutionListener notificationListener;
    
    @Autowired
	private CrewMapper crewMapper;
    
    @Autowired
	private FileVerificationSkipper skipper;
    
    /*@Autowired
    private CustomStepListener customStepListener;*/
    
    @Autowired
	private CrewWriter crewWriter;

    
    private static final Logger log = LoggerFactory.getLogger(BatchConfiguration.class);
    
   @Bean
    public Job importUserJob()  throws Exception {
        return jobBuilderFactory.get("importUserJob")
                .incrementer(new RunIdIncrementer())
                .listener(listener())
                .flow(step1())
                .end()
                .build();
    }

   public JobExecutionListener listener() {
       return this.notificationListener;
   }
   
    @Bean
    public Step step1()  throws Exception {
        return stepBuilderFactory.get("step1")
        		//.tasklet(tasklet())
                .<BaseDTO, CrewMember> chunk(2)
                .reader(reader())
                .faultTolerant().skipPolicy(fileVerificationSkipper())
                .processor(processor())
                .writer(writer())
                .build();
    }
        
    @Bean
    public CrewReader reader() throws Exception {
    	CrewReader reader = new CrewReader();
    	reader.setDelegate(new FlatFileItemReader<BaseDTO>());
    	reader.getDelegate().setResource(new ClassPathResource("sample-data.txt"));
    	reader.getDelegate().setEncoding("UTF-8");
    	reader.getDelegate().setLineMapper(mapper().crewLineMapper());
        return reader;
        
      //reader.getDelegate().setLinesToSkip(1);    	
    }
    
    public CrewMapper mapper() {	   
   	   log.info("mapper()");
   	   return crewMapper;
    }
    
    @Bean
    public SkipPolicy fileVerificationSkipper() {
        return skipper;
    }

    /*@Bean
    public CustomStepListener customStepListener() {
        return customStepListener;
    }*/
    
    @Bean
    public CrewItemProcessor processor() {
    	log.info("processor()");
    	return new CrewItemProcessor();
    }
    
    public CrewWriter writer() {	   
 	   log.info("writer()");
 	   return crewWriter;
    }
    
}
