/**
 * 
 */
package com.aa.crewpay.constant.enums;

/**
 * @author muthusba
 *
 */
public enum PositionCodeType {

	/**
	 * '1' - CAPTAIN.
	 */
	CA(1),

	/**
	 * '2' - FIRST OFFICER
	 */
	FO(2),
	
	/**
	 * '3' - FLIGHT ENGINEER 
	 */
	FE(3),
	
	/**
	 * '4' - IO 
	 */
	IO(4),
	
	/**
	 * '5' - RE.
	 */
	RE(5),

	/**
	 * '6' - FB
	 */
	FB(6),
	
	/**
	 * '7' - FC 
	 */
	FC(7),
	
	/**
	 * '8' - RC 
	 */
	RC(8),
	
	/**
	 * '9' - XA.
	 */
	XA(9),

	/**
	 * '2' - XO
	 */
	XO(10),
	
	/**
	 * '3' - XE 
	 */
	XE(11),
	
	/**
	 * '4' - IO 
	 */
	FA1(22),
	
	/**
	 * '5' - RE.
	 */
	FA2(23),

	/**
	 * '6' - FB
	 */
	FA3(24),
	
	/**
	 * '7' - FC 
	 */
	FA4(25),
	
	/**
	 * '8' - RC 
	 */
	FA5(26),
	
	/**
	 * '4' - IO 
	 */
	FA6(27),
	
	/**
	 * '5' - RE.
	 */
	FA7(28),

	/**
	 * '6' - FB
	 */
	FA8(29),
	
	/**
	 * '7' - FC 
	 */
	FA9(30),
	
	/**
	 * '8' - RC 
	 */
	FA10(31),
	
	/**
	 * '4' - IO 
	 */
	FA11(32),
	
	/**
	 * '5' - RE.
	 */
	FA12(33),

	/**
	 * '6' - FB
	 */
	FA13(34),
	
	/**
	 * '7' - FC 
	 */
	FA14(35),
	
	/**
	 * '8' - RC 
	 */
	FA15(36),
	
	/**
	 * '4' - IO 
	 */
	FA16(37),
	
	/**
	 * '5' - RE.
	 */
	VM(38),

	/**
	 * '6' - FB
	 */
	VM1(39),
	
	/**
	 * '7' - FC 
	 */
	VM2(40),
	
	/**
	 * '8' - RC 
	 */
	VM3(58),
	
	/**
	 * '4' - IO 
	 */
	FA99(59),
	
	/**
	 * '5' - RE.
	 */
	FA95(60),

	/**
	 * '6' - FB
	 */
	FA96(61),
	
	/**
	 * '7' - FC 
	 */
	FA97(62),
	
	/**
	 * '63' - FA98 
	 */
	FA98(63);

	/**
	 * Attribute to hold the PositionCode <code>type</code>.
	 */
	private Integer type;

	/**
	 * <code>Parameterized constructor.</code>
	 * <p>
	 * 
	 * @param pType
	 *            the new value of the <code>type</code> property.
	 */
	PositionCodeType(Integer pType) {
		type = pType;
	}

	/**
	 * Gets the <code>type</code> property.
	 * <p>
	 * 
	 * @return the current value of the <code>type</code> property.
	 */
	public int getType() {
		return this.type;
	}

	/**
	 * Gives the string format of enumerated <code>PositionCodeType</code>.
	 * <p>
	 * 
	 * @return the current value of the <code>PositionCodeType</code>.
	 */
	public String value() {
		return this.name();
	}
}
