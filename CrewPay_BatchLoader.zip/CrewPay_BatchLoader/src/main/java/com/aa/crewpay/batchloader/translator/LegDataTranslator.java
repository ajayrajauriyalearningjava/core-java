package com.aa.crewpay.batchloader.translator;

import com.aa.crewpay.batchloader.dto.LegDataDto;
import com.aa.crewpay.domain.LegData;

public class LegDataTranslator {

	public static LegData mapDtoToDomain(LegDataDto dto) {
		
		LegData legData = new LegData();
		
		//legData.set(dto.get());
		//legData.set(dto.get());
		//legData.set(dto.get());
		//legData.set(dto.get());
		//legData.set(dto.get());
		//legData.set(dto.get());
		//legData.set(dto.get());
		//legData.set(dto.get());
		//legData.set(dto.get());
		//legData.set(dto.get());
		//legData.set(dto.get());
		//legData.set(dto.get());
		//legData.set(dto.get());
		//legData.set(dto.get());
		//legData.set(dto.get());
		//legData.set(dto.get());
		//legData.set(dto.get());
		//legData.set(dto.get());
		//legData.set(dto.get());
		//legData.set(dto.get());
		//legData.set(dto.get());
		//legData.set(dto.get());
		//legData.set(dto.get());
		//legData.set(dto.get());
		
		return legData;
	}
}
