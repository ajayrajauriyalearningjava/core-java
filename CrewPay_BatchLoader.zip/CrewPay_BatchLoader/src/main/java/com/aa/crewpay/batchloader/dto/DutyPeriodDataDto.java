/**
 *
 */
package com.aa.crewpay.batchloader.dto;

import java.util.ArrayList;
import java.util.List;

/**
 * @author muthusba
 *
 */
public class DutyPeriodDataDto extends BaseDTO {

	/**
	 * SEQUENTIAL NUMBER
	 */
	private Integer sequentialNo;

	/**
	 * DUTY PERIOD NUMBER.
	 *
	 */
	private Integer dutyPeriodNo;

	private boolean noapplicableLegInd;

	private boolean shrtDutyPeriodInd;

	/**
	 * SEQ SCHEDULED START DATE: YYYYMMDD
	 */

	private Integer scheduleStartDate;

	/**
	 * RESCHEDULED START DATE OF SEQUENCE: YYYYMMDD This is driven by a manual
	 * sign in time that has been entered into the crewmember's sequence on the
	 * 1st duty period. If it exists, this field gets populated.
	 *
	 */

	private Integer rescheduledStartDate;

	/**
	 * ACTUAL START DATE OF SEQUENCE: YYYYMMDD
	 */

	private Integer actualStartDate;

	/**
	 * SCHEDULED START MINS OF SEQUENCE. THIS IS THE SCHEDULED GMT ON WHICH AN
	 * ACTIVITY OR EVENT IS SCHEDULED TO START : MMMM. Note: The difference
	 * between this SCHD_STR_MNS in record 02 versus that in record 04 is the
	 * 1hrs sign-in difference.
	 *
	 */

	private Integer scheduledStartMins;

	/**
	 * RESCHEDULED START MINS OF SEQUENCE. Note: if there is a RESCHEDULED START
	 * DATE then there is a RESCHEDULED START MINS populated. THIS IS THE RSCHD
	 * GMT ON WHICH AN ACTIVITY OR EVENT IS RESCHEDULED TO START : MMMM
	 */

	private Integer reScheduledStartMins;

	/**
	 * ACTUAL START MINS OF SEQUENCE. THIS IS THE ACTUAL GMT ON WHICH AN
	 * ACTIVITY OR EVENT ACTUALLY STARTED : MMMM THERE ARE VALUES IN ACTUAL DATE
	 * AND MINS FOR REMOVED SEQUENCE, JUST EQUALS SCHEDULED. It fills in the
	 * actual anyway, even though the sequence has been removed off of the
	 * crewmember's schedule, so they use the SCHD value to fill in the ACTL
	 * value.
	 */

	private Integer actualStartMins;

	/**
	 * SCHEDULED END DATE OF SEQUENCE: YYYYMMDD
	 */

	private Integer scheduledEndDate;

	/**
	 * RESCHEDULED END DATE OF SEQUENCE: YYYYMMDD
	 */

	private Integer reScheduledEndDate;

	/**
	 * ACTUAL END DATE OF SEQUENCE: YYYYMMDD
	 */

	private Integer actualEndDate;

	/**
	 * THIS IS RELATIVE TO THE SCHEDULED START MINS ABOVE
	 */

	private Integer scheduledEndMins;

	/**
	 * THIS IS RELATIVE TO THE RESCHEDULED START MINS ABOVE
	 */

	private Integer reScheduledEndMins;

	/**
	 * THIS IS RELATIVE TO THE ACTUAL START MINS ABOVE
	 */
	private Integer actualEndMins;

	/**
	 * THIS IS THE GMT TIME IN MINUTES FOR THE SCHEDULED START MINS 300 five
	 * hour adjustment for ORD time
	 */
	private Integer startGMTAdjmtMins;

	/**
	 * THIS IS THE GMT TIME IN MINUTES FOR THE SCHEDULED END MINS 240 four hour
	 * adjustment for TPA time
	 */
	private Integer endGMTAdjmtMins;

	/**
	 * GREATER OF ALL THE SCHEDULED AND ACTUAL LEGS 155 this number is divided
	 * by 60 to equal 2.35 flight hours
	 */
	private Integer legGreaterMins;

	/**
	 * -. FLY TIME THIS IS THE SCHEDULED VALUE OF ALL THE LEGS 155 this number
	 * is divided by 60 to equal 2.35 flight hours
	 */
	private Integer scheduledGateToGateMins;

	/**
	 * _� <-INCLUDES RCD, DEI, ATC. THIS IS THE TOTAL ACTUAL FLYING OF ALL THE
	 * LEGS. IT'S INCLUDED DUE TO PAY PURPOSES.
	 *
	 * 155 this number is divided by 60 to equal 2.35 flight hours
	 */
	private Integer actualGateToGateMins;

	/**
	 * -. E TIME SCHEDULED
	 */
	private Integer scheduledDutyPerCRMins;

	/**
	 * _� ACTUAL E TIME
	 */
	private Integer actualDutyPerCRMins;

	/**
	 * Minutes; total duty period deadhead minutes; deadhead minutes are always
	 * scheduled not actual
	 *
	 */
	private Integer deadHeadMins;

	/**
	 * Minutes; scheduled duty period off duty layover minutes
	 *
	 */
	private Integer schdOffDutyLayoverMins;

	/**
	 * Minutes; actual duty period off duty layover minutes
	 *
	 */
	private Integer actualOffDutyLayoverMins;

	/**
	 * Off duty time related to the specific duty period. "0" = Starts this
	 * month but does not carry over into next month; "1" = Starts this month
	 * and carries over into next month
	 *
	 */
	private boolean carryoverInd;

	/**
	 * "Off duty time related to the specific duty period ""0"" = Does not
	 * involves next month; ""1"" = involves next month"
	 *
	 */
	private boolean DPNextMonthInd;

	private Integer shrtDPFlyMins;

	private Integer shrtDPCRMins;

	private boolean intlDPPayInd;

	/**
	 * "DFW  "; Off duty layover city1
	 */
	private String offdutyLayoverCity1;

	/**
	 * "04"; Off duty layover half day counts associated with he layover city1
	 */
	private Integer offdutyLayoverHalfDayCount1;

	/**
	 * "DFW  "; Off duty layover city2
	 */
	private String offdutyLayoverCity2;

	/**
	 * "04"; Off duty layover half day counts associated with he layover city2
	 */
	private Integer offdutyLayoverHalfDayCount2;

	private Integer DPSigininYear;

	private Integer DPSigininMonth;

	private Integer DPSigininDay;

	private Integer DPSigininTime;

	private Integer fillS1;

	private Long fillS2;

	private Integer fillS3;

	private List<LegDataDto> legs;

	/**
	 * @return the sequentialNo
	 */
	public Integer getSequentialNo() {
		return sequentialNo;
	}

	/**
	 * @param sequentialNo the sequentialNo to set
	 */
	public void setSequentialNo(Integer sequentialNo) {
		this.sequentialNo = sequentialNo;
	}

	/**
	 * @return the dutyPeriodNo
	 */
	public Integer getDutyPeriodNo() {
		return dutyPeriodNo;
	}

	/**
	 * @param dutyPeriodNo the dutyPeriodNo to set
	 */
	public void setDutyPeriodNo(Integer dutyPeriodNo) {
		this.dutyPeriodNo = dutyPeriodNo;
	}

	/**
	 * @return the noapplicableLegInd
	 */
	public boolean isNoapplicableLegInd() {
		return noapplicableLegInd;
	}

	/**
	 * @param noapplicableLegInd the noapplicableLegInd to set
	 */
	public void setNoapplicableLegInd(boolean noapplicableLegInd) {
		this.noapplicableLegInd = noapplicableLegInd;
	}

	/**
	 * @return the shrtDutyPeriodInd
	 */
	public boolean isShrtDutyPeriodInd() {
		return shrtDutyPeriodInd;
	}

	/**
	 * @param shrtDutyPeriodInd the shrtDutyPeriodInd to set
	 */
	public void setShrtDutyPeriodInd(boolean shrtDutyPeriodInd) {
		this.shrtDutyPeriodInd = shrtDutyPeriodInd;
	}

	/**
	 * @return the scheduleStartDate
	 */
	public Integer getScheduleStartDate() {
		return scheduleStartDate;
	}

	/**
	 * @param scheduleStartDate the scheduleStartDate to set
	 */
	public void setScheduleStartDate(Integer scheduleStartDate) {
		this.scheduleStartDate = scheduleStartDate;
	}

	/**
	 * @return the rescheduledStartDate
	 */
	public Integer getRescheduledStartDate() {
		return rescheduledStartDate;
	}

	/**
	 * @param rescheduledStartDate the rescheduledStartDate to set
	 */
	public void setRescheduledStartDate(Integer rescheduledStartDate) {
		this.rescheduledStartDate = rescheduledStartDate;
	}

	/**
	 * @return the actualStartDate
	 */
	public Integer getActualStartDate() {
		return actualStartDate;
	}

	/**
	 * @param actualStartDate the actualStartDate to set
	 */
	public void setActualStartDate(Integer actualStartDate) {
		this.actualStartDate = actualStartDate;
	}

	/**
	 * @return the scheduledStartMins
	 */
	public Integer getScheduledStartMins() {
		return scheduledStartMins;
	}

	/**
	 * @param scheduledStartMins the scheduledStartMins to set
	 */
	public void setScheduledStartMins(Integer scheduledStartMins) {
		this.scheduledStartMins = scheduledStartMins;
	}

	/**
	 * @return the reScheduledStartMins
	 */
	public Integer getReScheduledStartMins() {
		return reScheduledStartMins;
	}

	/**
	 * @param reScheduledStartMins the reScheduledStartMins to set
	 */
	public void setReScheduledStartMins(Integer reScheduledStartMins) {
		this.reScheduledStartMins = reScheduledStartMins;
	}

	/**
	 * @return the actualStartMins
	 */
	public Integer getActualStartMins() {
		return actualStartMins;
	}

	/**
	 * @param actualStartMins the actualStartMins to set
	 */
	public void setActualStartMins(Integer actualStartMins) {
		this.actualStartMins = actualStartMins;
	}

	/**
	 * @return the scheduledEndDate
	 */
	public Integer getScheduledEndDate() {
		return scheduledEndDate;
	}

	/**
	 * @param scheduledEndDate the scheduledEndDate to set
	 */
	public void setScheduledEndDate(Integer scheduledEndDate) {
		this.scheduledEndDate = scheduledEndDate;
	}

	/**
	 * @return the reScheduledEndDate
	 */
	public Integer getReScheduledEndDate() {
		return reScheduledEndDate;
	}

	/**
	 * @param reScheduledEndDate the reScheduledEndDate to set
	 */
	public void setReScheduledEndDate(Integer reScheduledEndDate) {
		this.reScheduledEndDate = reScheduledEndDate;
	}

	/**
	 * @return the actualEndDate
	 */
	public Integer getActualEndDate() {
		return actualEndDate;
	}

	/**
	 * @param actualEndDate the actualEndDate to set
	 */
	public void setActualEndDate(Integer actualEndDate) {
		this.actualEndDate = actualEndDate;
	}

	/**
	 * @return the scheduledEndMins
	 */
	public Integer getScheduledEndMins() {
		return scheduledEndMins;
	}

	/**
	 * @param scheduledEndMins the scheduledEndMins to set
	 */
	public void setScheduledEndMins(Integer scheduledEndMins) {
		this.scheduledEndMins = scheduledEndMins;
	}

	/**
	 * @return the reScheduledEndMins
	 */
	public Integer getReScheduledEndMins() {
		return reScheduledEndMins;
	}

	/**
	 * @param reScheduledEndMins the reScheduledEndMins to set
	 */
	public void setReScheduledEndMins(Integer reScheduledEndMins) {
		this.reScheduledEndMins = reScheduledEndMins;
	}

	/**
	 * @return the actualEndMins
	 */
	public Integer getActualEndMins() {
		return actualEndMins;
	}

	/**
	 * @param actualEndMins the actualEndMins to set
	 */
	public void setActualEndMins(Integer actualEndMins) {
		this.actualEndMins = actualEndMins;
	}

	/**
	 * @return the startGMTAdjmtMins
	 */
	public Integer getStartGMTAdjmtMins() {
		return startGMTAdjmtMins;
	}

	/**
	 * @param startGMTAdjmtMins the startGMTAdjmtMins to set
	 */
	public void setStartGMTAdjmtMins(Integer startGMTAdjmtMins) {
		this.startGMTAdjmtMins = startGMTAdjmtMins;
	}

	/**
	 * @return the endGMTAdjmtMins
	 */
	public Integer getEndGMTAdjmtMins() {
		return endGMTAdjmtMins;
	}

	/**
	 * @param endGMTAdjmtMins the endGMTAdjmtMins to set
	 */
	public void setEndGMTAdjmtMins(Integer endGMTAdjmtMins) {
		this.endGMTAdjmtMins = endGMTAdjmtMins;
	}

	/**
	 * @return the legGreaterMins
	 */
	public Integer getLegGreaterMins() {
		return legGreaterMins;
	}

	/**
	 * @param legGreaterMins the legGreaterMins to set
	 */
	public void setLegGreaterMins(Integer legGreaterMins) {
		this.legGreaterMins = legGreaterMins;
	}

	/**
	 * @return the scheduledGateToGateMins
	 */
	public Integer getScheduledGateToGateMins() {
		return scheduledGateToGateMins;
	}

	/**
	 * @param scheduledGateToGateMins the scheduledGateToGateMins to set
	 */
	public void setScheduledGateToGateMins(Integer scheduledGateToGateMins) {
		this.scheduledGateToGateMins = scheduledGateToGateMins;
	}

	/**
	 * @return the actualGateToGateMins
	 */
	public Integer getActualGateToGateMins() {
		return actualGateToGateMins;
	}

	/**
	 * @param actualGateToGateMins the actualGateToGateMins to set
	 */
	public void setActualGateToGateMins(Integer actualGateToGateMins) {
		this.actualGateToGateMins = actualGateToGateMins;
	}

	/**
	 * @return the scheduledDutyPerCRMins
	 */
	public Integer getScheduledDutyPerCRMins() {
		return scheduledDutyPerCRMins;
	}

	/**
	 * @param scheduledDutyPerCRMins the scheduledDutyPerCRMins to set
	 */
	public void setScheduledDutyPerCRMins(Integer scheduledDutyPerCRMins) {
		this.scheduledDutyPerCRMins = scheduledDutyPerCRMins;
	}

	/**
	 * @return the actualDutyPerCRMins
	 */
	public Integer getActualDutyPerCRMins() {
		return actualDutyPerCRMins;
	}

	/**
	 * @param actualDutyPerCRMins the actualDutyPerCRMins to set
	 */
	public void setActualDutyPerCRMins(Integer actualDutyPerCRMins) {
		this.actualDutyPerCRMins = actualDutyPerCRMins;
	}

	/**
	 * @return the deadHeadMins
	 */
	public Integer getDeadHeadMins() {
		return deadHeadMins;
	}

	/**
	 * @param deadHeadMins the deadHeadMins to set
	 */
	public void setDeadHeadMins(Integer deadHeadMins) {
		this.deadHeadMins = deadHeadMins;
	}

	/**
	 * @return the schdOffDutyLayoverMins
	 */
	public Integer getSchdOffDutyLayoverMins() {
		return schdOffDutyLayoverMins;
	}

	/**
	 * @param schdOffDutyLayoverMins the schdOffDutyLayoverMins to set
	 */
	public void setSchdOffDutyLayoverMins(Integer schdOffDutyLayoverMins) {
		this.schdOffDutyLayoverMins = schdOffDutyLayoverMins;
	}

	/**
	 * @return the actualOffDutyLayoverMins
	 */
	public Integer getActualOffDutyLayoverMins() {
		return actualOffDutyLayoverMins;
	}

	/**
	 * @param actualOffDutyLayoverMins the actualOffDutyLayoverMins to set
	 */
	public void setActualOffDutyLayoverMins(Integer actualOffDutyLayoverMins) {
		this.actualOffDutyLayoverMins = actualOffDutyLayoverMins;
	}

	/**
	 * @return the carryoverInd
	 */
	public boolean isCarryoverInd() {
		return carryoverInd;
	}

	/**
	 * @param carryoverInd the carryoverInd to set
	 */
	public void setCarryoverInd(boolean carryoverInd) {
		this.carryoverInd = carryoverInd;
	}

	/**
	 * @return the dPNextMonthInd
	 */
	public boolean isDPNextMonthInd() {
		return DPNextMonthInd;
	}

	/**
	 * @param dPNextMonthInd the dPNextMonthInd to set
	 */
	public void setDPNextMonthInd(boolean dPNextMonthInd) {
		DPNextMonthInd = dPNextMonthInd;
	}

	/**
	 * @return the shrtDPFlyMins
	 */
	public Integer getShrtDPFlyMins() {
		return shrtDPFlyMins;
	}

	/**
	 * @param shrtDPFlyMins the shrtDPFlyMins to set
	 */
	public void setShrtDPFlyMins(Integer shrtDPFlyMins) {
		this.shrtDPFlyMins = shrtDPFlyMins;
	}

	/**
	 * @return the shrtDPCRMins
	 */
	public Integer getShrtDPCRMins() {
		return shrtDPCRMins;
	}

	/**
	 * @param shrtDPCRMins the shrtDPCRMins to set
	 */
	public void setShrtDPCRMins(Integer shrtDPCRMins) {
		this.shrtDPCRMins = shrtDPCRMins;
	}

	/**
	 * @return the intlDPPayInd
	 */
	public boolean isIntlDPPayInd() {
		return intlDPPayInd;
	}

	/**
	 * @param intlDPPayInd the intlDPPayInd to set
	 */
	public void setIntlDPPayInd(boolean intlDPPayInd) {
		this.intlDPPayInd = intlDPPayInd;
	}

	/**
	 * @return the offdutyLayoverCity1
	 */
	public String getOffdutyLayoverCity1() {
		return offdutyLayoverCity1;
	}

	/**
	 * @param offdutyLayoverCity1 the offdutyLayoverCity1 to set
	 */
	public void setOffdutyLayoverCity1(String offdutyLayoverCity1) {
		this.offdutyLayoverCity1 = offdutyLayoverCity1;
	}

	/**
	 * @return the offdutyLayoverHalfDayCount1
	 */
	public Integer getOffdutyLayoverHalfDayCount1() {
		return offdutyLayoverHalfDayCount1;
	}

	/**
	 * @param offdutyLayoverHalfDayCount1 the offdutyLayoverHalfDayCount1 to set
	 */
	public void setOffdutyLayoverHalfDayCount1(Integer offdutyLayoverHalfDayCount1) {
		this.offdutyLayoverHalfDayCount1 = offdutyLayoverHalfDayCount1;
	}

	/**
	 * @return the offdutyLayoverCity2
	 */
	public String getOffdutyLayoverCity2() {
		return offdutyLayoverCity2;
	}

	/**
	 * @param offdutyLayoverCity2 the offdutyLayoverCity2 to set
	 */
	public void setOffdutyLayoverCity2(String offdutyLayoverCity2) {
		this.offdutyLayoverCity2 = offdutyLayoverCity2;
	}

	/**
	 * @return the offdutyLayoverHalfDayCount2
	 */
	public Integer getOffdutyLayoverHalfDayCount2() {
		return offdutyLayoverHalfDayCount2;
	}

	/**
	 * @param offdutyLayoverHalfDayCount2 the offdutyLayoverHalfDayCount2 to set
	 */
	public void setOffdutyLayoverHalfDayCount2(Integer offdutyLayoverHalfDayCount2) {
		this.offdutyLayoverHalfDayCount2 = offdutyLayoverHalfDayCount2;
	}

	/**
	 * @return the dPSigininYear
	 */
	public Integer getDPSigininYear() {
		return DPSigininYear;
	}

	/**
	 * @param dPSigininYear the dPSigininYear to set
	 */
	public void setDPSigininYear(Integer dPSigininYear) {
		DPSigininYear = dPSigininYear;
	}

	/**
	 * @return the dPSigininMonth
	 */
	public Integer getDPSigininMonth() {
		return DPSigininMonth;
	}

	/**
	 * @param dPSigininMonth the dPSigininMonth to set
	 */
	public void setDPSigininMonth(Integer dPSigininMonth) {
		DPSigininMonth = dPSigininMonth;
	}

	/**
	 * @return the dPSigininDay
	 */
	public Integer getDPSigininDay() {
		return DPSigininDay;
	}

	/**
	 * @param dPSigininDay the dPSigininDay to set
	 */
	public void setDPSigininDay(Integer dPSigininDay) {
		DPSigininDay = dPSigininDay;
	}

	/**
	 * @return the dPSigininTime
	 */
	public Integer getDPSigininTime() {
		return DPSigininTime;
	}

	/**
	 * @param dPSigininTime the dPSigininTime to set
	 */
	public void setDPSigininTime(Integer dPSigininTime) {
		DPSigininTime = dPSigininTime;
	}

	/**
	 * @return the fillS1
	 */
	public Integer getFillS1() {
		return fillS1;
	}

	/**
	 * @param fillS1 the fillS1 to set
	 */
	public void setFillS1(Integer fillS1) {
		this.fillS1 = fillS1;
	}

	/**
	 * @return the fillS2
	 */
	public Long getFillS2() {
		return fillS2;
	}

	/**
	 * @param fillS2 the fillS2 to set
	 */
	public void setFillS2(Long fillS2) {
		this.fillS2 = fillS2;
	}

	/**
	 * @return the fillS3
	 */
	public Integer getFillS3() {
		return fillS3;
	}

	/**
	 * @param fillS3 the fillS3 to set
	 */
	public void setFillS3(Integer fillS3) {
		this.fillS3 = fillS3;
	}

	/**
	 * @return the legs
	 */
	public List<LegDataDto> getLegs() {
		return legs;
	}

	/**
	 * @param legs the legs to set
	 */
	public void setLegs(List<LegDataDto> legs) {
		this.legs = legs;
	}
	
	/**
	 * @param legData the legData to add
	 */
	public void addLegData(LegDataDto legData) {
		if(this.legs == null){
			this.legs = new ArrayList<LegDataDto>();
		}
		this.legs.add(legData);
	}
	
}
