/**
 * 
 */
package com.aa.crewpay.batchloader.dto;

/**
 * @author muthusba
 *
 */
public class BidStatusGroupDto {

	/**
	 * 2 numeric character that corresponds to a specific 3 character crew base
	 * i.e., "04" = "DFW"
	 */
	private Integer seqCrewBase;

	/**
	 * 2 numeric character position code, i.e. "01" = CA
	 */
	private Integer positionCode;

	/**
	 * 2 character equipment code, i.e., "35" = S80
	 */
	private Integer equipmentCode;

	/**
	 * "D" or "I"
	 */
	private String domIntlCode;

	/**
	 * effective Date - YYYYMMDD
	 */
	private Integer effDate;

	/**
	 * Number of months crewmwmber is locked in to the current 4/2 part bid
	 * status?Need to determine
	 */
	private Integer lockedInMonQty;

}
