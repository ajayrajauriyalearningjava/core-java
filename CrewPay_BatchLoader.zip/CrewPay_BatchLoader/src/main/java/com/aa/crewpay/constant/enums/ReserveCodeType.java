/**
 * 
 */
package com.aa.crewpay.constant.enums;

/**
 * @author muthusba
 *
 */
public enum ReserveCodeType {

	/**
	 * '1' - READY.
	 */
	READY(1),

	/**
	 * '2' - CALL IN
	 */
	CALL_IN(2);

	/**
	 * Attribute to hold the ReserveCodeType <code>type</code>.
	 */
	private Integer type;

	/**
	 * <code>Parameterized constructor.</code>
	 * <p>
	 * 
	 * @param pType
	 *            the new value of the <code>type</code> property.
	 */
	ReserveCodeType(Integer pType) {
		type = pType;
	}

	/**
	 * Gets the <code>type</code> property.
	 * <p>
	 * 
	 * @return the current value of the <code>type</code> property.
	 */
	public int getType() {
		return this.type;
	}

	/**
	 * Gives the string format of enumerated <code>ReserveCodeType</code>.
	 * <p>
	 * 
	 * @return the current value of the <code>ReserveCodeType</code>.
	 */
	public String value() {
		return this.name();
	}
}
