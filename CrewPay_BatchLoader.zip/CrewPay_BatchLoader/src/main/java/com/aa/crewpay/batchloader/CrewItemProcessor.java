package com.aa.crewpay.batchloader;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;

import com.aa.crewpay.batchloader.dto.BaseDTO;
import com.aa.crewpay.batchloader.dto.CrewMemberDto;
import com.aa.crewpay.batchloader.translator.CrewMemberTranslator;
import com.aa.crewpay.domain.CrewMember;

public class CrewItemProcessor implements ItemProcessor<BaseDTO, CrewMember> {

	@Autowired
    public CrewMemberTranslator crewMemberTranslator;
	
    private static final Logger log = LoggerFactory.getLogger(CrewItemProcessor.class);

    @Override
    public CrewMember process(final BaseDTO baseDTO) throws Exception {
        
    	log.info("***********************			PersonItemProcessor	****************************************************");
    	
    	crewMemberTranslator.mapDtoToDomain((CrewMemberDto)baseDTO);
    	
    	log.info("*******************************************						****************************************");
    	
        return new CrewMember();
    }

}
