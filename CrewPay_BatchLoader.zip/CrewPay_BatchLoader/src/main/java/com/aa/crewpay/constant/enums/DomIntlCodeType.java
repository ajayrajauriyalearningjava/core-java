/**
 * 
 */
package com.aa.crewpay.constant.enums;

/**
 * <code>DomIntlCodeType</code> class holds the DomIntlCodeType constants.
 * <p>
 *
 * @author muthusba
 */
public enum DomIntlCodeType {

	/**
	 * 'D' - Domestic.
	 */
	DOMESTIC("D"),

	/**
	 * 'I' - International
	 */
	INTERNATIONAL("I");

	/**
	 * Attribute to hold the Domestic/International <code>type</code>.
	 */
	private String type;

	/**
	 * <code>Parameterized constructor.</code>
	 * <p>
	 * 
	 * @param pType
	 *            the new value of the <code>type</code> property.
	 */
	DomIntlCodeType(String pType) {
		type = pType;
	}

	/**
	 * Gets the <code>type</code> property.
	 * <p>
	 * 
	 * @return the current value of the <code>type</code> property.
	 */
	public String getType() {
		return this.type;
	}

	/**
	 * Gives the string format of enumerated <code>DomIntlCodeType</code>.
	 * <p>
	 * 
	 * @return the current value of the <code>DomIntlCodeType</code>.
	 */
	public String value() {
		return this.name();
	}
}
