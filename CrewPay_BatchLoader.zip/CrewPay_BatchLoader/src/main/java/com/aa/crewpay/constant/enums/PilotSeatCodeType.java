/**
 * 
 */
package com.aa.crewpay.constant.enums;

/**
 * @author muthusba
 *
 */
public enum PilotSeatCodeType {

	/**
	 * '1' - CAPTAIN.
	 */
	CAPTAIN(1),

	/**
	 * '2' - FIRST OFFICER
	 */
	FIRSTOFFICER(2),
	
	/**
	 * '3' - FLIGHT ENGINEER 
	 */
	FLIGHTENGINEER(3);

	/**
	 * Attribute to hold the PilotSeatCode <code>type</code>.
	 */
	private Integer type;

	/**
	 * <code>Parameterized constructor.</code>
	 * <p>
	 * 
	 * @param pType
	 *            the new value of the <code>type</code> property.
	 */
	PilotSeatCodeType(Integer pType) {
		type = pType;
	}

	/**
	 * Gets the <code>type</code> property.
	 * <p>
	 * 
	 * @return the current value of the <code>type</code> property.
	 */
	public int getType() {
		return this.type;
	}

	/**
	 * Gives the string format of enumerated <code>PilotSeatCodeType</code>.
	 * <p>
	 * 
	 * @return the current value of the <code>PilotSeatCodeType</code>.
	 */
	public String value() {
		return this.name();
	}
}
