package com.aa.crewpay.converter.enums;

import javax.persistence.AttributeConverter;

import org.springframework.stereotype.Component;

import com.aa.crewpay.constant.enums.ReserveCodeType;

@Component
public class ReserveCodeTypeConverter implements AttributeConverter<ReserveCodeType, Integer> {

	@Override
	public Integer convertToDatabaseColumn(ReserveCodeType attribute) {
		if(attribute != null)
			return attribute.getType();
		else
			return null;
	}

	@Override
	public ReserveCodeType convertToEntityAttribute(Integer dbData) {
		switch (dbData) {
			case 1: return ReserveCodeType.READY;
			case 2: return ReserveCodeType.CALL_IN;
		}
		return null;
	}

}
