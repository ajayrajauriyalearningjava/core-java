/**
 * 
 */
package com.aa.crewpay.constant.enums;

/**
 * @author muthusba
 *
 */
public enum TripSelectCodeType {

	/**
	 * '0' - PI REG COCKPIT / FA INACTIVE.
	 */
	PI_REG_COCKPIT_OR_FA_INACTIVE(0),

	/**
	 * '1' - RSV
	 */
	RSV(1),
	
	/**
	 * '2' - SECOND ROUND (was SUPNUM)
	 */
	SECOND_ROUND(2),
	
	/**
	 * '3' - RELIEF 
	 */
	RELIEF(3),
	
	/**
	 * '4' - REG REPL(referred to as Open Replacement; CAN HAVE AVBL DAYS).
	 */
	REG_REPL(4),

	/**
	 * '5' -  REG_REG (CAN HAVE AVBL DAYS
	 */
	 REG_REG(5),
	
	/**
	 * '6' - RSV READY
	 */
	 RSV_READY(6),
	
	/**
	 * '7' - RSV CALLIN 
	 */
	 RSV_CALLIN(7),
	 
	/**
	 * '8' - RSV READY
	 */
	 REG_AVAIL(8),
	
	/**
	 * '9' - REG RELIEF 
	 */
	 REG_RELIEF(9);

	/**
	 * Attribute to hold the Domestic/International <code>type</code>.
	 */
	private Integer type;

	/**
	 * <code>Parameterized constructor.</code>
	 * <p>
	 * 
	 * @param pType
	 *            the new value of the <code>type</code> property.
	 */
	TripSelectCodeType(Integer pType) {
		type = pType;
	}

	/**
	 * Gets the <code>type</code> property.
	 * <p>
	 * 
	 * @return the current value of the <code>type</code> property.
	 */
	public int getType() {
		return this.type;
	}

	/**
	 * Gives the string format of enumerated <code>CrewCodeType</code>.
	 * <p>
	 * 
	 * @return the current value of the <code>CrewCodeType</code>.
	 */
	public String value() {
		return this.name();
	}
}
