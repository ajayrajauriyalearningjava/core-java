/**
 *
 */
package com.aa.crewpay.domain;

import java.util.Date;
import java.util.List;

import com.aa.crewpay.constant.enums.DomIntlCodeType;
import com.aa.crewpay.constant.enums.PositionCodeType;
import com.aa.crewpay.constant.enums.SequenceStateCodeType;

/**
 * @author muthusba
 *
 */
public class SequenceData {


	private Integer seqNo;

	/**
	 * SEQUENCE REASSIGNMENT NUMBER GROUPING OF SEQUENCES ORIGINALLY SCHEDULE
	 * AND REASSIGNED. HAS VALUE ONLY ON THIS MONTH SEQ, NOT CARRYOVER - If it's
	 * a carryover from APR into MAY, the sequence in the APR FCRM will have a
	 * value but the MAY FCRM will not.
	 */
	private Integer reassignmentNo;

	/**
	 * SEQ REMOVAL CODE
	 */
	private Integer removalReasonCode;

	/**
	 * SEQUENCE LEVEL NUMBER FOR REMOVED SEQUENCE - This is the Trip Trade Level
	 * number which appears on both added and removed sequences to show that
	 * they are "married" to each other.
	 */
	private Integer levelNumberRemoved;

	/**
	 * Scheduled Date & Time
	 */
	private DateTimeRange scheduledDT;

	/**
	 * ReScheduled Date & Time
	 */
	private DateTimeRange reScheduledDT;

	/**
	 * Actual Date & Time
	 */
	private DateTimeRange actualDT;

	/*	*//**
			 * SEQ SCHEDULED START DATE: YYYYMMDD
			 */
	/*
	 * private Date scheduleStartDate;
	 *
	 *//**
		 * RESCHEDULED START DATE OF SEQUENCE: YYYYMMDD This is driven by a
		 * manual sign in time that has been entered into the crewmember's
		 * sequence on the 1st duty period. If it exists, this field gets
		 * populated.
		 *
		 */
	/*
	 * private Date rescheduledStartDate;
	 *
	 *//**
		 * ACTUAL START DATE OF SEQUENCE: YYYYMMDD
		 */
	/*
	 * private Date actualStartDate;
	 *
	 *//**
		 * SCHEDULED START MINS OF SEQUENCE. THIS IS THE SCHEDULED GMT ON WHICH
		 * AN ACTIVITY OR EVENT IS SCHEDULED TO START : MMMM. Note: The
		 * difference between this SCHD_STR_MNS in record 02 versus that in
		 * record 04 is the 1hrs sign-in difference.
		 *
		 */
	/*
	 * private Integer scheduledStartMins;
	 *
	 *//**
		 * RESCHEDULED START MINS OF SEQUENCE. Note: if there is a RESCHEDULED
		 * START DATE then there is a RESCHEDULED START MINS populated. THIS IS
		 * THE RSCHD GMT ON WHICH AN ACTIVITY OR EVENT IS RESCHEDULED TO START :
		 * MMMM
		 */
	/*
	 * private Integer reScheduledStartMins;
	 *
	 *//**
		 * ACTUAL START MINS OF SEQUENCE. THIS IS THE ACTUAL GMT ON WHICH AN
		 * ACTIVITY OR EVENT ACTUALLY STARTED : MMMM THERE ARE VALUES IN ACTUAL
		 * DATE AND MINS FOR REMOVED SEQUENCE, JUST EQUALS SCHEDULED. It fills
		 * in the actual anyway, even though the sequence has been removed off
		 * of the crewmember's schedule, so they use the SCHD value to fill in
		 * the ACTL value.
		 */
	/*
	 * private Integer actualStartMins;
	 *
	 *//**
		 * SCHEDULED END DATE OF SEQUENCE: YYYYMMDD
		 */
	/*
	 * private Date scheduledEndDate;
	 *
	 *//**
		 * RESCHEDULED END DATE OF SEQUENCE: YYYYMMDD
		 */
	/*
	 * private Date reScheduledEndDate;
	 *
	 *//**
		 * ACTUAL END DATE OF SEQUENCE: YYYYMMDD
		 */
	/*
	 * private Date actualEndDate;
	 *
	 *//**
		 * THIS IS RELATIVE TO THE SCHEDULED START MINS ABOVE
		 */
	/*
	 * private Integer scheduledEndMins;
	 *
	 *//**
		 * THIS IS RELATIVE TO THE RESCHEDULED START MINS ABOVE
		 */
	/*
	 * private Integer reScheduledEndMins;
	 *
	 *//**
		 * THIS IS RELATIVE TO THE ACTUAL START MINS ABOVE
		 *//*
		 * private Integer actualEndMins;
		 */
	/**
	 * THIS IS THE GMT TIME IN MINUTES FOR THE SCHEDULED START MINS
	 */
	private Integer startGMTAdjmtMins;

	/**
	 * THIS IS THE GMT TIME IN MINUTES FOR THE SCHEDULED END MINS
	 */
	private Integer endGMTAdjmtMins;

	/**
	 * APPEARS TO BE BID SHEET DAYS. NUMBER OF DAYS REQUIRED TO COMPLETE THIS
	 * SET OF FLIGHT LEGS.
	 */
	private Integer segOprgDaysQty;

	private Integer seqCrewBase;

	/**
	 * HIGH EQUIPMENT TYPE CODE - 2 DIGIT CODE Ex: 'AF'
	 */
	private String highEqpTypeCode;

	/**
	 * DOMESTIC OR INTERNATIONAL CODE: "D" OR "I"
	 */
	private DomIntlCodeType domIntlCode;

	/**
	 * Will have 1 on Seq part of denied bid line (SEQ RMV = 146, 147) SPECIFIES
	 * WHETHER OR NOT A SEQUENCE HAS ANY LEGS WHICH HAVE NOT BEEN CANCELLED. 0 =
	 * NO 1= YES.
	 *
	 */
	private boolean noAplbeLegInd;

	/**
	 * MISSING DATA INDICATOR This specifies whether or not a sequence is
	 * missing one or more of the leg times. 0=No Data Missing 1=Data missing
	 *
	 */
	private boolean missingDataInd;

	/**
	 * FAILED CONTINUITY INDICATOR
	 */
	private boolean failedContinuityInd;

	private SequenceStateCodeType segStateCode;

	private boolean changeOverInd;

	private boolean carryOverInd;

	/**
	 * WE THINK THIS TURNS ON WHEN IT'S A VM POS, BUT WE HAVE A SEQUENCE
	 * POSITION LATER AND WE JUST USE THAT TO FIND OUT WHAT POSITION IT IS.
	 *
	 */
	private boolean varMangInd;

	/**
	 * SPECIFIES WHETHER THE CORRESPONDING ITEM IS TAXABLE. 1=ITEM IS TAXABLE 2=
	 * ITEM IS NOT TAXABLE
	 *
	 * TODO -- enumeration ??
	 */
	private String taxInd;

	/**
	 * NUMBER OF DUTY PERIODS IN SEQUENCE, INCLUDING ANY REMOVED OR CANCELLED
	 * DUTY PERIODS. (Implies that it comes from the allocation and doesn't get
	 * updated)
	 */
	private Integer dutyPeriodQty;

	/**
	 * NUMBER OF LEGS IN SEQUENCE, INCLUDING ANY DEADHEAD, REMOVED OR CANCELLED
	 * LEGS. (Implies that it comes from the allocation and doesn't get updated)
	 */
	private Integer SegLegQty;

	/**
	 * REPLACED CHANGEOVER SEQUENCE NUMBER - identifies the sequence number that
	 * was replaced due to a changeover.
	 */
	private Integer replacedChgOverSeqNo;

	/**
	 * POSITION CODE IS A NUMBERIC VALUE THAT COMES FROM TABLE. EX: 01 = CA, 22=
	 * #1 FA
	 *
	 */
	private PositionCodeType positionCode;

	/**
	 * GREATER OF ALL THE SCHEDULED AND ACTUAL LEGS
	 *
	 */
	private Integer legGreaterMins;

	/**
	 * -. FLY TIME THIS IS THE SCHEDULED VALUE OF ALL THE LEGS
	 *
	 */
	private Integer scheduledGateToGateMins;

	/**
	 * _� <-INCLUDES RCD, DEI, ATC. THIS IS THE TOTAL ACTUAL FLYING OF ALL THE
	 * LEGS. IT'S INCLUDED DUE TO PAY PURPOSES.
	 *
	 */
	private Integer actualGateToGateMins;

	/**
	 * -. E TIME SCHEDULED
	 */
	private Integer scheduledDutyPerCRMins;

	/**
	 * _� ACTUAL E TIME
	 */
	private Integer actualDutyPerCRMins;

	/**
	 * -. F TIME SCHEDULED
	 */
	private Integer scheduledSeqCRMins;

	/**
	 * _� <-THIS INCLUDES 8F TIME, WHICH IS CREDITED, SO ADDING THIS INTO SEQVAL
	 * WILL NOT MATCH DECS WHEN THERE IS 8F. ACTUAL F TIME.
	 *
	 */
	private Integer actualSeqCRMins;

	/**
	 * - RPT ! THE REPORT TIME IN THE SEQUENCE IS INCLUDED IN THIS FIELD (The
	 * flight shows RPT in the dhd field instead of AA for the DHD airline)
	 */
	private Integer deadHeadMins;

	/**
	 * NITEPAY2; hours actually flown between hours of 2400 and 0559;
	 */
	private Integer schdNightPayMins;

	/**
	 * NITEPAY1; hours actually flown between hours of 2045 and 2359;
	 *
	 */
	private Integer nightPayMins;

	/**
	 * REASSINGMENT PAY MINS - THE NBR OF MINS A FLT ATT WILL BE CREDITED ABOVE
	 * THOSE FOR ACTUAL WORK PERFORMED WEN REMOVED FROM ONE WORK ASSIGNMENT AND
	 * REASSIGNED TO ANOTHER OF LESSER VALUE. (It implies that this would show
	 * on the flown sequence only).
	 *
	 */
	private Integer reassignPayMins;

	/**
	 * CAN'T TRUST THIS TO BE 1 FOR SEQ W/ADD CODE OF ZERO (ORIGINAL SCHEDULE)
	 * SPECIFIES WHETHER A GIVEN SEQUENCE WAS GENERATED FROM THE ORIGINAL FLT
	 * ALLOCATION SCHEDULE (BID LINE) OR WAS CREATED LATER BY FLT OPERATIONS. 0
	 * = UNSCHEDULE 1=ORIG ALLOCATION.
	 *
	 */
	private boolean originalSchInd;

	/**
	 * specifies whether an activity is still on their schedule and not removed
	 * or cancelled or reassigned. 0=Not currently schedule 1= currently
	 * scheduled
	 *
	 */
	private boolean currentSchActyInd;

	/**
	 * SEQUENCE CONTRACTUAL PATH INDICATOR 0=FOR SUPVSR FLYING, 6=PAY ONLY, 1=
	 * CREDIT ONLY, 7=PAY AND CREDIT
	 *
	 */
	private Integer seqControlPathInd;

	/**
	 * "SEQUENCE CONTRACTUAL PATH INDICATOR 0=FOR SUPVSR FLYING, 6=PAY ONLY, 1=
	 * CREDIT ONLY, 7=PAY AND CREDIT "
	 *
	 */
	private Integer seqActualPathInd;

	/**
	 * SEQ ADD CODE. if = 0, then was originally allocated to the FA in the bid
	 * line. Translate this with the GJA table. IF a FA sequence and the add
	 * code = 0, and the rmvl code = 146 or 147, then this was not on their
	 * original schedule. It was a "denied" bid and these were the sequences in
	 * the denied bid.
	 *
	 */
	private Integer assignmentReasonCode;

	/**
	 * INDICATES WHETHER A SEQUENCE INCLUDES ANY FLIGHT LEGS THAT WERE
	 * REASSIGNMENTS. Y=YES N=NO
	 */
	// @Convert(converter=BooleanToYNConverter.class)
	private boolean partialReassignmentInd;

	/**
	 * "This is whether the sequence has been removed and will be credited. EX:
	 * VC. =0 IF NOT CREDITED, =1 IF CREDITED"
	 *
	 */
	private boolean removedCreditActivityInd;

	/**
	 * SUPERVISOR OPEN SEQUENCE INDICATOR - indicates whether a supervisor is
	 * flying a sequence that came from open time.
	 *
	 */
	private boolean supervisorOpenSeqInd;

	/**
	 * SHORT DUTY PERIOD FLYING MINUTES - THE TTL NUMBER OF MINS A CREWMEMBER
	 * HAS FLOWN BASED ON A SHORT DUTY PERIOD REFER TO CONTRACTUAL AGREEMENT B/W
	 * AA PILOTS AND ALPA, ATR 21E, ITEM 2.
	 *
	 */
	private Integer shortDutyPeriodFlyMins;

	/**
	 * SHORT DUTY PERIOD CREDIT MINUTES - THE TTL NUMBER OF MINS A CREWMEMBER IS
	 * CREDITED BASED ON A SHORT DUTY PERIOD REFER TO CONTRACTUAL AGREEMENT B/W
	 * AA PILOTS AND ALPA, ATR 21E, ITEM 2.
	 *
	 */
	private Integer shortDutyPeriodCreditMins;

	/**
	 * Number of variable mins scheduled for flt leg.
	 *
	 */
	private Integer variableFlyMins;

	/**
	 * FLIGHT ENGINEER APPROVED A INDICATOR. (We think this was for A scale pay
	 * rates)
	 */
	// @Convert(converter=BooleanToYNConverter.class)
	private boolean FEPrimaryApprovedInd;

	/**
	 * PILOT APPROVED A INDICATOR. (We think this was for A scale pay rates)
	 */
	// @Convert(converter=BooleanToYNConverter.class)
	private boolean pilotPrimaryApprovedInd;

	/**
	 * FLIGHT ENGINEER APPROVED B INDICATOR. (We think this was for B scale pay
	 * rates)
	 */
	// @Convert(converter=BooleanToYNConverter.class)
	private boolean FESecondaryApprovedInd;

	/**
	 * PILOT APPROVED B INDICATOR. (We think this was for B scale pay rates)
	 */
	// @Convert(converter=BooleanToYNConverter.class)
	private boolean pilotSecondaryApprovedInd;

	/**
	 * BLOCKED FOR IE
	 */
	// @Convert(converter=BooleanToYNConverter.class)
	private boolean blockedInd;

	/**
	 * IF ON THEN G TIME IS HIGHER THAN F TIME, SO VALUE IN F TIME WILL INCLUDE
	 * G TIME - SCHEDULED
	 */
	// @Convert(converter=BooleanToYNConverter.class)
	private boolean scheduledCRMinsInd;

	/**
	 * IF ON THEN G TIME IS HIGHER THAN F TIME, SO VALUE IN F TIME WILL INCLUDE
	 * G TIME - ACTUAL
	 *
	 */
	// @Convert(converter=BooleanToYNConverter.class)
	private boolean actualCRMinsInd;

	/**
	 * UNBLOCKED FOR IE
	 */
	// @Convert(converter=BooleanToYNConverter.class)
	private boolean unblockedInd;

	/**
	 * SEQUENCE LEVEL NUMBER FOR ADDED SEQUENCE - This is the Trip Trade Level
	 * number which appears on both added and removed sequences to show that
	 * they are "married" to each other.
	 */
	private Integer levelNoAddSeq;

	/**
	 * USED FOR EXPENSES-NOT F TIME CALC, SOME SPECIAL CASES HAVE MINUTES NOT
	 * INCLUDED FOR EXPENSES. TAFB IS ZERO FOR REMOVED SEQ. IS 0 FOR SAM FA ACT
	 * SEQ TAFB = SEQ_TAFB +AND SUP FLYING. MAX(0,(SSEQEND-ASEQEND)); ON HSS
	 * DISPLAY, THIS FIELD IS ON THE TAXABLE EXP LINE, NOT THE TAFB LINE.
	 *
	 */
	private Integer SeqTAFBMins;

	/**
	 * VMC DEADHEAD MINS IN THE ORIGINATING MONTH
	 *
	 */
	private Integer vmcDeadheadMinsOrigMth;

	/**
	 * VMC DEADHEAD MINS IN THE CARRYOVER MONTH
	 *
	 */
	private Integer vmcDeadheadMinsCarryoverMth;

	/**
	 * SOMETHING ABOUT PAY MAX MIN?
	 */
	private Integer seqRemoval75Mins;

	/**
	 * ORIGINAL VALUE AT TIME OF INITIAL LOAD. ONLY ON SEQUENCES THAT WERE THERE
	 * AT THE TIME OF THE INITIAL LOAD. SO NOT THERE FOR CREW SCHEDULE-BUILT
	 * SEQUENCES.
	 *
	 */
	private Integer originalSeqVal;

	/**
	 * ORIGINAL START DATE AT TIME OF INITIAL LOAD. ONLY ON SEQUENCES THAT WERE
	 * THERE AT THE TIME OF THE INITIAL LOAD. SO NOT THERE FOR CREW
	 * SCHEDULE-BUILT SEQUENCES.
	 *
	 */
	private Date originalSeqStartDate;

	/**
	 * ORIGINAL SEQ START TIME AT TIME OF INITIAL LOAD. ONLY ON SEQUENCES THAT
	 * WERE THERE AT THE TIME OF THE INITIAL LOAD. SO NOT THERE FOR CREW
	 * SCHEDULE-BUILT SEQUENCES.
	 *
	 */
	private Integer originalSeqStartTime;

	/**
	 * THE PARTITION WHERE THE SEQ CAME FROM. AA OR TW
	 *
	 */
	private String operAirline;

	/**
	 * FOR A CARRYOVER SEQ, THIS IS THE VALUE OF THE SEQ IN THE PREV MONTH.
	 * SCHEDULED, NOT ACTUAL.
	 *
	 */
	private Integer previousMnthSeqValue;

	/**
	 * FOR A CARRYOVER SEQ, THIS IS THE VALUE OF THE SEQ IN THE NEXT MONTH.
	 * SCHEDULED, NOT ACTUAL.
	 *
	 */
	private Integer nextMnthSeqValue;

	private String homeBaseRest;

	private Long fillS1;

	private Long fillS2;
	
	private List<DutyPeriodData> dutyPeriods;

}
