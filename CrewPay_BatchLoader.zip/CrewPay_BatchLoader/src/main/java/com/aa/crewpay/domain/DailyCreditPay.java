/**
 * 
 */
package com.aa.crewpay.domain;

/**
 * @author muthusba
 *
 */
public class DailyCreditPay {

	private Integer dailyCredit;
	
	private Integer dailyPay;
	
}
