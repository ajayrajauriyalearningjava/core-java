package com.aa.crewpay.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class CrewCompPropertiesLoader {
	
	private static final Logger log = LoggerFactory.getLogger(CrewCompPropertiesLoader.class);
	private static Properties properties = null;

    public static String get(String propertyName) {
		
		if (properties == null) {		
			properties = new Properties();
			InputStream inputStream = null;
			inputStream = CrewCompPropertiesLoader.class.getClassLoader().getResourceAsStream("crewpayload.properties");
			try {
				properties.load(inputStream);
			} catch (IOException e) {
				log.error("Exeption in loading properties", e);
				e.printStackTrace();
			}
			try {
				if (inputStream != null)
					inputStream.close();
			} catch (IOException e) {
				log.error("Exception in Input Stream", e);
				e.printStackTrace();
			}
			inputStream = null;
		}
		return properties.getProperty(propertyName);
	}
	/**/

}