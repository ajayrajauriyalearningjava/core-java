package com.aa.crewpay.converter.enums;

import javax.persistence.AttributeConverter;

import org.springframework.stereotype.Component;

import com.aa.crewpay.constant.enums.DomIntlCodeType;

@Component
public class DomIntlConverter implements AttributeConverter<DomIntlCodeType, String> {

	@Override
	public String convertToDatabaseColumn(DomIntlCodeType attribute) {
		if(attribute != null)
			return attribute.getType();
		else
			return null;
	}

	@Override
	public DomIntlCodeType convertToEntityAttribute(String dbData) {
		switch (dbData) {
			case "D": return DomIntlCodeType.DOMESTIC;
			case "I": return DomIntlCodeType.INTERNATIONAL;
		}
		return null;
	}
	
	public static DomIntlCodeType convertToEnum(String dbData) {
		switch (dbData) {
			case "D": return DomIntlCodeType.DOMESTIC;
			case "I": return DomIntlCodeType.INTERNATIONAL;
		}
		return null;
	}

}
