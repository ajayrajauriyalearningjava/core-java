package com.aa.crewpay.converter.enums;

import javax.persistence.AttributeConverter;

import org.springframework.stereotype.Component;

import com.aa.crewpay.constant.enums.SelectionReasonCodeType;

@Component
public class SelectionReasonCodeTypeConverter implements AttributeConverter<SelectionReasonCodeType, String> {

	@Override
	public String convertToDatabaseColumn(SelectionReasonCodeType attribute) {
		if(attribute != null)
			return attribute.getType();
		else
			return null;
	}

	@Override
	public SelectionReasonCodeType convertToEntityAttribute(String dbData) {
		switch (dbData) {
			case "N": return SelectionReasonCodeType.ACTIVE;
			case "I": return SelectionReasonCodeType.INACTIVE;
			case "S": return SelectionReasonCodeType.SUPERVISOR;
		}
		return null;
	}

}
