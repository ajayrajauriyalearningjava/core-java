package com.aa.crewpay.batchloader.dto;

public class PilotGroupDto {

	private String equipment;

	private Integer regularMaxScheduledHrs;

	private Integer reserveMaxScheduledHrs;

	private boolean flexMoInd;

	private Integer captainSpare;

	private Integer firstOfficerSpare;
}
