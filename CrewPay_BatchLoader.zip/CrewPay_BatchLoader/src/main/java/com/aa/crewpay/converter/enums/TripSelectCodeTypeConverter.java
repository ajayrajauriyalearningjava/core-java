package com.aa.crewpay.converter.enums;

import javax.persistence.AttributeConverter;

import org.springframework.stereotype.Component;

import com.aa.crewpay.constant.enums.TripSelectCodeType;

@Component
public class TripSelectCodeTypeConverter implements AttributeConverter<TripSelectCodeType, Integer> {

	@Override
	public Integer convertToDatabaseColumn(TripSelectCodeType attribute) {
		if(attribute != null)
			return attribute.getType();
		else
			return null;
	}

	@Override
	public TripSelectCodeType convertToEntityAttribute(Integer dbData) {
		switch (dbData) {
			case 0: return TripSelectCodeType.PI_REG_COCKPIT_OR_FA_INACTIVE;
			case 1: return TripSelectCodeType.RSV;
			case 2: return TripSelectCodeType.SECOND_ROUND;
			case 3: return TripSelectCodeType.RELIEF;
			case 4: return TripSelectCodeType.REG_REPL;
			case 5: return TripSelectCodeType.REG_REG;
			case 6: return TripSelectCodeType.RSV_READY;
			case 7: return TripSelectCodeType.RSV_CALLIN;
			case 8: return TripSelectCodeType.REG_AVAIL;
			case 9: return TripSelectCodeType.REG_RELIEF;
		}
		return null;
	}

}
