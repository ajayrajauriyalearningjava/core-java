/**
 * 
 */
package com.aa.crewpay.batchloader.dto;

/**
 * @author muthusba
 *
 */
public class EquipmentQualificationDto {

	/**
	 * 2 character equip code (or "00") for each equip the crewmember is
	 * qualified on up to 10 equipments. The 2 character passed for the fleet
	 * type qualification appears in the 1st 2 character equipment associated to
	 * the fleet type from the JQ*ALL record in FOS. From the JQ - 777 fleet =
	 * "777   772P  AF   772A  AE" the first 2 character code is "AF" so this is
	 * the equipment that would be passed for each crewmember with a
	 * qualification on the 777.
	 */
	private String equipment;
	
	/**
	 * """P"" = PRIOR, ""*"" = CURRENT, ""M"" = PRIOR (MANUAL DEL), ""L"
	 * " = CURRENT AND NEED LINECHECK, ""R"" = CURRENT (RESTRICTED) or ("" "");
	 * For each of the 10 equipment qualifications in the prior record there
	 * will be 3 position code records (so equp 1 the pos (1,1 (CA)), (1,2(FO)),
	 * (1,3(FE)) with the crewmember current qualification indicator for that
	 * seat."
	 */
	private String eqpQualCodeTypes;
	
	/**
	 * "(1) ""*"" = CURRENT, ""P"" = EXPIRED, ""G"" = ? or "" "" (2) ""I"" =
	 * INTL, ""P"" = PREV, ""D"" = (I did not see any ""D"" indicators so maybe
	 * ""D"" is assumed and ""I"" is passed when current on International and
	 * ""P"" is passed when pervious on international BUT emp#656052 has ""I""
	 * for equipment ""36"" which is S80) or "" ""; For each of the 10 equipment
	 * qualifications in the prior record there will be 2 qualification records
	 * (so equp 1 the qlftn (1,1 (equipment currancy)), (1,2(International
	 * currancy?)), with the crewmember current qualification indicator."
	 * 
	 */
	private String faQualCodeTypes;

	/**
	 * @return the equipment
	 */
	public String getEquipment() {
		return equipment;
	}

	/**
	 * @param equipment the equipment to set
	 */
	public void setEquipment(String equipment) {
		this.equipment = equipment;
	}

	/**
	 * @return the eqpQualCodeTypes
	 */
	public String getEqpQualCodeTypes() {
		return eqpQualCodeTypes;
	}

	/**
	 * @param eqpQualCodeTypes the eqpQualCodeTypes to set
	 */
	public void setEqpQualCodeTypes(String eqpQualCodeTypes) {
		this.eqpQualCodeTypes = eqpQualCodeTypes;
	}

	/**
	 * @return the faQualCodeTypes
	 */
	public String getFaQualCodeTypes() {
		return faQualCodeTypes;
	}

	/**
	 * @param faQualCodeTypes the faQualCodeTypes to set
	 */
	public void setFaQualCodeTypes(String faQualCodeTypes) {
		this.faQualCodeTypes = faQualCodeTypes;
	}
	
	
}
