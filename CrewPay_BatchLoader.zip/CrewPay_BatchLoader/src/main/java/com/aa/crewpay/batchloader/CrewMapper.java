package com.aa.crewpay.batchloader;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.mapping.PatternMatchingCompositeLineMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;
import org.springframework.batch.item.file.transform.Range;
import org.springframework.batch.item.file.transform.RangeArrayPropertyEditor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.aa.crewpay.batchloader.dto.BaseDTO;
import com.aa.crewpay.batchloader.dto.CrewMemberDto;
import com.aa.crewpay.batchloader.dto.DutyPeriodDataDto;
import com.aa.crewpay.batchloader.dto.LegDataDto;
import com.aa.crewpay.batchloader.dto.SequenceDataDto;
import com.aa.crewpay.util.CrewCompPropertiesLoader;

@Configuration
@Service("CrewMapper")
public class CrewMapper {

	private static final Logger log = LoggerFactory.getLogger(CrewMapper.class);

	public LineMapper<com.aa.crewpay.batchloader.dto.BaseDTO> crewLineMapper() throws Exception {

		log.info("personlineMapper()");
		PatternMatchingCompositeLineMapper<BaseDTO> compositeLineMapper = new PatternMatchingCompositeLineMapper<BaseDTO>();

		HashMap<String, LineTokenizer> tokenizers = new HashMap<String, LineTokenizer>();
		tokenizers.put("01*", crewMemberLineTokenizer());
		tokenizers.put("02*", sequenceLineTokenizer());
		tokenizers.put("03*", dutyPeriodLineTokenizer());
		tokenizers.put("04*", legDataLineTokenizer());
		compositeLineMapper.setTokenizers(tokenizers);

		Map<String, FieldSetMapper<BaseDTO>> mappers = new HashMap<String, FieldSetMapper<BaseDTO>>();
		mappers.put("01*", crewMemberFieldSetMapper());
		mappers.put("02*", sequenceFieldSetMapper());
		mappers.put("03*", dutyPeriodFieldSetMapper());
		mappers.put("04*", legDataFieldSetMapper());
		compositeLineMapper.setFieldSetMappers(mappers);

		return compositeLineMapper;
	}

	@Bean
	public FieldSetMapper<BaseDTO> crewMemberFieldSetMapper() throws Exception {

		log.info("crewMemberFieldSetMapper()");
		BeanWrapperFieldSetMapper<BaseDTO> crewMemberMapper = new BeanWrapperFieldSetMapper<BaseDTO>();
		crewMemberMapper.setPrototypeBeanName("crewMember");
		crewMemberMapper.afterPropertiesSet();
		return crewMemberMapper;
	}

	@Bean
	@Scope("prototype")
	public CrewMemberDto crewMember() {
		return new CrewMemberDto();
	}

	@Bean
	public LineTokenizer crewMemberLineTokenizer() {
		log.info("crewMemberLineTokenizer()");
		FixedLengthTokenizer crewMemberLineTokenizer = new FixedLengthTokenizer();
		crewMemberLineTokenizer.setNames(CrewCompPropertiesLoader.get("CrewMemberFieldSet").split(","));

		RangeArrayPropertyEditor range = new RangeArrayPropertyEditor();
		range.setAsText(CrewCompPropertiesLoader.get("CrewMemberFieldRange"));
		crewMemberLineTokenizer.setColumns((Range[]) range.getValue());

		crewMemberLineTokenizer.setStrict(false);
		return crewMemberLineTokenizer;
	}

	@Bean
	public FieldSetMapper<BaseDTO> sequenceFieldSetMapper() throws Exception {

		log.info("sequenceFieldSetMapper()");
		BeanWrapperFieldSetMapper<BaseDTO> sequenceMapper = new BeanWrapperFieldSetMapper<BaseDTO>();
		sequenceMapper.setPrototypeBeanName("sequence");
		sequenceMapper.afterPropertiesSet();
		return sequenceMapper;
	}

	@Bean
	@Scope("prototype")
	public SequenceDataDto sequence() {
		return new SequenceDataDto();
	}

	@Bean
	public LineTokenizer sequenceLineTokenizer() {
		log.info("sequenceLineTokenizer()");
		FixedLengthTokenizer sequenceLineTokenizer = new FixedLengthTokenizer();
		sequenceLineTokenizer.setNames(CrewCompPropertiesLoader.get("SequenceFieldSet").split(","));

		RangeArrayPropertyEditor range = new RangeArrayPropertyEditor();
		range.setAsText(CrewCompPropertiesLoader.get("SequenceFieldRange"));
		sequenceLineTokenizer.setColumns((Range[]) range.getValue());

		sequenceLineTokenizer.setStrict(false);
		return sequenceLineTokenizer;
	}

	@Bean
	public FieldSetMapper<BaseDTO> dutyPeriodFieldSetMapper() throws Exception {

		log.info("DutyPeriodFieldSetMapper()");
		BeanWrapperFieldSetMapper<BaseDTO> DutyPeriodMapper = new BeanWrapperFieldSetMapper<BaseDTO>();
		DutyPeriodMapper.setPrototypeBeanName("dutyPeriod");
		DutyPeriodMapper.afterPropertiesSet();
		return DutyPeriodMapper;
	}

	@Bean
	@Scope("prototype")
	public DutyPeriodDataDto dutyPeriod() {
		return new DutyPeriodDataDto();
	}

	@Bean
	public LineTokenizer dutyPeriodLineTokenizer() {
		log.info("DutyPeriodLineTokenizer()");
		FixedLengthTokenizer DutyPeriodLineTokenizer = new FixedLengthTokenizer();
		DutyPeriodLineTokenizer.setNames(CrewCompPropertiesLoader.get("DutyPeriodFieldSet").split(","));

		RangeArrayPropertyEditor range = new RangeArrayPropertyEditor();
		range.setAsText(CrewCompPropertiesLoader.get("DutyPeriodFieldRange"));
		DutyPeriodLineTokenizer.setColumns((Range[]) range.getValue());

		DutyPeriodLineTokenizer.setStrict(false);
		return DutyPeriodLineTokenizer;
	}

	@Bean
	public FieldSetMapper<BaseDTO> legDataFieldSetMapper() throws Exception {

		log.info("legDataFieldSetMapper()");
		BeanWrapperFieldSetMapper<BaseDTO> legDataMapper = new BeanWrapperFieldSetMapper<BaseDTO>();
		legDataMapper.setPrototypeBeanName("legData");
		legDataMapper.afterPropertiesSet();
		return legDataMapper;
	}

	@Bean
	@Scope("prototype")
	public LegDataDto legData() {
		return new LegDataDto();
	}

	@Bean
	public LineTokenizer legDataLineTokenizer() {
		log.info("legDataLineTokenizer()");
		FixedLengthTokenizer legDataLineTokenizer = new FixedLengthTokenizer();
		legDataLineTokenizer.setNames(CrewCompPropertiesLoader.get("legDataFieldSet").split(","));

		RangeArrayPropertyEditor range = new RangeArrayPropertyEditor();
		range.setAsText(CrewCompPropertiesLoader.get("legDataFieldRange"));
		legDataLineTokenizer.setColumns((Range[]) range.getValue());

		legDataLineTokenizer.setStrict(false);
		return legDataLineTokenizer;
	}

}
