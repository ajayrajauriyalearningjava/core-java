/**
 * 
 */
package com.aa.crewpay.constant.enums;

/**
 * @author muthusba
 *
 */
public enum SickCodeType {

	/**
	 * '01' - CURRENTLY SICK.
	 */
	CURRENTLYSICK(01),

	/**
	 * '02' - PENDING SICK
	 */
	PENDINGSICK(02),
	
	/**
	 * '03' - EXTENDED SICK LEAVE 
	 */
	EXTENDEDSICKLEAVE(03),
	
	/**
	 * '04' -  ASSIGNED GSW
	 */
	ASSIGNEDGSW(04),
	
	/**
	 * '05' -  ASSIGNED FST
	 */
	ASSIGNEDFST(05),
	
	/**
	 * '06' -  SICK IF NEEDED
	 */
	SICKIFNEEDED(06);

	/**
	 * Attribute to hold the  <code>SickCodeType</code>.
	 */
	private Integer type;

	/**
	 * <code>Parameterized constructor.</code>
	 * <p>
	 * 
	 * @param pType
	 *            the new value of the <code>type</code> property.
	 */
	SickCodeType(Integer pType) {
		type = pType;
	}

	/**
	 * Gets the <code>type</code> property.
	 * <p>
	 * 
	 * @return the current value of the <code>type</code> property.
	 */
	public int getType() {
		return this.type;
	}

	/**
	 * Gives the string format of enumerated <code>ConditionCodeType</code>.
	 * <p>
	 * 
	 * @return the current value of the <code>ConditionCodeType</code>.
	 */
	public String value() {
		return this.name();
	}
}
