/**
 * 
 */
package com.aa.crewpay.constant.enums;

/**
 * @author muthusba
 *
 */
public enum CreditPayType {

	/**
	 * '1' - CREDIT.
	 */
	CREDIT(1),

	/**
	 * '5' - PAY
	 */
	PAY(5),
	
	/**
	 * '6' - PAY AND CREDIT 
	 */
	PAY_AND_CREDIT(6);

	/**
	 * Attribute to hold the <code>CreditPayType</code>.
	 */
	private Integer type;

	/**
	 * <code>Parameterized constructor.</code>
	 * <p>
	 * 
	 * @param pType
	 *            the new value of the <code>type</code> property.
	 */
	CreditPayType(Integer pType) {
		type = pType;
	}

	/**
	 * Gets the <code>type</code> property.
	 * <p>
	 * 
	 * @return the current value of the <code>type</code> property.
	 */
	public int getType() {
		return this.type;
	}

	/**
	 * Gives the string format of enumerated <code>CreditPayType</code>.
	 * <p>
	 * 
	 * @return the current value of the <code>CreditPayType</code>.
	 */
	public String value() {
		return this.name();
	}
}
