/**
 *
 */
package com.aa.crewpay.batchloader.dto;

/**
 * @author muthusba
 *
 */
public class CrewBaseDto {

	private Integer seqCrewBaseNo;

	private String crewBaseCode;

	private ProjectionGroupDto pltPrjnGrp;

	private Long filler1;
}
