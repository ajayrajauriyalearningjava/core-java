/**
 * 
 */
package com.aa.crewpay.constant.enums;

/**
 * @author muthusba
 *
 */
public enum FAQualificationCodeType {

	/**
	 * '*' - CURRENT
	 */
	CURRENT("*"),
	
	/**
	 * 'P' - EXPIRED.
	 */
	EXPIRED("P"),
	
	/**
	 * 'I' - INTL
	 * 
	 */
	INTL("I"),
	
	/**
	 * 'P' - PREV
	 * 
	 */
	PREV("P"),
	
	/**
	 *  'D' - DOMESTIC
	 *  
	 */
	DOMESTIC("D");

	/**
	 * Attribute to hold the Equipment Qualification Code <code>type</code>.
	 */
	private String type;

	/**
	 * <code>Parameterized constructor.</code>
	 * <p>
	 * 
	 * @param pType
	 *            the new value of the <code>type</code> property.
	 */
	FAQualificationCodeType(String pType) {
		type = pType;
	}

	/**
	 * Gets the <code>type</code> property.
	 * <p>
	 * 
	 * @return the current value of the <code>type</code> property.
	 */
	public String getType() {
		return this.type;
	}

	/**
	 * Gives the string format of enumerated <code>FAQualificationCodeType</code>.
	 * <p>
	 * 
	 * @return the current value of the <code>FAQualificationCodeType</code>.
	 */
	public String value() {
		return this.name();
	}
}
