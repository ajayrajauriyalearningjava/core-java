/**
 * 
 */
package com.aa.crewpay.constant.enums;

/**
 * @author muthusba
 *
 */
public enum EquipmentQualificationCodeType {

	/**
	 * 'P' - PRIOR.
	 */
	PRIOR("P"),

	/**
	 * '*' - CURRENT
	 */
	CURRENT("*"),
	
	/**
	 * 'M' - MANUAL DEL
	 * 
	 */
	PRIOR_MANUAL_DEL("M"),
	
	/**
	 * 'L' - CURRENT AND NEED LINECHECK
	 * 
	 */
	CURRENT_AND_NEED_LINECHECK("L"),
	
	/**
	 *  'R' - CURRENT RESTRICTED
	 *  
	 */
	CURRENT_RESTRICTED("R");

	/**
	 * Attribute to hold the Equipment Qualification Code <code>type</code>.
	 */
	private String type;

	/**
	 * <code>Parameterized constructor.</code>
	 * <p>
	 * 
	 * @param pType
	 *            the new value of the <code>type</code> property.
	 */
	EquipmentQualificationCodeType(String pType) {
		type = pType;
	}

	/**
	 * Gets the <code>type</code> property.
	 * <p>
	 * 
	 * @return the current value of the <code>type</code> property.
	 */
	public String getType() {
		return this.type;
	}

	/**
	 * Gives the string format of enumerated <code>EquipmentQualificationCodeType</code>.
	 * <p>
	 * 
	 * @return the current value of the <code>EquipmentQualificationCodeType</code>.
	 */
	public String value() {
		return this.name();
	}

}
