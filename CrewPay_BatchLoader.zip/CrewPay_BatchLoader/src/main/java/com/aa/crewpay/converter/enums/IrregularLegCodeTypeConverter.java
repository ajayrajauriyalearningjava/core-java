package com.aa.crewpay.converter.enums;

import javax.persistence.AttributeConverter;

import org.springframework.stereotype.Component;

import com.aa.crewpay.constant.enums.IrregularLegCodeType;

@Component
public class IrregularLegCodeTypeConverter implements AttributeConverter<IrregularLegCodeType, Integer> {

	@Override
	public Integer convertToDatabaseColumn(IrregularLegCodeType attribute) {
		if(attribute != null)
			return attribute.getType();
		else
			return null;
	}

	@Override
	public IrregularLegCodeType convertToEntityAttribute(Integer dbData) {
		switch (dbData) {
			case 0: return IrregularLegCodeType.OK;
			case 1: return IrregularLegCodeType.GROUND_INTERUPT;
			case 2: return IrregularLegCodeType.AIR_INTERUPT;
			case 3: return IrregularLegCodeType.DIVERTED;
		}
		return null;
	}

}
