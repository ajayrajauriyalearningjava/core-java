/**
 *
 */
package com.aa.crewpay.domain;

import java.util.Date;

/**
 * @author muthusba
 *
 */
public class DateTimeRange {

	/**
	 * START DATE: YYYYMMDD
	 */
	private Date startDate;

	/**
	 * END DATE: YYYYMMDD
	 */
	private Date endDate;

	/**
	 * MINS OF SEQUENCE. THIS IS THE GMT ON WHICH AN ACTIVITY OR EVENT IS
	 * SCHEDULED/RESCHEDULED/ACTUAL TO START : MMMM. Note: The difference
	 * between this SCHD_STR_MNS in record 02 versus that in record 04 is the
	 * 1hrs sign-in difference.
	 */
	private Integer startTimeMins;

	/**
	 * MINS OF SEQUENCE. THIS IS THE GMT ON WHICH AN ACTIVITY OR EVENT IS
	 * SCHEDULED/RESCHEDULED/ACTUAL TO END : MMMM. Note: The difference
	 * between this SCHD_STR_MNS in record 02 versus that in record 04 is the
	 * 1hrs sign-in difference.
	 */
	private Integer endTimeMins;

}
