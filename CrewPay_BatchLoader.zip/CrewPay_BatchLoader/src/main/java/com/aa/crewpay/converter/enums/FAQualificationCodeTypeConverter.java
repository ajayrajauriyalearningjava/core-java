package com.aa.crewpay.converter.enums;

import javax.persistence.AttributeConverter;

import org.springframework.stereotype.Component;

import com.aa.crewpay.constant.enums.FAQualificationCodeType;

@Component
public class FAQualificationCodeTypeConverter implements AttributeConverter<FAQualificationCodeType, String> {

	@Override
	public String convertToDatabaseColumn(FAQualificationCodeType attribute) {
		if(attribute != null)
			return attribute.getType();
		else
			return null;
	}

	@Override
	public FAQualificationCodeType convertToEntityAttribute(String dbData) {
		switch (dbData) {
			case "*": return FAQualificationCodeType.CURRENT;
			case "P": return FAQualificationCodeType.EXPIRED;
			case "I": return FAQualificationCodeType.INTL;
			//case "P": return FAQualificationCodeType.PREV;
			case "D": return FAQualificationCodeType.DOMESTIC;
		}
		return null;
	}

}
