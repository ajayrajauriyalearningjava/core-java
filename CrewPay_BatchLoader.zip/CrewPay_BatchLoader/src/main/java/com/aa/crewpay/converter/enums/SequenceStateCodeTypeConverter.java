package com.aa.crewpay.converter.enums;

import javax.persistence.AttributeConverter;

import org.springframework.stereotype.Component;

import com.aa.crewpay.constant.enums.SequenceStateCodeType;

@Component
public class SequenceStateCodeTypeConverter implements AttributeConverter<SequenceStateCodeType, Integer> {

	@Override
	public Integer convertToDatabaseColumn(SequenceStateCodeType attribute) {
		if(attribute != null)
			return attribute.getType();
		else
			return null;
	}

	@Override
	public SequenceStateCodeType convertToEntityAttribute(Integer dbData) {
		switch (dbData) {
			case 0: return SequenceStateCodeType.NOT_STARTED;
			case 1: return SequenceStateCodeType.IN_PROGRESS;
			case 2: return SequenceStateCodeType.COMPLETED;
			case 3: return SequenceStateCodeType.CANCELLED;
		}
		return null;
	}

}
