package com.aa.crewpay.converter.enums;

import javax.persistence.AttributeConverter;

import org.springframework.stereotype.Component;

import com.aa.crewpay.constant.enums.SickCodeType;

@Component
public class SickCodeTypeConverter implements AttributeConverter<SickCodeType, Integer> {

	@Override
	public Integer convertToDatabaseColumn(SickCodeType attribute) {
		if(attribute != null)
			return attribute.getType();
		else
			return null;
	}

	@Override
	public SickCodeType convertToEntityAttribute(Integer dbData) {
		switch (dbData) {
			case 01: return SickCodeType.CURRENTLYSICK;
			case 02: return SickCodeType.PENDINGSICK;
			case 03: return SickCodeType.EXTENDEDSICKLEAVE;
			case 04: return SickCodeType.ASSIGNEDGSW;
			case 05: return SickCodeType.ASSIGNEDFST;
			case 06: return SickCodeType.SICKIFNEEDED;
		}
		return null;
	}

}
