/**
 *
 */
package com.aa.crewpay.batchloader.dto;

/**
 * @author muthusba
 *
 */
public class ProjectionGroupDto {

	/**
	 * Attribute to hold the crew member contract date. ex:YYYYMM
	 *
	 */
	private Integer contractDate;

	private String domIntlCode;

	private PilotGroupDto captainGrp;

	private PilotGroupDto firstOfficerGrp;

	private Integer faMaxScheduleHrsQty;

	private boolean faFlexMOInd;
}
