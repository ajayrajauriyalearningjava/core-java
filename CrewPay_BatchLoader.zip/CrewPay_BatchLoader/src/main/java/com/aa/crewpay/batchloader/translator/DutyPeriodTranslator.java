package com.aa.crewpay.batchloader.translator;

import com.aa.crewpay.batchloader.dto.DutyPeriodDataDto;
import com.aa.crewpay.domain.DutyPeriodData;

public class DutyPeriodTranslator {

	public static DutyPeriodData mapDtoToDomain(DutyPeriodDataDto dto) {
		
		DutyPeriodData dutyPeriod = new DutyPeriodData();
		
		
		//dutyPeriod.set(dto.get());
		//dutyPeriod.set(dto.get());
		//dutyPeriod.set(dto.get());
		//dutyPeriod.set(dto.get());
		//dutyPeriod.set(dto.get());
		//dutyPeriod.set(dto.get());
		//dutyPeriod.set(dto.get());
		//dutyPeriod.set(dto.get());
		//dutyPeriod.set(dto.get());
		//dutyPeriod.set(dto.get());
		//dutyPeriod.set(dto.get());
		//dutyPeriod.set(dto.get());
		//dutyPeriod.set(dto.get());
		//dutyPeriod.set(dto.get());
		//dutyPeriod.set(dto.get());
		//dutyPeriod.set(dto.get());
		//dutyPeriod.set(dto.get());
		//dutyPeriod.set(dto.get());
		//dutyPeriod.set(dto.get());
		//dutyPeriod.set(dto.get());
		//dutyPeriod.set(dto.get());
		//dutyPeriod.set(dto.get());
		//dutyPeriod.set(dto.get());
		//dutyPeriod.set(dto.get());
		
		return dutyPeriod;
	}	
}
