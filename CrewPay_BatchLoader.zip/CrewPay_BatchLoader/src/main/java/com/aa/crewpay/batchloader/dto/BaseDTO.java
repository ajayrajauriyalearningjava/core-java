package com.aa.crewpay.batchloader.dto;

import java.io.Serializable;

public class BaseDTO implements Serializable  {

	private static final long serialVersionUID = 1L;
	
	private String recordCode;

	public String getRecordCode() {
		return recordCode;
	}

	public void setRecordCode(String recordCode) {
		this.recordCode = recordCode;
	}
	
}