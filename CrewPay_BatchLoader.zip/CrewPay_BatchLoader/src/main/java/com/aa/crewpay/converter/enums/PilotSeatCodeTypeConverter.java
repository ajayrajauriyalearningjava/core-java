package com.aa.crewpay.converter.enums;

import javax.persistence.AttributeConverter;

import org.springframework.stereotype.Component;

import com.aa.crewpay.constant.enums.PilotSeatCodeType;

@Component
public class PilotSeatCodeTypeConverter implements AttributeConverter<PilotSeatCodeType, Integer> {

	@Override
	public Integer convertToDatabaseColumn(PilotSeatCodeType attribute) {
		if(attribute != null)
			return attribute.getType();
		else
			return null;
	}

	@Override
	public PilotSeatCodeType convertToEntityAttribute(Integer dbData) {
		switch (dbData) {
			case 1: return PilotSeatCodeType.CAPTAIN;
			case 2: return PilotSeatCodeType.FIRSTOFFICER;
			case 3: return PilotSeatCodeType.FLIGHTENGINEER;
		}
		return null;
	}

}
