/**
 *
 */
package com.aa.crewpay.constant.enums;

/**
 * @author muthusba
 *
 */
public enum SequenceStateCodeType {

	/**
	 * '0' - NOT_STARTED.
	 */
	NOT_STARTED(0),

	/**
	 * '1' - IN_PROGRESS
	 */
	IN_PROGRESS(1),

	/**
	 * '2' - COMPLETED
	 */
	COMPLETED(2),

	/**
	 * '3' - CANCELLED
	 */
	CANCELLED(3);

	/**
	 * Attribute to hold the SequenceStateCode <code>type</code>.
	 */
	private Integer type;

	/**
	 * <code>Parameterized constructor.</code>
	 * <p>
	 *
	 * @param pType
	 *            the new value of the <code>type</code> property.
	 */
	SequenceStateCodeType(Integer pType) {
		type = pType;
	}

	/**
	 * Gets the <code>type</code> property.
	 * <p>
	 *
	 * @return the current value of the <code>type</code> property.
	 */
	public int getType() {
		return this.type;
	}

	/**
	 * Gives the string format of enumerated <code>SequenceStateCodeType</code>.
	 * <p>
	 *
	 * @return the current value of the <code>SequenceStateCodeType</code>.
	 */
	public String value() {
		return this.name();
	}
}
