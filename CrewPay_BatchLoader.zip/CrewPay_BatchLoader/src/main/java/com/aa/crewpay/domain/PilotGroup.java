package com.aa.crewpay.domain;

public class PilotGroup {

	private String equipment;

	private Integer regularMaxScheduledHrs;

	private Integer reserveMaxScheduledHrs;

	private boolean flexMoInd;

	private Integer captainSpare;

	private Integer firstOfficerSpare;
}
