/**
 * 
 */
package com.aa.crewpay.domain;

import java.util.Date;

import com.aa.crewpay.constant.enums.PositionCodeType;

/**
 * @author muthusba
 *
 */
public class DeferralsBidStatusGroup {

	private PositionCodeType positionCode;
	
	private Date effDate;
}
