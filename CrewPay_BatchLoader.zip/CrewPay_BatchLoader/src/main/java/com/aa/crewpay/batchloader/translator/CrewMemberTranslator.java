package com.aa.crewpay.batchloader.translator;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.aa.crewpay.batchloader.dto.CrewMemberDto;
import com.aa.crewpay.batchloader.dto.DailyCreditPayDto;
import com.aa.crewpay.batchloader.dto.SequenceDataDto;
import com.aa.crewpay.converter.enums.CrewCodeTypeConverter;
import com.aa.crewpay.converter.enums.DomIntlConverter;
import com.aa.crewpay.converter.enums.PilotSeatCodeTypeConverter;
import com.aa.crewpay.converter.enums.SickCodeTypeConverter;
import com.aa.crewpay.domain.CrewMember;
import com.aa.crewpay.domain.DailyCreditPay;
import com.aa.crewpay.domain.EmployeeDetail;
import com.aa.crewpay.domain.SequenceData;
import com.aa.crewpay.util.DateUtilityMethods;

@Component
public class CrewMemberTranslator {

	/*@Autowired
    public DomIntlConverter domIntlConverter;*/
	
	@Autowired
    public CrewCodeTypeConverter crewCodeTypeConverter;
	
	@Autowired
    public PilotSeatCodeTypeConverter pilotSeatCodeTypeConveter;
    
	@Autowired
    public SickCodeTypeConverter sickCodeTypeConverter;
	
	public void mapDtoToDomain(CrewMemberDto dto) {
		
		CrewMember crewMember = new CrewMember();
		
		crewMember.setEmployee(buildEmpDetail(dto));		
		//crewMember.setEqpQualifications(dto.getEqpQualifications());
		crewMember.setMaidenName(dto.getMaidenName());
		crewMember.setFormerCode(dto.getFormerCode());
		crewMember.setMailLocation(dto.getMailLocation());
		crewMember.setPilotcommissionDate( DateUtilityMethods.convertIntegerToDate(dto.getPilotCommissionDate()) );
		crewMember.setCoPilotcommissionDate( DateUtilityMethods.convertIntegerToDate(dto.getCoPilotCommissionDate()) );
		crewMember.setHighSeatCodeType( pilotSeatCodeTypeConveter.convertToEntityAttribute(dto.getHighSeatCodeType()) );
		crewMember.setPremanentCrewBase(dto.getPremanentCrewBase());
		crewMember.setCrewBaseAssignDate( DateUtilityMethods.convertIntegerToDate(dto.getCrewBaseAssignDate()) );
		crewMember.setIntlAssignCodeType( DomIntlConverter.convertToEnum(dto.getIntlAssignCodeType()) );
		crewMember.setNextIntlAssignCodeType(DomIntlConverter.convertToEnum(dto.getNextIntlAssignCodeType()));
		crewMember.setNextCrewBase(dto.getNextCrewBase());
		crewMember.setNextCrewBaseDate( DateUtilityMethods.convertIntegerToDate(dto.getNextCrewBaseDate()) );
		crewMember.setPayrollExcludeIndicator(dto.isPayrollExcludeIndicator());
		crewMember.setRetainSeniorityIndicator(dto.isRetainSeniorityIndicator());
		crewMember.setAnnualSenSequence(dto.getAnnualSenSequence());
		crewMember.setCurrentSeniorityNumber(dto.getCurrentSeniorityNumber());
		crewMember.setYearOfService(dto.getYearOfService());
		crewMember.setConditionCodeType( sickCodeTypeConverter.convertToEntityAttribute(dto.getConditionCodeType()) );
		crewMember.setPermStatusCode(dto.getPermStatusCode());
		//crewMember.set(dto.get());
		//crewMember.set(dto.get());
		//crewMember.set(dto.get());
		//crewMember.set(dto.get());
		//crewMember.set(dto.get());
		//crewMember.set(dto.get());
		//crewMember.set(dto.get());
		//crewMember.set(dto.get());
		//crewMember.set(dto.get());
		//crewMember.set(dto.get());
		//crewMember.set(dto.get());
		//crewMember.set(dto.get());
		
		crewMember.setDailyCreditPay( buildDailyCreditPay(dto.getDailyCreditPay()) );
		crewMember.setSequences(buildSequenceData(dto.getSequences()));
	}
	
	private EmployeeDetail buildEmpDetail(CrewMemberDto dto) {
		EmployeeDetail empDetail = new EmployeeDetail();
		empDetail.setContractDate(dto.getContractDate());
		empDetail.setLoadDate(dto.getLoadDate());
		empDetail.setAirlineCode(dto.getAirlineCode());
		empDetail.setDomIntlCode( DomIntlConverter.convertToEnum(dto.getDomIntlCode()) );
		empDetail.setCrewTypeCode( crewCodeTypeConverter.convertToEntityAttribute(dto.getCrewTypeCode()) );
		empDetail.setEmployeeNumber(dto.getEmployeeNumber());
		return empDetail;
	}
	
	/*private List<EquipmentQualification> buildEquipmentQualification(List<EquipmentQualificationDto> dtoList) {
		
		List<EquipmentQualification> domainList;
		EquipmentQualification eqDomain;
		
		for (EquipmentQualificationDto eqDto : dtoList) {
			eqDomain = new EquipmentQualification();
			eqDomain.setEquipment(eqDto.getEquipment());
		}		
		return null;		
	}*/
	
	private List<DailyCreditPay> buildDailyCreditPay(List<DailyCreditPayDto> dtoList) {
		
		List<DailyCreditPay> domainList = new ArrayList<DailyCreditPay>();
		DailyCreditPay dcpDomain;
		
		for (DailyCreditPayDto dcpDto : dtoList) {
			dcpDomain = new DailyCreditPay();
			BeanUtils.copyProperties(dcpDto, dcpDomain);
			domainList.add(dcpDomain);
		}		
		return domainList;	 
	}
	
	private List<SequenceData> buildSequenceData(List<SequenceDataDto> dtoList) {
		
		List<SequenceData> sequenceDataList = new ArrayList<SequenceData>();
		SequenceData sequenceData;
		
		for (SequenceDataDto seqDto : dtoList) {
			sequenceData = SequenceDataTranslator.mapDtoToDomain(seqDto);
			sequenceDataList.add(sequenceData);
		}		
		return sequenceDataList;	 
	}
}
