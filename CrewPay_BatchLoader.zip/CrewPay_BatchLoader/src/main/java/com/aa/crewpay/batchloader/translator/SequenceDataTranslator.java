package com.aa.crewpay.batchloader.translator;

import com.aa.crewpay.batchloader.dto.SequenceDataDto;
import com.aa.crewpay.domain.SequenceData;

public class SequenceDataTranslator {

	public static SequenceData mapDtoToDomain(SequenceDataDto dto) {
			
		SequenceData sequenceData = new SequenceData();
		
		
		//sequenceData.set(dto.get());
		//sequenceData.set(dto.get());
		//sequenceData.set(dto.get());
		//sequenceData.set(dto.get());
		//sequenceData.set(dto.get());
		//sequenceData.set(dto.get());
		//sequenceData.set(dto.get());
		//sequenceData.set(dto.get());
		//sequenceData.set(dto.get());
		//sequenceData.set(dto.get());
		//sequenceData.set(dto.get());
		//sequenceData.set(dto.get());
		//sequenceData.set(dto.get());
		//sequenceData.set(dto.get());
		//sequenceData.set(dto.get());
		//sequenceData.set(dto.get());
		//sequenceData.set(dto.get());
		//sequenceData.set(dto.get());
		//sequenceData.set(dto.get());
		//sequenceData.set(dto.get());
		//sequenceData.set(dto.get());
		//sequenceData.set(dto.get());
		//sequenceData.set(dto.get());
		//sequenceData.set(dto.get());
		return sequenceData;
	}
}
