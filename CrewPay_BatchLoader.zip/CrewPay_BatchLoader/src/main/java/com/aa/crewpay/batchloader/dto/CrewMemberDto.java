/**
 * 
 */
package com.aa.crewpay.batchloader.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @author muthusba
 *
 */
public class CrewMemberDto extends BaseDTO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Attribute to hold the crew member contract date. ex:YYYYMM
	 * 
	 */
	private Integer contractDate;

	/**
	 * Attribute to hold the crew member contract load date. ex:YYYYMMDD
	 * 
	 */
	private Date loadDate;

	/**
	 * Attribute to hold the airline code. Ex: AA
	 */
	private String airlineCode;

	/**
	 * Attribute to hold the Domestic International code.
	 */
	private String domIntlCode;

	/**
	 * Attribute to hold the Crew Type code.
	 */
	private Integer crewTypeCode;

	/**
	 * Attribute to hold the employee Number
	 */
	private Integer employeeNumber;

	private List<EquipmentQualificationDto> eqpQualifications;

	private String maidenName;

	/**
	 * NO DATA LOADED IN THIS FIELD
	 */
	private String formerCode;

	/**
	 * "DF3  "; as seen in FOS *L
	 */
	private String mailLocation;

	/**
	 * Pilot Commission Date - "YYYYMMDD"; from the "*L" record (emp#93437, ex
	 * "CAPT D/R 22AUG92"): Many Capt's have no date, sent list to JJ Oct 2011"
	 */
	private Integer pilotCommissionDate;

	/**
	 * "YYYYMMDD"; from the "*L" record (emp#93437,ex "ORIG F/O 13NOV85") Many
	 * F/O's have no date, sent list to JJ Oct 2011"
	 * 
	 */
	private Integer coPilotCommissionDate;

	/**
	 * PI ONLY - "1" = Captain, "2" = FO, "3" = FE; The highest seat code for
	 * this month�s activity or since the last time the crew member was active
	 */
	private Integer highSeatCodeType;

	/**
	 * 2 numeric character that corresponds to a specific 3 character crew base
	 * i.e., "04" = "DFW"; FROM "*-" RECORD, IF CURRENT BASE THEN SHOULD BE THE
	 * SAME ON 3K* note: from Record Type 31
	 */
	private Integer premanentCrewBase;

	/**
	 * PI = "D", FA = "D" or "I"
	 */
	private Integer crewBaseAssignDate;

	/**
	 * PI = "D", FA = "D" or "I"
	 */
	private String intlAssignCodeType;

	/**
	 * PI = "D", FA = "D" or "I"
	 */
	private String nextIntlAssignCodeType;

	/**
	 * 2 numeric character that correspondes to a specific 3 character crew base
	 * i.e., "04" = "DFW". note: from Record Type 31
	 */
	private Integer nextCrewBase;

	private Integer nextCrewBaseDate;

	/**
	 * "1" = Crewmember is not to appear on payroll capture
	 */
	private boolean payrollExcludeIndicator;

	/**
	 * "1" = Crewmember retaining seniority
	 */
	private boolean retainSeniorityIndicator;

	/*
	 * ANNUAL SEN#
	 */
	private Integer annualSenSequence;

	/**
	 * MONTHLY SEN#, PFE add 30000 to their actual sen#
	 */
	private Integer currentSeniorityNumber;

	/**
	 * "1" = FA has 1 year of service "3" = FA has 3 years of service Although
	 * the label says "FA" there is data populated for Pilots (see #63254 =
	 * "3");
	 * 
	 */
	private Integer yearOfService;

	/**
	 * "01" = Currently Sick "02" = Pending Sick "03" = Extended Sick Leave "04"
	 * = Assigned GSW "05" = Assigned FST "06" = Sick If Needed *
	 */
	private Integer conditionCodeType;

	//////////////// Status Code/Date ///////////////////////

	/**
	 * 3 numeric character, in FOS the 3 numeric character has a corresponding 2
	 * character code (GJS*)
	 */
	private Integer permStatusCode;

	private Integer permStatusEffDate;

	private Integer permStatusTrmDate;

	/**
	 * 3 numeric character, in FOS the 3 numeric character has a corresponding 2
	 * character code (GJS*)
	 */
	private Integer nextPermStatusCode;

	private Integer nextPermStatusEffDate;

	private Integer tempStatusEffDate;

	private Integer tempStatusTrmDate;

	/**
	 * 3 numeric character, in FOS the 3 numeric character has a corresponding 2
	 * character code (GJS*)
	 */
	private Integer tempStatusCode;

	private Integer nextTempStatusEffDate;

	private Integer nextTempStatusTrmDate;

	/**
	 * 3 numeric character, in FOS the 3 numeric character has a corresponding 2
	 * character code (GJS*)
	 */
	private Integer nextTempStatusCode;

	private Integer macEffDate;

	private Integer macTrmDate;

	private Integer trainingBaseEffDate;

	private Integer trainingBaseTrmDate;

	//////////////// Status Code///////////////////////

	/**
	 * Passport Issue Date; "YYYYMMDD"; license record "**" in FOS
	 */
	private Integer passportDate;

	/**
	 * Passport Number; i.e., "212072213          "
	 */
	private String passportNumber;

	/**
	 * Passport Issue Country i.e., "US "
	 */
	private String passportCountryCode;

	/**
	 * Passport Expire Date; "YYYYMMDD"
	 */
	private Integer passportExpDate;

	/**
	 * the ICAO #; i.e., "56926       ";license record "**" in FOS
	 */
	private String icaoRegistrationNo;

	/**
	 * the ICAO Issue Date; "YYYYMMDD"
	 */
	private Integer icaoIssueDate;

	/**
	 * 2=FA, REST PI; not sure where the date being loaded to this field is
	 * stored in FOS i.e., emp# 63254-date = "19801218". The company medical
	 * process is no longer used by AA
	 */
	private Integer companyMedicalDate;

	/**
	 * 5000 FA, ALL PI - "YYYYMMDD"
	 */
	private Integer FAAMedicalDate;

	/**
	 * Type "1" or Type "2"; PI ONLY; from license record "*" in FOS
	 */
	private Integer FAAMedicalClass;

	/**
	 * doctor name; i.e."KRASS       ": license record "**" in FOS
	 */
	private String FAADoctor;

	/**
	 * FA="L", PI = "G" or "L"; Not sure where the date being loaded to this
	 * field is stored in FOS i.e., emp# 63254-Med_LOCN_IND = "G". The company
	 * medical process is no longer used by AA
	 */
	private String medicalLocationInd;

	/**
	 * 2 FA, 2 PI; Not sure where the date being loaded to this field is stored
	 * in FOS i.e., emp# 63254-date = "00". The company medical process is no
	 * longer used by AA
	 */
	private Integer companyMedicalBaseMonth;

	/**
	 * PI ONLY; 2 numeric month "MM"
	 */
	private Integer FAAMedicalBaseMonth;

	/**
	 * NO DATA LOADED IN THIS FIELD
	 */
	private Integer sickReleaseDate;

	private Integer unpaidSickStartDate;

	/**
	 * NO DATA LOADED IN THIS FIELD
	 */
	private Integer sickReleaseMins;

	/**
	 * AVAIL SICK minutes; displayed on NAP
	 */
	private Integer unUsedSickTime;

	/**
	 * Value is sick minutes used for the crewmembers Career, not yearly
	 */
	private Integer sickTimeMinsUsedYTD;

	/**
	 * NO ONE <- Need to validate this is true, could be that F/A's rarely pick
	 * up a sequence with SM (sick makeup)
	 */
	private Integer sickTimeMakeUp;

	/**
	 * Is sick PAID minutes used month to date displayed on NAP; there is some
	 * exception that deals with F/A Sick CAP program doing something to CAP the
	 * PPROJ at 85:00. Although Lois' notes indicate that there are times the
	 * values just don�t calculate.
	 */
	private Integer sickTimeMinsUsedMTD;

	/**
	 * 0=ALL PI, FA
	 */
	private String mergeEmployeeInd;

	/**
	 * PROJ; Actual Projection minutes displayed on NA
	 */
	private Integer currentProjection;

	/**
	 * SPROJ; Schedule Projection minutes displayed on NA
	 */
	private Integer scheduledProjection;

	/**
	 * GTD; Greater Time To Date minutes displayed on NA
	 */
	private Integer greaterTimeMTD;

	/**
	 * PPROJ; Pay Projection minutes displayed on NA
	 */
	private Integer specAssignmentCurrentMins;

	/**
	 * FA ONLY, TOTAL 8F TIME; minutes displayed on NAP - The minutes associated
	 * with 8F are included in the PPROJ
	 */
	private Integer intlSequenceCurrentMins;

	/**
	 * "PI=FLYTHRU CPA minutes (not accurate if the c/o sequence is changed to
	 * not paid); FA=REASSGN PAY minutes FOR RA RA (is this included in the
	 * PPROJ?); Current month FTCPA Bank --(1)-- this is field 1, see not for
	 * field --(2)-- at column 341 concerning carryover amount of sequence fly
	 * through"
	 * 
	 */
	private Integer reassignPayMins;

	/**
	 * NO DATA LOADED IN THIS FIELD
	 */
	private Integer underStaffPTRNPayMins;

	/**
	 * FA ONLY - NEW UNDERSTAFFING PAY; Total monthly understaffing minutes
	 * displayed on the NAP in "U/S"
	 */
	private Integer underStaffSRVCPayMins;

	/**
	 * "Lois deScription = NITEPAY 1; Not displayed on the NAP; 11/2011: FA
	 * Night Time 1 hours actually flown between hours of 2045 and 2359; PI,
	 * there are minutes in NITEPAY1 but none in NITEPAY2, i.e., emp#63254 April
	 * 2011 = "942". See NGT_PAY_MNS2 field in FCRM @1301."
	 * 
	 */
	private Integer nightPayMins;

	/**
	 * For Pilots = VALUE OF C/O SEQ IN THIS MONTH THAT WILL be placed in CPA
	 * BANK ON 25th (used to be 28th) when pre/post runs. These minutes are in
	 * the GTD as displayed on the NA. Remainder of C/O sequence not in FTCPA
	 * bank for current month --(2)-- this is field 2. If you add field 1 +
	 * field 2 you get the carryover amount of the sequenc flying into this
	 * month (whole amount)
	 */
	private Integer fAPremPayOrPltCpaMins;

	/**
	 * "00"; FA ONLY; Description makes me think this is the number of legs the
	 * FA will be paid foreign language pay need to validate
	 */
	private Integer foreignLanguagePayLeg;

	/**
	 * FA ONLY; Total monthly holding time minutes; total minutes for the month
	 * of all miscellaneous credit 127 (HLDGTME).
	 */
	private Integer holdTimePayMins;

	/**
	 * FA ONLY; Total monthly ground time minutes; total minutes for the month
	 * of all miscellaneous credit 122 (GRDTME).
	 * 
	 */
	private Integer groundTimePayMins;

	/**
	 * Total monthly domestic expenses (both taxable and non-taxable) diplayed
	 * on the NA
	 */
	private Integer totalDomesticExpenses;

	/**
	 * Total monthly Domestic Taxable expense minutes which are a subset of the
	 * minutes in field "DOM_TAFB_XPNS"
	 */
	private Integer totalDomesticTaxableExpenses;

	/**
	 * Total monthly Miscellaneous Taxable expense minutes which are a subset of
	 * the minutes in field "MISC_XPNS"
	 */
	private Integer totalMiscTaxableExpenses;

	/**
	 * Total miscellaneous expenses (both taxable and non-taxable)
	 */
	private Integer totalMiscExpenses;

	/**
	 * Monthly trip selection number; i.e., "       1", "    1050"
	 */
	private Integer tripSelectionNumber;

	/**
	 * Monthly trip selection Crew Base Code; 2 numeric character that
	 * corresponds to a specific 3 character crew base i.e., "04" = "DFW"
	 */
	private Integer selectionCrewBaseCode;

	/**
	 * "2 numeric position code associated with the crewmembers monthly bid award; For F/A RSV "
	 * "RD"" this code is ""00"" (since we do not use call-in the code can not
	 * be validated) @See PositionCodeType"
	 * 
	 */
	private Integer monthCrewMemberPositionCode;

	/**
	 * "D" or "I" division associated with the crewmembers monthly bid award
	 */
	private String monthDomIntlCode;

	/**
	 * SelectionReasonCodeType associated with the crewmembers monthly bid award
	 * status.
	 */
	private String inactiveSelRsnCode;

	/**
	 * "P" or "N"; ALL PI = N, FA if awards a paper bid then "P"
	 */
	private String PABidInd;

	/**
	 * PI: "0" = REG COCKPIT, "1" = RSV, "2" = SECOND ROUND (was SUPNUM), "3" =
	 * RELIEF FA: "0" = INACTIVE, "4" = REG REPL (referred to as Open
	 * Replacement; CAN HAVE AVBL DAYS), "5" REG REG (CAN HAVE AVBL DAYS), "6" =
	 * RSV READY, "7" = RSV CALLIN, "8" = REG AVAIL (never find any), "9" = REG
	 * RELIEF"
	 * 
	 */
	private Integer tripSelTypeCode;

	/**
	 * "2 character equipment code, i.e. "35" = S80. To determine High equipment
	 * code in the selection see FOS display NYE*. The equipment loaded here
	 * should be the equipment as displayed on the NAP See Equipment Code
	 * worksheet tab"
	 * 
	 */
	private String highEqpTypeCode;

	/**
	 * 2 numberic i.e., "01"; = # times F/A has a standby assignment (S/B)
	 * displayed NA; FA ONLY
	 */
	private Integer callOutStandbyQty;

	/**
	 * FA: "1" OR "2" FOR Monthly OPTION 1 OR 2, For Partime F/A's: "A","8","9"
	 * = parttime A (work first half of month) or "B","4","5","6" = parttime B
	 * (work second half of month)
	 */
	private String faBidOptCode;

	/**
	 * "The daily crewmember bid group calendar will be through field
	 * PILOT_PARYLL_CDE (@404); there are 31 repeats for each field with the
	 * first being the 1st contractual day of the month. So for June, the 1st
	 * instance is June 1st, the 31st instance is July 1st. When a contractual
	 * month is 30 days long, the 31st instance would not be used. CALENDAR.
	 * ""P"" or/and ""F"" means PI or FA changes values between intial load the
	 * final reload."
	 * 
	 */
	private List<DailyBidGroupDto> dailyBidGroup;

	/**
	 * PI and FA; Need to figure out exact calculations for example if the
	 * crewmember is Intl and flies a domestic trip is the value here only the
	 * Intl minutes for the month
	 */
	private Integer intlPayMins;

	private String firstInitial;

	private String middleInitial;

	/**
	 * First 18 characters of last name will preceeding spaces, i.e.,
	 * "BRYANT            "
	 */
	private String lastName;

	private Integer birthDate;

	/**
	 * "YYYYMMDD" , Compay Sen Date; USED FOR CALCULATING VACATION ACCRUAL
	 */
	private Integer compaySeniorityDate;

	/**
	 * "YYYYMMDD" , Occupational Sen Date;USED FOR BID SENIORITY
	 */
	private Integer occupSeniorityDate;

	/**
	 * "YYYYMMDD" , Classification Sen Date; USED FOR PAYSTEP; pilot moves to
	 * next pay step on this exact date;
	 */
	private Integer clsSeniorityDate;

	/**
	 * "YYYYMMDD" , Hire Sen Date;
	 */
	private Integer orgHireDate;

	/**
	 * "USE REC TYPE 20" in the SP indicators; For PI if SP # 12 = 1, for FA if
	 * SP # 7 = 1
	 */
	private Integer commuteFlag;

	private boolean varManInd;

	private Integer paperBidReason;

	private BidStatusGroupDto currentBidStatGrp;

	private BidStatusGroupDto nextBidStatGrp;

	private BidStatusGroupDto withBidStatGrp;

	private Integer deferralBidPositionCode;

	private Integer deferralBidEffDate;

	/**
	 * PI Only
	 */
	private Integer nextBidDisplacementPrefCode;

	/**
	 * PI Only
	 */
	private boolean excludeMolyFlyHRSAgrmtInd;

	/**
	 * PI Only
	 */
	private boolean captBidRqmtInd;

	/**
	 * PI Only
	 */
	private boolean foBidRqmtInd;

	/**
	 * PI = "0", APFA = "0" , SAM FA = "1";
	 */
	private String aircalFormerEmpInd;

	/**
	 * PI original guarantee (before reduction if TT down); PI ONLY
	 */
	private Integer guaranteeMinMontMins;

	/**
	 * foreign Language Pay Mins
	 */
	private Integer foreignLangPayMins;

	/**
	 * FA i.e., "2" displayed in *- record; PI = 0
	 */
	private Integer crwbSupervisorNum;

	private Integer drugTestDate;

	private Integer lastFlownDate;

	/**
	 * Total monthly international expenses (both taxable and non-taxable)
	 * diplayed on the NA
	 */
	private Integer IntlTotalExpenses;

	/**
	 * Total monthly International Taxable expense minutes which are a subset of
	 * the minutes in field "DOM_TAFB_XPNS"
	 */
	private Integer IntlTotalTaxableExpenses;

	/**
	 * PAY PPROJ FROM ORIGINAL BID
	 */
	private Integer tsPayProjMins;

	/**
	 * SEL PPROJ FROM ORIGINAL BID
	 */
	private Integer bidSelProjMins;

	private String ckaFlag;

	private String ckaType;

	private Integer ckaBank;

	/**
	 * Actual Base Guarantee (with any reduction); FA ONLY
	 */
	private Integer faActualBaseGuar;

	/**
	 * Actual Incentive Guarantee (with any reduction); FA ONLY
	 */
	private Integer faActualIncGuar;

	/**
	 * FA ONLY, Not displayed on the NAP; 11/2011: FA Night Time 2 hours
	 * actually flown between hours of 2400 and 0559; NITEPAY1 at NGT_PAY_MNS
	 * field in FCRM @338;
	 */
	private Integer nightPayMins2;

	private Integer chaseFlMins;

	private String homeTelephoneNumber;

	private String businessTelephoneNumber;

	private String tempTelephoneNumber;

	private String empSecondaryTelephoneNumber;

	private Integer restartedSickTimeMins;

	/**
	 * Pilot adjusted guarantee; This adjusted guarantee will include only the
	 * reduction for TT below guarantee all other code 8 guarantee reductions
	 * are handled by the pilot payroll program; PI ONLY
	 */
	private Integer adjCkptPayGurantee;

	/**
	 * "N" or "Y"; PI ONLY
	 */
	private String ckptWaviedInd;

	/**
	 * Original Airline for crewmember, "AA" or "TW"
	 */
	private String origAirlineCode;

	/**
	 * Original Airline for crewmember, "AA" or "TW"
	 */
	private String currentAirlineCode;

	private Integer prevTripSelTypeCode;

	private BidStatusGroupDto previousBidStsGroup;

	/**
	 * Second OCC date (for when TW moved to AA) will have the ORIG TW OCC Date
	 * (don't know where this date is stored
	 */
	private Integer occ2Date;

	/**
	 * Combined Seniority number (TW & AA)
	 */
	private Integer systSeniorityNo;

	/**
	 * Date of TFMOVE from one airline to another, is the actual date the move
	 * is done so for example March emps will be moved after Feb 10th
	 */
	private Integer tfcopyEffDate;

	private Integer tfcopyNEffDate;

	private boolean pilMoncurrentStatusInd;

	private Integer pilMoncurrentDailyCred;

	private Integer pillCurrentMonthlyIPMax;

	private Integer vacationSeniorityDate;

	private List<DailyCreditPayDto> dailyCreditPay;

	private Integer fillerS2;

	private Integer fillerS3;

	private String fillerS4;

	private List<SequenceDataDto> sequences;

	private List<MiscCreditExpenseDto> miscCreditExpenses;

	private CapFlexDataDto capFlex;

	private List<PlannedAbsenceGroupDto> plannedAbsenceGroups;

	/**
	 * @return the contractDate
	 */
	public Integer getContractDate() {
		return contractDate;
	}

	/**
	 * @param contractDate the contractDate to set
	 */
	public void setContractDate(Integer contractDate) {
		this.contractDate = contractDate;
	}

	/**
	 * @return the loadDate
	 */
	public Date getLoadDate() {
		return loadDate;
	}

	/**
	 * @param loadDate the loadDate to set
	 */
	public void setLoadDate(Date loadDate) {
		this.loadDate = loadDate;
	}

	/**
	 * @return the airlineCode
	 */
	public String getAirlineCode() {
		return airlineCode;
	}

	/**
	 * @param airlineCode the airlineCode to set
	 */
	public void setAirlineCode(String airlineCode) {
		this.airlineCode = airlineCode;
	}

	/**
	 * @return the domIntlCode
	 */
	public String getDomIntlCode() {
		return domIntlCode;
	}

	/**
	 * @param domIntlCode the domIntlCode to set
	 */
	public void setDomIntlCode(String domIntlCode) {
		this.domIntlCode = domIntlCode;
	}

	/**
	 * @return the crewTypeCode
	 */
	public Integer getCrewTypeCode() {
		return crewTypeCode;
	}

	/**
	 * @param crewTypeCode the crewTypeCode to set
	 */
	public void setCrewTypeCode(Integer crewTypeCode) {
		this.crewTypeCode = crewTypeCode;
	}

	/**
	 * @return the employeeNumber
	 */
	public Integer getEmployeeNumber() {
		return employeeNumber;
	}

	/**
	 * @param employeeNumber the employeeNumber to set
	 */
	public void setEmployeeNumber(Integer employeeNumber) {
		this.employeeNumber = employeeNumber;
	}

	/**
	 * @return the eqpQualifications
	 */
	public List<EquipmentQualificationDto> getEqpQualifications() {
		return eqpQualifications;
	}

	/**
	 * @param eqpQualifications the eqpQualifications to set
	 */
	public void setEqpQualifications(List<EquipmentQualificationDto> eqpQualifications) {
		this.eqpQualifications = eqpQualifications;
	}

	/**
	 * @return the maidenName
	 */
	public String getMaidenName() {
		return maidenName;
	}

	/**
	 * @param maidenName the maidenName to set
	 */
	public void setMaidenName(String maidenName) {
		this.maidenName = maidenName;
	}

	/**
	 * @return the formerCode
	 */
	public String getFormerCode() {
		return formerCode;
	}

	/**
	 * @param formerCode the formerCode to set
	 */
	public void setFormerCode(String formerCode) {
		this.formerCode = formerCode;
	}

	/**
	 * @return the mailLocation
	 */
	public String getMailLocation() {
		return mailLocation;
	}

	/**
	 * @param mailLocation the mailLocation to set
	 */
	public void setMailLocation(String mailLocation) {
		this.mailLocation = mailLocation;
	}

	/**
	 * @return the pilotCommissionDate
	 */
	public Integer getPilotCommissionDate() {
		return pilotCommissionDate;
	}

	/**
	 * @param pilotCommissionDate the pilotCommissionDate to set
	 */
	public void setPilotCommissionDate(Integer pilotCommissionDate) {
		this.pilotCommissionDate = pilotCommissionDate;
	}

	/**
	 * @return the coPilotCommissionDate
	 */
	public Integer getCoPilotCommissionDate() {
		return coPilotCommissionDate;
	}

	/**
	 * @param coPilotCommissionDate the coPilotCommissionDate to set
	 */
	public void setCoPilotCommissionDate(Integer coPilotCommissionDate) {
		this.coPilotCommissionDate = coPilotCommissionDate;
	}

	/**
	 * @return the highSeatCodeType
	 */
	public Integer getHighSeatCodeType() {
		return highSeatCodeType;
	}

	/**
	 * @param highSeatCodeType the highSeatCodeType to set
	 */
	public void setHighSeatCodeType(Integer highSeatCodeType) {
		this.highSeatCodeType = highSeatCodeType;
	}

	/**
	 * @return the premanentCrewBase
	 */
	public Integer getPremanentCrewBase() {
		return premanentCrewBase;
	}

	/**
	 * @param premanentCrewBase the premanentCrewBase to set
	 */
	public void setPremanentCrewBase(Integer premanentCrewBase) {
		this.premanentCrewBase = premanentCrewBase;
	}

	/**
	 * @return the crewBaseAssignDate
	 */
	public Integer getCrewBaseAssignDate() {
		return crewBaseAssignDate;
	}

	/**
	 * @param crewBaseAssignDate the crewBaseAssignDate to set
	 */
	public void setCrewBaseAssignDate(Integer crewBaseAssignDate) {
		this.crewBaseAssignDate = crewBaseAssignDate;
	}

	/**
	 * @return the intlAssignCodeType
	 */
	public String getIntlAssignCodeType() {
		return intlAssignCodeType;
	}

	/**
	 * @param intlAssignCodeType the intlAssignCodeType to set
	 */
	public void setIntlAssignCodeType(String intlAssignCodeType) {
		this.intlAssignCodeType = intlAssignCodeType;
	}

	/**
	 * @return the nextIntlAssignCodeType
	 */
	public String getNextIntlAssignCodeType() {
		return nextIntlAssignCodeType;
	}

	/**
	 * @param nextIntlAssignCodeType the nextIntlAssignCodeType to set
	 */
	public void setNextIntlAssignCodeType(String nextIntlAssignCodeType) {
		this.nextIntlAssignCodeType = nextIntlAssignCodeType;
	}

	/**
	 * @return the nextCrewBase
	 */
	public Integer getNextCrewBase() {
		return nextCrewBase;
	}

	/**
	 * @param nextCrewBase the nextCrewBase to set
	 */
	public void setNextCrewBase(Integer nextCrewBase) {
		this.nextCrewBase = nextCrewBase;
	}

	/**
	 * @return the nextCrewBaseDate
	 */
	public Integer getNextCrewBaseDate() {
		return nextCrewBaseDate;
	}

	/**
	 * @param nextCrewBaseDate the nextCrewBaseDate to set
	 */
	public void setNextCrewBaseDate(Integer nextCrewBaseDate) {
		this.nextCrewBaseDate = nextCrewBaseDate;
	}

	/**
	 * @return the payrollExcludeIndicator
	 */
	public boolean isPayrollExcludeIndicator() {
		return payrollExcludeIndicator;
	}

	/**
	 * @param payrollExcludeIndicator the payrollExcludeIndicator to set
	 */
	public void setPayrollExcludeIndicator(boolean payrollExcludeIndicator) {
		this.payrollExcludeIndicator = payrollExcludeIndicator;
	}

	/**
	 * @return the retainSeniorityIndicator
	 */
	public boolean isRetainSeniorityIndicator() {
		return retainSeniorityIndicator;
	}

	/**
	 * @param retainSeniorityIndicator the retainSeniorityIndicator to set
	 */
	public void setRetainSeniorityIndicator(boolean retainSeniorityIndicator) {
		this.retainSeniorityIndicator = retainSeniorityIndicator;
	}

	/**
	 * @return the annualSenSequence
	 */
	public Integer getAnnualSenSequence() {
		return annualSenSequence;
	}

	/**
	 * @param annualSenSequence the annualSenSequence to set
	 */
	public void setAnnualSenSequence(Integer annualSenSequence) {
		this.annualSenSequence = annualSenSequence;
	}

	/**
	 * @return the currentSeniorityNumber
	 */
	public Integer getCurrentSeniorityNumber() {
		return currentSeniorityNumber;
	}

	/**
	 * @param currentSeniorityNumber the currentSeniorityNumber to set
	 */
	public void setCurrentSeniorityNumber(Integer currentSeniorityNumber) {
		this.currentSeniorityNumber = currentSeniorityNumber;
	}

	/**
	 * @return the yearOfService
	 */
	public Integer getYearOfService() {
		return yearOfService;
	}

	/**
	 * @param yearOfService the yearOfService to set
	 */
	public void setYearOfService(Integer yearOfService) {
		this.yearOfService = yearOfService;
	}

	/**
	 * @return the conditionCodeType
	 */
	public Integer getConditionCodeType() {
		return conditionCodeType;
	}

	/**
	 * @param conditionCodeType the conditionCodeType to set
	 */
	public void setConditionCodeType(Integer conditionCodeType) {
		this.conditionCodeType = conditionCodeType;
	}

	/**
	 * @return the permStatusCode
	 */
	public Integer getPermStatusCode() {
		return permStatusCode;
	}

	/**
	 * @param permStatusCode the permStatusCode to set
	 */
	public void setPermStatusCode(Integer permStatusCode) {
		this.permStatusCode = permStatusCode;
	}

	/**
	 * @return the permStatusEffDate
	 */
	public Integer getPermStatusEffDate() {
		return permStatusEffDate;
	}

	/**
	 * @param permStatusEffDate the permStatusEffDate to set
	 */
	public void setPermStatusEffDate(Integer permStatusEffDate) {
		this.permStatusEffDate = permStatusEffDate;
	}

	/**
	 * @return the permStatusTrmDate
	 */
	public Integer getPermStatusTrmDate() {
		return permStatusTrmDate;
	}

	/**
	 * @param permStatusTrmDate the permStatusTrmDate to set
	 */
	public void setPermStatusTrmDate(Integer permStatusTrmDate) {
		this.permStatusTrmDate = permStatusTrmDate;
	}

	/**
	 * @return the nextPermStatusCode
	 */
	public Integer getNextPermStatusCode() {
		return nextPermStatusCode;
	}

	/**
	 * @param nextPermStatusCode the nextPermStatusCode to set
	 */
	public void setNextPermStatusCode(Integer nextPermStatusCode) {
		this.nextPermStatusCode = nextPermStatusCode;
	}

	/**
	 * @return the nextPermStatusEffDate
	 */
	public Integer getNextPermStatusEffDate() {
		return nextPermStatusEffDate;
	}

	/**
	 * @param nextPermStatusEffDate the nextPermStatusEffDate to set
	 */
	public void setNextPermStatusEffDate(Integer nextPermStatusEffDate) {
		this.nextPermStatusEffDate = nextPermStatusEffDate;
	}

	/**
	 * @return the tempStatusEffDate
	 */
	public Integer getTempStatusEffDate() {
		return tempStatusEffDate;
	}

	/**
	 * @param tempStatusEffDate the tempStatusEffDate to set
	 */
	public void setTempStatusEffDate(Integer tempStatusEffDate) {
		this.tempStatusEffDate = tempStatusEffDate;
	}

	/**
	 * @return the tempStatusTrmDate
	 */
	public Integer getTempStatusTrmDate() {
		return tempStatusTrmDate;
	}

	/**
	 * @param tempStatusTrmDate the tempStatusTrmDate to set
	 */
	public void setTempStatusTrmDate(Integer tempStatusTrmDate) {
		this.tempStatusTrmDate = tempStatusTrmDate;
	}

	/**
	 * @return the tempStatusCode
	 */
	public Integer getTempStatusCode() {
		return tempStatusCode;
	}

	/**
	 * @param tempStatusCode the tempStatusCode to set
	 */
	public void setTempStatusCode(Integer tempStatusCode) {
		this.tempStatusCode = tempStatusCode;
	}

	/**
	 * @return the nextTempStatusEffDate
	 */
	public Integer getNextTempStatusEffDate() {
		return nextTempStatusEffDate;
	}

	/**
	 * @param nextTempStatusEffDate the nextTempStatusEffDate to set
	 */
	public void setNextTempStatusEffDate(Integer nextTempStatusEffDate) {
		this.nextTempStatusEffDate = nextTempStatusEffDate;
	}

	/**
	 * @return the nextTempStatusTrmDate
	 */
	public Integer getNextTempStatusTrmDate() {
		return nextTempStatusTrmDate;
	}

	/**
	 * @param nextTempStatusTrmDate the nextTempStatusTrmDate to set
	 */
	public void setNextTempStatusTrmDate(Integer nextTempStatusTrmDate) {
		this.nextTempStatusTrmDate = nextTempStatusTrmDate;
	}

	/**
	 * @return the nextTempStatusCode
	 */
	public Integer getNextTempStatusCode() {
		return nextTempStatusCode;
	}

	/**
	 * @param nextTempStatusCode the nextTempStatusCode to set
	 */
	public void setNextTempStatusCode(Integer nextTempStatusCode) {
		this.nextTempStatusCode = nextTempStatusCode;
	}

	/**
	 * @return the macEffDate
	 */
	public Integer getMacEffDate() {
		return macEffDate;
	}

	/**
	 * @param macEffDate the macEffDate to set
	 */
	public void setMacEffDate(Integer macEffDate) {
		this.macEffDate = macEffDate;
	}

	/**
	 * @return the macTrmDate
	 */
	public Integer getMacTrmDate() {
		return macTrmDate;
	}

	/**
	 * @param macTrmDate the macTrmDate to set
	 */
	public void setMacTrmDate(Integer macTrmDate) {
		this.macTrmDate = macTrmDate;
	}

	/**
	 * @return the trainingBaseEffDate
	 */
	public Integer getTrainingBaseEffDate() {
		return trainingBaseEffDate;
	}

	/**
	 * @param trainingBaseEffDate the trainingBaseEffDate to set
	 */
	public void setTrainingBaseEffDate(Integer trainingBaseEffDate) {
		this.trainingBaseEffDate = trainingBaseEffDate;
	}

	/**
	 * @return the trainingBaseTrmDate
	 */
	public Integer getTrainingBaseTrmDate() {
		return trainingBaseTrmDate;
	}

	/**
	 * @param trainingBaseTrmDate the trainingBaseTrmDate to set
	 */
	public void setTrainingBaseTrmDate(Integer trainingBaseTrmDate) {
		this.trainingBaseTrmDate = trainingBaseTrmDate;
	}

	/**
	 * @return the passportDate
	 */
	public Integer getPassportDate() {
		return passportDate;
	}

	/**
	 * @param passportDate the passportDate to set
	 */
	public void setPassportDate(Integer passportDate) {
		this.passportDate = passportDate;
	}

	/**
	 * @return the passportNumber
	 */
	public String getPassportNumber() {
		return passportNumber;
	}

	/**
	 * @param passportNumber the passportNumber to set
	 */
	public void setPassportNumber(String passportNumber) {
		this.passportNumber = passportNumber;
	}

	/**
	 * @return the passportCountryCode
	 */
	public String getPassportCountryCode() {
		return passportCountryCode;
	}

	/**
	 * @param passportCountryCode the passportCountryCode to set
	 */
	public void setPassportCountryCode(String passportCountryCode) {
		this.passportCountryCode = passportCountryCode;
	}

	/**
	 * @return the passportExpDate
	 */
	public Integer getPassportExpDate() {
		return passportExpDate;
	}

	/**
	 * @param passportExpDate the passportExpDate to set
	 */
	public void setPassportExpDate(Integer passportExpDate) {
		this.passportExpDate = passportExpDate;
	}

	/**
	 * @return the icaoRegistrationNo
	 */
	public String getIcaoRegistrationNo() {
		return icaoRegistrationNo;
	}

	/**
	 * @param icaoRegistrationNo the icaoRegistrationNo to set
	 */
	public void setIcaoRegistrationNo(String icaoRegistrationNo) {
		this.icaoRegistrationNo = icaoRegistrationNo;
	}

	/**
	 * @return the icaoIssueDate
	 */
	public Integer getIcaoIssueDate() {
		return icaoIssueDate;
	}

	/**
	 * @param icaoIssueDate the icaoIssueDate to set
	 */
	public void setIcaoIssueDate(Integer icaoIssueDate) {
		this.icaoIssueDate = icaoIssueDate;
	}

	/**
	 * @return the companyMedicalDate
	 */
	public Integer getCompanyMedicalDate() {
		return companyMedicalDate;
	}

	/**
	 * @param companyMedicalDate the companyMedicalDate to set
	 */
	public void setCompanyMedicalDate(Integer companyMedicalDate) {
		this.companyMedicalDate = companyMedicalDate;
	}

	/**
	 * @return the fAAMedicalDate
	 */
	public Integer getFAAMedicalDate() {
		return FAAMedicalDate;
	}

	/**
	 * @param fAAMedicalDate the fAAMedicalDate to set
	 */
	public void setFAAMedicalDate(Integer fAAMedicalDate) {
		FAAMedicalDate = fAAMedicalDate;
	}

	/**
	 * @return the fAAMedicalClass
	 */
	public Integer getFAAMedicalClass() {
		return FAAMedicalClass;
	}

	/**
	 * @param fAAMedicalClass the fAAMedicalClass to set
	 */
	public void setFAAMedicalClass(Integer fAAMedicalClass) {
		FAAMedicalClass = fAAMedicalClass;
	}

	/**
	 * @return the fAADoctor
	 */
	public String getFAADoctor() {
		return FAADoctor;
	}

	/**
	 * @param fAADoctor the fAADoctor to set
	 */
	public void setFAADoctor(String fAADoctor) {
		FAADoctor = fAADoctor;
	}

	/**
	 * @return the medicalLocationInd
	 */
	public String getMedicalLocationInd() {
		return medicalLocationInd;
	}

	/**
	 * @param medicalLocationInd the medicalLocationInd to set
	 */
	public void setMedicalLocationInd(String medicalLocationInd) {
		this.medicalLocationInd = medicalLocationInd;
	}

	/**
	 * @return the companyMedicalBaseMonth
	 */
	public Integer getCompanyMedicalBaseMonth() {
		return companyMedicalBaseMonth;
	}

	/**
	 * @param companyMedicalBaseMonth the companyMedicalBaseMonth to set
	 */
	public void setCompanyMedicalBaseMonth(Integer companyMedicalBaseMonth) {
		this.companyMedicalBaseMonth = companyMedicalBaseMonth;
	}

	/**
	 * @return the fAAMedicalBaseMonth
	 */
	public Integer getFAAMedicalBaseMonth() {
		return FAAMedicalBaseMonth;
	}

	/**
	 * @param fAAMedicalBaseMonth the fAAMedicalBaseMonth to set
	 */
	public void setFAAMedicalBaseMonth(Integer fAAMedicalBaseMonth) {
		FAAMedicalBaseMonth = fAAMedicalBaseMonth;
	}

	/**
	 * @return the sickReleaseDate
	 */
	public Integer getSickReleaseDate() {
		return sickReleaseDate;
	}

	/**
	 * @param sickReleaseDate the sickReleaseDate to set
	 */
	public void setSickReleaseDate(Integer sickReleaseDate) {
		this.sickReleaseDate = sickReleaseDate;
	}

	/**
	 * @return the unpaidSickStartDate
	 */
	public Integer getUnpaidSickStartDate() {
		return unpaidSickStartDate;
	}

	/**
	 * @param unpaidSickStartDate the unpaidSickStartDate to set
	 */
	public void setUnpaidSickStartDate(Integer unpaidSickStartDate) {
		this.unpaidSickStartDate = unpaidSickStartDate;
	}

	/**
	 * @return the sickReleaseMins
	 */
	public Integer getSickReleaseMins() {
		return sickReleaseMins;
	}

	/**
	 * @param sickReleaseMins the sickReleaseMins to set
	 */
	public void setSickReleaseMins(Integer sickReleaseMins) {
		this.sickReleaseMins = sickReleaseMins;
	}

	/**
	 * @return the unUsedSickTime
	 */
	public Integer getUnUsedSickTime() {
		return unUsedSickTime;
	}

	/**
	 * @param unUsedSickTime the unUsedSickTime to set
	 */
	public void setUnUsedSickTime(Integer unUsedSickTime) {
		this.unUsedSickTime = unUsedSickTime;
	}

	/**
	 * @return the sickTimeMinsUsedYTD
	 */
	public Integer getSickTimeMinsUsedYTD() {
		return sickTimeMinsUsedYTD;
	}

	/**
	 * @param sickTimeMinsUsedYTD the sickTimeMinsUsedYTD to set
	 */
	public void setSickTimeMinsUsedYTD(Integer sickTimeMinsUsedYTD) {
		this.sickTimeMinsUsedYTD = sickTimeMinsUsedYTD;
	}

	/**
	 * @return the sickTimeMakeUp
	 */
	public Integer getSickTimeMakeUp() {
		return sickTimeMakeUp;
	}

	/**
	 * @param sickTimeMakeUp the sickTimeMakeUp to set
	 */
	public void setSickTimeMakeUp(Integer sickTimeMakeUp) {
		this.sickTimeMakeUp = sickTimeMakeUp;
	}

	/**
	 * @return the sickTimeMinsUsedMTD
	 */
	public Integer getSickTimeMinsUsedMTD() {
		return sickTimeMinsUsedMTD;
	}

	/**
	 * @param sickTimeMinsUsedMTD the sickTimeMinsUsedMTD to set
	 */
	public void setSickTimeMinsUsedMTD(Integer sickTimeMinsUsedMTD) {
		this.sickTimeMinsUsedMTD = sickTimeMinsUsedMTD;
	}

	/**
	 * @return the mergeEmployeeInd
	 */
	public String getMergeEmployeeInd() {
		return mergeEmployeeInd;
	}

	/**
	 * @param mergeEmployeeInd the mergeEmployeeInd to set
	 */
	public void setMergeEmployeeInd(String mergeEmployeeInd) {
		this.mergeEmployeeInd = mergeEmployeeInd;
	}

	/**
	 * @return the currentProjection
	 */
	public Integer getCurrentProjection() {
		return currentProjection;
	}

	/**
	 * @param currentProjection the currentProjection to set
	 */
	public void setCurrentProjection(Integer currentProjection) {
		this.currentProjection = currentProjection;
	}

	/**
	 * @return the scheduledProjection
	 */
	public Integer getScheduledProjection() {
		return scheduledProjection;
	}

	/**
	 * @param scheduledProjection the scheduledProjection to set
	 */
	public void setScheduledProjection(Integer scheduledProjection) {
		this.scheduledProjection = scheduledProjection;
	}

	/**
	 * @return the greaterTimeMTD
	 */
	public Integer getGreaterTimeMTD() {
		return greaterTimeMTD;
	}

	/**
	 * @param greaterTimeMTD the greaterTimeMTD to set
	 */
	public void setGreaterTimeMTD(Integer greaterTimeMTD) {
		this.greaterTimeMTD = greaterTimeMTD;
	}

	/**
	 * @return the specAssignmentCurrentMins
	 */
	public Integer getSpecAssignmentCurrentMins() {
		return specAssignmentCurrentMins;
	}

	/**
	 * @param specAssignmentCurrentMins the specAssignmentCurrentMins to set
	 */
	public void setSpecAssignmentCurrentMins(Integer specAssignmentCurrentMins) {
		this.specAssignmentCurrentMins = specAssignmentCurrentMins;
	}

	/**
	 * @return the intlSequenceCurrentMins
	 */
	public Integer getIntlSequenceCurrentMins() {
		return intlSequenceCurrentMins;
	}

	/**
	 * @param intlSequenceCurrentMins the intlSequenceCurrentMins to set
	 */
	public void setIntlSequenceCurrentMins(Integer intlSequenceCurrentMins) {
		this.intlSequenceCurrentMins = intlSequenceCurrentMins;
	}

	/**
	 * @return the reassignPayMins
	 */
	public Integer getReassignPayMins() {
		return reassignPayMins;
	}

	/**
	 * @param reassignPayMins the reassignPayMins to set
	 */
	public void setReassignPayMins(Integer reassignPayMins) {
		this.reassignPayMins = reassignPayMins;
	}

	/**
	 * @return the underStaffPTRNPayMins
	 */
	public Integer getUnderStaffPTRNPayMins() {
		return underStaffPTRNPayMins;
	}

	/**
	 * @param underStaffPTRNPayMins the underStaffPTRNPayMins to set
	 */
	public void setUnderStaffPTRNPayMins(Integer underStaffPTRNPayMins) {
		this.underStaffPTRNPayMins = underStaffPTRNPayMins;
	}

	/**
	 * @return the underStaffSRVCPayMins
	 */
	public Integer getUnderStaffSRVCPayMins() {
		return underStaffSRVCPayMins;
	}

	/**
	 * @param underStaffSRVCPayMins the underStaffSRVCPayMins to set
	 */
	public void setUnderStaffSRVCPayMins(Integer underStaffSRVCPayMins) {
		this.underStaffSRVCPayMins = underStaffSRVCPayMins;
	}

	/**
	 * @return the nightPayMins
	 */
	public Integer getNightPayMins() {
		return nightPayMins;
	}

	/**
	 * @param nightPayMins the nightPayMins to set
	 */
	public void setNightPayMins(Integer nightPayMins) {
		this.nightPayMins = nightPayMins;
	}

	/**
	 * @return the fAPremPayOrPltCpaMins
	 */
	public Integer getfAPremPayOrPltCpaMins() {
		return fAPremPayOrPltCpaMins;
	}

	/**
	 * @param fAPremPayOrPltCpaMins the fAPremPayOrPltCpaMins to set
	 */
	public void setfAPremPayOrPltCpaMins(Integer fAPremPayOrPltCpaMins) {
		this.fAPremPayOrPltCpaMins = fAPremPayOrPltCpaMins;
	}

	/**
	 * @return the foreignLanguagePayLeg
	 */
	public Integer getForeignLanguagePayLeg() {
		return foreignLanguagePayLeg;
	}

	/**
	 * @param foreignLanguagePayLeg the foreignLanguagePayLeg to set
	 */
	public void setForeignLanguagePayLeg(Integer foreignLanguagePayLeg) {
		this.foreignLanguagePayLeg = foreignLanguagePayLeg;
	}

	/**
	 * @return the holdTimePayMins
	 */
	public Integer getHoldTimePayMins() {
		return holdTimePayMins;
	}

	/**
	 * @param holdTimePayMins the holdTimePayMins to set
	 */
	public void setHoldTimePayMins(Integer holdTimePayMins) {
		this.holdTimePayMins = holdTimePayMins;
	}

	/**
	 * @return the groundTimePayMins
	 */
	public Integer getGroundTimePayMins() {
		return groundTimePayMins;
	}

	/**
	 * @param groundTimePayMins the groundTimePayMins to set
	 */
	public void setGroundTimePayMins(Integer groundTimePayMins) {
		this.groundTimePayMins = groundTimePayMins;
	}

	/**
	 * @return the totalDomesticExpenses
	 */
	public Integer getTotalDomesticExpenses() {
		return totalDomesticExpenses;
	}

	/**
	 * @param totalDomesticExpenses the totalDomesticExpenses to set
	 */
	public void setTotalDomesticExpenses(Integer totalDomesticExpenses) {
		this.totalDomesticExpenses = totalDomesticExpenses;
	}

	/**
	 * @return the totalDomesticTaxableExpenses
	 */
	public Integer getTotalDomesticTaxableExpenses() {
		return totalDomesticTaxableExpenses;
	}

	/**
	 * @param totalDomesticTaxableExpenses the totalDomesticTaxableExpenses to set
	 */
	public void setTotalDomesticTaxableExpenses(Integer totalDomesticTaxableExpenses) {
		this.totalDomesticTaxableExpenses = totalDomesticTaxableExpenses;
	}

	/**
	 * @return the totalMiscTaxableExpenses
	 */
	public Integer getTotalMiscTaxableExpenses() {
		return totalMiscTaxableExpenses;
	}

	/**
	 * @param totalMiscTaxableExpenses the totalMiscTaxableExpenses to set
	 */
	public void setTotalMiscTaxableExpenses(Integer totalMiscTaxableExpenses) {
		this.totalMiscTaxableExpenses = totalMiscTaxableExpenses;
	}

	/**
	 * @return the totalMiscExpenses
	 */
	public Integer getTotalMiscExpenses() {
		return totalMiscExpenses;
	}

	/**
	 * @param totalMiscExpenses the totalMiscExpenses to set
	 */
	public void setTotalMiscExpenses(Integer totalMiscExpenses) {
		this.totalMiscExpenses = totalMiscExpenses;
	}

	/**
	 * @return the tripSelectionNumber
	 */
	public Integer getTripSelectionNumber() {
		return tripSelectionNumber;
	}

	/**
	 * @param tripSelectionNumber the tripSelectionNumber to set
	 */
	public void setTripSelectionNumber(Integer tripSelectionNumber) {
		this.tripSelectionNumber = tripSelectionNumber;
	}

	/**
	 * @return the selectionCrewBaseCode
	 */
	public Integer getSelectionCrewBaseCode() {
		return selectionCrewBaseCode;
	}

	/**
	 * @param selectionCrewBaseCode the selectionCrewBaseCode to set
	 */
	public void setSelectionCrewBaseCode(Integer selectionCrewBaseCode) {
		this.selectionCrewBaseCode = selectionCrewBaseCode;
	}

	/**
	 * @return the monthCrewMemberPositionCode
	 */
	public Integer getMonthCrewMemberPositionCode() {
		return monthCrewMemberPositionCode;
	}

	/**
	 * @param monthCrewMemberPositionCode the monthCrewMemberPositionCode to set
	 */
	public void setMonthCrewMemberPositionCode(Integer monthCrewMemberPositionCode) {
		this.monthCrewMemberPositionCode = monthCrewMemberPositionCode;
	}

	/**
	 * @return the monthDomIntlCode
	 */
	public String getMonthDomIntlCode() {
		return monthDomIntlCode;
	}

	/**
	 * @param monthDomIntlCode the monthDomIntlCode to set
	 */
	public void setMonthDomIntlCode(String monthDomIntlCode) {
		this.monthDomIntlCode = monthDomIntlCode;
	}

	/**
	 * @return the inactiveSelRsnCode
	 */
	public String getInactiveSelRsnCode() {
		return inactiveSelRsnCode;
	}

	/**
	 * @param inactiveSelRsnCode the inactiveSelRsnCode to set
	 */
	public void setInactiveSelRsnCode(String inactiveSelRsnCode) {
		this.inactiveSelRsnCode = inactiveSelRsnCode;
	}

	/**
	 * @return the pABidInd
	 */
	public String getPABidInd() {
		return PABidInd;
	}

	/**
	 * @param pABidInd the pABidInd to set
	 */
	public void setPABidInd(String pABidInd) {
		PABidInd = pABidInd;
	}

	/**
	 * @return the tripSelTypeCode
	 */
	public Integer getTripSelTypeCode() {
		return tripSelTypeCode;
	}

	/**
	 * @param tripSelTypeCode the tripSelTypeCode to set
	 */
	public void setTripSelTypeCode(Integer tripSelTypeCode) {
		this.tripSelTypeCode = tripSelTypeCode;
	}

	/**
	 * @return the highEqpTypeCode
	 */
	public String getHighEqpTypeCode() {
		return highEqpTypeCode;
	}

	/**
	 * @param highEqpTypeCode the highEqpTypeCode to set
	 */
	public void setHighEqpTypeCode(String highEqpTypeCode) {
		this.highEqpTypeCode = highEqpTypeCode;
	}

	/**
	 * @return the callOutStandbyQty
	 */
	public Integer getCallOutStandbyQty() {
		return callOutStandbyQty;
	}

	/**
	 * @param callOutStandbyQty the callOutStandbyQty to set
	 */
	public void setCallOutStandbyQty(Integer callOutStandbyQty) {
		this.callOutStandbyQty = callOutStandbyQty;
	}

	/**
	 * @return the faBidOptCode
	 */
	public String getFaBidOptCode() {
		return faBidOptCode;
	}

	/**
	 * @param faBidOptCode the faBidOptCode to set
	 */
	public void setFaBidOptCode(String faBidOptCode) {
		this.faBidOptCode = faBidOptCode;
	}

	/**
	 * @return the dailyBidGroup
	 */
	public List<DailyBidGroupDto> getDailyBidGroup() {
		return dailyBidGroup;
	}

	/**
	 * @param dailyBidGroup the dailyBidGroup to set
	 */
	public void setDailyBidGroup(List<DailyBidGroupDto> dailyBidGroup) {
		this.dailyBidGroup = dailyBidGroup;
	}

	/**
	 * @return the intlPayMins
	 */
	public Integer getIntlPayMins() {
		return intlPayMins;
	}

	/**
	 * @param intlPayMins the intlPayMins to set
	 */
	public void setIntlPayMins(Integer intlPayMins) {
		this.intlPayMins = intlPayMins;
	}

	/**
	 * @return the firstInitial
	 */
	public String getFirstInitial() {
		return firstInitial;
	}

	/**
	 * @param firstInitial the firstInitial to set
	 */
	public void setFirstInitial(String firstInitial) {
		this.firstInitial = firstInitial;
	}

	/**
	 * @return the middleInitial
	 */
	public String getMiddleInitial() {
		return middleInitial;
	}

	/**
	 * @param middleInitial the middleInitial to set
	 */
	public void setMiddleInitial(String middleInitial) {
		this.middleInitial = middleInitial;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * @return the birthDate
	 */
	public Integer getBirthDate() {
		return birthDate;
	}

	/**
	 * @param birthDate the birthDate to set
	 */
	public void setBirthDate(Integer birthDate) {
		this.birthDate = birthDate;
	}

	/**
	 * @return the compaySeniorityDate
	 */
	public Integer getCompaySeniorityDate() {
		return compaySeniorityDate;
	}

	/**
	 * @param compaySeniorityDate the compaySeniorityDate to set
	 */
	public void setCompaySeniorityDate(Integer compaySeniorityDate) {
		this.compaySeniorityDate = compaySeniorityDate;
	}

	/**
	 * @return the occupSeniorityDate
	 */
	public Integer getOccupSeniorityDate() {
		return occupSeniorityDate;
	}

	/**
	 * @param occupSeniorityDate the occupSeniorityDate to set
	 */
	public void setOccupSeniorityDate(Integer occupSeniorityDate) {
		this.occupSeniorityDate = occupSeniorityDate;
	}

	/**
	 * @return the clsSeniorityDate
	 */
	public Integer getClsSeniorityDate() {
		return clsSeniorityDate;
	}

	/**
	 * @param clsSeniorityDate the clsSeniorityDate to set
	 */
	public void setClsSeniorityDate(Integer clsSeniorityDate) {
		this.clsSeniorityDate = clsSeniorityDate;
	}

	/**
	 * @return the orgHireDate
	 */
	public Integer getOrgHireDate() {
		return orgHireDate;
	}

	/**
	 * @param orgHireDate the orgHireDate to set
	 */
	public void setOrgHireDate(Integer orgHireDate) {
		this.orgHireDate = orgHireDate;
	}

	/**
	 * @return the commuteFlag
	 */
	public Integer getCommuteFlag() {
		return commuteFlag;
	}

	/**
	 * @param commuteFlag the commuteFlag to set
	 */
	public void setCommuteFlag(Integer commuteFlag) {
		this.commuteFlag = commuteFlag;
	}

	/**
	 * @return the varManInd
	 */
	public boolean isVarManInd() {
		return varManInd;
	}

	/**
	 * @param varManInd the varManInd to set
	 */
	public void setVarManInd(boolean varManInd) {
		this.varManInd = varManInd;
	}

	/**
	 * @return the paperBidReason
	 */
	public Integer getPaperBidReason() {
		return paperBidReason;
	}

	/**
	 * @param paperBidReason the paperBidReason to set
	 */
	public void setPaperBidReason(Integer paperBidReason) {
		this.paperBidReason = paperBidReason;
	}

	/**
	 * @return the currentBidStatGrp
	 */
	public BidStatusGroupDto getCurrentBidStatGrp() {
		return currentBidStatGrp;
	}

	/**
	 * @param currentBidStatGrp the currentBidStatGrp to set
	 */
	public void setCurrentBidStatGrp(BidStatusGroupDto currentBidStatGrp) {
		this.currentBidStatGrp = currentBidStatGrp;
	}

	/**
	 * @return the nextBidStatGrp
	 */
	public BidStatusGroupDto getNextBidStatGrp() {
		return nextBidStatGrp;
	}

	/**
	 * @param nextBidStatGrp the nextBidStatGrp to set
	 */
	public void setNextBidStatGrp(BidStatusGroupDto nextBidStatGrp) {
		this.nextBidStatGrp = nextBidStatGrp;
	}

	/**
	 * @return the withBidStatGrp
	 */
	public BidStatusGroupDto getWithBidStatGrp() {
		return withBidStatGrp;
	}

	/**
	 * @param withBidStatGrp the withBidStatGrp to set
	 */
	public void setWithBidStatGrp(BidStatusGroupDto withBidStatGrp) {
		this.withBidStatGrp = withBidStatGrp;
	}

	/**
	 * @return the deferralBidPositionCode
	 */
	public Integer getDeferralBidPositionCode() {
		return deferralBidPositionCode;
	}

	/**
	 * @param deferralBidPositionCode the deferralBidPositionCode to set
	 */
	public void setDeferralBidPositionCode(Integer deferralBidPositionCode) {
		this.deferralBidPositionCode = deferralBidPositionCode;
	}

	/**
	 * @return the deferralBidEffDate
	 */
	public Integer getDeferralBidEffDate() {
		return deferralBidEffDate;
	}

	/**
	 * @param deferralBidEffDate the deferralBidEffDate to set
	 */
	public void setDeferralBidEffDate(Integer deferralBidEffDate) {
		this.deferralBidEffDate = deferralBidEffDate;
	}

	/**
	 * @return the nextBidDisplacementPrefCode
	 */
	public Integer getNextBidDisplacementPrefCode() {
		return nextBidDisplacementPrefCode;
	}

	/**
	 * @param nextBidDisplacementPrefCode the nextBidDisplacementPrefCode to set
	 */
	public void setNextBidDisplacementPrefCode(Integer nextBidDisplacementPrefCode) {
		this.nextBidDisplacementPrefCode = nextBidDisplacementPrefCode;
	}

	/**
	 * @return the excludeMolyFlyHRSAgrmtInd
	 */
	public boolean isExcludeMolyFlyHRSAgrmtInd() {
		return excludeMolyFlyHRSAgrmtInd;
	}

	/**
	 * @param excludeMolyFlyHRSAgrmtInd the excludeMolyFlyHRSAgrmtInd to set
	 */
	public void setExcludeMolyFlyHRSAgrmtInd(boolean excludeMolyFlyHRSAgrmtInd) {
		this.excludeMolyFlyHRSAgrmtInd = excludeMolyFlyHRSAgrmtInd;
	}

	/**
	 * @return the captBidRqmtInd
	 */
	public boolean isCaptBidRqmtInd() {
		return captBidRqmtInd;
	}

	/**
	 * @param captBidRqmtInd the captBidRqmtInd to set
	 */
	public void setCaptBidRqmtInd(boolean captBidRqmtInd) {
		this.captBidRqmtInd = captBidRqmtInd;
	}

	/**
	 * @return the foBidRqmtInd
	 */
	public boolean isFoBidRqmtInd() {
		return foBidRqmtInd;
	}

	/**
	 * @param foBidRqmtInd the foBidRqmtInd to set
	 */
	public void setFoBidRqmtInd(boolean foBidRqmtInd) {
		this.foBidRqmtInd = foBidRqmtInd;
	}

	/**
	 * @return the aircalFormerEmpInd
	 */
	public String getAircalFormerEmpInd() {
		return aircalFormerEmpInd;
	}

	/**
	 * @param aircalFormerEmpInd the aircalFormerEmpInd to set
	 */
	public void setAircalFormerEmpInd(String aircalFormerEmpInd) {
		this.aircalFormerEmpInd = aircalFormerEmpInd;
	}

	/**
	 * @return the guaranteeMinMontMins
	 */
	public Integer getGuaranteeMinMontMins() {
		return guaranteeMinMontMins;
	}

	/**
	 * @param guaranteeMinMontMins the guaranteeMinMontMins to set
	 */
	public void setGuaranteeMinMontMins(Integer guaranteeMinMontMins) {
		this.guaranteeMinMontMins = guaranteeMinMontMins;
	}

	/**
	 * @return the foreignLangPayMins
	 */
	public Integer getForeignLangPayMins() {
		return foreignLangPayMins;
	}

	/**
	 * @param foreignLangPayMins the foreignLangPayMins to set
	 */
	public void setForeignLangPayMins(Integer foreignLangPayMins) {
		this.foreignLangPayMins = foreignLangPayMins;
	}

	/**
	 * @return the crwbSupervisorNum
	 */
	public Integer getCrwbSupervisorNum() {
		return crwbSupervisorNum;
	}

	/**
	 * @param crwbSupervisorNum the crwbSupervisorNum to set
	 */
	public void setCrwbSupervisorNum(Integer crwbSupervisorNum) {
		this.crwbSupervisorNum = crwbSupervisorNum;
	}

	/**
	 * @return the drugTestDate
	 */
	public Integer getDrugTestDate() {
		return drugTestDate;
	}

	/**
	 * @param drugTestDate the drugTestDate to set
	 */
	public void setDrugTestDate(Integer drugTestDate) {
		this.drugTestDate = drugTestDate;
	}

	/**
	 * @return the lastFlownDate
	 */
	public Integer getLastFlownDate() {
		return lastFlownDate;
	}

	/**
	 * @param lastFlownDate the lastFlownDate to set
	 */
	public void setLastFlownDate(Integer lastFlownDate) {
		this.lastFlownDate = lastFlownDate;
	}

	/**
	 * @return the intlTotalExpenses
	 */
	public Integer getIntlTotalExpenses() {
		return IntlTotalExpenses;
	}

	/**
	 * @param intlTotalExpenses the intlTotalExpenses to set
	 */
	public void setIntlTotalExpenses(Integer intlTotalExpenses) {
		IntlTotalExpenses = intlTotalExpenses;
	}

	/**
	 * @return the intlTotalTaxableExpenses
	 */
	public Integer getIntlTotalTaxableExpenses() {
		return IntlTotalTaxableExpenses;
	}

	/**
	 * @param intlTotalTaxableExpenses the intlTotalTaxableExpenses to set
	 */
	public void setIntlTotalTaxableExpenses(Integer intlTotalTaxableExpenses) {
		IntlTotalTaxableExpenses = intlTotalTaxableExpenses;
	}

	/**
	 * @return the tsPayProjMins
	 */
	public Integer getTsPayProjMins() {
		return tsPayProjMins;
	}

	/**
	 * @param tsPayProjMins the tsPayProjMins to set
	 */
	public void setTsPayProjMins(Integer tsPayProjMins) {
		this.tsPayProjMins = tsPayProjMins;
	}

	/**
	 * @return the bidSelProjMins
	 */
	public Integer getBidSelProjMins() {
		return bidSelProjMins;
	}

	/**
	 * @param bidSelProjMins the bidSelProjMins to set
	 */
	public void setBidSelProjMins(Integer bidSelProjMins) {
		this.bidSelProjMins = bidSelProjMins;
	}

	/**
	 * @return the ckaFlag
	 */
	public String getCkaFlag() {
		return ckaFlag;
	}

	/**
	 * @param ckaFlag the ckaFlag to set
	 */
	public void setCkaFlag(String ckaFlag) {
		this.ckaFlag = ckaFlag;
	}

	/**
	 * @return the ckaType
	 */
	public String getCkaType() {
		return ckaType;
	}

	/**
	 * @param ckaType the ckaType to set
	 */
	public void setCkaType(String ckaType) {
		this.ckaType = ckaType;
	}

	/**
	 * @return the ckaBank
	 */
	public Integer getCkaBank() {
		return ckaBank;
	}

	/**
	 * @param ckaBank the ckaBank to set
	 */
	public void setCkaBank(Integer ckaBank) {
		this.ckaBank = ckaBank;
	}

	/**
	 * @return the faActualBaseGuar
	 */
	public Integer getFaActualBaseGuar() {
		return faActualBaseGuar;
	}

	/**
	 * @param faActualBaseGuar the faActualBaseGuar to set
	 */
	public void setFaActualBaseGuar(Integer faActualBaseGuar) {
		this.faActualBaseGuar = faActualBaseGuar;
	}

	/**
	 * @return the faActualIncGuar
	 */
	public Integer getFaActualIncGuar() {
		return faActualIncGuar;
	}

	/**
	 * @param faActualIncGuar the faActualIncGuar to set
	 */
	public void setFaActualIncGuar(Integer faActualIncGuar) {
		this.faActualIncGuar = faActualIncGuar;
	}

	/**
	 * @return the nightPayMins2
	 */
	public Integer getNightPayMins2() {
		return nightPayMins2;
	}

	/**
	 * @param nightPayMins2 the nightPayMins2 to set
	 */
	public void setNightPayMins2(Integer nightPayMins2) {
		this.nightPayMins2 = nightPayMins2;
	}

	/**
	 * @return the chaseFlMins
	 */
	public Integer getChaseFlMins() {
		return chaseFlMins;
	}

	/**
	 * @param chaseFlMins the chaseFlMins to set
	 */
	public void setChaseFlMins(Integer chaseFlMins) {
		this.chaseFlMins = chaseFlMins;
	}

	/**
	 * @return the homeTelephoneNumber
	 */
	public String getHomeTelephoneNumber() {
		return homeTelephoneNumber;
	}

	/**
	 * @param homeTelephoneNumber the homeTelephoneNumber to set
	 */
	public void setHomeTelephoneNumber(String homeTelephoneNumber) {
		this.homeTelephoneNumber = homeTelephoneNumber;
	}

	/**
	 * @return the businessTelephoneNumber
	 */
	public String getBusinessTelephoneNumber() {
		return businessTelephoneNumber;
	}

	/**
	 * @param businessTelephoneNumber the businessTelephoneNumber to set
	 */
	public void setBusinessTelephoneNumber(String businessTelephoneNumber) {
		this.businessTelephoneNumber = businessTelephoneNumber;
	}

	/**
	 * @return the tempTelephoneNumber
	 */
	public String getTempTelephoneNumber() {
		return tempTelephoneNumber;
	}

	/**
	 * @param tempTelephoneNumber the tempTelephoneNumber to set
	 */
	public void setTempTelephoneNumber(String tempTelephoneNumber) {
		this.tempTelephoneNumber = tempTelephoneNumber;
	}

	/**
	 * @return the empSecondaryTelephoneNumber
	 */
	public String getEmpSecondaryTelephoneNumber() {
		return empSecondaryTelephoneNumber;
	}

	/**
	 * @param empSecondaryTelephoneNumber the empSecondaryTelephoneNumber to set
	 */
	public void setEmpSecondaryTelephoneNumber(String empSecondaryTelephoneNumber) {
		this.empSecondaryTelephoneNumber = empSecondaryTelephoneNumber;
	}

	/**
	 * @return the restartedSickTimeMins
	 */
	public Integer getRestartedSickTimeMins() {
		return restartedSickTimeMins;
	}

	/**
	 * @param restartedSickTimeMins the restartedSickTimeMins to set
	 */
	public void setRestartedSickTimeMins(Integer restartedSickTimeMins) {
		this.restartedSickTimeMins = restartedSickTimeMins;
	}

	/**
	 * @return the adjCkptPayGurantee
	 */
	public Integer getAdjCkptPayGurantee() {
		return adjCkptPayGurantee;
	}

	/**
	 * @param adjCkptPayGurantee the adjCkptPayGurantee to set
	 */
	public void setAdjCkptPayGurantee(Integer adjCkptPayGurantee) {
		this.adjCkptPayGurantee = adjCkptPayGurantee;
	}

	/**
	 * @return the ckptWaviedInd
	 */
	public String getCkptWaviedInd() {
		return ckptWaviedInd;
	}

	/**
	 * @param ckptWaviedInd the ckptWaviedInd to set
	 */
	public void setCkptWaviedInd(String ckptWaviedInd) {
		this.ckptWaviedInd = ckptWaviedInd;
	}

	/**
	 * @return the origAirlineCode
	 */
	public String getOrigAirlineCode() {
		return origAirlineCode;
	}

	/**
	 * @param origAirlineCode the origAirlineCode to set
	 */
	public void setOrigAirlineCode(String origAirlineCode) {
		this.origAirlineCode = origAirlineCode;
	}

	/**
	 * @return the currentAirlineCode
	 */
	public String getCurrentAirlineCode() {
		return currentAirlineCode;
	}

	/**
	 * @param currentAirlineCode the currentAirlineCode to set
	 */
	public void setCurrentAirlineCode(String currentAirlineCode) {
		this.currentAirlineCode = currentAirlineCode;
	}

	/**
	 * @return the prevTripSelTypeCode
	 */
	public Integer getPrevTripSelTypeCode() {
		return prevTripSelTypeCode;
	}

	/**
	 * @param prevTripSelTypeCode the prevTripSelTypeCode to set
	 */
	public void setPrevTripSelTypeCode(Integer prevTripSelTypeCode) {
		this.prevTripSelTypeCode = prevTripSelTypeCode;
	}

	/**
	 * @return the previousBidStsGroup
	 */
	public BidStatusGroupDto getPreviousBidStsGroup() {
		return previousBidStsGroup;
	}

	/**
	 * @param previousBidStsGroup the previousBidStsGroup to set
	 */
	public void setPreviousBidStsGroup(BidStatusGroupDto previousBidStsGroup) {
		this.previousBidStsGroup = previousBidStsGroup;
	}

	/**
	 * @return the occ2Date
	 */
	public Integer getOcc2Date() {
		return occ2Date;
	}

	/**
	 * @param occ2Date the occ2Date to set
	 */
	public void setOcc2Date(Integer occ2Date) {
		this.occ2Date = occ2Date;
	}

	/**
	 * @return the systSeniorityNo
	 */
	public Integer getSystSeniorityNo() {
		return systSeniorityNo;
	}

	/**
	 * @param systSeniorityNo the systSeniorityNo to set
	 */
	public void setSystSeniorityNo(Integer systSeniorityNo) {
		this.systSeniorityNo = systSeniorityNo;
	}

	/**
	 * @return the tfcopyEffDate
	 */
	public Integer getTfcopyEffDate() {
		return tfcopyEffDate;
	}

	/**
	 * @param tfcopyEffDate the tfcopyEffDate to set
	 */
	public void setTfcopyEffDate(Integer tfcopyEffDate) {
		this.tfcopyEffDate = tfcopyEffDate;
	}

	/**
	 * @return the tfcopyNEffDate
	 */
	public Integer getTfcopyNEffDate() {
		return tfcopyNEffDate;
	}

	/**
	 * @param tfcopyNEffDate the tfcopyNEffDate to set
	 */
	public void setTfcopyNEffDate(Integer tfcopyNEffDate) {
		this.tfcopyNEffDate = tfcopyNEffDate;
	}

	/**
	 * @return the pilMoncurrentStatusInd
	 */
	public boolean isPilMoncurrentStatusInd() {
		return pilMoncurrentStatusInd;
	}

	/**
	 * @param pilMoncurrentStatusInd the pilMoncurrentStatusInd to set
	 */
	public void setPilMoncurrentStatusInd(boolean pilMoncurrentStatusInd) {
		this.pilMoncurrentStatusInd = pilMoncurrentStatusInd;
	}

	/**
	 * @return the pilMoncurrentDailyCred
	 */
	public Integer getPilMoncurrentDailyCred() {
		return pilMoncurrentDailyCred;
	}

	/**
	 * @param pilMoncurrentDailyCred the pilMoncurrentDailyCred to set
	 */
	public void setPilMoncurrentDailyCred(Integer pilMoncurrentDailyCred) {
		this.pilMoncurrentDailyCred = pilMoncurrentDailyCred;
	}

	/**
	 * @return the pillCurrentMonthlyIPMax
	 */
	public Integer getPillCurrentMonthlyIPMax() {
		return pillCurrentMonthlyIPMax;
	}

	/**
	 * @param pillCurrentMonthlyIPMax the pillCurrentMonthlyIPMax to set
	 */
	public void setPillCurrentMonthlyIPMax(Integer pillCurrentMonthlyIPMax) {
		this.pillCurrentMonthlyIPMax = pillCurrentMonthlyIPMax;
	}

	/**
	 * @return the vacationSeniorityDate
	 */
	public Integer getVacationSeniorityDate() {
		return vacationSeniorityDate;
	}

	/**
	 * @param vacationSeniorityDate the vacationSeniorityDate to set
	 */
	public void setVacationSeniorityDate(Integer vacationSeniorityDate) {
		this.vacationSeniorityDate = vacationSeniorityDate;
	}

	/**
	 * @return the dailyCreditPay
	 */
	public List<DailyCreditPayDto> getDailyCreditPay() {
		return dailyCreditPay;
	}

	/**
	 * @param dailyCreditPay the dailyCreditPay to set
	 */
	public void setDailyCreditPay(List<DailyCreditPayDto> dailyCreditPay) {
		this.dailyCreditPay = dailyCreditPay;
	}

	/**
	 * @return the fillerS2
	 */
	public Integer getFillerS2() {
		return fillerS2;
	}

	/**
	 * @param fillerS2 the fillerS2 to set
	 */
	public void setFillerS2(Integer fillerS2) {
		this.fillerS2 = fillerS2;
	}

	/**
	 * @return the fillerS3
	 */
	public Integer getFillerS3() {
		return fillerS3;
	}

	/**
	 * @param fillerS3 the fillerS3 to set
	 */
	public void setFillerS3(Integer fillerS3) {
		this.fillerS3 = fillerS3;
	}

	/**
	 * @return the fillerS4
	 */
	public String getFillerS4() {
		return fillerS4;
	}

	/**
	 * @param fillerS4 the fillerS4 to set
	 */
	public void setFillerS4(String fillerS4) {
		this.fillerS4 = fillerS4;
	}

	/**
	 * @return the sequences
	 */
	public List<SequenceDataDto> getSequences() {
		return sequences;
	}

	/**
	 * @param sequences the sequences to set
	 */
	public void setSequences(List<SequenceDataDto> sequences) {
		this.sequences = sequences;
	}

	/**
	 * @param sequences the sequences to set
	 */
	public void addSequence(SequenceDataDto sequence) {
		if(this.sequences == null){
			this.sequences = new ArrayList<SequenceDataDto>();
		}
		this.sequences.add(sequence);
	}
	
	/**
	 * @return the miscCreditExpenses
	 */
	public List<MiscCreditExpenseDto> getMiscCreditExpenses() {
		return miscCreditExpenses;
	}

	/**
	 * @param miscCreditExpenses the miscCreditExpenses to set
	 */
	public void setMiscCreditExpenses(List<MiscCreditExpenseDto> miscCreditExpenses) {
		this.miscCreditExpenses = miscCreditExpenses;
	}

	public void addMiscCreditExpense(MiscCreditExpenseDto miscCreditExpenses) {
		if(this.miscCreditExpenses == null){
			this.miscCreditExpenses = new ArrayList<MiscCreditExpenseDto>();
		}
		this.miscCreditExpenses.add(miscCreditExpenses);
	}
	
	/**
	 * @return the capFlex
	 */
	public CapFlexDataDto getCapFlex() {
		return capFlex;
	}

	/**
	 * @param capFlex the capFlex to set
	 */
	public void setCapFlex(CapFlexDataDto capFlex) {
		this.capFlex = capFlex;
	}

	/**
	 * @return the plannedAbsenceGroups
	 */
	public List<PlannedAbsenceGroupDto> getPlannedAbsenceGroups() {
		return plannedAbsenceGroups;
	}

	/**
	 * @param plannedAbsenceGroups the plannedAbsenceGroups to set
	 */
	public void setPlannedAbsenceGroups(List<PlannedAbsenceGroupDto> plannedAbsenceGroups) {
		this.plannedAbsenceGroups = plannedAbsenceGroups;
	}

	
	public void addPlannedAbsenceGroup(PlannedAbsenceGroupDto plannedAbsenceGroup) {
		if(this.plannedAbsenceGroups == null){
			this.plannedAbsenceGroups = new ArrayList<PlannedAbsenceGroupDto>();
		}
		this.plannedAbsenceGroups.add(plannedAbsenceGroup);
	}
}
