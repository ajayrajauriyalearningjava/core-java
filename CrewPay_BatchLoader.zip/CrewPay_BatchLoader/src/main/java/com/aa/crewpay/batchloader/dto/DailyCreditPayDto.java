/**
 * 
 */
package com.aa.crewpay.batchloader.dto;

/**
 * @author muthusba
 *
 */
public class DailyCreditPayDto {

	private Integer dailyCredit;
	
	private Integer dailyPay;
	
}
