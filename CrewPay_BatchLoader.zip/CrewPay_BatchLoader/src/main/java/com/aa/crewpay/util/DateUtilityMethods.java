/**
 * 
 */
package com.aa.crewpay.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author Chandra.vir.singh@hpe.com
 * 
 * Common utility program to reform operation on dates
 *
 */
public final class DateUtilityMethods {

	private static final Logger log = LoggerFactory.getLogger("app.util");

	private static final String DT_FORMAT_EOtoPVD = "yyyyMMdd";

	/**
	 * This method convert string values to Date data type expected string
	 * format is "yyyymmdd" eg. 20160528 current usability -Eo to Pvd conversion
	 * 
	 * @param String "yyyymmdd"
	 * 
	 *
	 */
	public static Date convertStringToDate(String inpStr) {

		Date date = null;
		try {
			DateFormat format = new SimpleDateFormat(DT_FORMAT_EOtoPVD, Locale.ENGLISH);
			date = format.parse(inpStr);

		} catch (ParseException e) {
			log.debug("unable to parse dates");
		}
		return date;
	}
	
	
	/**
	 * @param Integer "yyyymmdd"
	 */
	public static Date convertIntegerToDate(Integer inpStr) {

		Date date = null;
		try {
			DateFormat format = new SimpleDateFormat(DT_FORMAT_EOtoPVD, Locale.ENGLISH);
			date = format.parse(inpStr.toString());

		} catch (ParseException e) {
			log.debug("unable to parse dates");
		}
		return date;
	}

	// method for calculating number of days difference between two inputed
	// dates
	public static Long daysDiff(Date startDate, Date endDate) {
		long diff = endDate.getTime() - startDate.getTime();
		long diffDays = diff / (24 * 60 * 60 * 1000);
		return diffDays;
	}

	// method for calculating number of days difference between two inputed
	// dates
	public static Long hoursDiff(Date startDate, Date endDate) {
		long diff = endDate.getTime() - startDate.getTime();
		long diffHours = diff / (60 * 60 * 1000) % 24;
		return diffHours;
	}

	// method for calculating number of days difference between two inputed
	// dates
	public static Long MinutesDiff(Date startDate, Date endDate) {
		long diff = endDate.getTime() - startDate.getTime();
		long diffMinutes = diff / (60 * 1000) % 60;
		return diffMinutes;
	}

	// method for calculating number of days difference between two inputed
	// dates
	public static Long secondsDiff(Date startDate, Date endDate) {
		long diff = endDate.getTime() - startDate.getTime();
		long diffSeconds = diff / 1000 % 60;
		return diffSeconds;
	}

	// Converts XMLGregorian Calendar to String ddMMM
	public static String convertToddMMM(XMLGregorianCalendar date) {

		Calendar calendar = date.toGregorianCalendar();
		SimpleDateFormat format = new SimpleDateFormat("ddMMM");

		format.setTimeZone(calendar.getTimeZone());
		return format.format(calendar.getTime());

	}

	public static int compareDates(String date1, String date2) throws ParseException {
		SimpleDateFormat dateFormat = new SimpleDateFormat("ddMMM");
		Date date_1 = dateFormat.parse(date1);
		Date date_2 = dateFormat.parse(date2);
		return date_1.compareTo(date_2);
	}

	// method for converting the date to string which is used for fos update in
	// eo to pvd
	public static String convertDateForFOSUpdate(Date inpDate) {
		DateFormat df = new SimpleDateFormat("ddMMMyy");
		String reportDate = df.format(inpDate);
		return reportDate.toUpperCase();
	}

}
