package com.crewpay.fa.commons;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;
import java.util.Scanner;
import java.util.StringTokenizer;

import org.supercsv.io.CsvBeanWriter;
import org.supercsv.io.ICsvBeanWriter;
import org.supercsv.prefs.CsvPreference;

import com.crewpay.fa.model.CrewMembers;
import com.crewpay.fa.model.Dutyperiods;
import com.crewpay.fa.model.FlightAttendantModel;
import com.crewpay.fa.model.Legs;
import com.crewpay.fa.model.RecType25;
import com.crewpay.fa.model.RecType31;
import com.crewpay.fa.model.RecType32;
import com.crewpay.fa.model.RecType411;
import com.crewpay.fa.model.RecType412;
import com.crewpay.fa.model.RecType413;
import com.crewpay.fa.model.RecType414;
import com.crewpay.fa.model.RecType415;
import com.crewpay.fa.model.RecType416;
import com.crewpay.fa.model.Sequences;

public class FlightAttendantUtil {

	static FileInputStream fis;

	public static FlightAttendantModel getInputFilesFromFlatFile() {
		List<CrewMembers> crewMembers=new ArrayList<>();
		FlightAttendantModel flightAttendantModel=new FlightAttendantModel();
		try(FileInputStream  fis = new FileInputStream("src/com/crewpay/fa/resources/FCRM.properties");) {
			Properties MyProps = new Properties();
			MyProps.load(fis);
			@SuppressWarnings("resource")
			Scanner scanner=new Scanner(new File("src/com/crewpay/fa/resources/FCRM_PI.txt"));
			List<Sequences> sequences=new ArrayList<>();
			List<Dutyperiods> dutyperiods=new ArrayList<>();;
			List<Legs> legs=new ArrayList<>();
			List<RecType31> recType31s=new ArrayList<>();
			List<RecType32> recType32s=new ArrayList<>();
			List<RecType25> recType25s=new ArrayList<>();
			List<RecType411> recType411s=new ArrayList<>();
			List<RecType412> recType412s=new ArrayList<>();
			List<RecType413> recType413s=new ArrayList<>();
			List<RecType414> recType414s=new ArrayList<>();
			List<RecType415> recType415s=new ArrayList<>();
			List<RecType416> recType416s=new ArrayList<>();
			RecType31 recType31=null;
			RecType32 recType32=null;
			RecType25 recType25=null;
			RecType411 recType411=null;
			RecType412 recType412=null;
			RecType413 recType413=null;
			RecType414 recType414=null;
			RecType415 recType415=null;
			RecType416 recType416=null;
			CrewMembers crewMember=null;
			Sequences sequence=null;
			Dutyperiods dutyperiod=null;
			Legs leg=null;
			Map<Integer, String[]> fcrmFile=CrewMapperUtil.fetchingRecordNameAndClassName();
			while(scanner.hasNextLine()){
				String recordTypeNoLine=scanner.nextLine();
				if(recordTypeNoLine.startsWith("199")||recordTypeNoLine.startsWith(" 9")){
					break;
				}
				else if(recordTypeNoLine.startsWith("01")){
//					System.out.println(recordTypeNoLine);
				}
				Integer recordNumber=Integer.parseInt(recordTypeNoLine.substring(0, 2));
				recordTypeNoLine=recordTypeNoLine.substring(2);
				Object obj= FlightAttendantUtil.parsingFCRMDumpFileIntoDTO(recordNumber,recordTypeNoLine,fcrmFile);
				if(obj instanceof CrewMembers){
					if(crewMember!=null){
//						crewMember.setSequences(sequences);
//						crewMember.setRecType31s(recType31s);
//						crewMember.setRecType32s(recType32s);
//						crewMember.setRecType411s(recType411s);
//						crewMember.setRecType412s(recType412s);
//						crewMember.setRecType413s(recType413s);
//						crewMember.setRecType414s(recType414s);
//						crewMember.setRecType415s(recType415s);
//						crewMember.setRecType416s(recType416s);
						crewMembers.add(crewMember);
						sequences=new ArrayList<>();
//						recType31s=new ArrayList<>();
//						 recType32s=new ArrayList<>();
//						 recType25s=new ArrayList<>();
//						 recType411s=new ArrayList<>();
//						 recType412s=new ArrayList<>();
//						recType413s=new ArrayList<>();
//						recType414s=new ArrayList<>();
//						 recType415s=new ArrayList<>();
//						 recType416s=new ArrayList<>();
					}
					crewMember=(CrewMembers) obj;
//					crewMember.setPROCESSING_START_DATE("20160702");
//					crewMember.setPROCESSING_END_DATE("20160731");
				}
				else if(obj instanceof Sequences){
					if(dutyperiods.size()!=0){
						sequence.setDutyperiods(dutyperiods);
						sequences.add(sequence);
						dutyperiods=new ArrayList<>();
					}
					sequence=(Sequences) obj;
//					sequence.setSEQ_EMPNo(crewMember.getEMPNo());
					sequences.add(sequence);
				}
				else if(obj instanceof Dutyperiods){
					if(legs.size()!=0){
						dutyperiod.setLegs(legs);
						dutyperiods.add(dutyperiod);
						legs=new ArrayList<>();
					}
					dutyperiod=(Dutyperiods) obj;
//					dutyperiod.setDP_EMPNo(crewMember.getEMPNo());
					dutyperiod.setDP_SEQUENCE_NUMBER(sequence.getSEQUENCE_NUMBER());
					dutyperiods.add(dutyperiod);
				}
				else if(obj instanceof Legs){
					leg=(Legs) obj;
//					leg.setLEG_EMPNo(crewMember.getEMPNo());
					leg.setLEG_SEQUENCE_NUMBER(sequence.getSEQUENCE_NUMBER());
					leg.setLEG_DP_NO(dutyperiod.getXDTYPER());
					legs.add(leg);
				}
				else if(obj instanceof RecType31){
					recType31= (RecType31) obj;
					recType31s.add(recType31);
				}
				else if(obj instanceof RecType32){
					recType32=(RecType32) obj;
					recType32s.add(recType32);
				}
				else if(obj instanceof RecType25){
					recType25=(RecType25) obj;
					recType25s.add(recType25);
				}
				else if(obj instanceof RecType411){
					recType411=(RecType411) obj;
					recType411s.add(recType411);
				}
				else if(obj instanceof RecType412){
					recType412=(RecType412) obj;
					recType412s.add(recType412);
				}
				else if(obj instanceof RecType413){
					recType413=(RecType413) obj;
					recType413s.add(recType413);
				}
				else if(obj instanceof RecType414){
					recType414=(RecType414) obj;
					recType414s.add(recType414);
				}
				else if(obj instanceof RecType415){
					recType415=(RecType415) obj;
					recType415s.add(recType415);
				}
				else if(obj instanceof RecType416){
					recType416=(RecType416) obj;
					recType416s.add(recType416);
				}
				
			}
			
			flightAttendantModel.setCrewMember(crewMembers);
			flightAttendantModel.setRecType32s(recType32s);
			System.out.println("File parsing Compleeted....");
	}
	catch(Exception e){
		e.printStackTrace();
	}
		return flightAttendantModel;
	}
	
	
	public static Object parsingFCRMDumpFileIntoDTO(Integer recordNumber,String line, Map<Integer, String[]> fcrmFile)
			throws IOException, ClassNotFoundException, InstantiationException, IllegalAccessException {
		if(recordNumber==41){
			line=line.substring(9);
			String recordSubNumber=line.substring(0, 1);
			recordNumber=Integer.parseInt(recordNumber+recordSubNumber);
		}
		List<String> activeList=CrewMapperUtil.mappingDTOsWithIndexfile(recordNumber,fcrmFile);
		Object obj=null;
		if(activeList.size()!=0){
		fis = new FileInputStream(activeList.get(0));
		ResourceBundle resources = new PropertyResourceBundle(fis);
		String delims = ",";
		List<String> list = null;
		Map<String, List<String>> map = new HashMap<String, List<String>>();
		// convert ResourceBundle to Map
		Enumeration<String> keys = resources.getKeys();
		String index=null;
		while (keys.hasMoreElements()) {
			String key = (String) keys.nextElement();
			String value = resources.getString(key);
			StringTokenizer st = new StringTokenizer(value, delims);
			list = new ArrayList<>();
			while (st.hasMoreTokens()) {
				String str = st.nextToken();
				index=str.trim();
				list.add(index);
			}
			map.put(key, list);
		}
		Class<?> clazz=Class.forName(activeList.get(1).trim());
		obj=clazz.newInstance();
		
			for(Field field : clazz.getDeclaredFields()) {
				field.setAccessible(true);
				if(map.size()!=0&&map.get(field.getName())!=null&&map.get(field.getName()).size()!=0){
//					System.out.println(field.getName());
					int stIndex=Integer.parseInt(map.get(field.getName()).get(0));
					int endIndex=Integer.parseInt(map.get(field.getName()).get(1));
					List<Object> fieldlist=new ArrayList<>();
					if(field.getType().getCanonicalName().contains("List")){
						if(map.get(field.getName()).size()!=0){
							int fsindex=0;
							int feindex=0;
							int len=0;
							Class<?> clazz1=Class.forName(map.get(field.getName()).get(3));
							for(int i=Integer.parseInt(map.get(field.getName()).get(0));i<=Integer.parseInt(map.get(field.getName()).get(1));i++){
								Object fieldObj=clazz1.newInstance();
								List<Object> subfieldlist=new ArrayList<>();
								for(Field fieldObjField:clazz1.getDeclaredFields()){
									if(map.get(fieldObjField.getName()).size()!=0){
										fsindex=Integer.parseInt(map.get(fieldObjField.getName()).get(0))+len;
										feindex=Integer.parseInt(map.get(fieldObjField.getName()).get(1))+len;
										if(fieldObjField.getType().getCanonicalName().contains("List")){
											if(map.get(fieldObjField.getName()).size()!=0){
												int subFieldsindex=0;
												int subFieldeindex=0;
												int subFieldlen=0;
												Class<?> subclazz=Class.forName(map.get(fieldObjField.getName()).get(3));
												for(int j=Integer.parseInt(map.get(fieldObjField.getName()).get(0));j<=Integer.parseInt(map.get(fieldObjField.getName()).get(1));j++){
													Object subfieldObj=subclazz.newInstance();
													for(Field subObjField:subclazz.getDeclaredFields()){
														subFieldsindex=Integer.parseInt(map.get(subObjField.getName()).get(0))+subFieldlen;
														subFieldeindex=Integer.parseInt(map.get(subObjField.getName()).get(1))+subFieldlen;
														subObjField.set(subfieldObj, line.substring(subFieldsindex,subFieldeindex));
													}
													subFieldlen=subFieldlen+Integer.parseInt(map.get(fieldObjField.getName()).get(2));
													subfieldlist.add(subfieldObj);
												}
											}
											fieldObjField.set(fieldObj, subfieldlist);
										}
										else{
											fieldObjField.set(fieldObj, line.substring(fsindex, feindex));
										}
									}
								}
								len=len+Integer.parseInt(map.get(field.getName()).get(2));
//								System.out.println(len+"----"+(len+19));
								fieldlist.add(fieldObj);
							}
						}
						field.set(obj, fieldlist);
					}
					else if(stIndex!=0){
					   if (field.getType().getCanonicalName().contains("Date")) {
							field.set(obj, line.substring(stIndex,endIndex));
						} else if (field.getType().getCanonicalName().contains("Integer")) {
							field.set(obj, Integer.parseInt(line.substring(stIndex,endIndex)));
						} else if (field.getType().getCanonicalName().contains("Character")) {
							field.set(obj, line.substring(stIndex,endIndex).charAt(0));
						} else {
							field.set(obj, line.substring(stIndex,endIndex));
						}
					}
				}
			}
		}
//			System.out.println(obj);
		return obj;

	}
	
	public static void reportGenerate1(List<?> objectList,String fileName) {
		if(objectList!=null&&objectList.size()!=0){
			System.out.println(objectList.size());
			try(ICsvBeanWriter writer=new CsvBeanWriter(new FileWriter(fileName), CsvPreference.STANDARD_PREFERENCE);){
				String headers[]=new String[200];
				int flag=0;
				for(Field field:objectList.get(0).getClass().getFields()){
					headers[flag]=field.getName();
					flag++;
				}
				writer.writeHeader(headers);
					for (Object object :objectList ) {
						writer.write(object, headers);
					}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
	
		}
		
		
	}
	public static void reportGenerate(List<?> objectList,String fileName) throws IOException {
	     File f = new File(fileName);
		        Writer oos = new FileWriter(f);
		        for(Object obj:objectList)
		        oos.write(obj.toString());
		        oos.flush();
		        oos.close(); 

	}
}
