package com.crewpay.fa.text;

import java.io.FileNotFoundException;
import java.io.IOException;

import com.crewpay.fa.commons.FlightAttendantUtil;
import com.crewpay.fa.model.FlightAttendantModel;
public class FlightAttendant {
	
	public static void main(String[] args) {
		try {
			FlightAttendantModel flightAttendantModel=FlightAttendantUtil.getInputFilesFromFlatFile();
			FlightAttendantUtil.reportGenerate(flightAttendantModel.getCrewMember(), "crewmembers.txt");
			FlightAttendantUtil.reportGenerate(flightAttendantModel.getRecType32s(), "RecType32.txt");
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
