package com.crewpay.fa.model;

import java.util.List;

public class CrewMembers2 {
	
	
	
	public String MAIDEN_NAME;
	public String FRMR_CO_CDE;
	public String MAIL_LOCN;
	public String PLT_COMN_DTE;
	public String COPLT_COMN_DTE;
	public String HIGH_SEAT_CDE;
	public String PRMNT_CRW_BASE_CDE;;
	public String CRW_BASE_ASGN_DATE;
	public String INTL_ASGN_CDE;
	public String NEXT_INTL_ASGN_CDE;
	public String NEXT_CRW_BASE;
	public String NEXT_CRW_BASE_DATE;
	public String PAYRL_XCLU_INDR;
	public String ACRD_SNRTY_INDR;
	public String NSENSEQ;
//	public String CRNT_SNRTY_NBR;
//	public String FA_YRS_SRVC;
//	public String CRWMBR_COND_CDE;
//	public String PRMNT_STAT_CDE;
//	public String PRMNT_STAT_EFF_DTE;
//	public String PRMNT_STAT_TRM_DTE;
//	public String NEXT_PRMNT_STAT_CDE;
//	public String NEXT_PRMNT_STAT_EFF_DTE;
//	public String TEMP_STAT_EFF_DTE;
//	public String TEMP_STAT_TRM_DTE;
//	public String TEMP_STAT_CDE;
//	public String NEXT_TEMP_STAT_EFF_DTE;
//	public String NEXT_TEMP_STAT_TRM_DTE;
//	public String NEXT_TEMP_STAT_CDE;
//	public String MAC_EFF_DTE;
//	public String MAC_TRM_DTE;
//	public String TRNG_BASE_EFF_DTE;
//	public String TRNG_BASE_TRM_DTE;
//	public String PSPT_DTE;
//	public String PSPT_NBR;
//	public String PSPT_CNTRY_CDE;
//	public String PSPT_EXP_DTE;
//	public String INTL_CRW_CRD_NBR;
//	public String INTNL_CRW_CRD_DTE;
//	public String CO_MED_DTE;
//	public String FAA_MED_DTE;
//	public String FAA_MED_CLS;
//	public String FAA_DOCR;
//	public String MED_LOCN_IND;
//	public String CRWMBR_POSN_CDE;
//	public String CO_MED_BASE_MO;
//	public String FAA_MED_BASE_MO;
//	public String SICK_RLSE_DTE;
//	public String UNPD_SICK_STR_DTE;
//	public String SICK_RLSE_MNS;
//	public String UNUSED_SICK_TIME;
//	public String SICK_TIME_MINS_USED_YTD;
//	public String SICK_TIME_MAKE_UP;
//	public String SICK_TIME_MINS_USED_MTD;
//	public String MRG_EMP_INDR;
//	public String CR_PRJN;
//	public String SCH_PRJN;
//	public String GRTR_TIME_MTD;
//	public String SPEC_ASGNMT_CR_MNS;
//	public String INTL_SEQ_CR_MNS;
//	public String REASGN_PAY_MN;
//	public String UNDR_STAF_PTRN_PAY_MN;
//	public String UNDR_STAF_SRVC_PAY_MN;
//	public String NGT_PAY_MNS;
//	public String FA_PREM_PAY_OR_PLT_CPA_MNS;
//	public String FORGN_LANG_PAY_LEG;
//	public String HOLD_TIME_PAY_MNS;;
//	public String GRND_TIME_PAY_MNS;
//	public String DOM_TAFB_XPNS;
//	public String DOM_TAFB_TAX_XPNS;
//	public String MISC_TAX_XPNS;
//	public String MISC_XPNS;
//	public String TRIP_SEL_NBR;
//	public String SEL_CRW_BASE_CDE;
//	public String MO_SELN_GRP_CRWMBR_POSN_CDE;
//	public String MO_SELN_GRP_DOM_INTL_CDE;
//	public String INACTV_SEL_RSN_CDE;
//	public String PA_BID_IND;
//	public String TRIP_SEL_TYPE_CDE;
//	public String HIGH_EQP_TYPE_CDE;
//	public String CALL_OUT_STNDBY_QTY;
//	public String FA_BID_OPT_CDE;
//	
//	public String INTL_PAY_MN;
//	public String FIRST_INITIAL;
//	public String MIDDLE_INITIAL;
//	public String LAST_NAME;
//	public String BIRTH_DTE;
//	public String CO_SNRTY_DTE;
//	public String OCCUP_SNRTY_DTE;
//	public String CLS_SNRTY_DTE;
//	public String ORG_HIRE_DTE;
//	public String COMMUTE_FLAG;
//	public String VAR_MAN_IND;
	public String PAPER_BID_REASON;
//	public String NEXT_BID_DSPLCMT_PREFNC_CDE;
//	public String XCD_MOLY_FLYG_HRS_AGRMT_INDR;
//	public String CAPT_BID_RQMT_INDR;
//	public String FIR_OFCR_BID_RQMT_INDR;
//	public String AIRCAL_FRMR_EMP_INDR;
//	public String GUAR_MIN_MOLY_MN_QTY;
//	public String FRGN_LNG_PAY_MN_QTY;
//	public String CRWB_SUPV_NUM;
//	public String DRUG_TST_DTE;
//	public String LST_FLWN_DTE;
//	public String INTL_TAFB_XPNS;
//	public String INTL_TAFB_TAX_XPNS;
//	public String TS_PAY_PROJ_MINUTES;
//	public String BID_SEL_PROJ_MNS;
//	public String CKA_FLAG;
//	public String CKA_TYPE;
//	public String CKA_BANK;
//	public String FA_ACTL_BASE_GUAR;
//	public String FA_ACTL_INC_GUAR;
//	public String NGT_PAY_MNS2;
//	public String CHASE_FL_MNS;
//	public String HOME_TEL_NBR;
//	public String BUS_TEL_NBR;
//	public String TEMP_TEL_NBR;
//	public String EMP_SCNDRY_TEL_NBR;
//	public String RSTRD_SICK_TME_MNS;
//	public String ADJ_CKPT_PAY_GUAR;
//	public String CKPT_WAVED_DFP;
//	public String ORIG_AIRL_CDE;
//	public String CURR_AIRL_CDE;
//	public String PRV_TRIP_SEL_TYPE_CDE;
//	public String PRV_BID_STS_GRP;
//	public String PRV_BID_STS_GRP_SEQ_CRW_BASE;
//	public String PRV_BID_STS_GRP_CRWMBR_POSN_CDE;
//	public String PRV_BID_STS_GRP_EQUIPMENT;
//	public String PRV_BID_STS_GRP_DOM_INTL_CDE;
//	public String PRV_BID_STS_GRP_EFF_DTE;
//	public String OCC2_DTE;
//	public String SYST_SNRTY_NO;
//	public String TFCOPY_EFF_DTE;
//	public String TFCOPY_NEFF_DTE;
//	public String PIL_MON_RSV_GRP_CUR_STAT_INDR;
//	public String PIL_MON_RSV_GRP_CUR_DALY_CRED;
//	public String PIL_IPMAX_GRP_CUR_MNTH_IPMAX;
//	public String VAC_SNRTY_DTE;
//	public String DAILY_CREDIT_PAY_DAILY_CREDIT;
//	public String DAILY_CREDIT_PAY_DAILY_PAY;
//	public String FILL_S2;
//	public String FILL_S3;
//	public String FILL_S4;
	public List<XCMDATA> XCMDATA;
	public List<CRWMBR_EQP_QLFN_GRP> CRWMBR_EQP_QLFN_GRP;
	public List<DLY_CRWMR_BID_GRP> DLY_CRWMR_BID_GRP;
	public List<CRNT_BID_STAT_GRP> CRNT_BID_STAT_GRP;
//	public List<NEXT_BID_STAT_GRP> NEXT_BID_STAT_GRP;
//	public List<WTHD_BID_STAT_GRP> WTHD_BID_STAT_GRP;
//	public List<DEFRL_BID_STAT_GRP> DEFRL_BID_STAT_GRP;
	
	
	public List<XCMDATA> getXCMDATA() {
		return XCMDATA;
	}
	public String getPAPER_BID_REASON() {
		return PAPER_BID_REASON;
	}
	public void setPAPER_BID_REASON(String pAPER_BID_REASON) {
		PAPER_BID_REASON = pAPER_BID_REASON;
	}
	public List<CRNT_BID_STAT_GRP> getCRNT_BID_STAT_GRP() {
		return CRNT_BID_STAT_GRP;
	}
	public void setCRNT_BID_STAT_GRP(List<CRNT_BID_STAT_GRP> cRNT_BID_STAT_GRP) {
		CRNT_BID_STAT_GRP = cRNT_BID_STAT_GRP;
	}
	public String getMAIDEN_NAME() {
		return MAIDEN_NAME;
	}
	public void setMAIDEN_NAME(String mAIDEN_NAME) {
		MAIDEN_NAME = mAIDEN_NAME;
	}
	public String getFRMR_CO_CDE() {
		return FRMR_CO_CDE;
	}
	public void setFRMR_CO_CDE(String fRMR_CO_CDE) {
		FRMR_CO_CDE = fRMR_CO_CDE;
	}
	public String getMAIL_LOCN() {
		return MAIL_LOCN;
	}
	public void setMAIL_LOCN(String mAIL_LOCN) {
		MAIL_LOCN = mAIL_LOCN;
	}
	public String getPLT_COMN_DTE() {
		return PLT_COMN_DTE;
	}
	public void setPLT_COMN_DTE(String pLT_COMN_DTE) {
		PLT_COMN_DTE = pLT_COMN_DTE;
	}
	public String getCOPLT_COMN_DTE() {
		return COPLT_COMN_DTE;
	}
	public void setCOPLT_COMN_DTE(String cOPLT_COMN_DTE) {
		COPLT_COMN_DTE = cOPLT_COMN_DTE;
	}
	public String getHIGH_SEAT_CDE() {
		return HIGH_SEAT_CDE;
	}
	public void setHIGH_SEAT_CDE(String hIGH_SEAT_CDE) {
		HIGH_SEAT_CDE = hIGH_SEAT_CDE;
	}
	public String getPRMNT_CRW_BASE_CDE() {
		return PRMNT_CRW_BASE_CDE;
	}
	public void setPRMNT_CRW_BASE_CDE(String pRMNT_CRW_BASE_CDE) {
		PRMNT_CRW_BASE_CDE = pRMNT_CRW_BASE_CDE;
	}
	public String getCRW_BASE_ASGN_DATE() {
		return CRW_BASE_ASGN_DATE;
	}
	public void setCRW_BASE_ASGN_DATE(String cRW_BASE_ASGN_DATE) {
		CRW_BASE_ASGN_DATE = cRW_BASE_ASGN_DATE;
	}
	public String getINTL_ASGN_CDE() {
		return INTL_ASGN_CDE;
	}
	public void setINTL_ASGN_CDE(String iNTL_ASGN_CDE) {
		INTL_ASGN_CDE = iNTL_ASGN_CDE;
	}
	public String getNEXT_INTL_ASGN_CDE() {
		return NEXT_INTL_ASGN_CDE;
	}
	public void setNEXT_INTL_ASGN_CDE(String nEXT_INTL_ASGN_CDE) {
		NEXT_INTL_ASGN_CDE = nEXT_INTL_ASGN_CDE;
	}
	public String getNEXT_CRW_BASE() {
		return NEXT_CRW_BASE;
	}
	public void setNEXT_CRW_BASE(String nEXT_CRW_BASE) {
		NEXT_CRW_BASE = nEXT_CRW_BASE;
	}
	public String getNEXT_CRW_BASE_DATE() {
		return NEXT_CRW_BASE_DATE;
	}
	public void setNEXT_CRW_BASE_DATE(String nEXT_CRW_BASE_DATE) {
		NEXT_CRW_BASE_DATE = nEXT_CRW_BASE_DATE;
	}
	public String getPAYRL_XCLU_INDR() {
		return PAYRL_XCLU_INDR;
	}
	public void setPAYRL_XCLU_INDR(String pAYRL_XCLU_INDR) {
		PAYRL_XCLU_INDR = pAYRL_XCLU_INDR;
	}
	public String getACRD_SNRTY_INDR() {
		return ACRD_SNRTY_INDR;
	}
	public void setACRD_SNRTY_INDR(String aCRD_SNRTY_INDR) {
		ACRD_SNRTY_INDR = aCRD_SNRTY_INDR;
	}
	public String getNSENSEQ() {
		return NSENSEQ;
	}
	public void setNSENSEQ(String nSENSEQ) {
		NSENSEQ = nSENSEQ;
	}
	public void setXCMDATA(List<XCMDATA> xCMDATA) {
		XCMDATA = xCMDATA;
	}
	
public List<DLY_CRWMR_BID_GRP> getDLY_CRWMR_BID_GRP() {
		return DLY_CRWMR_BID_GRP;
	}
	public void setDLY_CRWMR_BID_GRP(List<DLY_CRWMR_BID_GRP> dLY_CRWMR_BID_GRP) {
		DLY_CRWMR_BID_GRP = dLY_CRWMR_BID_GRP;
	}
	//	@Override
//	public String toString() {
//		return "CrewMembers [XCMDATA=" + XCMDATA + "]";
//	}
//	
//	
	public List<CRWMBR_EQP_QLFN_GRP> getCRWMBR_EQP_QLFN_GRP() {
		return CRWMBR_EQP_QLFN_GRP;
	}
	public void setCRWMBR_EQP_QLFN_GRP(List<CRWMBR_EQP_QLFN_GRP> cRWMBR_EQP_QLFN_GRP) {
		CRWMBR_EQP_QLFN_GRP = cRWMBR_EQP_QLFN_GRP;
	}
	@Override
	public String toString() {
		return "CrewMembers [MAIDEN_NAME=" + MAIDEN_NAME + ", FRMR_CO_CDE=" + FRMR_CO_CDE + ", MAIL_LOCN=" + MAIL_LOCN
				+ ", PLT_COMN_DTE=" + PLT_COMN_DTE + ", COPLT_COMN_DTE=" + COPLT_COMN_DTE + ", HIGH_SEAT_CDE="
				+ HIGH_SEAT_CDE + ", PRMNT_CRW_BASE_CDE=" + PRMNT_CRW_BASE_CDE + ", CRW_BASE_ASGN_DATE="
				+ CRW_BASE_ASGN_DATE + ", INTL_ASGN_CDE=" + INTL_ASGN_CDE + ", NEXT_INTL_ASGN_CDE=" + NEXT_INTL_ASGN_CDE
				+ ", NEXT_CRW_BASE=" + NEXT_CRW_BASE + ", NEXT_CRW_BASE_DATE=" + NEXT_CRW_BASE_DATE
				+ ", PAYRL_XCLU_INDR=" + PAYRL_XCLU_INDR + ", ACRD_SNRTY_INDR=" + ACRD_SNRTY_INDR + ", NSENSEQ="
				+ NSENSEQ + ", PAPER_BID_REASON=" + PAPER_BID_REASON + ", XCMDATA=" + XCMDATA + ", CRWMBR_EQP_QLFN_GRP="
				+ CRWMBR_EQP_QLFN_GRP + ", DLY_CRWMR_BID_GRP=" + DLY_CRWMR_BID_GRP + ", CRNT_BID_STAT_GRP="
				+ CRNT_BID_STAT_GRP + "]";
	}
	
	
	
	

	
	
//	public List<Sequences> sequences;
//	public List<RecType31> recType31s;
//	public List<RecType32> recType32s;
//	public List<RecType25> recType25List;
//	public List<RecType411> recType411s;
//	public List<RecType412> recType412s;
//	public List<RecType413> recType413s;
//	public List<RecType414> recType414s;
//	public List<RecType415> recType415s;
//	public List<RecType416> recType416s;
	
	
	
	
	
	

}
