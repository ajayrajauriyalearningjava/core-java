package com.crewpay.fa.model;

public class XCMDATA {
	public String XCMDATA_DATE;
	public String XCMDATA_DOM_INTL_CODE;
	public String XCMDATA_CREW_TYPE;
	public String XCMDATA_EMPNo;
	
	
	public String getXCMDATA_DATE() {
		return XCMDATA_DATE;
	}
	public void setXCMDATA_DATE(String xCMDATA_DATE) {
		XCMDATA_DATE = xCMDATA_DATE;
	}
	public String getXCMDATA_CREW_TYPE() {
		return XCMDATA_CREW_TYPE;
	}
	public void setXCMDATA_CREW_TYPE(String xCMDATA_CREW_TYPE) {
		XCMDATA_CREW_TYPE = xCMDATA_CREW_TYPE;
	}
	public String getXCMDATA_EMPNo() {
		return XCMDATA_EMPNo;
	}
	public void setXCMDATA_EMPNo(String xCMDATA_EMPNo) {
		XCMDATA_EMPNo = xCMDATA_EMPNo;
	}
	public String getXCMDATA_DOM_INTL_CODE() {
		return XCMDATA_DOM_INTL_CODE;
	}
	public void setXCMDATA_DOM_INTL_CODE(String xCMDATA_DOM_INTL_CODE) {
		XCMDATA_DOM_INTL_CODE = xCMDATA_DOM_INTL_CODE;
	}
	
	@Override
	public String toString() {
		return "\t\tXCMDATA_DATE=" + XCMDATA_DATE + ", XCMDATA_CREW_TYPE=" + XCMDATA_CREW_TYPE + ", XCMDATA_EMPNo="
				+ XCMDATA_EMPNo + ", XCMDATA_DOM_INTL_CODE=" + XCMDATA_DOM_INTL_CODE + "]\n";
	}
	
	
	
}
