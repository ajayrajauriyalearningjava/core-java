package com.crewpay.fa.model;

import java.util.List;
import java.util.Set;

public class FlightAttendantModel {

	public List<CrewMembers> crewMember;
	public List<RecType31> recType31s;
	public List<RecType32> recType32s;
	public List<RecType414> recType411s;
	public List<RecType414> recType412s;
	public List<RecType414> recType413s;
	public List<RecType414> recType414s;
	public List<RecType415> recType415s;
	public List<RecType414> recType416s;
	public List<CrewMembers> getCrewMember() {
		return crewMember;
	}
	public void setCrewMember(List<CrewMembers> crewMember) {
		this.crewMember = crewMember;
	}
	public List<RecType31> getRecType31s() {
		return recType31s;
	}
	public void setRecType31s(List<RecType31> recType31s) {
		this.recType31s = recType31s;
	}
	public List<RecType32> getRecType32s() {
		return recType32s;
	}
	public void setRecType32s(List<RecType32> recType32s2) {
		this.recType32s = recType32s2;
	}
	public List<RecType414> getRecType411s() {
		return recType411s;
	}
	public void setRecType411s(List<RecType414> recType411s) {
		this.recType411s = recType411s;
	}
	public List<RecType414> getRecType412s() {
		return recType412s;
	}
	public void setRecType412s(List<RecType414> recType412s) {
		this.recType412s = recType412s;
	}
	public List<RecType414> getRecType413s() {
		return recType413s;
	}
	public void setRecType413s(List<RecType414> recType413s) {
		this.recType413s = recType413s;
	}
	public List<RecType414> getRecType414s() {
		return recType414s;
	}
	public void setRecType414s(List<RecType414> recType414s) {
		this.recType414s = recType414s;
	}
	public List<RecType415> getRecType415s() {
		return recType415s;
	}
	public void setRecType415s(List<RecType415> recType415s) {
		this.recType415s = recType415s;
	}
	public List<RecType414> getRecType416s() {
		return recType416s;
	}
	public void setRecType416s(List<RecType414> recType416s) {
		this.recType416s = recType416s;
	}
	@Override
	public String toString() {
		return "FlightAttendantModel [crewMember=" + crewMember + ", recType31s=" + recType31s + ", recType32s="
				+ recType32s + ", recType411s=" + recType411s + ", recType412s=" + recType412s + ", recType413s="
				+ recType413s + ", recType414s=" + recType414s + ", recType415s=" + recType415s + ", recType416s="
				+ recType416s + "]";
	}
	
	
	
	
	
	
}
