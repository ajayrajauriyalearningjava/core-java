package com.crewpay.fa.model;

import java.util.List;

public class RecType32 {

	public String XFMCMD02_SEQ_CRW_BASE;         
	public String CREW_BASE_CODE;     
	public List<PLT_PRJN_GRP> PLT_PRJN_GRP;
	public String FILLER01;
	
	
	public String getXFMCMD02_SEQ_CRW_BASE() {
		return XFMCMD02_SEQ_CRW_BASE;
	}
	public void setXFMCMD02_SEQ_CRW_BASE(String xFMCMD02_SEQ_CRW_BASE) {
		XFMCMD02_SEQ_CRW_BASE = xFMCMD02_SEQ_CRW_BASE;
	}
	public String getCREW_BASE_CODE() {
		return CREW_BASE_CODE;
	}
	public void setCREW_BASE_CODE(String cREW_BASE_CODE) {
		CREW_BASE_CODE = cREW_BASE_CODE;
	}
	public List<PLT_PRJN_GRP> getPlt_PRJN_GRPs() {
		return PLT_PRJN_GRP;
	}
	public void setPlt_PRJN_GRPs(List<PLT_PRJN_GRP> plt_PRJN_GRPs) {
		this.PLT_PRJN_GRP = plt_PRJN_GRPs;
	}
	public String getFILLER01() {
		return FILLER01;
	}
	public void setFILLER01(String fILLER01) {
		FILLER01 = fILLER01;
	}
	@Override
	public String toString() {
		return "RecType32 [XFMCMD02_SEQ_CRW_BASE=" + XFMCMD02_SEQ_CRW_BASE
				+ ", CREW_BASE_CODE=" + CREW_BASE_CODE + ",\t" + PLT_PRJN_GRP + ", FILLER01=" + FILLER01
				+ "]\n\n";
	}
	
	

}
