package com.crewpay.fa.model;

import java.util.List;

public class CrewMembers {
	
	
	
	private String MAIDEN_NAME;
	private String FRMR_CO_CDE;
	private String MAIL_LOCN;
	private String PLT_COMN_DTE;
	private String COPLT_COMN_DTE;
	private String HIGH_SEAT_CDE;
	private String PRMNT_CRW_BASE_CDE;;
	private String CRW_BASE_ASGN_DATE;
	private String INTL_ASGN_CDE;
	private String NEXT_INTL_ASGN_CDE;
	private String NEXT_CRW_BASE;
	private String NEXT_CRW_BASE_DATE;
	private String PAYRL_XCLU_INDR;
	private String ACRD_SNRTY_INDR;
	private String NSENSEQ;
	private String CRNT_SNRTY_NBR;
	private String FA_YRS_SRVC;
	private String CRWMBR_COND_CDE;
	private String PRMNT_STAT_CDE;
	private String PRMNT_STAT_EFF_DTE;
	private String PRMNT_STAT_TRM_DTE;
	private String NEXT_PRMNT_STAT_CDE;
	private String NEXT_PRMNT_STAT_EFF_DTE;
	private String TEMP_STAT_EFF_DTE;
	private String TEMP_STAT_TRM_DTE;
	private String TEMP_STAT_CDE;
	private String NEXT_TEMP_STAT_EFF_DTE;
	private String NEXT_TEMP_STAT_TRM_DTE;
	private String NEXT_TEMP_STAT_CDE;
	private String MAC_EFF_DTE;
	private String MAC_TRM_DTE;
	private String TRNG_BASE_EFF_DTE;
	private String TRNG_BASE_TRM_DTE;
	private String PSPT_DTE;
	private String PSPT_NBR;
	private String PSPT_CNTRY_CDE;
	private String PSPT_EXP_DTE;
	private String INTL_CRW_CRD_NBR;
	private String INTNL_CRW_CRD_DTE;
	private String CO_MED_DTE;
	private String FAA_MED_DTE;
	private String FAA_MED_CLS;
	private String FAA_DOCR;
	private String MED_LOCN_IND;
	private String CRWMBR_POSN_CDE;
	private String CO_MED_BASE_MO;
	private String FAA_MED_BASE_MO;
	private String SICK_RLSE_DTE;
	private String UNPD_SICK_STR_DTE;
	private String SICK_RLSE_MNS;
	private String UNUSED_SICK_TIME;
	private String SICK_TIME_MINS_USED_YTD;
	private String SICK_TIME_MAKE_UP;
	private String SICK_TIME_MINS_USED_MTD;
	private String MRG_EMP_INDR;
	private String CR_PRJN;
	private String SCH_PRJN;
	private String GRTR_TIME_MTD;
	private String SPEC_ASGNMT_CR_MNS;
	private String INTL_SEQ_CR_MNS;
	private String REASGN_PAY_MN;
	private String UNDR_STAF_PTRN_PAY_MN;
	private String UNDR_STAF_SRVC_PAY_MN;
	private String NGT_PAY_MNS;
	private String FA_PREM_PAY_OR_PLT_CPA_MNS;
	private String FORGN_LANG_PAY_LEG;
	private String HOLD_TIME_PAY_MNS;;
	private String GRND_TIME_PAY_MNS;
	private String DOM_TAFB_XPNS;
	private String DOM_TAFB_TAX_XPNS;
	private String MISC_TAX_XPNS;
	private String MISC_XPNS;
	private String TRIP_SEL_NBR;
	private String SEL_CRW_BASE_CDE;
	private String MO_SELN_GRP_CRWMBR_POSN_CDE;
	private String MO_SELN_GRP_DOM_INTL_CDE;
	private String INACTV_SEL_RSN_CDE;
	private String PA_BID_IND;
	private String TRIP_SEL_TYPE_CDE;
	private String HIGH_EQP_TYPE_CDE;
	private String CALL_OUT_STNDBY_QTY;
	private String FA_BID_OPT_CDE;
	
	private String INTL_PAY_MN;
	private String FIRST_INITIAL;
	private String MIDDLE_INITIAL;
	private String LAST_NAME;
	private String BIRTH_DTE;
	private String CO_SNRTY_DTE;
	private String OCCUP_SNRTY_DTE;
	private String CLS_SNRTY_DTE;
	private String ORG_HIRE_DTE;
	private String COMMUTE_FLAG;
	private String VAR_MAN_IND;
	private String PAPER_BID_REASON;
	private String NEXT_BID_DSPLCMT_PREFNC_CDE;
	private String XCD_MOLY_FLYG_HRS_AGRMT_INDR;
	private String CAPT_BID_RQMT_INDR;
	private String FIR_OFCR_BID_RQMT_INDR;
	private String AIRCAL_FRMR_EMP_INDR;
	private String GUAR_MIN_MOLY_MN_QTY;
	private String FRGN_LNG_PAY_MN_QTY;
	private String CRWB_SUPV_NUM;
	private String DRUG_TST_DTE;
	private String LST_FLWN_DTE;
	private String INTL_TAFB_XPNS;
	private String INTL_TAFB_TAX_XPNS;
	private String TS_PAY_PROJ_MINUTES;
	private String BID_SEL_PROJ_MNS;
	private String CKA_FLAG;
	private String CKA_TYPE;
	private String CKA_BANK;
	private String FA_ACTL_BASE_GUAR;
	private String FA_ACTL_INC_GUAR;
	private String NGT_PAY_MNS2;
	private String CHASE_FL_MNS;
	private String HOME_TEL_NBR;
	private String BUS_TEL_NBR;
	private String TEMP_TEL_NBR;
	private String EMP_SCNDRY_TEL_NBR;
	private String RSTRD_SICK_TME_MNS;
	private String ADJ_CKPT_PAY_GUAR;
	private String CKPT_WAVED_DFP;
	private String ORIG_AIRL_CDE;
	private String CURR_AIRL_CDE;
	private String PRV_TRIP_SEL_TYPE_CDE;
	private String PRV_BID_STS_GRP;
	private String PRV_BID_STS_GRP_SEQ_CRW_BASE;
	private String PRV_BID_STS_GRP_CRWMBR_POSN_CDE;
	private String PRV_BID_STS_GRP_EQUIPMENT;
	private String PRV_BID_STS_GRP_DOM_INTL_CDE;
	private String PRV_BID_STS_GRP_EFF_DTE;
	private String OCC2_DTE;
	private String SYST_SNRTY_NO;
	private String TFCOPY_EFF_DTE;
	private String TFCOPY_NEFF_DTE;
	private String PIL_MON_RSV_GRP_CUR_STAT_INDR;
	private String PIL_MON_RSV_GRP_CUR_DALY_CRED;
	private String PIL_IPMAX_GRP_CUR_MNTH_IPMAX;
	private String VAC_SNRTY_DTE;
	private String DAILY_CREDIT_PAY_DAILY_CREDIT;
	private String DAILY_CREDIT_PAY_DAILY_PAY;
	private String FILL_S2;
	private String FILL_S3;
	private String FILL_S4;
	private List<XCMDATA> XCMDATA;
	private List<CRWMBR_EQP_QLFN_GRP> CRWMBR_EQP_QLFN_GRP;
	private List<DLY_CRWMR_BID_GRP> DLY_CRWMR_BID_GRP;
	private List<CRNT_BID_STAT_GRP> CRNT_BID_STAT_GRP;
	private List<NEXT_BID_STAT_GRP> NEXT_BID_STAT_GRP;
	private List<WTHD_BID_STAT_GRP> WTHD_BID_STAT_GRP;
	private List<DEFRL_BID_STAT_GRP> DEFRL_BID_STAT_GRP;
	
	public String getMAIDEN_NAME() {
		return MAIDEN_NAME;
	}
	public void setMAIDEN_NAME(String mAIDEN_NAME) {
		MAIDEN_NAME = mAIDEN_NAME;
	}
	public String getFRMR_CO_CDE() {
		return FRMR_CO_CDE;
	}
	public void setFRMR_CO_CDE(String fRMR_CO_CDE) {
		FRMR_CO_CDE = fRMR_CO_CDE;
	}
	public String getMAIL_LOCN() {
		return MAIL_LOCN;
	}
	public void setMAIL_LOCN(String mAIL_LOCN) {
		MAIL_LOCN = mAIL_LOCN;
	}
	public String getPLT_COMN_DTE() {
		return PLT_COMN_DTE;
	}
	public void setPLT_COMN_DTE(String pLT_COMN_DTE) {
		PLT_COMN_DTE = pLT_COMN_DTE;
	}
	public String getCOPLT_COMN_DTE() {
		return COPLT_COMN_DTE;
	}
	public void setCOPLT_COMN_DTE(String cOPLT_COMN_DTE) {
		COPLT_COMN_DTE = cOPLT_COMN_DTE;
	}
	public String getHIGH_SEAT_CDE() {
		return HIGH_SEAT_CDE;
	}
	public void setHIGH_SEAT_CDE(String hIGH_SEAT_CDE) {
		HIGH_SEAT_CDE = hIGH_SEAT_CDE;
	}
	public String getPRMNT_CRW_BASE_CDE() {
		return PRMNT_CRW_BASE_CDE;
	}
	public void setPRMNT_CRW_BASE_CDE(String pRMNT_CRW_BASE_CDE) {
		PRMNT_CRW_BASE_CDE = pRMNT_CRW_BASE_CDE;
	}
	public String getCRW_BASE_ASGN_DATE() {
		return CRW_BASE_ASGN_DATE;
	}
	public void setCRW_BASE_ASGN_DATE(String cRW_BASE_ASGN_DATE) {
		CRW_BASE_ASGN_DATE = cRW_BASE_ASGN_DATE;
	}
	public String getINTL_ASGN_CDE() {
		return INTL_ASGN_CDE;
	}
	public void setINTL_ASGN_CDE(String iNTL_ASGN_CDE) {
		INTL_ASGN_CDE = iNTL_ASGN_CDE;
	}
	public String getNEXT_INTL_ASGN_CDE() {
		return NEXT_INTL_ASGN_CDE;
	}
	public void setNEXT_INTL_ASGN_CDE(String nEXT_INTL_ASGN_CDE) {
		NEXT_INTL_ASGN_CDE = nEXT_INTL_ASGN_CDE;
	}
	public String getNEXT_CRW_BASE() {
		return NEXT_CRW_BASE;
	}
	public void setNEXT_CRW_BASE(String nEXT_CRW_BASE) {
		NEXT_CRW_BASE = nEXT_CRW_BASE;
	}
	public String getNEXT_CRW_BASE_DATE() {
		return NEXT_CRW_BASE_DATE;
	}
	public void setNEXT_CRW_BASE_DATE(String nEXT_CRW_BASE_DATE) {
		NEXT_CRW_BASE_DATE = nEXT_CRW_BASE_DATE;
	}
	public String getPAYRL_XCLU_INDR() {
		return PAYRL_XCLU_INDR;
	}
	public void setPAYRL_XCLU_INDR(String pAYRL_XCLU_INDR) {
		PAYRL_XCLU_INDR = pAYRL_XCLU_INDR;
	}
	public String getACRD_SNRTY_INDR() {
		return ACRD_SNRTY_INDR;
	}
	public void setACRD_SNRTY_INDR(String aCRD_SNRTY_INDR) {
		ACRD_SNRTY_INDR = aCRD_SNRTY_INDR;
	}
	public String getNSENSEQ() {
		return NSENSEQ;
	}
	public void setNSENSEQ(String nSENSEQ) {
		NSENSEQ = nSENSEQ;
	}
	public String getCRNT_SNRTY_NBR() {
		return CRNT_SNRTY_NBR;
	}
	public void setCRNT_SNRTY_NBR(String cRNT_SNRTY_NBR) {
		CRNT_SNRTY_NBR = cRNT_SNRTY_NBR;
	}
	public String getFA_YRS_SRVC() {
		return FA_YRS_SRVC;
	}
	public void setFA_YRS_SRVC(String fA_YRS_SRVC) {
		FA_YRS_SRVC = fA_YRS_SRVC;
	}
	public String getCRWMBR_COND_CDE() {
		return CRWMBR_COND_CDE;
	}
	public void setCRWMBR_COND_CDE(String cRWMBR_COND_CDE) {
		CRWMBR_COND_CDE = cRWMBR_COND_CDE;
	}
	public String getPRMNT_STAT_CDE() {
		return PRMNT_STAT_CDE;
	}
	public void setPRMNT_STAT_CDE(String pRMNT_STAT_CDE) {
		PRMNT_STAT_CDE = pRMNT_STAT_CDE;
	}
	public String getPRMNT_STAT_EFF_DTE() {
		return PRMNT_STAT_EFF_DTE;
	}
	public void setPRMNT_STAT_EFF_DTE(String pRMNT_STAT_EFF_DTE) {
		PRMNT_STAT_EFF_DTE = pRMNT_STAT_EFF_DTE;
	}
	public String getPRMNT_STAT_TRM_DTE() {
		return PRMNT_STAT_TRM_DTE;
	}
	public void setPRMNT_STAT_TRM_DTE(String pRMNT_STAT_TRM_DTE) {
		PRMNT_STAT_TRM_DTE = pRMNT_STAT_TRM_DTE;
	}
	public String getNEXT_PRMNT_STAT_CDE() {
		return NEXT_PRMNT_STAT_CDE;
	}
	public void setNEXT_PRMNT_STAT_CDE(String nEXT_PRMNT_STAT_CDE) {
		NEXT_PRMNT_STAT_CDE = nEXT_PRMNT_STAT_CDE;
	}
	public String getNEXT_PRMNT_STAT_EFF_DTE() {
		return NEXT_PRMNT_STAT_EFF_DTE;
	}
	public void setNEXT_PRMNT_STAT_EFF_DTE(String nEXT_PRMNT_STAT_EFF_DTE) {
		NEXT_PRMNT_STAT_EFF_DTE = nEXT_PRMNT_STAT_EFF_DTE;
	}
	public String getTEMP_STAT_EFF_DTE() {
		return TEMP_STAT_EFF_DTE;
	}
	public void setTEMP_STAT_EFF_DTE(String tEMP_STAT_EFF_DTE) {
		TEMP_STAT_EFF_DTE = tEMP_STAT_EFF_DTE;
	}
	public String getTEMP_STAT_TRM_DTE() {
		return TEMP_STAT_TRM_DTE;
	}
	public void setTEMP_STAT_TRM_DTE(String tEMP_STAT_TRM_DTE) {
		TEMP_STAT_TRM_DTE = tEMP_STAT_TRM_DTE;
	}
	public String getTEMP_STAT_CDE() {
		return TEMP_STAT_CDE;
	}
	public void setTEMP_STAT_CDE(String tEMP_STAT_CDE) {
		TEMP_STAT_CDE = tEMP_STAT_CDE;
	}
	public String getNEXT_TEMP_STAT_EFF_DTE() {
		return NEXT_TEMP_STAT_EFF_DTE;
	}
	public void setNEXT_TEMP_STAT_EFF_DTE(String nEXT_TEMP_STAT_EFF_DTE) {
		NEXT_TEMP_STAT_EFF_DTE = nEXT_TEMP_STAT_EFF_DTE;
	}
	public String getNEXT_TEMP_STAT_TRM_DTE() {
		return NEXT_TEMP_STAT_TRM_DTE;
	}
	public void setNEXT_TEMP_STAT_TRM_DTE(String nEXT_TEMP_STAT_TRM_DTE) {
		NEXT_TEMP_STAT_TRM_DTE = nEXT_TEMP_STAT_TRM_DTE;
	}
	public String getNEXT_TEMP_STAT_CDE() {
		return NEXT_TEMP_STAT_CDE;
	}
	public void setNEXT_TEMP_STAT_CDE(String nEXT_TEMP_STAT_CDE) {
		NEXT_TEMP_STAT_CDE = nEXT_TEMP_STAT_CDE;
	}
	public String getMAC_EFF_DTE() {
		return MAC_EFF_DTE;
	}
	public void setMAC_EFF_DTE(String mAC_EFF_DTE) {
		MAC_EFF_DTE = mAC_EFF_DTE;
	}
	public String getMAC_TRM_DTE() {
		return MAC_TRM_DTE;
	}
	public void setMAC_TRM_DTE(String mAC_TRM_DTE) {
		MAC_TRM_DTE = mAC_TRM_DTE;
	}
	public String getTRNG_BASE_EFF_DTE() {
		return TRNG_BASE_EFF_DTE;
	}
	public void setTRNG_BASE_EFF_DTE(String tRNG_BASE_EFF_DTE) {
		TRNG_BASE_EFF_DTE = tRNG_BASE_EFF_DTE;
	}
	public String getTRNG_BASE_TRM_DTE() {
		return TRNG_BASE_TRM_DTE;
	}
	public void setTRNG_BASE_TRM_DTE(String tRNG_BASE_TRM_DTE) {
		TRNG_BASE_TRM_DTE = tRNG_BASE_TRM_DTE;
	}
	public String getPSPT_DTE() {
		return PSPT_DTE;
	}
	public void setPSPT_DTE(String pSPT_DTE) {
		PSPT_DTE = pSPT_DTE;
	}
	public String getPSPT_NBR() {
		return PSPT_NBR;
	}
	public void setPSPT_NBR(String pSPT_NBR) {
		PSPT_NBR = pSPT_NBR;
	}
	public String getPSPT_CNTRY_CDE() {
		return PSPT_CNTRY_CDE;
	}
	public void setPSPT_CNTRY_CDE(String pSPT_CNTRY_CDE) {
		PSPT_CNTRY_CDE = pSPT_CNTRY_CDE;
	}
	public String getPSPT_EXP_DTE() {
		return PSPT_EXP_DTE;
	}
	public void setPSPT_EXP_DTE(String pSPT_EXP_DTE) {
		PSPT_EXP_DTE = pSPT_EXP_DTE;
	}
	public String getINTL_CRW_CRD_NBR() {
		return INTL_CRW_CRD_NBR;
	}
	public void setINTL_CRW_CRD_NBR(String iNTL_CRW_CRD_NBR) {
		INTL_CRW_CRD_NBR = iNTL_CRW_CRD_NBR;
	}
	public String getINTNL_CRW_CRD_DTE() {
		return INTNL_CRW_CRD_DTE;
	}
	public void setINTNL_CRW_CRD_DTE(String iNTNL_CRW_CRD_DTE) {
		INTNL_CRW_CRD_DTE = iNTNL_CRW_CRD_DTE;
	}
	public String getCO_MED_DTE() {
		return CO_MED_DTE;
	}
	public void setCO_MED_DTE(String cO_MED_DTE) {
		CO_MED_DTE = cO_MED_DTE;
	}
	public String getFAA_MED_DTE() {
		return FAA_MED_DTE;
	}
	public void setFAA_MED_DTE(String fAA_MED_DTE) {
		FAA_MED_DTE = fAA_MED_DTE;
	}
	public String getFAA_MED_CLS() {
		return FAA_MED_CLS;
	}
	public void setFAA_MED_CLS(String fAA_MED_CLS) {
		FAA_MED_CLS = fAA_MED_CLS;
	}
	public String getFAA_DOCR() {
		return FAA_DOCR;
	}
	public void setFAA_DOCR(String fAA_DOCR) {
		FAA_DOCR = fAA_DOCR;
	}
	public String getMED_LOCN_IND() {
		return MED_LOCN_IND;
	}
	public void setMED_LOCN_IND(String mED_LOCN_IND) {
		MED_LOCN_IND = mED_LOCN_IND;
	}
	public String getCRWMBR_POSN_CDE() {
		return CRWMBR_POSN_CDE;
	}
	public void setCRWMBR_POSN_CDE(String cRWMBR_POSN_CDE) {
		CRWMBR_POSN_CDE = cRWMBR_POSN_CDE;
	}
	public String getCO_MED_BASE_MO() {
		return CO_MED_BASE_MO;
	}
	public void setCO_MED_BASE_MO(String cO_MED_BASE_MO) {
		CO_MED_BASE_MO = cO_MED_BASE_MO;
	}
	public String getFAA_MED_BASE_MO() {
		return FAA_MED_BASE_MO;
	}
	public void setFAA_MED_BASE_MO(String fAA_MED_BASE_MO) {
		FAA_MED_BASE_MO = fAA_MED_BASE_MO;
	}
	public String getSICK_RLSE_DTE() {
		return SICK_RLSE_DTE;
	}
	public void setSICK_RLSE_DTE(String sICK_RLSE_DTE) {
		SICK_RLSE_DTE = sICK_RLSE_DTE;
	}
	public String getUNPD_SICK_STR_DTE() {
		return UNPD_SICK_STR_DTE;
	}
	public void setUNPD_SICK_STR_DTE(String uNPD_SICK_STR_DTE) {
		UNPD_SICK_STR_DTE = uNPD_SICK_STR_DTE;
	}
	public String getSICK_RLSE_MNS() {
		return SICK_RLSE_MNS;
	}
	public void setSICK_RLSE_MNS(String sICK_RLSE_MNS) {
		SICK_RLSE_MNS = sICK_RLSE_MNS;
	}
	public String getUNUSED_SICK_TIME() {
		return UNUSED_SICK_TIME;
	}
	public void setUNUSED_SICK_TIME(String uNUSED_SICK_TIME) {
		UNUSED_SICK_TIME = uNUSED_SICK_TIME;
	}
	public String getSICK_TIME_MINS_USED_YTD() {
		return SICK_TIME_MINS_USED_YTD;
	}
	public void setSICK_TIME_MINS_USED_YTD(String sICK_TIME_MINS_USED_YTD) {
		SICK_TIME_MINS_USED_YTD = sICK_TIME_MINS_USED_YTD;
	}
	public String getSICK_TIME_MAKE_UP() {
		return SICK_TIME_MAKE_UP;
	}
	public void setSICK_TIME_MAKE_UP(String sICK_TIME_MAKE_UP) {
		SICK_TIME_MAKE_UP = sICK_TIME_MAKE_UP;
	}
	public String getSICK_TIME_MINS_USED_MTD() {
		return SICK_TIME_MINS_USED_MTD;
	}
	public void setSICK_TIME_MINS_USED_MTD(String sICK_TIME_MINS_USED_MTD) {
		SICK_TIME_MINS_USED_MTD = sICK_TIME_MINS_USED_MTD;
	}
	public String getMRG_EMP_INDR() {
		return MRG_EMP_INDR;
	}
	public void setMRG_EMP_INDR(String mRG_EMP_INDR) {
		MRG_EMP_INDR = mRG_EMP_INDR;
	}
	public String getCR_PRJN() {
		return CR_PRJN;
	}
	public void setCR_PRJN(String cR_PRJN) {
		CR_PRJN = cR_PRJN;
	}
	public String getSCH_PRJN() {
		return SCH_PRJN;
	}
	public void setSCH_PRJN(String sCH_PRJN) {
		SCH_PRJN = sCH_PRJN;
	}
	public String getGRTR_TIME_MTD() {
		return GRTR_TIME_MTD;
	}
	public void setGRTR_TIME_MTD(String gRTR_TIME_MTD) {
		GRTR_TIME_MTD = gRTR_TIME_MTD;
	}
	public String getSPEC_ASGNMT_CR_MNS() {
		return SPEC_ASGNMT_CR_MNS;
	}
	public void setSPEC_ASGNMT_CR_MNS(String sPEC_ASGNMT_CR_MNS) {
		SPEC_ASGNMT_CR_MNS = sPEC_ASGNMT_CR_MNS;
	}
	public String getINTL_SEQ_CR_MNS() {
		return INTL_SEQ_CR_MNS;
	}
	public void setINTL_SEQ_CR_MNS(String iNTL_SEQ_CR_MNS) {
		INTL_SEQ_CR_MNS = iNTL_SEQ_CR_MNS;
	}
	public String getREASGN_PAY_MN() {
		return REASGN_PAY_MN;
	}
	public void setREASGN_PAY_MN(String rEASGN_PAY_MN) {
		REASGN_PAY_MN = rEASGN_PAY_MN;
	}
	public String getUNDR_STAF_PTRN_PAY_MN() {
		return UNDR_STAF_PTRN_PAY_MN;
	}
	public void setUNDR_STAF_PTRN_PAY_MN(String uNDR_STAF_PTRN_PAY_MN) {
		UNDR_STAF_PTRN_PAY_MN = uNDR_STAF_PTRN_PAY_MN;
	}
	public String getUNDR_STAF_SRVC_PAY_MN() {
		return UNDR_STAF_SRVC_PAY_MN;
	}
	public void setUNDR_STAF_SRVC_PAY_MN(String uNDR_STAF_SRVC_PAY_MN) {
		UNDR_STAF_SRVC_PAY_MN = uNDR_STAF_SRVC_PAY_MN;
	}
	public String getNGT_PAY_MNS() {
		return NGT_PAY_MNS;
	}
	public void setNGT_PAY_MNS(String nGT_PAY_MNS) {
		NGT_PAY_MNS = nGT_PAY_MNS;
	}
	public String getFA_PREM_PAY_OR_PLT_CPA_MNS() {
		return FA_PREM_PAY_OR_PLT_CPA_MNS;
	}
	public void setFA_PREM_PAY_OR_PLT_CPA_MNS(String fA_PREM_PAY_OR_PLT_CPA_MNS) {
		FA_PREM_PAY_OR_PLT_CPA_MNS = fA_PREM_PAY_OR_PLT_CPA_MNS;
	}
	public String getFORGN_LANG_PAY_LEG() {
		return FORGN_LANG_PAY_LEG;
	}
	public void setFORGN_LANG_PAY_LEG(String fORGN_LANG_PAY_LEG) {
		FORGN_LANG_PAY_LEG = fORGN_LANG_PAY_LEG;
	}
	public String getHOLD_TIME_PAY_MNS() {
		return HOLD_TIME_PAY_MNS;
	}
	public void setHOLD_TIME_PAY_MNS(String hOLD_TIME_PAY_MNS) {
		HOLD_TIME_PAY_MNS = hOLD_TIME_PAY_MNS;
	}
	public String getGRND_TIME_PAY_MNS() {
		return GRND_TIME_PAY_MNS;
	}
	public void setGRND_TIME_PAY_MNS(String gRND_TIME_PAY_MNS) {
		GRND_TIME_PAY_MNS = gRND_TIME_PAY_MNS;
	}
	public String getDOM_TAFB_XPNS() {
		return DOM_TAFB_XPNS;
	}
	public void setDOM_TAFB_XPNS(String dOM_TAFB_XPNS) {
		DOM_TAFB_XPNS = dOM_TAFB_XPNS;
	}
	public String getDOM_TAFB_TAX_XPNS() {
		return DOM_TAFB_TAX_XPNS;
	}
	public void setDOM_TAFB_TAX_XPNS(String dOM_TAFB_TAX_XPNS) {
		DOM_TAFB_TAX_XPNS = dOM_TAFB_TAX_XPNS;
	}
	public String getMISC_TAX_XPNS() {
		return MISC_TAX_XPNS;
	}
	public void setMISC_TAX_XPNS(String mISC_TAX_XPNS) {
		MISC_TAX_XPNS = mISC_TAX_XPNS;
	}
	public String getMISC_XPNS() {
		return MISC_XPNS;
	}
	public void setMISC_XPNS(String mISC_XPNS) {
		MISC_XPNS = mISC_XPNS;
	}
	public String getTRIP_SEL_NBR() {
		return TRIP_SEL_NBR;
	}
	public void setTRIP_SEL_NBR(String tRIP_SEL_NBR) {
		TRIP_SEL_NBR = tRIP_SEL_NBR;
	}
	public String getSEL_CRW_BASE_CDE() {
		return SEL_CRW_BASE_CDE;
	}
	public void setSEL_CRW_BASE_CDE(String sEL_CRW_BASE_CDE) {
		SEL_CRW_BASE_CDE = sEL_CRW_BASE_CDE;
	}
	public String getMO_SELN_GRP_CRWMBR_POSN_CDE() {
		return MO_SELN_GRP_CRWMBR_POSN_CDE;
	}
	public void setMO_SELN_GRP_CRWMBR_POSN_CDE(String mO_SELN_GRP_CRWMBR_POSN_CDE) {
		MO_SELN_GRP_CRWMBR_POSN_CDE = mO_SELN_GRP_CRWMBR_POSN_CDE;
	}
	public String getMO_SELN_GRP_DOM_INTL_CDE() {
		return MO_SELN_GRP_DOM_INTL_CDE;
	}
	public void setMO_SELN_GRP_DOM_INTL_CDE(String mO_SELN_GRP_DOM_INTL_CDE) {
		MO_SELN_GRP_DOM_INTL_CDE = mO_SELN_GRP_DOM_INTL_CDE;
	}
	public String getINACTV_SEL_RSN_CDE() {
		return INACTV_SEL_RSN_CDE;
	}
	public void setINACTV_SEL_RSN_CDE(String iNACTV_SEL_RSN_CDE) {
		INACTV_SEL_RSN_CDE = iNACTV_SEL_RSN_CDE;
	}
	public String getPA_BID_IND() {
		return PA_BID_IND;
	}
	public void setPA_BID_IND(String pA_BID_IND) {
		PA_BID_IND = pA_BID_IND;
	}
	public String getTRIP_SEL_TYPE_CDE() {
		return TRIP_SEL_TYPE_CDE;
	}
	public void setTRIP_SEL_TYPE_CDE(String tRIP_SEL_TYPE_CDE) {
		TRIP_SEL_TYPE_CDE = tRIP_SEL_TYPE_CDE;
	}
	public String getHIGH_EQP_TYPE_CDE() {
		return HIGH_EQP_TYPE_CDE;
	}
	public void setHIGH_EQP_TYPE_CDE(String hIGH_EQP_TYPE_CDE) {
		HIGH_EQP_TYPE_CDE = hIGH_EQP_TYPE_CDE;
	}
	public String getCALL_OUT_STNDBY_QTY() {
		return CALL_OUT_STNDBY_QTY;
	}
	public void setCALL_OUT_STNDBY_QTY(String cALL_OUT_STNDBY_QTY) {
		CALL_OUT_STNDBY_QTY = cALL_OUT_STNDBY_QTY;
	}
	public String getFA_BID_OPT_CDE() {
		return FA_BID_OPT_CDE;
	}
	public void setFA_BID_OPT_CDE(String fA_BID_OPT_CDE) {
		FA_BID_OPT_CDE = fA_BID_OPT_CDE;
	}
	public String getINTL_PAY_MN() {
		return INTL_PAY_MN;
	}
	public void setINTL_PAY_MN(String iNTL_PAY_MN) {
		INTL_PAY_MN = iNTL_PAY_MN;
	}
	public String getFIRST_INITIAL() {
		return FIRST_INITIAL;
	}
	public void setFIRST_INITIAL(String fIRST_INITIAL) {
		FIRST_INITIAL = fIRST_INITIAL;
	}
	public String getMIDDLE_INITIAL() {
		return MIDDLE_INITIAL;
	}
	public void setMIDDLE_INITIAL(String mIDDLE_INITIAL) {
		MIDDLE_INITIAL = mIDDLE_INITIAL;
	}
	public String getLAST_NAME() {
		return LAST_NAME;
	}
	public void setLAST_NAME(String lAST_NAME) {
		LAST_NAME = lAST_NAME;
	}
	public String getBIRTH_DTE() {
		return BIRTH_DTE;
	}
	public void setBIRTH_DTE(String bIRTH_DTE) {
		BIRTH_DTE = bIRTH_DTE;
	}
	public String getCO_SNRTY_DTE() {
		return CO_SNRTY_DTE;
	}
	public void setCO_SNRTY_DTE(String cO_SNRTY_DTE) {
		CO_SNRTY_DTE = cO_SNRTY_DTE;
	}
	public String getOCCUP_SNRTY_DTE() {
		return OCCUP_SNRTY_DTE;
	}
	public void setOCCUP_SNRTY_DTE(String oCCUP_SNRTY_DTE) {
		OCCUP_SNRTY_DTE = oCCUP_SNRTY_DTE;
	}
	public String getCLS_SNRTY_DTE() {
		return CLS_SNRTY_DTE;
	}
	public void setCLS_SNRTY_DTE(String cLS_SNRTY_DTE) {
		CLS_SNRTY_DTE = cLS_SNRTY_DTE;
	}
	public String getORG_HIRE_DTE() {
		return ORG_HIRE_DTE;
	}
	public void setORG_HIRE_DTE(String oRG_HIRE_DTE) {
		ORG_HIRE_DTE = oRG_HIRE_DTE;
	}
	public String getCOMMUTE_FLAG() {
		return COMMUTE_FLAG;
	}
	public void setCOMMUTE_FLAG(String cOMMUTE_FLAG) {
		COMMUTE_FLAG = cOMMUTE_FLAG;
	}
	public String getVAR_MAN_IND() {
		return VAR_MAN_IND;
	}
	public void setVAR_MAN_IND(String vAR_MAN_IND) {
		VAR_MAN_IND = vAR_MAN_IND;
	}
	public String getPAPER_BID_REASON() {
		return PAPER_BID_REASON;
	}
	public void setPAPER_BID_REASON(String pAPER_BID_REASON) {
		PAPER_BID_REASON = pAPER_BID_REASON;
	}
	public String getNEXT_BID_DSPLCMT_PREFNC_CDE() {
		return NEXT_BID_DSPLCMT_PREFNC_CDE;
	}
	public void setNEXT_BID_DSPLCMT_PREFNC_CDE(String nEXT_BID_DSPLCMT_PREFNC_CDE) {
		NEXT_BID_DSPLCMT_PREFNC_CDE = nEXT_BID_DSPLCMT_PREFNC_CDE;
	}
	public String getXCD_MOLY_FLYG_HRS_AGRMT_INDR() {
		return XCD_MOLY_FLYG_HRS_AGRMT_INDR;
	}
	public void setXCD_MOLY_FLYG_HRS_AGRMT_INDR(String xCD_MOLY_FLYG_HRS_AGRMT_INDR) {
		XCD_MOLY_FLYG_HRS_AGRMT_INDR = xCD_MOLY_FLYG_HRS_AGRMT_INDR;
	}
	public String getCAPT_BID_RQMT_INDR() {
		return CAPT_BID_RQMT_INDR;
	}
	public void setCAPT_BID_RQMT_INDR(String cAPT_BID_RQMT_INDR) {
		CAPT_BID_RQMT_INDR = cAPT_BID_RQMT_INDR;
	}
	public String getFIR_OFCR_BID_RQMT_INDR() {
		return FIR_OFCR_BID_RQMT_INDR;
	}
	public void setFIR_OFCR_BID_RQMT_INDR(String fIR_OFCR_BID_RQMT_INDR) {
		FIR_OFCR_BID_RQMT_INDR = fIR_OFCR_BID_RQMT_INDR;
	}
	public String getAIRCAL_FRMR_EMP_INDR() {
		return AIRCAL_FRMR_EMP_INDR;
	}
	public void setAIRCAL_FRMR_EMP_INDR(String aIRCAL_FRMR_EMP_INDR) {
		AIRCAL_FRMR_EMP_INDR = aIRCAL_FRMR_EMP_INDR;
	}
	public String getGUAR_MIN_MOLY_MN_QTY() {
		return GUAR_MIN_MOLY_MN_QTY;
	}
	public void setGUAR_MIN_MOLY_MN_QTY(String gUAR_MIN_MOLY_MN_QTY) {
		GUAR_MIN_MOLY_MN_QTY = gUAR_MIN_MOLY_MN_QTY;
	}
	public String getFRGN_LNG_PAY_MN_QTY() {
		return FRGN_LNG_PAY_MN_QTY;
	}
	public void setFRGN_LNG_PAY_MN_QTY(String fRGN_LNG_PAY_MN_QTY) {
		FRGN_LNG_PAY_MN_QTY = fRGN_LNG_PAY_MN_QTY;
	}
	public String getCRWB_SUPV_NUM() {
		return CRWB_SUPV_NUM;
	}
	public void setCRWB_SUPV_NUM(String cRWB_SUPV_NUM) {
		CRWB_SUPV_NUM = cRWB_SUPV_NUM;
	}
	public String getDRUG_TST_DTE() {
		return DRUG_TST_DTE;
	}
	public void setDRUG_TST_DTE(String dRUG_TST_DTE) {
		DRUG_TST_DTE = dRUG_TST_DTE;
	}
	public String getLST_FLWN_DTE() {
		return LST_FLWN_DTE;
	}
	public void setLST_FLWN_DTE(String lST_FLWN_DTE) {
		LST_FLWN_DTE = lST_FLWN_DTE;
	}
	public String getINTL_TAFB_XPNS() {
		return INTL_TAFB_XPNS;
	}
	public void setINTL_TAFB_XPNS(String iNTL_TAFB_XPNS) {
		INTL_TAFB_XPNS = iNTL_TAFB_XPNS;
	}
	public String getINTL_TAFB_TAX_XPNS() {
		return INTL_TAFB_TAX_XPNS;
	}
	public void setINTL_TAFB_TAX_XPNS(String iNTL_TAFB_TAX_XPNS) {
		INTL_TAFB_TAX_XPNS = iNTL_TAFB_TAX_XPNS;
	}
	public String getTS_PAY_PROJ_MINUTES() {
		return TS_PAY_PROJ_MINUTES;
	}
	public void setTS_PAY_PROJ_MINUTES(String tS_PAY_PROJ_MINUTES) {
		TS_PAY_PROJ_MINUTES = tS_PAY_PROJ_MINUTES;
	}
	public String getBID_SEL_PROJ_MNS() {
		return BID_SEL_PROJ_MNS;
	}
	public void setBID_SEL_PROJ_MNS(String bID_SEL_PROJ_MNS) {
		BID_SEL_PROJ_MNS = bID_SEL_PROJ_MNS;
	}
	public String getCKA_FLAG() {
		return CKA_FLAG;
	}
	public void setCKA_FLAG(String cKA_FLAG) {
		CKA_FLAG = cKA_FLAG;
	}
	public String getCKA_TYPE() {
		return CKA_TYPE;
	}
	public void setCKA_TYPE(String cKA_TYPE) {
		CKA_TYPE = cKA_TYPE;
	}
	public String getCKA_BANK() {
		return CKA_BANK;
	}
	public void setCKA_BANK(String cKA_BANK) {
		CKA_BANK = cKA_BANK;
	}
	public String getFA_ACTL_BASE_GUAR() {
		return FA_ACTL_BASE_GUAR;
	}
	public void setFA_ACTL_BASE_GUAR(String fA_ACTL_BASE_GUAR) {
		FA_ACTL_BASE_GUAR = fA_ACTL_BASE_GUAR;
	}
	public String getFA_ACTL_INC_GUAR() {
		return FA_ACTL_INC_GUAR;
	}
	public void setFA_ACTL_INC_GUAR(String fA_ACTL_INC_GUAR) {
		FA_ACTL_INC_GUAR = fA_ACTL_INC_GUAR;
	}
	public String getNGT_PAY_MNS2() {
		return NGT_PAY_MNS2;
	}
	public void setNGT_PAY_MNS2(String nGT_PAY_MNS2) {
		NGT_PAY_MNS2 = nGT_PAY_MNS2;
	}
	public String getCHASE_FL_MNS() {
		return CHASE_FL_MNS;
	}
	public void setCHASE_FL_MNS(String cHASE_FL_MNS) {
		CHASE_FL_MNS = cHASE_FL_MNS;
	}
	public String getHOME_TEL_NBR() {
		return HOME_TEL_NBR;
	}
	public void setHOME_TEL_NBR(String hOME_TEL_NBR) {
		HOME_TEL_NBR = hOME_TEL_NBR;
	}
	public String getBUS_TEL_NBR() {
		return BUS_TEL_NBR;
	}
	public void setBUS_TEL_NBR(String bUS_TEL_NBR) {
		BUS_TEL_NBR = bUS_TEL_NBR;
	}
	public String getTEMP_TEL_NBR() {
		return TEMP_TEL_NBR;
	}
	public void setTEMP_TEL_NBR(String tEMP_TEL_NBR) {
		TEMP_TEL_NBR = tEMP_TEL_NBR;
	}
	public String getEMP_SCNDRY_TEL_NBR() {
		return EMP_SCNDRY_TEL_NBR;
	}
	public void setEMP_SCNDRY_TEL_NBR(String eMP_SCNDRY_TEL_NBR) {
		EMP_SCNDRY_TEL_NBR = eMP_SCNDRY_TEL_NBR;
	}
	public String getRSTRD_SICK_TME_MNS() {
		return RSTRD_SICK_TME_MNS;
	}
	public void setRSTRD_SICK_TME_MNS(String rSTRD_SICK_TME_MNS) {
		RSTRD_SICK_TME_MNS = rSTRD_SICK_TME_MNS;
	}
	public String getADJ_CKPT_PAY_GUAR() {
		return ADJ_CKPT_PAY_GUAR;
	}
	public void setADJ_CKPT_PAY_GUAR(String aDJ_CKPT_PAY_GUAR) {
		ADJ_CKPT_PAY_GUAR = aDJ_CKPT_PAY_GUAR;
	}
	public String getCKPT_WAVED_DFP() {
		return CKPT_WAVED_DFP;
	}
	public void setCKPT_WAVED_DFP(String cKPT_WAVED_DFP) {
		CKPT_WAVED_DFP = cKPT_WAVED_DFP;
	}
	public String getORIG_AIRL_CDE() {
		return ORIG_AIRL_CDE;
	}
	public void setORIG_AIRL_CDE(String oRIG_AIRL_CDE) {
		ORIG_AIRL_CDE = oRIG_AIRL_CDE;
	}
	public String getCURR_AIRL_CDE() {
		return CURR_AIRL_CDE;
	}
	public void setCURR_AIRL_CDE(String cURR_AIRL_CDE) {
		CURR_AIRL_CDE = cURR_AIRL_CDE;
	}
	public String getPRV_TRIP_SEL_TYPE_CDE() {
		return PRV_TRIP_SEL_TYPE_CDE;
	}
	public void setPRV_TRIP_SEL_TYPE_CDE(String pRV_TRIP_SEL_TYPE_CDE) {
		PRV_TRIP_SEL_TYPE_CDE = pRV_TRIP_SEL_TYPE_CDE;
	}
	public String getPRV_BID_STS_GRP() {
		return PRV_BID_STS_GRP;
	}
	public void setPRV_BID_STS_GRP(String pRV_BID_STS_GRP) {
		PRV_BID_STS_GRP = pRV_BID_STS_GRP;
	}
	public String getPRV_BID_STS_GRP_SEQ_CRW_BASE() {
		return PRV_BID_STS_GRP_SEQ_CRW_BASE;
	}
	public void setPRV_BID_STS_GRP_SEQ_CRW_BASE(String pRV_BID_STS_GRP_SEQ_CRW_BASE) {
		PRV_BID_STS_GRP_SEQ_CRW_BASE = pRV_BID_STS_GRP_SEQ_CRW_BASE;
	}
	public String getPRV_BID_STS_GRP_CRWMBR_POSN_CDE() {
		return PRV_BID_STS_GRP_CRWMBR_POSN_CDE;
	}
	public void setPRV_BID_STS_GRP_CRWMBR_POSN_CDE(String pRV_BID_STS_GRP_CRWMBR_POSN_CDE) {
		PRV_BID_STS_GRP_CRWMBR_POSN_CDE = pRV_BID_STS_GRP_CRWMBR_POSN_CDE;
	}
	public String getPRV_BID_STS_GRP_EQUIPMENT() {
		return PRV_BID_STS_GRP_EQUIPMENT;
	}
	public void setPRV_BID_STS_GRP_EQUIPMENT(String pRV_BID_STS_GRP_EQUIPMENT) {
		PRV_BID_STS_GRP_EQUIPMENT = pRV_BID_STS_GRP_EQUIPMENT;
	}
	public String getPRV_BID_STS_GRP_DOM_INTL_CDE() {
		return PRV_BID_STS_GRP_DOM_INTL_CDE;
	}
	public void setPRV_BID_STS_GRP_DOM_INTL_CDE(String pRV_BID_STS_GRP_DOM_INTL_CDE) {
		PRV_BID_STS_GRP_DOM_INTL_CDE = pRV_BID_STS_GRP_DOM_INTL_CDE;
	}
	public String getPRV_BID_STS_GRP_EFF_DTE() {
		return PRV_BID_STS_GRP_EFF_DTE;
	}
	public void setPRV_BID_STS_GRP_EFF_DTE(String pRV_BID_STS_GRP_EFF_DTE) {
		PRV_BID_STS_GRP_EFF_DTE = pRV_BID_STS_GRP_EFF_DTE;
	}
	public String getOCC2_DTE() {
		return OCC2_DTE;
	}
	public void setOCC2_DTE(String oCC2_DTE) {
		OCC2_DTE = oCC2_DTE;
	}
	public String getSYST_SNRTY_NO() {
		return SYST_SNRTY_NO;
	}
	public void setSYST_SNRTY_NO(String sYST_SNRTY_NO) {
		SYST_SNRTY_NO = sYST_SNRTY_NO;
	}
	public String getTFCOPY_EFF_DTE() {
		return TFCOPY_EFF_DTE;
	}
	public void setTFCOPY_EFF_DTE(String tFCOPY_EFF_DTE) {
		TFCOPY_EFF_DTE = tFCOPY_EFF_DTE;
	}
	public String getTFCOPY_NEFF_DTE() {
		return TFCOPY_NEFF_DTE;
	}
	public void setTFCOPY_NEFF_DTE(String tFCOPY_NEFF_DTE) {
		TFCOPY_NEFF_DTE = tFCOPY_NEFF_DTE;
	}
	public String getPIL_MON_RSV_GRP_CUR_STAT_INDR() {
		return PIL_MON_RSV_GRP_CUR_STAT_INDR;
	}
	public void setPIL_MON_RSV_GRP_CUR_STAT_INDR(String pIL_MON_RSV_GRP_CUR_STAT_INDR) {
		PIL_MON_RSV_GRP_CUR_STAT_INDR = pIL_MON_RSV_GRP_CUR_STAT_INDR;
	}
	public String getPIL_MON_RSV_GRP_CUR_DALY_CRED() {
		return PIL_MON_RSV_GRP_CUR_DALY_CRED;
	}
	public void setPIL_MON_RSV_GRP_CUR_DALY_CRED(String pIL_MON_RSV_GRP_CUR_DALY_CRED) {
		PIL_MON_RSV_GRP_CUR_DALY_CRED = pIL_MON_RSV_GRP_CUR_DALY_CRED;
	}
	public String getPIL_IPMAX_GRP_CUR_MNTH_IPMAX() {
		return PIL_IPMAX_GRP_CUR_MNTH_IPMAX;
	}
	public void setPIL_IPMAX_GRP_CUR_MNTH_IPMAX(String pIL_IPMAX_GRP_CUR_MNTH_IPMAX) {
		PIL_IPMAX_GRP_CUR_MNTH_IPMAX = pIL_IPMAX_GRP_CUR_MNTH_IPMAX;
	}
	public String getVAC_SNRTY_DTE() {
		return VAC_SNRTY_DTE;
	}
	public void setVAC_SNRTY_DTE(String vAC_SNRTY_DTE) {
		VAC_SNRTY_DTE = vAC_SNRTY_DTE;
	}
	public String getDAILY_CREDIT_PAY_DAILY_CREDIT() {
		return DAILY_CREDIT_PAY_DAILY_CREDIT;
	}
	public void setDAILY_CREDIT_PAY_DAILY_CREDIT(String dAILY_CREDIT_PAY_DAILY_CREDIT) {
		DAILY_CREDIT_PAY_DAILY_CREDIT = dAILY_CREDIT_PAY_DAILY_CREDIT;
	}
	public String getDAILY_CREDIT_PAY_DAILY_PAY() {
		return DAILY_CREDIT_PAY_DAILY_PAY;
	}
	public void setDAILY_CREDIT_PAY_DAILY_PAY(String dAILY_CREDIT_PAY_DAILY_PAY) {
		DAILY_CREDIT_PAY_DAILY_PAY = dAILY_CREDIT_PAY_DAILY_PAY;
	}
	public String getFILL_S2() {
		return FILL_S2;
	}
	public void setFILL_S2(String fILL_S2) {
		FILL_S2 = fILL_S2;
	}
	public String getFILL_S3() {
		return FILL_S3;
	}
	public void setFILL_S3(String fILL_S3) {
		FILL_S3 = fILL_S3;
	}
	public String getFILL_S4() {
		return FILL_S4;
	}
	public void setFILL_S4(String fILL_S4) {
		FILL_S4 = fILL_S4;
	}
	public List<XCMDATA> getXCMDATA() {
		return XCMDATA;
	}
	public void setXCMDATA(List<XCMDATA> xCMDATA) {
		XCMDATA = xCMDATA;
	}
	public List<CRWMBR_EQP_QLFN_GRP> getCRWMBR_EQP_QLFN_GRP() {
		return CRWMBR_EQP_QLFN_GRP;
	}
	public void setCRWMBR_EQP_QLFN_GRP(List<CRWMBR_EQP_QLFN_GRP> cRWMBR_EQP_QLFN_GRP) {
		CRWMBR_EQP_QLFN_GRP = cRWMBR_EQP_QLFN_GRP;
	}
	public List<DLY_CRWMR_BID_GRP> getDLY_CRWMR_BID_GRP() {
		return DLY_CRWMR_BID_GRP;
	}
	public void setDLY_CRWMR_BID_GRP(List<DLY_CRWMR_BID_GRP> dLY_CRWMR_BID_GRP) {
		DLY_CRWMR_BID_GRP = dLY_CRWMR_BID_GRP;
	}
	public List<CRNT_BID_STAT_GRP> getCRNT_BID_STAT_GRP() {
		return CRNT_BID_STAT_GRP;
	}
	public void setCRNT_BID_STAT_GRP(List<CRNT_BID_STAT_GRP> cRNT_BID_STAT_GRP) {
		CRNT_BID_STAT_GRP = cRNT_BID_STAT_GRP;
	}
	public List<NEXT_BID_STAT_GRP> getNEXT_BID_STAT_GRP() {
		return NEXT_BID_STAT_GRP;
	}
	public void setNEXT_BID_STAT_GRP(List<NEXT_BID_STAT_GRP> nEXT_BID_STAT_GRP) {
		NEXT_BID_STAT_GRP = nEXT_BID_STAT_GRP;
	}
	public List<WTHD_BID_STAT_GRP> getWTHD_BID_STAT_GRP() {
		return WTHD_BID_STAT_GRP;
	}
	public void setWTHD_BID_STAT_GRP(List<WTHD_BID_STAT_GRP> wTHD_BID_STAT_GRP) {
		WTHD_BID_STAT_GRP = wTHD_BID_STAT_GRP;
	}
	public List<DEFRL_BID_STAT_GRP> getDEFRL_BID_STAT_GRP() {
		return DEFRL_BID_STAT_GRP;
	}
	public void setDEFRL_BID_STAT_GRP(List<DEFRL_BID_STAT_GRP> dEFRL_BID_STAT_GRP) {
		DEFRL_BID_STAT_GRP = dEFRL_BID_STAT_GRP;
	}
	@Override
	public String toString() {
		return "CrewMembers [MAIDEN_NAME=" + MAIDEN_NAME + ", FRMR_CO_CDE=" + FRMR_CO_CDE + ", MAIL_LOCN=" + MAIL_LOCN
				+ ", PLT_COMN_DTE=" + PLT_COMN_DTE + ", COPLT_COMN_DTE=" + COPLT_COMN_DTE + ", HIGH_SEAT_CDE="
				+ HIGH_SEAT_CDE + ", PRMNT_CRW_BASE_CDE=" + PRMNT_CRW_BASE_CDE + ", CRW_BASE_ASGN_DATE="
				+ CRW_BASE_ASGN_DATE + ", INTL_ASGN_CDE=" + INTL_ASGN_CDE + ", NEXT_INTL_ASGN_CDE=" + NEXT_INTL_ASGN_CDE
				+ ", NEXT_CRW_BASE=" + NEXT_CRW_BASE + ", NEXT_CRW_BASE_DATE=" + NEXT_CRW_BASE_DATE
				+ ", PAYRL_XCLU_INDR=" + PAYRL_XCLU_INDR + ", ACRD_SNRTY_INDR=" + ACRD_SNRTY_INDR + ", NSENSEQ="
				+ NSENSEQ + ", CRNT_SNRTY_NBR=" + CRNT_SNRTY_NBR + ", FA_YRS_SRVC=" + FA_YRS_SRVC + ", CRWMBR_COND_CDE="
				+ CRWMBR_COND_CDE + ", PRMNT_STAT_CDE=" + PRMNT_STAT_CDE + ", PRMNT_STAT_EFF_DTE=" + PRMNT_STAT_EFF_DTE
				+ ", PRMNT_STAT_TRM_DTE=" + PRMNT_STAT_TRM_DTE + ", NEXT_PRMNT_STAT_CDE=" + NEXT_PRMNT_STAT_CDE
				+ ", NEXT_PRMNT_STAT_EFF_DTE=" + NEXT_PRMNT_STAT_EFF_DTE + ", TEMP_STAT_EFF_DTE=" + TEMP_STAT_EFF_DTE
				+ ", TEMP_STAT_TRM_DTE=" + TEMP_STAT_TRM_DTE + ", TEMP_STAT_CDE=" + TEMP_STAT_CDE
				+ ", NEXT_TEMP_STAT_EFF_DTE=" + NEXT_TEMP_STAT_EFF_DTE + ", NEXT_TEMP_STAT_TRM_DTE="
				+ NEXT_TEMP_STAT_TRM_DTE + ", NEXT_TEMP_STAT_CDE=" + NEXT_TEMP_STAT_CDE + ", MAC_EFF_DTE=" + MAC_EFF_DTE
				+ ", MAC_TRM_DTE=" + MAC_TRM_DTE + ", TRNG_BASE_EFF_DTE=" + TRNG_BASE_EFF_DTE + ", TRNG_BASE_TRM_DTE="
				+ TRNG_BASE_TRM_DTE + ", PSPT_DTE=" + PSPT_DTE + ", PSPT_NBR=" + PSPT_NBR + ", PSPT_CNTRY_CDE="
				+ PSPT_CNTRY_CDE + ", PSPT_EXP_DTE=" + PSPT_EXP_DTE + ", INTL_CRW_CRD_NBR=" + INTL_CRW_CRD_NBR
				+ ", INTNL_CRW_CRD_DTE=" + INTNL_CRW_CRD_DTE + ", CO_MED_DTE=" + CO_MED_DTE + ", FAA_MED_DTE="
				+ FAA_MED_DTE + ", FAA_MED_CLS=" + FAA_MED_CLS + ", FAA_DOCR=" + FAA_DOCR + ", MED_LOCN_IND="
				+ MED_LOCN_IND + ", CRWMBR_POSN_CDE=" + CRWMBR_POSN_CDE + ", CO_MED_BASE_MO=" + CO_MED_BASE_MO
				+ ", FAA_MED_BASE_MO=" + FAA_MED_BASE_MO + ", SICK_RLSE_DTE=" + SICK_RLSE_DTE + ", UNPD_SICK_STR_DTE="
				+ UNPD_SICK_STR_DTE + ", SICK_RLSE_MNS=" + SICK_RLSE_MNS + ", UNUSED_SICK_TIME=" + UNUSED_SICK_TIME
				+ ", SICK_TIME_MINS_USED_YTD=" + SICK_TIME_MINS_USED_YTD + ", SICK_TIME_MAKE_UP=" + SICK_TIME_MAKE_UP
				+ ", SICK_TIME_MINS_USED_MTD=" + SICK_TIME_MINS_USED_MTD + ", MRG_EMP_INDR=" + MRG_EMP_INDR
				+ ", CR_PRJN=" + CR_PRJN + ", SCH_PRJN=" + SCH_PRJN + ", GRTR_TIME_MTD=" + GRTR_TIME_MTD
				+ ", SPEC_ASGNMT_CR_MNS=" + SPEC_ASGNMT_CR_MNS + ", INTL_SEQ_CR_MNS=" + INTL_SEQ_CR_MNS
				+ ", REASGN_PAY_MN=" + REASGN_PAY_MN + ", UNDR_STAF_PTRN_PAY_MN=" + UNDR_STAF_PTRN_PAY_MN
				+ ", UNDR_STAF_SRVC_PAY_MN=" + UNDR_STAF_SRVC_PAY_MN + ", NGT_PAY_MNS=" + NGT_PAY_MNS
				+ ", FA_PREM_PAY_OR_PLT_CPA_MNS=" + FA_PREM_PAY_OR_PLT_CPA_MNS + ", FORGN_LANG_PAY_LEG="
				+ FORGN_LANG_PAY_LEG + ", HOLD_TIME_PAY_MNS=" + HOLD_TIME_PAY_MNS + ", GRND_TIME_PAY_MNS="
				+ GRND_TIME_PAY_MNS + ", DOM_TAFB_XPNS=" + DOM_TAFB_XPNS + ", DOM_TAFB_TAX_XPNS=" + DOM_TAFB_TAX_XPNS
				+ ", MISC_TAX_XPNS=" + MISC_TAX_XPNS + ", MISC_XPNS=" + MISC_XPNS + ", TRIP_SEL_NBR=" + TRIP_SEL_NBR
				+ ", SEL_CRW_BASE_CDE=" + SEL_CRW_BASE_CDE + ", MO_SELN_GRP_CRWMBR_POSN_CDE="
				+ MO_SELN_GRP_CRWMBR_POSN_CDE + ", MO_SELN_GRP_DOM_INTL_CDE=" + MO_SELN_GRP_DOM_INTL_CDE
				+ ", INACTV_SEL_RSN_CDE=" + INACTV_SEL_RSN_CDE + ", PA_BID_IND=" + PA_BID_IND + ", TRIP_SEL_TYPE_CDE="
				+ TRIP_SEL_TYPE_CDE + ", HIGH_EQP_TYPE_CDE=" + HIGH_EQP_TYPE_CDE + ", CALL_OUT_STNDBY_QTY="
				+ CALL_OUT_STNDBY_QTY + ", FA_BID_OPT_CDE=" + FA_BID_OPT_CDE + ", INTL_PAY_MN=" + INTL_PAY_MN
				+ ", FIRST_INITIAL=" + FIRST_INITIAL + ", MIDDLE_INITIAL=" + MIDDLE_INITIAL + ", LAST_NAME=" + LAST_NAME
				+ ", BIRTH_DTE=" + BIRTH_DTE + ", CO_SNRTY_DTE=" + CO_SNRTY_DTE + ", OCCUP_SNRTY_DTE=" + OCCUP_SNRTY_DTE
				+ ", CLS_SNRTY_DTE=" + CLS_SNRTY_DTE + ", ORG_HIRE_DTE=" + ORG_HIRE_DTE + ", COMMUTE_FLAG="
				+ COMMUTE_FLAG + ", VAR_MAN_IND=" + VAR_MAN_IND + ", PAPER_BID_REASON=" + PAPER_BID_REASON
				+ ", NEXT_BID_DSPLCMT_PREFNC_CDE=" + NEXT_BID_DSPLCMT_PREFNC_CDE + ", XCD_MOLY_FLYG_HRS_AGRMT_INDR="
				+ XCD_MOLY_FLYG_HRS_AGRMT_INDR + ", CAPT_BID_RQMT_INDR=" + CAPT_BID_RQMT_INDR
				+ ", FIR_OFCR_BID_RQMT_INDR=" + FIR_OFCR_BID_RQMT_INDR + ", AIRCAL_FRMR_EMP_INDR="
				+ AIRCAL_FRMR_EMP_INDR + ", GUAR_MIN_MOLY_MN_QTY=" + GUAR_MIN_MOLY_MN_QTY + ", FRGN_LNG_PAY_MN_QTY="
				+ FRGN_LNG_PAY_MN_QTY + ", CRWB_SUPV_NUM=" + CRWB_SUPV_NUM + ", DRUG_TST_DTE=" + DRUG_TST_DTE
				+ ", LST_FLWN_DTE=" + LST_FLWN_DTE + ", INTL_TAFB_XPNS=" + INTL_TAFB_XPNS + ", INTL_TAFB_TAX_XPNS="
				+ INTL_TAFB_TAX_XPNS + ", TS_PAY_PROJ_MINUTES=" + TS_PAY_PROJ_MINUTES + ", BID_SEL_PROJ_MNS="
				+ BID_SEL_PROJ_MNS + ", CKA_FLAG=" + CKA_FLAG + ", CKA_TYPE=" + CKA_TYPE + ", CKA_BANK=" + CKA_BANK
				+ ", FA_ACTL_BASE_GUAR=" + FA_ACTL_BASE_GUAR + ", FA_ACTL_INC_GUAR=" + FA_ACTL_INC_GUAR
				+ ", NGT_PAY_MNS2=" + NGT_PAY_MNS2 + ", CHASE_FL_MNS=" + CHASE_FL_MNS + ", HOME_TEL_NBR=" + HOME_TEL_NBR
				+ ", BUS_TEL_NBR=" + BUS_TEL_NBR + ", TEMP_TEL_NBR=" + TEMP_TEL_NBR + ", EMP_SCNDRY_TEL_NBR="
				+ EMP_SCNDRY_TEL_NBR + ", RSTRD_SICK_TME_MNS=" + RSTRD_SICK_TME_MNS + ", ADJ_CKPT_PAY_GUAR="
				+ ADJ_CKPT_PAY_GUAR + ", CKPT_WAVED_DFP=" + CKPT_WAVED_DFP + ", ORIG_AIRL_CDE=" + ORIG_AIRL_CDE
				+ ", CURR_AIRL_CDE=" + CURR_AIRL_CDE + ", PRV_TRIP_SEL_TYPE_CDE=" + PRV_TRIP_SEL_TYPE_CDE
				+ ", PRV_BID_STS_GRP=" + PRV_BID_STS_GRP + ", PRV_BID_STS_GRP_SEQ_CRW_BASE="
				+ PRV_BID_STS_GRP_SEQ_CRW_BASE + ", PRV_BID_STS_GRP_CRWMBR_POSN_CDE=" + PRV_BID_STS_GRP_CRWMBR_POSN_CDE
				+ ", PRV_BID_STS_GRP_EQUIPMENT=" + PRV_BID_STS_GRP_EQUIPMENT + ", PRV_BID_STS_GRP_DOM_INTL_CDE="
				+ PRV_BID_STS_GRP_DOM_INTL_CDE + ", PRV_BID_STS_GRP_EFF_DTE=" + PRV_BID_STS_GRP_EFF_DTE + ", OCC2_DTE="
				+ OCC2_DTE + ", SYST_SNRTY_NO=" + SYST_SNRTY_NO + ", TFCOPY_EFF_DTE=" + TFCOPY_EFF_DTE
				+ ", TFCOPY_NEFF_DTE=" + TFCOPY_NEFF_DTE + ", PIL_MON_RSV_GRP_CUR_STAT_INDR="
				+ PIL_MON_RSV_GRP_CUR_STAT_INDR + ", PIL_MON_RSV_GRP_CUR_DALY_CRED=" + PIL_MON_RSV_GRP_CUR_DALY_CRED
				+ ", PIL_IPMAX_GRP_CUR_MNTH_IPMAX=" + PIL_IPMAX_GRP_CUR_MNTH_IPMAX + ", VAC_SNRTY_DTE=" + VAC_SNRTY_DTE
				+ ", DAILY_CREDIT_PAY_DAILY_CREDIT=" + DAILY_CREDIT_PAY_DAILY_CREDIT + ", DAILY_CREDIT_PAY_DAILY_PAY="
				+ DAILY_CREDIT_PAY_DAILY_PAY + ", FILL_S2=" + FILL_S2 + ", FILL_S3=" + FILL_S3 + ", FILL_S4=" + FILL_S4
				+ ",\n XCMDATA=" + XCMDATA + ",\n\t CRWMBR_EQP_QLFN_GRP=" + CRWMBR_EQP_QLFN_GRP + ",\n\t\t DLY_CRWMR_BID_GRP="
				+ DLY_CRWMR_BID_GRP + ",\n\t\t\t CRNT_BID_STAT_GRP=" + CRNT_BID_STAT_GRP + ",\n\t\t\t\t NEXT_BID_STAT_GRP="
				+ NEXT_BID_STAT_GRP + ",\n\t\t\t\t\t WTHD_BID_STAT_GRP=" + WTHD_BID_STAT_GRP + ",\n\t\t\t\t\t\t DEFRL_BID_STAT_GRP="
				+ DEFRL_BID_STAT_GRP + "]\n\n";
	}
	
	
	
	

	
	
//	public List<Sequences> sequences;
//	public List<RecType31> recType31s;
//	public List<RecType32> recType32s;
//	public List<RecType25> recType25List;
//	public List<RecType411> recType411s;
//	public List<RecType412> recType412s;
//	public List<RecType413> recType413s;
//	public List<RecType414> recType414s;
//	public List<RecType415> recType415s;
//	public List<RecType416> recType416s;
	
	
	
	
	
	

}
