package com.crewpay.fa.commons;

import java.io.File;

import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.lang.reflect.Field;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;
import java.util.Scanner;
import java.util.Set;
import java.util.StringTokenizer;

import org.supercsv.io.CsvBeanWriter;
import org.supercsv.io.ICsvBeanWriter;
import org.supercsv.prefs.CsvPreference;

import com.crewpay.fa.model.CITYCODE;
import com.crewpay.fa.model.CrewMembers;
import com.crewpay.fa.model.Dutyperiods;
import com.crewpay.fa.model.FlightAttendantModel;
import com.crewpay.fa.model.IPDStations;
import com.crewpay.fa.model.Legs;
import com.crewpay.fa.model.PARAMETERS;
import com.crewpay.fa.model.RAWDATA;
import com.crewpay.fa.model.ReasonGroups;
import com.crewpay.fa.model.Sequences;

public class FlightAttendantUtil {

	public static FlightAttendantModel getInputFilesFromFlatFile() {
		FlightAttendantModel FAModel=new FlightAttendantModel();
		try(FileInputStream  fis = new FileInputStream("src/com/crewpay/fa/resources/FCRM.properties");) {
			Properties MyProps = new Properties();
			MyProps.load(fis);
			Scanner scanner=new Scanner(new File("src/com/crewpay/fa/resources/FCRM_FA.txt"));
			List<Sequences> sequences=new ArrayList<>();
			List<Dutyperiods> dutyperiods=new ArrayList<>();;
			List<Legs> legs=new ArrayList<>();
			List<CrewMembers> crewMembers=new ArrayList<>();
			CrewMembers crewMember=null;
			Sequences sequence=null;
			Dutyperiods dutyperiod=null;
			Legs leg=null;
			Map<Integer, String[]> fcrmFile=CrewMapperUtil.fetchingRecordNameAndClassName();
			//Setting values for dto's from fcrm file 
			while(scanner.hasNextLine()){
				String recordTypeNoLine=scanner.nextLine();
				if(recordTypeNoLine.startsWith("199")||recordTypeNoLine.startsWith(" 9")){
					break;
				}

				Integer recordNumber=Integer.parseInt(recordTypeNoLine.substring(0, 2));
				recordTypeNoLine=recordTypeNoLine.substring(2);
				Object obj= FlightAttendantUtil.parsingFCRMDumpFileIntoDTO(recordNumber,recordTypeNoLine,fcrmFile);
				if(obj instanceof CrewMembers){
					crewMember=(CrewMembers) obj;
					crewMember.setPROCESSING_START_DATE("20160702");
					crewMember.setPROCESSING_END_DATE("20160731");
					crewMembers.add(crewMember);
				}
				else if(obj instanceof Sequences){
					sequence=(Sequences) obj;
					sequence.setSEQ_EMPNo(crewMember.getEMPNo());
					sequences.add(sequence);
				}
				else if(obj instanceof Dutyperiods){
					dutyperiod=(Dutyperiods) obj;
					dutyperiod.setDP_EMPNo(crewMember.getEMPNo());
					dutyperiod.setDP_SEQUENCE_NUMBER(sequence.getSEQUENCE_NUMBER());
					dutyperiods.add(dutyperiod);
				}
				else if(obj instanceof Legs){
					leg=(Legs) obj;
					leg.setLEG_EMPNo(crewMember.getEMPNo());
					leg.setLEG_SEQUENCE_NUMBER(sequence.getSEQUENCE_NUMBER());
					leg.setLEG_DP_NO(dutyperiod.getXDTYPER());
					legs.add(leg);
				}
				
			}
			FAModel.setFcrm_Model( FlightAttendantUtil.propsToMap(MyProps.getProperty("FCRM.Other_Props"), IPDStations.class));
			
			List<String> ipdStations=new ArrayList<>();
			for(IPDStations ipStations:FAModel.getFcrm_Model()){
				ipdStations.add(ipStations.getIPD_STATION().trim());
			}
			List<CrewMembers> crewMembersList=new ArrayList<>();
			List<Sequences> sequencesList=new ArrayList<>();
			List<Dutyperiods> dutyperiodsList=new ArrayList<>();;
			List<Legs> legsList=new ArrayList<>();
//			Setting all records in a relationship like Crewmembers-->Sequences-->Dutyperiods-->Legs 
			for (CrewMembers crewMember2 : crewMembers) {
				sequencesList = new ArrayList<>();
				for (Sequences sequences2 : sequences){
					if (crewMember2.getEMPNo().equals(sequences2.getSEQ_EMPNo())) {
						dutyperiodsList = new ArrayList<>();
						for (Dutyperiods dutyperiods1 : dutyperiods) {
							if ((crewMember2.getEMPNo().equals(dutyperiods1.getDP_EMPNo()))&& (sequences2.getSEQUENCE_NUMBER().equals(dutyperiods1.getDP_SEQUENCE_NUMBER()))) {
								legsList=new ArrayList<>();
								for(Legs legs1:legs){
									if(legs1.getLEG_DP_NO()!=null){
										if((dutyperiods1.getDP_EMPNo().equals(legs1.getLEG_EMPNo()))&& (dutyperiods1.getDP_SEQUENCE_NUMBER().equals(legs1.getLEG_SEQUENCE_NUMBER()))&&(legs1.getLEG_DP_NO().equals(dutyperiods1.getXDTYPER()))){
											if((ipdStations.contains(legs1.getARRIVAL_STATION().trim()))||(ipdStations.contains(legs1.getDEPARTURE_STATION().trim()))){
												legsList.add(legs1);
											}
										}}}	if (legsList .size()!=0) {
									dutyperiods1.setLegs(legsList);
									dutyperiodsList.add(dutyperiods1);
								}}}if (dutyperiods.size() != 0) {
							sequences2.setDutyperiods(dutyperiodsList);
							sequencesList.add(sequences2);
						}}}if (sequencesList.size()!=0 ) {
					crewMember2.setSequences(sequencesList);
					crewMembersList.add(crewMember2);
				}
			}
			
			FAModel.setCitycode(FlightAttendantUtil.propsToMap(MyProps.getProperty("FCRM.citycode"), CITYCODE.class));
			System.out.println(FAModel.getCitycode());
			FAModel.setParameters(FlightAttendantUtil.propsToMap(MyProps.getProperty("FCRM.parameters"), PARAMETERS.class));
			FAModel.setReasonGroups(FlightAttendantUtil.propsToMap(MyProps.getProperty("FCRM.reasonGroups"), ReasonGroups.class));
			FAModel.setCrewMember(crewMembersList);
	}
	catch(Exception e){
		e.printStackTrace();
	}
		return FAModel;
	}
	
	public static Object parsingFCRMDumpFileIntoDTO(Integer recordNumber,String line,Map<Integer,String[]> fcrmFile)
			throws IOException, ClassNotFoundException, InstantiationException, IllegalAccessException {
		if(recordNumber==41){
			line=line.substring(9);
			String recordSubNumber=line.substring(0, 1);
			recordNumber=Integer.parseInt(recordNumber+recordSubNumber);
		}
		List<String> activeList=CrewMapperUtil.mappingDTOsWithIndexfile(recordNumber,fcrmFile);
		Object obj=null;
		if(activeList.size()!=0){
			try(FileInputStream fis= new FileInputStream(activeList.get(0));){
				ResourceBundle resources = new PropertyResourceBundle(fis);
				String delims = ",";
				List<Integer> list = null;
				Map<String, List<Integer>> map = new HashMap<String, List<Integer>>();
				// convert ResourceBundle to Map
				Enumeration<String> keys = resources.getKeys();
				int index=0;
				while (keys.hasMoreElements()) {
					String key = (String) keys.nextElement();
					String value = resources.getString(key);
					StringTokenizer st = new StringTokenizer(value, delims);
					list = new ArrayList<>();
					while (st.hasMoreTokens()) {
						String str = st.nextToken();
						index=Integer.parseInt(str.trim());
						list.add(index);
					}
					map.put(key, list);
				}
				
				Class<?> clazz=Class.forName(activeList.get(1).trim());
				obj=clazz.newInstance();
					for(Field field : clazz.getDeclaredFields()) {
						Object field1 = field;
						// convert ResourceBundle to Map
		//						System.out.println(field.getName());
								if(map.size()!=0&&map.get(field.getName())!=null){
									if(map.get(field.getName()).size()!=0){
								   if (field.getType().getCanonicalName().contains("Date")) {
										field.set(obj, line.substring(map.get(field.getName()).get(0),map.get(field.getName()).get(1)));
									} else if (field.getType().getCanonicalName().contains("Integer")) {
										field.set(obj, Integer.parseInt(line.substring(map.get(field.getName()).get(0),map.get(field.getName()).get(1))));
									} else if (field.getType().getCanonicalName().contains("Character")) {
										field.set(obj, line.substring(map.get(field.getName()).get(0),map.get(field.getName()).get(1)).charAt(0));
									} else {
										field.set(obj, line.substring(map.get(field.getName()).get(0),map.get(field.getName()).get(1)));
									}
								}
							}
//						System.out.println(field.getName() + "<------->" + field.get(obj));
					}
				}
				catch (Exception e) {
					e.printStackTrace();
				}
		}
//			System.out.println(obj);
		return obj;

	}
	
	public static List<Object> propsToMap(String path, Class<?> clazz)
			throws IOException, ClassNotFoundException, InstantiationException, IllegalAccessException {
		List<Object> otherFiles = new ArrayList<>();
		try(FileInputStream fis=new FileInputStream(path);){
		ResourceBundle resources = new PropertyResourceBundle(fis);
		String delims = ",";
		List<String> list = null;
		Map<String, List<String>> map = new HashMap<String, List<String>>();
		// convert ResourceBundle to Map
		Enumeration<String> keys = resources.getKeys();
		while (keys.hasMoreElements()) {
			String key = (String) keys.nextElement();
			String value = resources.getString(key);
			StringTokenizer st = new StringTokenizer(value, delims);
			list = new ArrayList<>();
			while (st.hasMoreTokens()) {
				String str = st.nextToken();
				list.add(str.trim());
			}
			map.put(key, list);
			System.out.println(key+"------"+list.size());
		}
		int j=0;
		for(String key:map.keySet()){
			if(j<map.get(key).size()){
				j=map.get(key).size();
			}
		}
		int i=0;
		while (j != 0) {
			Iterator<String> keys1 = map.keySet().iterator();
			
			Object obj=null;
			try {	
				obj=clazz.newInstance();
			System.out.println(obj);
			} catch (Exception e) {
				e.printStackTrace();
			}
			System.out.println(i);
			for(Field field : clazz.getDeclaredFields()) {
				Object field1 = field;
				// convert ResourceBundle to Map
				if (!field.getName().contains("sequences") || !field.getName().contains("dutyperiods")
						|| !field.getName().contains("legs")) {
					if (keys1.hasNext()) {
						System.out.println(field.getName());
//						System.out.println(map);
						if ((map.get(field.getName()) != null) && (map.get(field.getName()).size() != 0)&&(map.get(field.getName()).size()>i)) {
							
							System.out.println(map.get(field.getName()).get(i));
							field1 = (map.get(field.getName()).get(i));
							String value = (String) field1;
							
							 if (field.getType().getCanonicalName().contains("Date")) {
								Date date = getDate(value);
								field.set(obj, date);
							} else if (field.getType().getCanonicalName().contains("Integer")) {
								field.set(obj, Integer.parseInt(value));
							} else if (field.getType().getCanonicalName().contains("Character")) {
								field.set(obj, value.charAt(0));
							} else {
								field.set(obj, value);
							}
						}
//						System.out.println(field.getName() + "<------->" + field.get(obj));
					}
				}
			}
//			System.out.println(obj);
			otherFiles.add(obj);
			i++;
			--j;
		
		}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println(otherFiles);
		return otherFiles;

	}
	public static Object writingIntoDataSets(Object dutyperiods,Object object){
		try{
			Set<String> keys=new HashSet<>();
			for(Field key:dutyperiods.getClass().getFields()){
				keys.add(key.getName());
			}
			for (Field field : object.getClass().getFields()) {
				
			 if (field.getName().equals("Intl_Override")) {
				field.set(object, 0);
				} else {
					try {
						if (keys.contains(field.getName())) {
							if (field.getType().getCanonicalName().contains("Date")) {
								field.set(object, dutyperiods.getClass().getField(field.getName()).get(dutyperiods));
							} else if (field.getType().getCanonicalName().contains("Integer")) {
								if (dutyperiods.getClass().getField(field.getName()).get(dutyperiods) == null) {
									field.set(object, 0);
								} else {
									field.set(object, dutyperiods.getClass().getField(field.getName()).get(dutyperiods));
								}
							} else if (field.getType().getCanonicalName().contains("Character")) {
								if (dutyperiods.getClass().getField(field.getName()).get(dutyperiods) == null) {
									field.set(object,dutyperiods.getClass().getField(field.getName()).get(dutyperiods));
								} else {
									field.set(object, dutyperiods.getClass().getField(field.getName()).get(dutyperiods));
								}
							} else {
								field.set(object, dutyperiods.getClass().getField(field.getName()).get(dutyperiods));
							}
						}
						
					
					} catch (SecurityException e) {
						e.printStackTrace();
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			if(field.get(object)==null){
				if (field.getType().getCanonicalName().contains("Integer")) {
					field.set(object, 0);
			}
			}
		}
	}catch(Exception e){
		e.printStackTrace();
	}
		return object;
		
	}
	public static int mod(int temp) {
		return Math.abs(temp / 60) + ((temp % 60) / 100);
	}
	
	private static Date getDate(String date) {
		
		SimpleDateFormat sdf = null;
		Date dateType = null;
		try {
			if (date != null) {
				if (date.length() == 6) {
					sdf = new SimpleDateFormat("yyyymm");
					dateType = sdf.parse(date + "00");
				} else {
					sdf = new SimpleDateFormat("yyyymmdd");
					dateType = sdf.parse(date);
				}
			}
			String val=sdf.format(dateType);
			System.out.println(val);
		} catch (ParseException e) {
			e.printStackTrace();
		}

		return dateType;
	}

	public static void reportGenerate1(List<RAWDATA> objectList,String fileName) {
		
		if(objectList!=null&&objectList.size()!=0){
			
			Set<RAWDATA> dummySet=new HashSet<RAWDATA>(objectList);
			System.out.println(dummySet.size());
			objectList=new ArrayList<>(dummySet);
			Collections.sort(objectList, Comparator.comparing(RAWDATA::getEMPNo)
													.thenComparing(RAWDATA::getSEQUENCE_NUMBER)
													.thenComparing(RAWDATA::getXDTYPER)
													.thenComparing(RAWDATA::getLEG));
			
			try(ICsvBeanWriter writer=new CsvBeanWriter(new FileWriter(fileName), CsvPreference.STANDARD_PREFERENCE);){
				String headers[]=new String[200];
				int flag=0;
				for(Field field:objectList.get(0).getClass().getFields()){
					headers[flag]=field.getName();
					flag++;
				}
				writer.writeHeader(headers);
					for (Object object :objectList ) {
						writer.write(object, headers);
					}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
	
		}
	}
	public static void reportGenerate(List<?> objectList,String fileName) throws IOException {
	     File f = new File(fileName);
		        Writer oos = new FileWriter(f);
		        for(Object obj:objectList)
		        oos.write(obj.toString());
		        oos.flush();
		        oos.close(); 

	}

	
//
//	if((auxialiaryData.getUS_INDICATOR().equals("NO"))&&((auxialiaryData.getLOCATION().equals("CA"))||(auxialiaryData.getLOCATION().equals("CA")))||((auxialiaryData.getUS_INDICATOR().equals("NC"))&&(auxialiaryData.getSTATE().equals("HI")))){
//		cities=new CITIES();
//		cities.setSTATION(auxialiaryData.getSTATION());
//		cities.setEXCEPTION_INDICATOR(auxialiaryData.getEXCEPTION_INDICATOR());
//		cities.setLOCATION(auxialiaryData.getLOCATION());
//		cities.setNAME(auxialiaryData.getNAME());
//		cities.setSTATE(auxialiaryData.getSTATE());
//		cities.setUS_INDICATOR(auxialiaryData.getUS_INDICATOR());
//		citiesList.add(cities);
//	}
	
	
//	  
}
