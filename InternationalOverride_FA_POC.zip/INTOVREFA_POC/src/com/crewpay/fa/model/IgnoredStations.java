package com.crewpay.fa.model;

import java.util.Date;

public class IgnoredStations {

	public Integer EMPNo;
	public Date SCH_START_DATE;
	public Integer SEQUENCE_NUMBER;
	public String ARRIVAL_STATION;
	public String DEPARTURE_STATION;
	
	public Integer getEMPNo() {
		return EMPNo;
	}
	public void setEMPNo(Integer EMPNo) {
		this.EMPNo = EMPNo;
	}
	public Date getSCH_START_DATE() {
		return SCH_START_DATE;
	}
	public void setSCH_START_DATE(Date SCH_START_DATE) {
		this.SCH_START_DATE = SCH_START_DATE;
	}
	public Integer getSEQUENCE_NUMBER() {
		return SEQUENCE_NUMBER;
	}
	public void setSEQUENCE_NUMBER(Integer sEQUENCE_NUMBER) {
		SEQUENCE_NUMBER = sEQUENCE_NUMBER;
	}
	public String getARRIVAL_STATION() {
		return ARRIVAL_STATION;
	}
	public void setARRIVAL_STATION(String aRRIVAL_STATION) {
		ARRIVAL_STATION = aRRIVAL_STATION;
	}
	public String getDEPARTURE_STATION() {
		return DEPARTURE_STATION;
	}
	public void setDEPARTURE_STATION(String dEPARTURE_STATION) {
		DEPARTURE_STATION = dEPARTURE_STATION;
	}
	@Override
	public String toString() {
		return "IgnoredStations [EMPNo=" + EMPNo + ", SCH_START_DATE=" + SCH_START_DATE + ", SEQUENCE_NUMBER="
				+ SEQUENCE_NUMBER + ", ARRIVAL_STATION=" + ARRIVAL_STATION + ", DEPARTURE_STATION=" + DEPARTURE_STATION
				+ "]";
	}
	
	
	
}
