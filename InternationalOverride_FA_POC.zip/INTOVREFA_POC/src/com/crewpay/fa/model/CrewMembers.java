package com.crewpay.fa.model;

import java.util.Date;
import java.util.List;

public class CrewMembers {

	public String DATE;
	public Integer CREW_TYPE;
	public Integer EMPNo;
	public String DOM_INTL_CODE;
	public Character INACTIVE;
	public String TRIP_TYPE;
	public String EMPLOYEE_NAME;
	public String SAM_INDICATOR;
	
	public String PROCESSING_START_DATE;
	public String PROCESSING_END_DATE;
	public List<Sequences> sequences;
	
	
	public String getPROCESSING_START_DATE() {
		return PROCESSING_START_DATE;
	}

	public void setPROCESSING_START_DATE(String pROCESSING_START_DATE) {
		PROCESSING_START_DATE = pROCESSING_START_DATE;
	}

	public String getPROCESSING_END_DATE() {
		return PROCESSING_END_DATE;
	}

	public void setPROCESSING_END_DATE(String pROCESSING_END_DATE) {
		PROCESSING_END_DATE = pROCESSING_END_DATE;
	}

	public CrewMembers() {
		
	}
	
	public List<Sequences> getSequences() {
		return sequences;
	}
	public void setSequences(List<Sequences> sequences) {
		this.sequences = sequences;
	}
	public String getDATE() {
		return DATE;
	}
	public void setDATE(String dATE) {
		DATE = dATE;
	}
	public Integer getCREW_TYPE() {
		return CREW_TYPE;
	}
	public void setCREW_TYPE(Integer cREW_TYPE) {
		CREW_TYPE = cREW_TYPE;
	}
	public Integer getEMPNo() {
		return EMPNo;
	}
	public void setEMPNo(Integer eMPNo) {
		EMPNo = eMPNo;
	}
	public String getDOM_INTL_CODE() {
		return DOM_INTL_CODE;
	}
	public void setDOM_INTL_CODE(String dOM_INTL_CODE) {
		DOM_INTL_CODE = dOM_INTL_CODE;
	}
	public Character getINACTIVE() {
		return INACTIVE;
	}
	public void setINACTIVE(Character iNACTIVE) {
		INACTIVE = iNACTIVE;
	}
	public String getTRIP_TYPE() {
		return TRIP_TYPE;
	}
	public void setTRIP_TYPE(String tRIP_TYPE) {
		TRIP_TYPE = tRIP_TYPE;
	}
	public String getEMPLOYEE_NAME() {
		return EMPLOYEE_NAME;
	}
	public void setEMPLOYEE_NAME(String eMPLOYEE_NAME) {
		EMPLOYEE_NAME = eMPLOYEE_NAME;
	}
	public String getSAM_INDICATOR() {
		return SAM_INDICATOR;
	}
	public void setSAM_INDICATOR(String sAM_INDICATOR) {
		SAM_INDICATOR = sAM_INDICATOR;
	}
	@Override
	public String toString() {
		return "CrewMember [DATE=" + DATE + ", CREW_TYPE=" + CREW_TYPE + ", EMPNo=" + EMPNo + ", DOM_INTL_CODE="
				+ DOM_INTL_CODE + ", INACTIVE=" + INACTIVE + ", TRIP_TYPE=" + TRIP_TYPE + ", EMPLOYEE_NAME="
				+ EMPLOYEE_NAME + ", SAM_INDICATOR=" + SAM_INDICATOR + "\n, sequences=" + sequences+ "]\n";
	}
	
	
	
	
	

}
