package com.crewpay.fa.model;

public class ALLLEGS {

	
	private Integer EMP_NO;
	private Integer SEQ_NO;
	private Integer DP_NO;
	private Integer LEG_NO;
	private Integer SEQ_RMVL_CODE;
	private Integer LEG_RMVL_CODE;
	private Integer last_Leg_Ok;
	
	
	public Integer getLast_Leg_Ok() {
		return last_Leg_Ok;
	}
	public void setLast_Leg_Ok(Integer last_Leg_Ok) {
		this.last_Leg_Ok = last_Leg_Ok;
	}
	public Integer getEMP_NO() {
		return EMP_NO;
	}
	public void setEMP_NO(Integer eMP_NO) {
		EMP_NO = eMP_NO;
	}
	public Integer getSEQ_NO() {
		return SEQ_NO;
	}
	public void setSEQ_NO(Integer sEQ_NO) {
		SEQ_NO = sEQ_NO;
	}
	public Integer getDP_NO() {
		return DP_NO;
	}
	public void setDP_NO(Integer dP_NO) {
		DP_NO = dP_NO;
	}
	public Integer getLEG_NO() {
		return LEG_NO;
	}
	public void setLEG_NO(Integer lEG_NO) {
		LEG_NO = lEG_NO;
	}
	public Integer getSEQ_RMVL_CODE() {
		return SEQ_RMVL_CODE;
	}
	public void setSEQ_RMVL_CODE(Integer sEQ_RMVL_CODE) {
		SEQ_RMVL_CODE = sEQ_RMVL_CODE;
	}
	public Integer getLEG_RMVL_CODE() {
		return LEG_RMVL_CODE;
	}
	public void setLEG_RMVL_CODE(Integer lEG_RMVL_CODE) {
		LEG_RMVL_CODE = lEG_RMVL_CODE;
	}
	@Override
	public String toString() {
		return "ALLLEGS [EMP_NO=" + EMP_NO + ", SEQ_NO=" + SEQ_NO + ", DP_NO=" + DP_NO + ", LEG_NO=" + LEG_NO
				+ ", SEQ_RMVL_CODE=" + SEQ_RMVL_CODE + ", LEG_RMVL_CODE=" + LEG_RMVL_CODE + "]\n";
	}
	
	
	
}
