package com.crewpay.fa.model;



public class RAWDATA {

	public Integer EMPNo;
	public String EMPLOYEE_NAME;
	public String DATE;
	public Integer CREW_TYPE;
	public String DOM_INTL_CODE;
	public Character INACTIVE;
	public String TRIP_TYPE;
	public String SAM_INDICATOR;
	public String SCHEDULED_START_DATE;
	public Integer SEQ_EMPNo;
	public Integer SEQUENCE_NUMBER;
	public Integer SEQ_REASON_CODE;
	public Integer SEQ_REMOVAL_CODE;
	public Integer SEQ_LEVEL_NUMBER;
	public String SEQ_DOM_INTL_CODE;
	public Integer ACTL_SEQ_CR_MNS;
	public Integer ACTL_DUTY_PER_CR_MNS;
	public String SEQ_CNTRTL_PATH_INDR;
	
	public Integer XDTYPER;
	public Integer DP_NO;
	public String DP_ACTUAL_END_DATE;
	public String DP_SCHEDULED_START_DATE;
	public String DP_ACTUAL_START_DATE;
	public Integer DP_SCHEDULED_START_TIME;
	public String DP_SCHEDULED_END_DATE;
	public Integer DP_SEQUENCE_NUMBER;
	public Integer DP_ACTUAL_START_TIME;
	public Integer DP_SCHEDULED_END_TIME ; 
	public Integer DP_ACTUAL_END_TIME;  
	public Integer DP_STR_GMT_ADJMT_MNS;
	public Integer DP_END_GMT_ADJMT_MNS;
	public Integer DP_LEG_GRTR_MNS;
	public Integer DP_ACTL_DUTY_PER_CR_MNS;
	public Integer DP_DHD_MIN;	
	public Integer DHD_MIN;
	public String OTH_DOM_INTL_CODE;
	public Character OTH_INACTIVE;
	public String OTH_TRIP_TYPE;

	public Integer OTH_LEG_GRTR_MNS;
	public Integer OTH_ACTL_DUTY_PER_CR_MNS;
	public Integer OTH_ACTL_SEQ_CR_MNS;
	public Integer OTH_DHD_MIN;

	public Integer OTM_LEG_GRTR_MNS;
	public Integer OTM_ACTL_DUTY_PER_CR_MNS;
	public Integer OTM_DHD_MIN;

	public Integer LEG;
	public Integer LEG_DP_NO;
	public Integer LEG_EMPNo;
	public Integer LEG_SEQUENCE_NUMBER;
	public String LEG_SCHEDULED_START_DATE;
	public String LEG_ACTUAL_START_DATE;
	public Integer LEG_SCHEDULED_START_TIME;
	public Integer RSCHEDULED_START_TIME;
	public Integer LEG_ACTUAL_START_TIME;
	public Integer LEG_SCHEDULED_END_TIME;
	public Integer LEG_ACTUAL_END_TIME;
	public Integer FLIGHT_NUMBER;
	public String DEPARTURE_STATION;
	public Integer STR_GMT_ADJMT_MNS;
	public String ARRIVAL_STATION;
	public String SCHEDULED_EQUIPMENT_CODE;
	public String ACTUAL_EQUIP_CODE;
	public Integer ATC_MINS;
	public Integer CANCELLED_LEG_INDICATOR;
	public String FLT_LEG_STUB_INDR;
	public Integer IRREGULAR_LEG_INDICATOR;
	public String DEADHEAD_INDICATOR;
	public String RMVD_CRD_ACTY_INDR;
	public Integer LEG_CREWMEMBER_POSITION;
	public Integer LEG_ADD_CODE;
	public Integer LEG_REMOVAL_CODE;
	public Integer DEI_MINS;
	public Integer RCD_MINS;
	public Integer DVR_MINS;
	public Integer REASON_PAY_INDICATOR;
	public Integer Intl_Override;
	public Integer SEQ_CREWMEMBER_POSITION;
	public Integer ASSIGNMENT_REASON_CODE;

	public Integer LCL_SDEP;
	public Integer LCL_ADEP;
	public Integer SCH_BLK;
	public Integer ACT_BLK;
	public Integer ACT_BLK_MIN;
	public Integer TTL_ACT;
	public Integer GTR_BLK;
	public Integer GTR_BLK_MIN;
	public Integer SCH_BLK_MIN;
	public Integer LEG_EX_DH;
	public Integer DepMatch;

	public Integer totalIntlCount;
	public Integer totalFlights;
	public Integer DH_BLOCK;
	public Integer DH_SCHED;
	public Integer Match_OthRec;
	public Integer specialFlag;
	private Integer last_Leg_Ok;

	public Integer DP_A_ETIME_OK; 
	public Integer CO_DP_A_ETIME_OK;

	public Integer SDP_A_ETIME;
	public Integer SDP_A_ETIME_OK;
	public Integer SEQ_LAST_LEG_OK;
	public Integer CO_SDP_A_ETIME_OK;
	public Integer USED_FCRM_ETIME; 
	public String PROCESSING_START_DATE;
	public String PROCESSING_END_DATE;
	public Integer INT_DH_MIN;    
	public Integer DOM_DH_MIN ;
	public Integer EXTRA_INT_DH;  
	public Integer EXTRA_DOM_DH;
	public Integer CO_INT_DH_MIN ; 
	public Integer CO_EXTRA_INT_DH ;  
	public Integer SPLIT_TERM_MON_PD_CRD_DH ;   
	public Integer DH_AFT_12MID ;
	public Integer TTL_DH;   
	public Integer EXTRA_DH;  
	public Integer CO_INT_DH_MIN_DH_AFT_12MID;                        
	
	
	
	
	public Integer getASSIGNMENT_REASON_CODE() {
		return ASSIGNMENT_REASON_CODE;
	}

	public void setASSIGNMENT_REASON_CODE(Integer aSSIGNMENT_REASON_CODE) {
		ASSIGNMENT_REASON_CODE = aSSIGNMENT_REASON_CODE;
	}

	public String getSEQ_CNTRTL_PATH_INDR() {
		return SEQ_CNTRTL_PATH_INDR;
	}

	public void setSEQ_CNTRTL_PATH_INDR(String sEQ_CNTRTL_PATH_INDR) {
		SEQ_CNTRTL_PATH_INDR = sEQ_CNTRTL_PATH_INDR;
	}

	public Integer getDP_A_ETIME_OK() {
		return DP_A_ETIME_OK;
	}

	public void setDP_A_ETIME_OK(Integer dP_A_ETIME_OK) {
		DP_A_ETIME_OK = dP_A_ETIME_OK;
	}

	public Integer getCO_DP_A_ETIME_OK() {
		return CO_DP_A_ETIME_OK;
	}

	public void setCO_DP_A_ETIME_OK(Integer cO_DP_A_ETIME_OK) {
		CO_DP_A_ETIME_OK = cO_DP_A_ETIME_OK;
	}

	public Integer getTTL_DH() {
		return TTL_DH;
	}

	public void setTTL_DH(Integer tTL_DH) {
		TTL_DH = tTL_DH;
	}

	public Integer getEXTRA_DH() {
		return EXTRA_DH;
	}

	public void setEXTRA_DH(Integer eXTRA_DH) {
		EXTRA_DH = eXTRA_DH;
	}

	public Integer getCO_INT_DH_MIN_DH_AFT_12MID() {
		return CO_INT_DH_MIN_DH_AFT_12MID;
	}

	public void setCO_INT_DH_MIN_DH_AFT_12MID(Integer cO_INT_DH_MIN_DH_AFT_12MID) {
		CO_INT_DH_MIN_DH_AFT_12MID = cO_INT_DH_MIN_DH_AFT_12MID;
	}

	public Integer getDP_DHD_MIN() {
		return DP_DHD_MIN;
	}

	public void setDP_DHD_MIN(Integer dP_DHD_MIN) {
		DP_DHD_MIN = dP_DHD_MIN;
	}

	public Integer getDHD_MIN() {
		return DHD_MIN;
	}

	public Integer getACTL_DUTY_PER_CR_MNS() {
		return ACTL_DUTY_PER_CR_MNS;
	}

	public void setACTL_DUTY_PER_CR_MNS(Integer aCTL_DUTY_PER_CR_MNS) {
		ACTL_DUTY_PER_CR_MNS = aCTL_DUTY_PER_CR_MNS;
	}

	public void setDHD_MIN(Integer dHD_MIN) {
		DHD_MIN = dHD_MIN;
	}

	public Integer getINT_DH_MIN() {
		return INT_DH_MIN;
	}

	public void setINT_DH_MIN(Integer iNT_DH_MIN) {
		INT_DH_MIN = iNT_DH_MIN;
	}

	public Integer getDOM_DH_MIN() {
		return DOM_DH_MIN;
	}

	public void setDOM_DH_MIN(Integer dOM_DH_MIN) {
		DOM_DH_MIN = dOM_DH_MIN;
	}

	public Integer getEXTRA_INT_DH() {
		return EXTRA_INT_DH;
	}

	public void setEXTRA_INT_DH(Integer eXTRA_INT_DH) {
		EXTRA_INT_DH = eXTRA_INT_DH;
	}

	public Integer getEXTRA_DOM_DH() {
		return EXTRA_DOM_DH;
	}

	public void setEXTRA_DOM_DH(Integer eXTRA_DOM_DH) {
		EXTRA_DOM_DH = eXTRA_DOM_DH;
	}

	public Integer getCO_INT_DH_MIN() {
		return CO_INT_DH_MIN;
	}

	public void setCO_INT_DH_MIN(Integer cO_INT_DH_MIN) {
		CO_INT_DH_MIN = cO_INT_DH_MIN;
	}

	public Integer getCO_EXTRA_INT_DH() {
		return CO_EXTRA_INT_DH;
	}

	public void setCO_EXTRA_INT_DH(Integer cO_EXTRA_INT_DH) {
		CO_EXTRA_INT_DH = cO_EXTRA_INT_DH;
	}

	public Integer getSPLIT_TERM_MON_PD_CRD_DH() {
		return SPLIT_TERM_MON_PD_CRD_DH;
	}

	public void setSPLIT_TERM_MON_PD_CRD_DH(Integer sPLIT_TERM_MON_PD_CRD_DH) {
		SPLIT_TERM_MON_PD_CRD_DH = sPLIT_TERM_MON_PD_CRD_DH;
	}

	public Integer getDH_AFT_12MID() {
		return DH_AFT_12MID;
	}

	public void setDH_AFT_12MID(Integer dH_AFT_12MID) {
		DH_AFT_12MID = dH_AFT_12MID;
	}

	public String getPROCESSING_START_DATE() {
		return PROCESSING_START_DATE;
	}

	public void setPROCESSING_START_DATE(String pROCESSING_START_DATE) {
		PROCESSING_START_DATE = pROCESSING_START_DATE;
	}

	public String getPROCESSING_END_DATE() {
		return PROCESSING_END_DATE;
	}

	public void setPROCESSING_END_DATE(String pROCESSING_END_DATE) {
		PROCESSING_END_DATE = pROCESSING_END_DATE;
	}

	public Integer getSDP_A_ETIME() {
		return SDP_A_ETIME;
	}

	public void setSDP_A_ETIME(Integer sDP_A_ETIME) {
		SDP_A_ETIME = sDP_A_ETIME;
	}

	public Integer getSDP_A_ETIME_OK() {
		return SDP_A_ETIME_OK;
	}

	public void setSDP_A_ETIME_OK(Integer sDP_A_ETIME_OK) {
		SDP_A_ETIME_OK = sDP_A_ETIME_OK;
	}

	public Integer getSEQ_LAST_LEG_OK() {
		return SEQ_LAST_LEG_OK;
	}

	public void setSEQ_LAST_LEG_OK(Integer sEQ_LAST_LEG_OK) {
		SEQ_LAST_LEG_OK = sEQ_LAST_LEG_OK;
	}

	public Integer getCO_SDP_A_ETIME_OK() {
		return CO_SDP_A_ETIME_OK;
	}

	public void setCO_SDP_A_ETIME_OK(Integer cO_SDP_A_ETIME_OK) {
		CO_SDP_A_ETIME_OK = cO_SDP_A_ETIME_OK;
	}

	public Integer getUSED_FCRM_ETIME() {
		return USED_FCRM_ETIME;
	}

	public void setUSED_FCRM_ETIME(Integer uSED_FCRM_ETIME) {
		USED_FCRM_ETIME = uSED_FCRM_ETIME;
	}

	public Integer getACTL_SEQ_CR_MNS() {
		return ACTL_SEQ_CR_MNS;
	}

	public void setACTL_SEQ_CR_MNS(Integer aCTL_SEQ_CR_MNS) {
		ACTL_SEQ_CR_MNS = aCTL_SEQ_CR_MNS;
	}

	public String getOTH_DOM_INTL_CODE() {
		return OTH_DOM_INTL_CODE;
	}

	public void setOTH_DOM_INTL_CODE(String oTH_DOM_INTL_CODE) {
		OTH_DOM_INTL_CODE = oTH_DOM_INTL_CODE;
	}

	public Character getOTH_INACTIVE() {
		return OTH_INACTIVE;
	}

	public void setOTH_INACTIVE(Character oTH_INACTIVE) {
		OTH_INACTIVE = oTH_INACTIVE;
	}

	public String getOTH_TRIP_TYPE() {
		return OTH_TRIP_TYPE;
	}

	public void setOTH_TRIP_TYPE(String oTH_TRIP_TYPE) {
		OTH_TRIP_TYPE = oTH_TRIP_TYPE;
	}

	public Integer getOTH_LEG_GRTR_MNS() {
		return OTH_LEG_GRTR_MNS;
	}

	public void setOTH_LEG_GRTR_MNS(Integer oTH_LEG_GRTR_MNS) {
		OTH_LEG_GRTR_MNS = oTH_LEG_GRTR_MNS;
	}

	public Integer getOTH_ACTL_DUTY_PER_CR_MNS() {
		return OTH_ACTL_DUTY_PER_CR_MNS;
	}

	public void setOTH_ACTL_DUTY_PER_CR_MNS(Integer oTH_ACTL_DUTY_PER_CR_MNS) {
		OTH_ACTL_DUTY_PER_CR_MNS = oTH_ACTL_DUTY_PER_CR_MNS;
	}

	public Integer getOTH_ACTL_SEQ_CR_MNS() {
		return OTH_ACTL_SEQ_CR_MNS;
	}

	public void setOTH_ACTL_SEQ_CR_MNS(Integer oTH_ACTL_SEQ_CR_MNS) {
		OTH_ACTL_SEQ_CR_MNS = oTH_ACTL_SEQ_CR_MNS;
	}

	public Integer getOTH_DHD_MIN() {
		return OTH_DHD_MIN;
	}

	public void setOTH_DHD_MIN(Integer oTH_DHD_MIN) {
		OTH_DHD_MIN = oTH_DHD_MIN;
	}

	public Integer getOTM_LEG_GRTR_MNS() {
		return OTM_LEG_GRTR_MNS;
	}

	public void setOTM_LEG_GRTR_MNS(Integer oTM_LEG_GRTR_MNS) {
		OTM_LEG_GRTR_MNS = oTM_LEG_GRTR_MNS;
	}

	public Integer getOTM_ACTL_DUTY_PER_CR_MNS() {
		return OTM_ACTL_DUTY_PER_CR_MNS;
	}

	public void setOTM_ACTL_DUTY_PER_CR_MNS(Integer oTM_ACTL_DUTY_PER_CR_MNS) {
		OTM_ACTL_DUTY_PER_CR_MNS = oTM_ACTL_DUTY_PER_CR_MNS;
	}

	public Integer getOTM_DHD_MIN() {
		return OTM_DHD_MIN;
	}

	public void setOTM_DHD_MIN(Integer oTM_DHD_MIN) {
		OTM_DHD_MIN = oTM_DHD_MIN;
	}

	public Integer getMatch_OthRec() {
		return Match_OthRec;
	}

	public void setMatch_OthRec(Integer match_OthRec) {
		Match_OthRec = match_OthRec;
	}

	public Integer getLast_Leg_Ok() {
		return last_Leg_Ok;
	}

	public void setLast_Leg_Ok(Integer last_Leg_Ok) {
		this.last_Leg_Ok = last_Leg_Ok;
	}

	public Integer getDP_NO() {
		return DP_NO;
	}

	public void setDP_NO(Integer dP_NO) {
		DP_NO = dP_NO;
	}

	public Integer getLEG_EX_DH() {
		return LEG_EX_DH;
	}

	public void setLEG_EX_DH(Integer lEG_EX_DH) {
		LEG_EX_DH = lEG_EX_DH;
	}

	public Integer getREASON_PAY_INDICATOR() {
		return REASON_PAY_INDICATOR;
	}

	public void setREASON_PAY_INDICATOR(Integer rEASON_PAY_INDICATOR) {
		REASON_PAY_INDICATOR = rEASON_PAY_INDICATOR;
	}

	public Integer getSpecialFlag() {
		return specialFlag;
	}

	public void setSpecialFlag(Integer specialFlag) {
		this.specialFlag = specialFlag;
	}

	public Integer getDH_BLOCK() {
		return DH_BLOCK;
	}

	public void setDH_BLOCK(Integer dH_BLOCK) {
		DH_BLOCK = dH_BLOCK;
	}

	public Integer getDH_SCHED() {
		return DH_SCHED;
	}

	public void setDH_SCHED(Integer dH_SCHED) {
		DH_SCHED = dH_SCHED;
	}

	

	public Integer getTotalIntlCount() {
		return totalIntlCount;
	}

	public void setTotalIntlCount(Integer totalIntlCount) {
		this.totalIntlCount = totalIntlCount;
	}

	public Integer getTotalFlights() {
		return totalFlights;
	}

	public void setTotalFlights(Integer totalFlights) {
		this.totalFlights = totalFlights;
	}

	public String getSEQ_DOM_INTL_CODE() {
		return SEQ_DOM_INTL_CODE;
	}

	public void setSEQ_DOM_INTL_CODE(String sEQ_DOM_INTL_CODE) {
		SEQ_DOM_INTL_CODE = sEQ_DOM_INTL_CODE;
	}

	public Integer getSEQ_EMPNo() {
		return SEQ_EMPNo;
	}

	public void setSEQ_EMPNo(Integer sEQ_EMPNo) {
		SEQ_EMPNo = sEQ_EMPNo;
	}

	public Integer getLEG_DP_NO() {
		return LEG_DP_NO;
	}

	public void setLEG_DP_NO(Integer lEG_DP_NO) {
		LEG_DP_NO = lEG_DP_NO;
	}

	public Integer getLEG_EMPNo() {
		return LEG_EMPNo;
	}

	public void setLEG_EMPNo(Integer lEG_EMPNo) {
		LEG_EMPNo = lEG_EMPNo;
	}

	public Integer getLEG_SEQUENCE_NUMBER() {
		return LEG_SEQUENCE_NUMBER;
	}

	public void setLEG_SEQUENCE_NUMBER(Integer lEG_SEQUENCE_NUMBER) {
		LEG_SEQUENCE_NUMBER = lEG_SEQUENCE_NUMBER;
	}

	public Integer getXDTYPER() {
		return XDTYPER;
	}

	public void setXDTYPER(Integer xDTYPER) {
		XDTYPER = xDTYPER;
	}

	public Integer getLEG() {
		return LEG;
	}

	public void setLEG(Integer lEG) {
		LEG = lEG;
	}

	public Integer getDepMatch() {
		return DepMatch;
	}

	public void setDepMatch(Integer depMatch) {
		DepMatch = depMatch;
	}

	public Integer getACT_BLK() {
		return ACT_BLK;
	}

	public void setACT_BLK(Integer aCT_BLK) {
		ACT_BLK = aCT_BLK;
	}

	public Integer getLCL_SDEP() {
		return LCL_SDEP;
	}

	public void setLCL_SDEP(Integer lCL_SDEP) {
		LCL_SDEP = lCL_SDEP;
	}

	public Integer getLCL_ADEP() {
		return LCL_ADEP;
	}

	public void setLCL_ADEP(Integer lCL_ADEP) {
		LCL_ADEP = lCL_ADEP;
	}

	public Integer getSCH_BLK() {
		return SCH_BLK;
	}

	public void setSCH_BLK(Integer sCH_BLK) {
		SCH_BLK = sCH_BLK;
	}

	public Integer getACT_BLK_MIN() {
		return ACT_BLK_MIN;
	}

	public void setACT_BLK_MIN(Integer aCT_BLK_MIN) {
		ACT_BLK_MIN = aCT_BLK_MIN;
	}

	public Integer getTTL_ACT() {
		return TTL_ACT;
	}

	public void setTTL_ACT(Integer tTL_ACT) {
		TTL_ACT = tTL_ACT;
	}

	public Integer getGTR_BLK() {
		return GTR_BLK;
	}

	public void setGTR_BLK(Integer gTR_BLK) {
		GTR_BLK = gTR_BLK;
	}

	public Integer getGTR_BLK_MIN() {
		return GTR_BLK_MIN;
	}

	public void setGTR_BLK_MIN(Integer gTR_BLK_MIN) {
		GTR_BLK_MIN = gTR_BLK_MIN;
	}

	public Integer getSCH_BLK_MIN() {
		return SCH_BLK_MIN;
	}

	public void setSCH_BLK_MIN(Integer sCH_BLK_MIN) {
		SCH_BLK_MIN = sCH_BLK_MIN;
	}

	public Integer getDVR_MINS() {
		return DVR_MINS;
	}

	public void setDVR_MINS(Integer dVR_MINS) {
		DVR_MINS = dVR_MINS;
	}

	public String getDP_ACTUAL_END_DATE() {
		return DP_ACTUAL_END_DATE;
	}

	public void setDP_ACTUAL_END_DATE(String dP_ACTUAL_END_DATE) {
		DP_ACTUAL_END_DATE = dP_ACTUAL_END_DATE;
	}

	public Integer getSEQ_CREWMEMBER_POSITION() {
		return SEQ_CREWMEMBER_POSITION;
	}

	public void setSEQ_CREWMEMBER_POSITION(Integer sEQ_CREWMEMBER_POSITION) {
		SEQ_CREWMEMBER_POSITION = sEQ_CREWMEMBER_POSITION;
	}

	public Integer getIntl_Override() {
		return Intl_Override;
	}

	public void setIntl_Override(Integer intl_Override) {
		Intl_Override = intl_Override;
	}

	public String getDATE() {
		return DATE;
	}

	public void setDATE(String dATE) {
		DATE = dATE;
	}

	public Integer getCREW_TYPE() {
		return CREW_TYPE;
	}

	public void setCREW_TYPE(Integer cREW_TYPE) {
		CREW_TYPE = cREW_TYPE;
	}

	public Integer getEMPNo() {
		return EMPNo;
	}

	public void setEMPNo(Integer eMPNo) {
		EMPNo = eMPNo;
	}

	public String getDOM_INTL_CODE() {
		return DOM_INTL_CODE;
	}

	public void setDOM_INTL_CODE(String dOM_INTL_CODE) {
		DOM_INTL_CODE = dOM_INTL_CODE;
	}

	public Character getINACTIVE() {
		return INACTIVE;
	}

	public void setINACTIVE(Character iNACTIVE) {
		INACTIVE = iNACTIVE;
	}

	public String getTRIP_TYPE() {
		return TRIP_TYPE;
	}

	public void setTRIP_TYPE(String tRIP_TYPE) {
		TRIP_TYPE = tRIP_TYPE;
	}

	public String getEMPLOYEE_NAME() {
		return EMPLOYEE_NAME;
	}

	public void setEMPLOYEE_NAME(String eMPLOYEE_NAME) {
		EMPLOYEE_NAME = eMPLOYEE_NAME;
	}

	public String getSAM_INDICATOR() {
		return SAM_INDICATOR;
	}

	public void setSAM_INDICATOR(String sAM_INDICATOR) {
		SAM_INDICATOR = sAM_INDICATOR;
	}

	public String getSCHEDULED_START_DATE() {
		return SCHEDULED_START_DATE;
	}

	public void setSCHEDULED_START_DATE(String sCHEDULED_START_DATE) {
		SCHEDULED_START_DATE = sCHEDULED_START_DATE;
	}

	public Integer getSEQUENCE_NUMBER() {
		return SEQUENCE_NUMBER;
	}

	public void setSEQUENCE_NUMBER(Integer sEQUENCE_NUMBER) {
		SEQUENCE_NUMBER = sEQUENCE_NUMBER;
	}

	public Integer getSEQ_REASON_CODE() {
		return SEQ_REASON_CODE;
	}

	public void setSEQ_REASON_CODE(Integer sEQ_REASON_CODE) {
		SEQ_REASON_CODE = sEQ_REASON_CODE;
	}

	public Integer getSEQ_REMOVAL_CODE() {
		return SEQ_REMOVAL_CODE;
	}

	public void setSEQ_REMOVAL_CODE(Integer sEQ_REMOVAL_CODE) {
		SEQ_REMOVAL_CODE = sEQ_REMOVAL_CODE;
	}

	public Integer getSEQ_LEVEL_NUMBER() {
		return SEQ_LEVEL_NUMBER;
	}

	public void setSEQ_LEVEL_NUMBER(Integer sEQ_LEVEL_NUMBER) {
		SEQ_LEVEL_NUMBER = sEQ_LEVEL_NUMBER;
	}

	
	public Integer getDP_SEQUENCE_NUMBER() {
		return DP_SEQUENCE_NUMBER;
	}

	public void setDP_SEQUENCE_NUMBER(Integer dP_SEQUENCE_NUMBER) {
		DP_SEQUENCE_NUMBER = dP_SEQUENCE_NUMBER;
	}

	public Integer getDP_ACTUAL_START_TIME() {
		return DP_ACTUAL_START_TIME;
	}

	public void setDP_ACTUAL_START_TIME(Integer dP_ACTUAL_START_TIME) {
		DP_ACTUAL_START_TIME = dP_ACTUAL_START_TIME;
	}

	public Integer getDP_SCHEDULED_END_TIME() {
		return DP_SCHEDULED_END_TIME;
	}

	public void setDP_SCHEDULED_END_TIME(Integer dP_SCHEDULED_END_TIME) {
		DP_SCHEDULED_END_TIME = dP_SCHEDULED_END_TIME;
	}

	public Integer getDP_ACTUAL_END_TIME() {
		return DP_ACTUAL_END_TIME;
	}

	public void setDP_ACTUAL_END_TIME(Integer dP_ACTUAL_END_TIME) {
		DP_ACTUAL_END_TIME = dP_ACTUAL_END_TIME;
	}

	public Integer getDP_STR_GMT_ADJMT_MNS() {
		return DP_STR_GMT_ADJMT_MNS;
	}

	public void setDP_STR_GMT_ADJMT_MNS(Integer dP_STR_GMT_ADJMT_MNS) {
		DP_STR_GMT_ADJMT_MNS = dP_STR_GMT_ADJMT_MNS;
	}

	public Integer getDP_END_GMT_ADJMT_MNS() {
		return DP_END_GMT_ADJMT_MNS;
	}

	public void setDP_END_GMT_ADJMT_MNS(Integer dP_END_GMT_ADJMT_MNS) {
		DP_END_GMT_ADJMT_MNS = dP_END_GMT_ADJMT_MNS;
	}

	public Integer getDP_LEG_GRTR_MNS() {
		return DP_LEG_GRTR_MNS;
	}

	public void setDP_LEG_GRTR_MNS(Integer dP_LEG_GRTR_MNS) {
		DP_LEG_GRTR_MNS = dP_LEG_GRTR_MNS;
	}

	public Integer getDP_ACTL_DUTY_PER_CR_MNS() {
		return DP_ACTL_DUTY_PER_CR_MNS;
	}

	public void setDP_ACTL_DUTY_PER_CR_MNS(Integer dP_ACTL_DUTY_PER_CR_MNS) {
		DP_ACTL_DUTY_PER_CR_MNS = dP_ACTL_DUTY_PER_CR_MNS;
	}

	public String getDP_SCHEDULED_START_DATE() {
		return DP_SCHEDULED_START_DATE;
	}

	public void setDP_SCHEDULED_START_DATE(String dP_SCHEDULED_START_DATE) {
		DP_SCHEDULED_START_DATE = dP_SCHEDULED_START_DATE;
	}

	public String getDP_ACTUAL_START_DATE() {
		return DP_ACTUAL_START_DATE;
	}

	public void setDP_ACTUAL_START_DATE(String dP_ACTUAL_START_DATE) {
		DP_ACTUAL_START_DATE = dP_ACTUAL_START_DATE;
	}

	public Integer getDP_SCHEDULED_START_TIME() {
		return DP_SCHEDULED_START_TIME;
	}

	public void setDP_SCHEDULED_START_TIME(Integer dP_SCHEDULED_START_TIME) {
		DP_SCHEDULED_START_TIME = dP_SCHEDULED_START_TIME;
	}

	public String getDP_SCHEDULED_END_DATE() {
		return DP_SCHEDULED_END_DATE;
	}

	public void setDP_SCHEDULED_END_DATE(String dP_SCHEDULED_END_DATE) {
		DP_SCHEDULED_END_DATE = dP_SCHEDULED_END_DATE;
	}

	public String getLEG_SCHEDULED_START_DATE() {
		return LEG_SCHEDULED_START_DATE;
	}

	public void setLEG_SCHEDULED_START_DATE(String lEG_SCHEDULED_START_DATE) {
		LEG_SCHEDULED_START_DATE = lEG_SCHEDULED_START_DATE;
	}

	public String getLEG_ACTUAL_START_DATE() {
		return LEG_ACTUAL_START_DATE;
	}

	public void setLEG_ACTUAL_START_DATE(String lEG_ACTUAL_START_DATE) {
		LEG_ACTUAL_START_DATE = lEG_ACTUAL_START_DATE;
	}

	public Integer getLEG_SCHEDULED_START_TIME() {
		return LEG_SCHEDULED_START_TIME;
	}

	public void setLEG_SCHEDULED_START_TIME(Integer lEG_SCHEDULED_START_TIME) {
		LEG_SCHEDULED_START_TIME = lEG_SCHEDULED_START_TIME;
	}

	public Integer getRSCHEDULED_START_TIME() {
		return RSCHEDULED_START_TIME;
	}

	public void setRSCHEDULED_START_TIME(Integer rSCHEDULED_START_TIME) {
		RSCHEDULED_START_TIME = rSCHEDULED_START_TIME;
	}

	public Integer getLEG_ACTUAL_START_TIME() {
		return LEG_ACTUAL_START_TIME;
	}

	public void setLEG_ACTUAL_START_TIME(Integer lEG_ACTUAL_START_TIME) {
		LEG_ACTUAL_START_TIME = lEG_ACTUAL_START_TIME;
	}

	public Integer getLEG_SCHEDULED_END_TIME() {
		return LEG_SCHEDULED_END_TIME;
	}

	public void setLEG_SCHEDULED_END_TIME(Integer lEG_SCHEDULED_END_TIME) {
		LEG_SCHEDULED_END_TIME = lEG_SCHEDULED_END_TIME;
	}

	public Integer getLEG_ACTUAL_END_TIME() {
		return LEG_ACTUAL_END_TIME;
	}

	public void setLEG_ACTUAL_END_TIME(Integer lEG_ACTUAL_END_TIME) {
		LEG_ACTUAL_END_TIME = lEG_ACTUAL_END_TIME;
	}

	public Integer getFLIGHT_NUMBER() {
		return FLIGHT_NUMBER;
	}

	public void setFLIGHT_NUMBER(Integer fLIGHT_NUMBER) {
		FLIGHT_NUMBER = fLIGHT_NUMBER;
	}

	public String getDEPARTURE_STATION() {
		return DEPARTURE_STATION;
	}

	public void setDEPARTURE_STATION(String dEPARTURE_STATION) {
		DEPARTURE_STATION = dEPARTURE_STATION;
	}

	public Integer getSTR_GMT_ADJMT_MNS() {
		return STR_GMT_ADJMT_MNS;
	}

	public void setSTR_GMT_ADJMT_MNS(Integer sTR_GMT_ADJMT_MNS) {
		STR_GMT_ADJMT_MNS = sTR_GMT_ADJMT_MNS;
	}

	public String getARRIVAL_STATION() {
		return ARRIVAL_STATION;
	}

	public void setARRIVAL_STATION(String aRRIVAL_STATION) {
		ARRIVAL_STATION = aRRIVAL_STATION;
	}

	public String getSCHEDULED_EQUIPMENT_CODE() {
		return SCHEDULED_EQUIPMENT_CODE;
	}

	public void setSCHEDULED_EQUIPMENT_CODE(String sCHEDULED_EQUIPMENT_CODE) {
		SCHEDULED_EQUIPMENT_CODE = sCHEDULED_EQUIPMENT_CODE;
	}

	public String getACTUAL_EQUIP_CODE() {
		return ACTUAL_EQUIP_CODE;
	}

	public void setACTUAL_EQUIP_CODE(String aCTUAL_EQUIP_CODE) {
		ACTUAL_EQUIP_CODE = aCTUAL_EQUIP_CODE;
	}

	public Integer getATC_MINS() {
		return ATC_MINS;
	}

	public void setATC_MINS(Integer aTC_MINS) {
		ATC_MINS = aTC_MINS;
	}

	public Integer getCANCELLED_LEG_INDICATOR() {
		return CANCELLED_LEG_INDICATOR;
	}

	public void setCANCELLED_LEG_INDICATOR(Integer cANCELLED_LEG_INDICATOR) {
		CANCELLED_LEG_INDICATOR = cANCELLED_LEG_INDICATOR;
	}

	public String getFLT_LEG_STUB_INDR() {
		return FLT_LEG_STUB_INDR;
	}

	public void setFLT_LEG_STUB_INDR(String fLT_LEG_STUB_INDR) {
		FLT_LEG_STUB_INDR = fLT_LEG_STUB_INDR;
	}

	public Integer getIRREGULAR_LEG_INDICATOR() {
		return IRREGULAR_LEG_INDICATOR;
	}

	public void setIRREGULAR_LEG_INDICATOR(Integer iRREGULAR_LEG_INDICATOR) {
		IRREGULAR_LEG_INDICATOR = iRREGULAR_LEG_INDICATOR;
	}

	public String getDEADHEAD_INDICATOR() {
		return DEADHEAD_INDICATOR;
	}

	public void setDEADHEAD_INDICATOR(String dEADHEAD_INDICATOR) {
		DEADHEAD_INDICATOR = dEADHEAD_INDICATOR;
	}

	public String getRMVD_CRD_ACTY_INDR() {
		return RMVD_CRD_ACTY_INDR;
	}

	public void setRMVD_CRD_ACTY_INDR(String rMVD_CRD_ACTY_INDR) {
		RMVD_CRD_ACTY_INDR = rMVD_CRD_ACTY_INDR;
	}

	public Integer getLEG_CREWMEMBER_POSITION() {
		return LEG_CREWMEMBER_POSITION;
	}

	public void setLEG_CREWMEMBER_POSITION(Integer lEG_CREWMEMBER_POSITION) {
		LEG_CREWMEMBER_POSITION = lEG_CREWMEMBER_POSITION;
	}

	public Integer getLEG_ADD_CODE() {
		return LEG_ADD_CODE;
	}

	public void setLEG_ADD_CODE(Integer lEG_ADD_CODE) {
		LEG_ADD_CODE = lEG_ADD_CODE;
	}

	public Integer getLEG_REMOVAL_CODE() {
		return LEG_REMOVAL_CODE;
	}

	public void setLEG_REMOVAL_CODE(Integer lEG_REMOVAL_CODE) {
		LEG_REMOVAL_CODE = lEG_REMOVAL_CODE;
	}

	public Integer getDEI_MINS() {
		return DEI_MINS;
	}

	public void setDEI_MINS(Integer dEI_MINS) {
		DEI_MINS = dEI_MINS;
	}

	public Integer getRCD_MINS() {
		return RCD_MINS;
	}

	public void setRCD_MINS(Integer rCD_MINS) {
		RCD_MINS = rCD_MINS;
	}

	@Override
	public String toString() {
		return "RAWDATA [EMPNo=" + EMPNo + ", EMPLOYEE_NAME=" + EMPLOYEE_NAME + ", DATE=" + DATE + ", CREW_TYPE="
				+ CREW_TYPE + ", DOM_INTL_CODE=" + DOM_INTL_CODE + ", INACTIVE=" + INACTIVE + ", TRIP_TYPE=" + TRIP_TYPE
				+ ", SAM_INDICATOR=" + SAM_INDICATOR + ", SCHEDULED_START_DATE=" + SCHEDULED_START_DATE + ", SEQ_EMPNo="
				+ SEQ_EMPNo + ", SEQUENCE_NUMBER=" + SEQUENCE_NUMBER + ", SEQ_REASON_CODE=" + SEQ_REASON_CODE
				+ ", SEQ_REMOVAL_CODE=" + SEQ_REMOVAL_CODE + ", SEQ_LEVEL_NUMBER=" + SEQ_LEVEL_NUMBER
				+ ", SEQ_DOM_INTL_CODE=" + SEQ_DOM_INTL_CODE + ", ACTL_SEQ_CR_MNS=" + ACTL_SEQ_CR_MNS
				+ ", ACTL_DUTY_PER_CR_MNS=" + ACTL_DUTY_PER_CR_MNS + ", SEQ_CNTRTL_PATH_INDR=" + SEQ_CNTRTL_PATH_INDR
				+ ", XDTYPER=" + XDTYPER + ", DP_NO=" + DP_NO + ", DP_ACTUAL_END_DATE=" + DP_ACTUAL_END_DATE
				+ ", DP_SCHEDULED_START_DATE=" + DP_SCHEDULED_START_DATE + ", DP_ACTUAL_START_DATE="
				+ DP_ACTUAL_START_DATE + ", DP_SCHEDULED_START_TIME=" + DP_SCHEDULED_START_TIME
				+ ", DP_SCHEDULED_END_DATE=" + DP_SCHEDULED_END_DATE + ", DP_SEQUENCE_NUMBER=" + DP_SEQUENCE_NUMBER
				+ ", DP_ACTUAL_START_TIME=" + DP_ACTUAL_START_TIME + ", DP_SCHEDULED_END_TIME=" + DP_SCHEDULED_END_TIME
				+ ", DP_ACTUAL_END_TIME=" + DP_ACTUAL_END_TIME + ", DP_STR_GMT_ADJMT_MNS=" + DP_STR_GMT_ADJMT_MNS
				+ ", DP_END_GMT_ADJMT_MNS=" + DP_END_GMT_ADJMT_MNS + ", DP_LEG_GRTR_MNS=" + DP_LEG_GRTR_MNS
				+ ", DP_ACTL_DUTY_PER_CR_MNS=" + DP_ACTL_DUTY_PER_CR_MNS + ", DP_DHD_MIN=" + DP_DHD_MIN + ", DHD_MIN="
				+ DHD_MIN + ", OTH_DOM_INTL_CODE=" + OTH_DOM_INTL_CODE + ", OTH_INACTIVE=" + OTH_INACTIVE
				+ ", OTH_TRIP_TYPE=" + OTH_TRIP_TYPE + ", OTH_LEG_GRTR_MNS=" + OTH_LEG_GRTR_MNS
				+ ", OTH_ACTL_DUTY_PER_CR_MNS=" + OTH_ACTL_DUTY_PER_CR_MNS + ", OTH_ACTL_SEQ_CR_MNS="
				+ OTH_ACTL_SEQ_CR_MNS + ", OTH_DHD_MIN=" + OTH_DHD_MIN + ", OTM_LEG_GRTR_MNS=" + OTM_LEG_GRTR_MNS
				+ ", OTM_ACTL_DUTY_PER_CR_MNS=" + OTM_ACTL_DUTY_PER_CR_MNS + ", OTM_DHD_MIN=" + OTM_DHD_MIN + ", LEG="
				+ LEG + ", LEG_DP_NO=" + LEG_DP_NO + ", LEG_EMPNo=" + LEG_EMPNo + ", LEG_SEQUENCE_NUMBER="
				+ LEG_SEQUENCE_NUMBER + ", LEG_SCHEDULED_START_DATE=" + LEG_SCHEDULED_START_DATE
				+ ", LEG_ACTUAL_START_DATE=" + LEG_ACTUAL_START_DATE + ", LEG_SCHEDULED_START_TIME="
				+ LEG_SCHEDULED_START_TIME + ", RSCHEDULED_START_TIME=" + RSCHEDULED_START_TIME
				+ ", LEG_ACTUAL_START_TIME=" + LEG_ACTUAL_START_TIME + ", LEG_SCHEDULED_END_TIME="
				+ LEG_SCHEDULED_END_TIME + ", LEG_ACTUAL_END_TIME=" + LEG_ACTUAL_END_TIME + ", FLIGHT_NUMBER="
				+ FLIGHT_NUMBER + ", DEPARTURE_STATION=" + DEPARTURE_STATION + ", STR_GMT_ADJMT_MNS="
				+ STR_GMT_ADJMT_MNS + ", ARRIVAL_STATION=" + ARRIVAL_STATION + ", SCHEDULED_EQUIPMENT_CODE="
				+ SCHEDULED_EQUIPMENT_CODE + ", ACTUAL_EQUIP_CODE=" + ACTUAL_EQUIP_CODE + ", ATC_MINS=" + ATC_MINS
				+ ", CANCELLED_LEG_INDICATOR=" + CANCELLED_LEG_INDICATOR + ", FLT_LEG_STUB_INDR=" + FLT_LEG_STUB_INDR
				+ ", IRREGULAR_LEG_INDICATOR=" + IRREGULAR_LEG_INDICATOR + ", DEADHEAD_INDICATOR=" + DEADHEAD_INDICATOR
				+ ", RMVD_CRD_ACTY_INDR=" + RMVD_CRD_ACTY_INDR + ", LEG_CREWMEMBER_POSITION=" + LEG_CREWMEMBER_POSITION
				+ ", LEG_ADD_CODE=" + LEG_ADD_CODE + ", LEG_REMOVAL_CODE=" + LEG_REMOVAL_CODE + ", DEI_MINS=" + DEI_MINS
				+ ", RCD_MINS=" + RCD_MINS + ", DVR_MINS=" + DVR_MINS + ", REASON_PAY_INDICATOR=" + REASON_PAY_INDICATOR
				+ ", Intl_Override=" + Intl_Override + ", SEQ_CREWMEMBER_POSITION=" + SEQ_CREWMEMBER_POSITION
				+ ", ASSIGNMENT_REASON_CODE=" + ASSIGNMENT_REASON_CODE + ", LCL_SDEP=" + LCL_SDEP + ", LCL_ADEP="
				+ LCL_ADEP + ", SCH_BLK=" + SCH_BLK + ", ACT_BLK=" + ACT_BLK + ", ACT_BLK_MIN=" + ACT_BLK_MIN
				+ ", TTL_ACT=" + TTL_ACT + ", GTR_BLK=" + GTR_BLK + ", GTR_BLK_MIN=" + GTR_BLK_MIN + ", SCH_BLK_MIN="
				+ SCH_BLK_MIN + ", LEG_EX_DH=" + LEG_EX_DH + ", DepMatch=" + DepMatch + ", totalIntlCount="
				+ totalIntlCount + ", totalFlights=" + totalFlights + ", DH_BLOCK=" + DH_BLOCK + ", DH_SCHED="
				+ DH_SCHED + ", Match_OthRec=" + Match_OthRec + ", specialFlag=" + specialFlag + ", last_Leg_Ok="
				+ last_Leg_Ok + ", DP_A_ETIME_OK=" + DP_A_ETIME_OK + ", CO_DP_A_ETIME_OK=" + CO_DP_A_ETIME_OK
				+ ", SDP_A_ETIME=" + SDP_A_ETIME + ", SDP_A_ETIME_OK=" + SDP_A_ETIME_OK + ", SEQ_LAST_LEG_OK="
				+ SEQ_LAST_LEG_OK + ", CO_SDP_A_ETIME_OK=" + CO_SDP_A_ETIME_OK + ", USED_FCRM_ETIME=" + USED_FCRM_ETIME
				+ ", PROCESSING_START_DATE=" + PROCESSING_START_DATE + ", PROCESSING_END_DATE=" + PROCESSING_END_DATE
				+ ", INT_DH_MIN=" + INT_DH_MIN + ", DOM_DH_MIN=" + DOM_DH_MIN + ", EXTRA_INT_DH=" + EXTRA_INT_DH
				+ ", EXTRA_DOM_DH=" + EXTRA_DOM_DH + ", CO_INT_DH_MIN=" + CO_INT_DH_MIN + ", CO_EXTRA_INT_DH="
				+ CO_EXTRA_INT_DH + ", SPLIT_TERM_MON_PD_CRD_DH=" + SPLIT_TERM_MON_PD_CRD_DH + ", DH_AFT_12MID="
				+ DH_AFT_12MID + ", TTL_DH=" + TTL_DH + ", EXTRA_DH=" + EXTRA_DH + ", CO_INT_DH_MIN_DH_AFT_12MID="
				+ CO_INT_DH_MIN_DH_AFT_12MID + "]\n";
	}

	

	
	
}
