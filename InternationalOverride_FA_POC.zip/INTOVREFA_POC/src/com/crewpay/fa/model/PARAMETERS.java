package com.crewpay.fa.model;

import java.util.Date;

public class PARAMETERS {
  
	public Date START_DATE;
	public Date END_DATE;
	public String FLOWN_OR_REMOVED_PARAM;
	public Character CO_SEQ_PROCESSING_FLAG;
	public Date PROCESSING_START_DATE;
	public String PROCESSING_END_DATE;
	
	
	
	public Date getPROCESSING_START_DATE() {
		return PROCESSING_START_DATE;
	}
	public void setPROCESSING_START_DATE(Date pROCESSING_START_DATE) {
		PROCESSING_START_DATE = pROCESSING_START_DATE;
	}
	public String getPROCESSING_END_DATE() {
		return PROCESSING_END_DATE;
	}
	public void setPROCESSING_END_DATE(String pROCESSING_END_DATE) {
		PROCESSING_END_DATE = pROCESSING_END_DATE;
	}
	public Date getSTART_DATE() {
		return START_DATE;
	}
	public void setSTART_DATE(Date sTART_DATE) {
		START_DATE = sTART_DATE;
	}
	public Date getEND_DATE() {
		return END_DATE;
	}
	public void setEND_DATE(Date eND_DATE) {
		END_DATE = eND_DATE;
	}
	public String getFLOWN_OR_REMOVED_PARAM() {
		return FLOWN_OR_REMOVED_PARAM;
	}
	public void setFLOWN_OR_REMOVED_PARAM(String fLOWN_OR_REMOVED_PARAM) {
		FLOWN_OR_REMOVED_PARAM = fLOWN_OR_REMOVED_PARAM;
	}
	public Character getCO_SEQ_PROCESSING_FLAG() {
		return CO_SEQ_PROCESSING_FLAG;
	}
	public void setCO_SEQ_PROCESSING_FLAG(Character cO_SEQ_PROCESSING_FLAG) {
		CO_SEQ_PROCESSING_FLAG = cO_SEQ_PROCESSING_FLAG;
	}
	@Override
	public String toString() {
		return "PARAMETERS [START_DATE=" + START_DATE + ", END_DATE=" + END_DATE + ", FLOWN_OR_REMOVED_PARAM="
				+ FLOWN_OR_REMOVED_PARAM + ", CO_SEQ_PROCESSING_FLAG=" + CO_SEQ_PROCESSING_FLAG
				+ ", PROCESSING_START_DATE=" + PROCESSING_START_DATE + ", PROCESSING_END_DATE=" + PROCESSING_END_DATE
				+ "]";
	}
	
	
}
