package com.crewpay.fa.model;

import java.util.ArrayList;
import java.util.List;

public class FlightAttendantModel {

	public List<CrewMembers> crewMember;
	public List<IPDStations> fcrm_Model;
	public List<CITYCODE> citycode;
	public List<PARAMETERS> parameters;
	public List<ReasonGroups> reasonGroups;
	public List<IgnoredStations> ignoredStations=new ArrayList<IgnoredStations>();
	
	
	
	public List<IgnoredStations> getIgnoredStations() {
		return ignoredStations;
	}
	public void setIgnoredStations(List<IgnoredStations> ignoredStations) {
		this.ignoredStations = ignoredStations;
	}
	public List<ReasonGroups> getReasonGroups() {
		return reasonGroups;
	}
	@SuppressWarnings("unchecked")
	public void setReasonGroups(List<?> reasonGroups) {
		this.reasonGroups = (List<ReasonGroups>) reasonGroups;
	}
	public List<PARAMETERS> getParameters() {
		return parameters;
	}
	@SuppressWarnings("unchecked")
	public void setParameters(List<?> parameters) {
		this.parameters = (List<PARAMETERS>) parameters;
	}
	public List<CITYCODE> getCitycode() {
		return citycode;
	}
	@SuppressWarnings("unchecked")
	public void setCitycode(List<?> citycode) {
		this.citycode = (List<CITYCODE>) citycode;
	}
	@SuppressWarnings("unchecked")
	public void setCrewMember(List<?> crewMember) {
		this.crewMember =  (List<CrewMembers>)crewMember;
	}
	
	
	@SuppressWarnings("unchecked")
	public void setFcrm_Model(List<?> fcrm_Model) {
		this.fcrm_Model = (List<IPDStations>) fcrm_Model;
	}
	public List<CrewMembers> getCrewMember() {
		return crewMember;
	}
	
	public List<IPDStations> getFcrm_Model() {
		return fcrm_Model;
	}
	@Override
	public String toString() {
		return "FlightAttendantModel [crewMember=" + crewMember + ", fcrm_Model=" + fcrm_Model + ", citycode="
				+ citycode + ", parameters=" + parameters + ", reasonGroups=" + reasonGroups + ", ignoredStations="
				+ ignoredStations + "]";
	}
	
	
	
	
	
	
	
	
}
