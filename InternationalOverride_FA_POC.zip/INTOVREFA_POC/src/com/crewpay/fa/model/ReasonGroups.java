package com.crewpay.fa.model;

import java.util.Date;

public class ReasonGroups {

	public Integer REASON_NUMBER;
	public Integer REASON_CODE;
	public String REASON_GROUP;
	public Integer REASON_PAY_INDICATOR;
	public String REASON_PAY_CODE;
	public Date PROCESSING_START_DATE;
	public Date PROCESSING_END_DATE;
	
	public Date getPROCESSING_START_DATE() {
		return PROCESSING_START_DATE;
	}
	public void setPROCESSING_START_DATE(Date pROCESSING_START_DATE) {
		PROCESSING_START_DATE = pROCESSING_START_DATE;
	}
	public Date getPROCESSING_END_DATE() {
		return PROCESSING_END_DATE;
	}
	public void setPROCESSING_END_DATE(Date pROCESSING_END_DATE) {
		PROCESSING_END_DATE = pROCESSING_END_DATE;
	}
	public Integer getREASON_NUMBER() {
		return REASON_NUMBER;
	}
	public void setREASON_NUMBER(Integer rEASON_NUMBER) {
		REASON_NUMBER = rEASON_NUMBER;
	}
	public Integer getREASON_CODE() {
		return REASON_CODE;
	}
	public void setREASON_CODE(Integer rEASON_CODE) {
		REASON_CODE = rEASON_CODE;
	}
	public String getREASON_GROUP() {
		return REASON_GROUP;
	}
	public void setREASON_GROUP(String rEASON_GROUP) {
		REASON_GROUP = rEASON_GROUP;
	}
	public Integer getREASON_PAY_INDICATOR() {
		return REASON_PAY_INDICATOR;
	}
	public void setREASON_PAY_INDICATOR(Integer rEASON_PAY_INDICATOR) {
		REASON_PAY_INDICATOR = rEASON_PAY_INDICATOR;
	}
	public String getREASON_PAY_CODE() {
		return REASON_PAY_CODE;
	}
	public void setREASON_PAY_CODE(String rEASON_PAY_CODE) {
		REASON_PAY_CODE = rEASON_PAY_CODE;
	}
	@Override
	public String toString() {
		return "ReasonGroups [REASON_NUMBER=" + REASON_NUMBER + ", REASON_CODE=" + REASON_CODE + ", REASON_GROUP="
				+ REASON_GROUP + ", REASON_PAY_INDICATOR=" + REASON_PAY_INDICATOR + ", REASON_PAY_CODE="
				+ REASON_PAY_CODE + "]";
	}
	
}
