package com.crewpay.fa.model;

import java.util.Date;
import java.util.List;

public class DPDATA {
	
	public Integer EMPNo;
	public String EMPLOYEE_NAME;
	public Date DATE;
	public Integer CREW_TYPE;
	
	public String DOM_INTL_CODE;
	public Character INACTIVE;
	public String TRIP_TYPE;
	
	public String SAM_INDICATOR;
	public Integer SEQ_EMPNo;
	public Integer SEQUENCE_NUMBER;
	public Date SCHEDULED_START_DATE;
	public Integer SEQ_REASON_CODE;
	public Integer SEQ_REMOVAL_CODE;
	public Integer SEQ_LEVEL_NUMBER;
	public Integer DP_NO;
	
	public Integer DP_SEQUENCE_NUMBER;
	public Integer XDTYPER;
	public Date DP_SCHEDULED_START_DATE;
	public Date DP_ACTUAL_START_DATE;
	public Integer DP_SCHEDULED_START_TIME;
	public Integer DP_ACTUAL_START_TIME;
	public Date DP_ACTUAL_END_DATE;
	public Integer DP_SCHEDULED_END_TIME ; 
	public Integer DP_ACTUAL_END_TIME;  
	public Integer DP_STR_GMT_ADJMT_MNS;
	public Integer DP_END_GMT_ADJMT_MNS;
	public Integer DP_LEG_GRTR_MNS;
	public Integer DP_ACTL_DUTY_PER_CR_MNS;
	private Integer last_Leg_Ok;
	public Integer Match_OthRec;
	
	
	public Integer getLast_Leg_Ok() {
		return last_Leg_Ok;
	}
	public void setLast_Leg_Ok(Integer last_Leg_Ok) {
		this.last_Leg_Ok = last_Leg_Ok;
	}
	public Integer getEMPNo() {
		return EMPNo;
	}
	public void setEMPNo(Integer eMPNo) {
		EMPNo = eMPNo;
	}
	public String getEMPLOYEE_NAME() {
		return EMPLOYEE_NAME;
	}
	public void setEMPLOYEE_NAME(String eMPLOYEE_NAME) {
		EMPLOYEE_NAME = eMPLOYEE_NAME;
	}
	public Date getDATE() {
		return DATE;
	}
	public void setDATE(Date dATE) {
		DATE = dATE;
	}
	public Integer getCREW_TYPE() {
		return CREW_TYPE;
	}
	public void setCREW_TYPE(Integer cREW_TYPE) {
		CREW_TYPE = cREW_TYPE;
	}
	public String getDOM_INTL_CODE() {
		return DOM_INTL_CODE;
	}
	public void setDOM_INTL_CODE(String dOM_INTL_CODE) {
		DOM_INTL_CODE = dOM_INTL_CODE;
	}
	public Character getINACTIVE() {
		return INACTIVE;
	}
	public void setINACTIVE(Character iNACTIVE) {
		INACTIVE = iNACTIVE;
	}
	public String getTRIP_TYPE() {
		return TRIP_TYPE;
	}
	public void setTRIP_TYPE(String tRIP_TYPE) {
		TRIP_TYPE = tRIP_TYPE;
	}
	public String getSAM_INDICATOR() {
		return SAM_INDICATOR;
	}
	public void setSAM_INDICATOR(String sAM_INDICATOR) {
		SAM_INDICATOR = sAM_INDICATOR;
	}
	public Integer getSEQ_EMPNo() {
		return SEQ_EMPNo;
	}
	public void setSEQ_EMPNo(Integer sEQ_EMPNo) {
		SEQ_EMPNo = sEQ_EMPNo;
	}
	public Integer getSEQUENCE_NUMBER() {
		return SEQUENCE_NUMBER;
	}
	public void setSEQUENCE_NUMBER(Integer sEQUENCE_NUMBER) {
		SEQUENCE_NUMBER = sEQUENCE_NUMBER;
	}
	public Date getSCHEDULED_START_DATE() {
		return SCHEDULED_START_DATE;
	}
	public void setSCHEDULED_START_DATE(Date sCHEDULED_START_DATE) {
		SCHEDULED_START_DATE = sCHEDULED_START_DATE;
	}
	public Integer getSEQ_REASON_CODE() {
		return SEQ_REASON_CODE;
	}
	public void setSEQ_REASON_CODE(Integer sEQ_REASON_CODE) {
		SEQ_REASON_CODE = sEQ_REASON_CODE;
	}
	public Integer getSEQ_REMOVAL_CODE() {
		return SEQ_REMOVAL_CODE;
	}
	public void setSEQ_REMOVAL_CODE(Integer sEQ_REMOVAL_CODE) {
		SEQ_REMOVAL_CODE = sEQ_REMOVAL_CODE;
	}
	public Integer getSEQ_LEVEL_NUMBER() {
		return SEQ_LEVEL_NUMBER;
	}
	public void setSEQ_LEVEL_NUMBER(Integer sEQ_LEVEL_NUMBER) {
		SEQ_LEVEL_NUMBER = sEQ_LEVEL_NUMBER;
	}
	public Integer getDP_NO() {
		return DP_NO;
	}
	public void setDP_NO(Integer dP_NO) {
		DP_NO = dP_NO;
	}
	public Integer getDP_SEQUENCE_NUMBER() {
		return DP_SEQUENCE_NUMBER;
	}
	public void setDP_SEQUENCE_NUMBER(Integer dP_SEQUENCE_NUMBER) {
		DP_SEQUENCE_NUMBER = dP_SEQUENCE_NUMBER;
	}
	public Integer getXDTYPER() {
		return XDTYPER;
	}
	public void setXDTYPER(Integer xDTYPER) {
		XDTYPER = xDTYPER;
	}
	public Date getDP_SCHEDULED_START_DATE() {
		return DP_SCHEDULED_START_DATE;
	}
	public void setDP_SCHEDULED_START_DATE(Date dP_SCHEDULED_START_DATE) {
		DP_SCHEDULED_START_DATE = dP_SCHEDULED_START_DATE;
	}
	public Date getDP_ACTUAL_START_DATE() {
		return DP_ACTUAL_START_DATE;
	}
	public void setDP_ACTUAL_START_DATE(Date dP_ACTUAL_START_DATE) {
		DP_ACTUAL_START_DATE = dP_ACTUAL_START_DATE;
	}
	public Integer getDP_SCHEDULED_START_TIME() {
		return DP_SCHEDULED_START_TIME;
	}
	public void setDP_SCHEDULED_START_TIME(Integer dP_SCHEDULED_START_TIME) {
		DP_SCHEDULED_START_TIME = dP_SCHEDULED_START_TIME;
	}
	public Integer getDP_ACTUAL_START_TIME() {
		return DP_ACTUAL_START_TIME;
	}
	public void setDP_ACTUAL_START_TIME(Integer dP_ACTUAL_START_TIME) {
		DP_ACTUAL_START_TIME = dP_ACTUAL_START_TIME;
	}
	public Date getDP_ACTUAL_END_DATE() {
		return DP_ACTUAL_END_DATE;
	}
	public void setDP_ACTUAL_END_DATE(Date dP_ACTUAL_END_DATE) {
		DP_ACTUAL_END_DATE = dP_ACTUAL_END_DATE;
	}
	public Integer getDP_SCHEDULED_END_TIME() {
		return DP_SCHEDULED_END_TIME;
	}
	public void setDP_SCHEDULED_END_TIME(Integer dP_SCHEDULED_END_TIME) {
		DP_SCHEDULED_END_TIME = dP_SCHEDULED_END_TIME;
	}
	public Integer getDP_ACTUAL_END_TIME() {
		return DP_ACTUAL_END_TIME;
	}
	public void setDP_ACTUAL_END_TIME(Integer dP_ACTUAL_END_TIME) {
		DP_ACTUAL_END_TIME = dP_ACTUAL_END_TIME;
	}
	public Integer getDP_STR_GMT_ADJMT_MNS() {
		return DP_STR_GMT_ADJMT_MNS;
	}
	public void setDP_STR_GMT_ADJMT_MNS(Integer dP_STR_GMT_ADJMT_MNS) {
		DP_STR_GMT_ADJMT_MNS = dP_STR_GMT_ADJMT_MNS;
	}
	public Integer getDP_END_GMT_ADJMT_MNS() {
		return DP_END_GMT_ADJMT_MNS;
	}
	public void setDP_END_GMT_ADJMT_MNS(Integer dP_END_GMT_ADJMT_MNS) {
		DP_END_GMT_ADJMT_MNS = dP_END_GMT_ADJMT_MNS;
	}
	public Integer getDP_LEG_GRTR_MNS() {
		return DP_LEG_GRTR_MNS;
	}
	public void setDP_LEG_GRTR_MNS(Integer dP_LEG_GRTR_MNS) {
		DP_LEG_GRTR_MNS = dP_LEG_GRTR_MNS;
	}
	public Integer getDP_ACTL_DUTY_PER_CR_MNS() {
		return DP_ACTL_DUTY_PER_CR_MNS;
	}
	public void setDP_ACTL_DUTY_PER_CR_MNS(Integer dP_ACTL_DUTY_PER_CR_MNS) {
		DP_ACTL_DUTY_PER_CR_MNS = dP_ACTL_DUTY_PER_CR_MNS;
	}
	public Integer getMatch_OthRec() {
		return Match_OthRec;
	}
	public void setMatch_OthRec(Integer match_OthRec) {
		Match_OthRec = match_OthRec;
	}
	@Override
	public String toString() {
		return "DPDATA [EMPNo=" + EMPNo + ", EMPLOYEE_NAME=" + EMPLOYEE_NAME + ", DATE=" + DATE + ", CREW_TYPE="
				+ CREW_TYPE + ", DOM_INTL_CODE=" + DOM_INTL_CODE + ", INACTIVE=" + INACTIVE + ", TRIP_TYPE=" + TRIP_TYPE
				+ ", SAM_INDICATOR=" + SAM_INDICATOR + ", SEQ_EMPNo=" + SEQ_EMPNo + ", SEQUENCE_NUMBER="
				+ SEQUENCE_NUMBER + ", SCHEDULED_START_DATE=" + SCHEDULED_START_DATE + ", SEQ_REASON_CODE="
				+ SEQ_REASON_CODE + ", SEQ_REMOVAL_CODE=" + SEQ_REMOVAL_CODE + ", SEQ_LEVEL_NUMBER=" + SEQ_LEVEL_NUMBER
				+ ", DP_NO=" + DP_NO + ", DP_SEQUENCE_NUMBER=" + DP_SEQUENCE_NUMBER + ", XDTYPER=" + XDTYPER
				+ ", DP_SCHEDULED_START_DATE=" + DP_SCHEDULED_START_DATE + ", DP_ACTUAL_START_DATE="
				+ DP_ACTUAL_START_DATE + ", DP_SCHEDULED_START_TIME=" + DP_SCHEDULED_START_TIME
				+ ", DP_ACTUAL_START_TIME=" + DP_ACTUAL_START_TIME + ", DP_ACTUAL_END_DATE=" + DP_ACTUAL_END_DATE
				+ ", DP_SCHEDULED_END_TIME=" + DP_SCHEDULED_END_TIME + ", DP_ACTUAL_END_TIME=" + DP_ACTUAL_END_TIME
				+ ", DP_STR_GMT_ADJMT_MNS=" + DP_STR_GMT_ADJMT_MNS + ", DP_END_GMT_ADJMT_MNS=" + DP_END_GMT_ADJMT_MNS
				+ ", DP_LEG_GRTR_MNS=" + DP_LEG_GRTR_MNS + ", DP_ACTL_DUTY_PER_CR_MNS=" + DP_ACTL_DUTY_PER_CR_MNS
				+ ", Match_OthRec=" + Match_OthRec + "]";
	}
	
	
	
}
