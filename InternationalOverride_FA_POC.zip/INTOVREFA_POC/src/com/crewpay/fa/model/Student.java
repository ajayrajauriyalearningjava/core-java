package com.crewpay.fa.model;

public class Student {

	private int eid;
	private int sid;
	private int did;
	private int cid;
	
	
	public Student(int eid, int sid, int did, int cid) {
		super();
		this.eid = eid;
		this.sid = sid;
		this.did = did;
		this.cid = cid;
	}


	public int getEid() {
		return eid;
	}


	public int getSid() {
		return sid;
	}


	public int getDid() {
		return did;
	}


	public int getCid() {
		return cid;
	}


	@Override
	public String toString() {
		return "Student [eid=" + eid + ", sid=" + sid + ", did=" + did + ", cid=" + cid + "]\n";
	}
	

}
