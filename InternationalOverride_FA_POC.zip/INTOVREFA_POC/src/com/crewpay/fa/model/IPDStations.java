package com.crewpay.fa.model;

import java.util.List;

public class IPDStations {

	public String IPD_STATION;

	public String getIPD_STATION() {
		return IPD_STATION;
	}

	public void setIPD_STATION(String iPD_STATION) {
		IPD_STATION = iPD_STATION;
	}

	@Override
	public String toString() {
		return "IPDStations [IPD_STATION=" + IPD_STATION + "]";
	}

	

	
}
