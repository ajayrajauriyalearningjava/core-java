package com.crewpay.fa.model;

public class CITYCODE {

	public String EXCEPTION_INDICATOR;
	public String STATE;
	public String LOCATION;
	public String US_INDICATOR;
	public String NAME;
	public String STATION;
	public String getEXCEPTION_INDICATOR() {
		return EXCEPTION_INDICATOR;
	}
	public void setEXCEPTION_INDICATOR(String eXCEPTION_INDICATOR) {
		EXCEPTION_INDICATOR = eXCEPTION_INDICATOR;
	}
	public String getSTATE() {
		return STATE;
	}
	public void setSTATE(String sTATE) {
		STATE = sTATE;
	}
	public String getLOCATION() {
		return LOCATION;
	}
	public void setLOCATION(String lOCATION) {
		LOCATION = lOCATION;
	}
	public String getUS_INDICATOR() {
		return US_INDICATOR;
	}
	public void setUS_INDICATOR(String uS_INDICATOR) {
		US_INDICATOR = uS_INDICATOR;
	}
	public String getNAME() {
		return NAME;
	}
	public void setNAME(String nAME) {
		NAME = nAME;
	}
	public String getSTATION() {
		return STATION;
	}
	public void setSTATION(String sTATION) {
		STATION = sTATION;
	}
	@Override
	public String toString() {
		return "CITYCODE [EXCEPTION_INDICATOR=" + EXCEPTION_INDICATOR + ", STATE=" + STATE + ", LOCATION=" + LOCATION
				+ ", US_INDICATOR=" + US_INDICATOR + ", NAME=" + NAME + ", STATION=" + STATION + "]";
	}
	
	
	
}
