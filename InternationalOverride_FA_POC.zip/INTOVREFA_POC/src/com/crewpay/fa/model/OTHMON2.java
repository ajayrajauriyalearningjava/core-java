package com.crewpay.fa.model;

import java.util.Date;

public class OTHMON2 {

	public Integer EMPNO;
	public String DOM_INTL_CODE;
	public Character INACTIVE;
	public String TRIP_TYPE;
	
	public Date SCHEDULED_START_DATE;
	public Integer SEQUENCE_NUMBER;
	public Integer SEQ_REASON_CODE;
	public Integer SEQ_REMOVAL_CODE;
	public Integer SEQ_LEVEL_NUMBER;
	public Integer SEQ_LEG_GRTR_MNS;
	public Integer SEQ_ACTL_DUTY_PER_CR_MNS;
	public Integer SEQ_ACTL_SEQ_CR_MNS;
	public Integer SEQ_DHD_MIN;
	
	public Integer getEmp() {
		return EMPNO;
	}
	public void setEmp(Integer emp) {
		EMPNO = emp;
	}
	
	
	
	public Integer getEMPNO() {
		return EMPNO;
	}
	public void setEMPNO(Integer eMPNO) {
		EMPNO = eMPNO;
	}
	public String getDOM_INTL_CODE() {
		return DOM_INTL_CODE;
	}
	public void setDOM_INTL_CODE(String dOM_INTL_CODE) {
		DOM_INTL_CODE = dOM_INTL_CODE;
	}
	public Character getINACTIVE() {
		return INACTIVE;
	}
	public void setINACTIVE(Character iNACTIVE) {
		INACTIVE = iNACTIVE;
	}
	public String getTRIP_TYPE() {
		return TRIP_TYPE;
	}
	public void setTRIP_TYPE(String tRIP_TYPE) {
		TRIP_TYPE = tRIP_TYPE;
	}
	public Date getSCHEDULED_START_DATE() {
		return SCHEDULED_START_DATE;
	}
	public void setSCHEDULED_START_DATE(Date sCHEDULED_START_DATE) {
		SCHEDULED_START_DATE = sCHEDULED_START_DATE;
	}
	public Integer getSEQUENCE_NUMBER() {
		return SEQUENCE_NUMBER;
	}
	public void setSEQUENCE_NUMBER(Integer sEQUENCE_NUMBER) {
		SEQUENCE_NUMBER = sEQUENCE_NUMBER;
	}
	
	public Integer getSEQ_REASON_CODE() {
		return SEQ_REASON_CODE;
	}
	public void setSEQ_REASON_CODE(Integer sEQ_REASON_CODE) {
		SEQ_REASON_CODE = sEQ_REASON_CODE;
	}
	public Integer getSEQ_REMOVAL_CODE() {
		return SEQ_REMOVAL_CODE;
	}
	public void setSEQ_REMOVAL_CODE(Integer sEQ_REMOVAL_CODE) {
		SEQ_REMOVAL_CODE = sEQ_REMOVAL_CODE;
	}
	public Integer getSEQ_LEVEL_NUMBER() {
		return SEQ_LEVEL_NUMBER;
	}
	public void setSEQ_LEVEL_NUMBER(Integer sEQ_LEVEL_NUMBER) {
		SEQ_LEVEL_NUMBER = sEQ_LEVEL_NUMBER;
	}
	public Integer getSEQ_LEG_GRTR_MNS() {
		return SEQ_LEG_GRTR_MNS;
	}
	public void setSEQ_LEG_GRTR_MNS(Integer oTH_LEG_GRTR_MNS) {
		SEQ_LEG_GRTR_MNS = oTH_LEG_GRTR_MNS;
	}
	public Integer getSEQ_ACTL_DUTY_PER_CR_MNS() {
		return SEQ_ACTL_DUTY_PER_CR_MNS;
	}
	public void setSEQ_ACTL_DUTY_PER_CR_MNS(Integer oTH_ACTL_DUTY_PER_CR_MNS) {
		SEQ_ACTL_DUTY_PER_CR_MNS = oTH_ACTL_DUTY_PER_CR_MNS;
	}
	public Integer getSEQ_ACTL_SEQ_CR_MNS() {
		return SEQ_ACTL_SEQ_CR_MNS;
	}
	public void setSEQ_ACTL_SEQ_CR_MNS(Integer oTH_ACTL_SEQ_CR_MNS) {
		SEQ_ACTL_SEQ_CR_MNS = oTH_ACTL_SEQ_CR_MNS;
	}
	public Integer getSEQ_DHD_MIN() {
		return SEQ_DHD_MIN;
	}
	public void setSEQ_DHD_MIN(Integer oTH_DHD_MIN) {
		SEQ_DHD_MIN = oTH_DHD_MIN;
	}
	
	
}
