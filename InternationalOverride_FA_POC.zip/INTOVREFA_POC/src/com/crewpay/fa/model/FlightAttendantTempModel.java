package com.crewpay.fa.model;

import java.util.ArrayList;
import java.util.List;

public class FlightAttendantTempModel {
	
	public List<RAWDATA> rawdata=new ArrayList<>();
	public List<RAWDATA> dhdata=new ArrayList<>();
	public List<RAWDATA> dhdata1=new ArrayList<>();
	public List<RAWDATA> dhdata2=new ArrayList<>();
	public List<RAWDATA> dpdata=new ArrayList<>();
	public List<RAWDATA> dhdata3=new ArrayList<>();
	public List<RAWDATA> alllegs=new ArrayList<>();
	public List<CITYCODE> citieList=new ArrayList<>();
	public List<CITYCODE> citypairs=new ArrayList<>();
	public List<RAWDATA> dhdatabs=new ArrayList<>();
	public IPDStations IPDList=new IPDStations();
	public List<ReasonGroups> reasonGroups;
	public List<RAWDATA> om2List=new ArrayList<>();
	public List<RAWDATA> om3List=new ArrayList<>();
	public List<CITYCODE> citycode;
	
	
	
	public List<CITYCODE> getCitycode() {
		return citycode;
	}
	public void setCitycode(List<CITYCODE> citycode) {
		this.citycode = citycode;
	}
	public List<RAWDATA> getOm2List() {
		return om2List;
	}
	public void setOm2List(List<RAWDATA> om2List) {
		this.om2List = om2List;
	}
	public List<RAWDATA> getOm3List() {
		return om3List;
	}
	public void setOm3List(List<RAWDATA> om3List) {
		this.om3List = om3List;
	}
	public List<ReasonGroups> getReasonGroups() {
		return reasonGroups;
	}
	public void setReasonGroups(List<ReasonGroups> reasonGroups) {
		this.reasonGroups = reasonGroups;
	}
	public List<RAWDATA> getRawdata() {
		return rawdata;
	}
	public void setRawdata(List<RAWDATA> rawdata) {
		this.rawdata = rawdata;
	}
	public List<RAWDATA> getDhdata() {
		return dhdata;
	}
	public void setDhdata(List<RAWDATA> dhdata) {
		this.dhdata = dhdata;
	}
	public List<RAWDATA> getDhdata1() {
		return dhdata1;
	}
	public void setDhdata1(List<RAWDATA> dhdata1) {
		this.dhdata1 = dhdata1;
	}
	public List<RAWDATA> getDhdata2() {
		return dhdata2;
	}
	public void setDhdata2(List<RAWDATA> dhdata2) {
		this.dhdata2 = dhdata2;
	}
	public List<RAWDATA> getDpdata() {
		return dpdata;
	}
	public void setDpdata(List<RAWDATA> dpdata) {
		this.dpdata = dpdata;
	}
	public List<RAWDATA> getDhdata3() {
		return dhdata3;
	}
	public void setDhdata3(List<RAWDATA> dhdata3) {
		this.dhdata3 = dhdata3;
	}
	public List<RAWDATA> getAlllegs() {
		return alllegs;
	}
	public void setAlllegs(List<RAWDATA> alllegs) {
		this.alllegs = alllegs;
	}
	public List<CITYCODE> getCitieList() {
		return citieList;
	}
	public void setCitieList(List<CITYCODE> citieList) {
		this.citieList = citieList;
	}
	public List<CITYCODE> getCitypairs() {
		return citypairs;
	}
	public void setCitypairs(List<CITYCODE> citypairs) {
		this.citypairs = citypairs;
	}
	public List<RAWDATA> getDhdatabs() {
		return dhdatabs;
	}
	public void setDhdatabs(List<RAWDATA> dhdatabs) {
		this.dhdatabs = dhdatabs;
	}
	public IPDStations getIPDList() {
		return IPDList;
	}
	public void setIPDList(IPDStations iPDList) {
		IPDList = iPDList;
	}
	@Override
	public String toString() {
		return "FlightAttendantTempModel [rawdata=" + rawdata + ", dhdata=" + dhdata + ", dhdata1=" + dhdata1
				+ ", dhdata2=" + dhdata2 + ", dpdata=" + dpdata + ", dhdata3=" + dhdata3 + ", alllegs=" + alllegs
				+ ", citieList=" + citieList + ", citypairs=" + citypairs + ", dhdatabs=" + dhdatabs + ", IPDList="
				+ IPDList + ", reasonGroups=" + reasonGroups + ", om2List=" + om2List + ", om3List=" + om3List
				+ ", citycode=" + citycode + "]\n";
	}
	
	
	
	
	
}
