package com.crewpay.fa.service;

import java.text.ParseException;

import com.crewpay.fa.model.FlightAttendantTempModel;

public interface FinalAdjustmentsOnTimes {

	public void fix_GTR_BLK_onReturnstoGates(FlightAttendantTempModel main);
	
	public void calculateTotal_Actual_BLK_Time(FlightAttendantTempModel main) throws ParseException;
	
}
