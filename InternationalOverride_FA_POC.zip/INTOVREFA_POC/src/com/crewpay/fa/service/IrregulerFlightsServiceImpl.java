package com.crewpay.fa.service;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import com.crewpay.fa.model.FlightAttendantTempModel;
import com.crewpay.fa.model.RAWDATA;

public class IrregulerFlightsServiceImpl implements IrregulerFlightsService{

	@Override
	public FlightAttendantTempModel listOfNormalFlights(FlightAttendantTempModel main) {
		Set<Map<String,Object>> divertedFlownLegs=new HashSet<>();
		Map<String,Object> normalMap1=null;
		Map<String,Object> normalMap2=null;
		Map<String,Object> divertedLeg=null;
		int DepMatch =0;
		for (RAWDATA rawdata : main.getRawdata()) {
			System.out.println(rawdata.getIntl_Override()+"-----"+rawdata.getIRREGULAR_LEG_INDICATOR());
			if((rawdata.getIntl_Override()==1)&&(rawdata.getIRREGULAR_LEG_INDICATOR()==0)){
				//C.1 - 	Create a list of Normal Flights
				normalMap1=new HashMap<String, Object>();
				normalMap1.put("Flight Number",rawdata.getFLIGHT_NUMBER());
				normalMap1.put("Departure Station", rawdata.getDEPARTURE_STATION());
				normalMap1.put("Intl Override ", rawdata.getIntl_Override());
				
				normalMap2=new HashMap<String, Object>();
				normalMap2.put("Flight Number",rawdata.getFLIGHT_NUMBER());
				normalMap2.put("Arrival Station", rawdata.getARRIVAL_STATION());
				normalMap2.put("Intl Override ", rawdata.getIntl_Override());
				
			}
			//C.2 - 	Identify and check Diverted Flown Legs
//			System.out.println(rawdata.getIRREGULAR_LEG_INDICATOR()+"----"+rawdata.getLEG_ADD_CODE()+"----"+rawdata.getIntl_Override());
			if(((rawdata.getIRREGULAR_LEG_INDICATOR()==0)&&(rawdata.getLEG_ADD_CODE()==140))||((rawdata.getIRREGULAR_LEG_INDICATOR()==1)&&(rawdata.getIntl_Override()==0))){
				divertedLeg=new HashMap<>();
				divertedLeg.put("Flight Number",rawdata.getFLIGHT_NUMBER());
				divertedLeg.put("Arrival Station", rawdata.getARRIVAL_STATION());
				divertedLeg.put("Departure Station", rawdata.getDEPARTURE_STATION());
				divertedLeg.put("Intl Override ", rawdata.getIntl_Override());
				divertedFlownLegs.add(divertedLeg);
			}
			DepMatch=0;
			if(normalMap1!=null&&normalMap2!=null&&divertedLeg!=null){
				if(normalMap1.get("Departure Station").equals(divertedLeg.get("Departure Station"))&&(normalMap1.get("Flight Number").equals(divertedLeg.get("Flight Number")))){
					rawdata.setIntl_Override(1);
					DepMatch = 1;
				}
				if(normalMap2.get("Arrival Station").equals(divertedLeg.get("Arrival Station"))&&(normalMap2.get("Flight Number").equals(divertedLeg.get("Flight Number")))){
					if(!divertedLeg.get("Departure Station").equals(normalMap2.get("Arrival Station"))){
						rawdata.setIntl_Override(1);
							DepMatch = 1;
					}
				}
			}
	       rawdata.setDepMatch(DepMatch);
		}
		
		// Repeat the above procedure on DHDATA file  
		for (RAWDATA dhdata : main.getDhdata()) {
			if((dhdata.getIntl_Override()==1)&&(dhdata.getIRREGULAR_LEG_INDICATOR()==0)){
				normalMap1=new HashMap<String, Object>();
				normalMap1.put("Flight Number",dhdata.getFLIGHT_NUMBER());
				normalMap1.put("Departure Station", dhdata.getDEPARTURE_STATION());
				normalMap1.put("Intl Override ", dhdata.getIntl_Override());
				
				normalMap2=new HashMap<String, Object>();
				normalMap2.put("Flight Number",dhdata.getFLIGHT_NUMBER());
				normalMap2.put("Arrival Station", dhdata.getARRIVAL_STATION());
				normalMap2.put("Intl Override ", dhdata.getIntl_Override());
				
			}
			
//			System.out.println(dhdata.getIRREGULAR_LEG_INDICATOR()+"----"+dhdata.getLEG_ADD_CODE()+"----"+dhdata.getIntl_Override());
			if(((dhdata.getIRREGULAR_LEG_INDICATOR()==0)&&(dhdata.getLEG_ADD_CODE()==140))||((dhdata.getIRREGULAR_LEG_INDICATOR()==1)&&(dhdata.getIntl_Override()==0))){
				divertedLeg=new HashMap<>();
				divertedLeg.put("Flight Number",dhdata.getFLIGHT_NUMBER());
				divertedLeg.put("Arrival Station", dhdata.getARRIVAL_STATION());
				divertedLeg.put("Departure Station", dhdata.getDEPARTURE_STATION());
				divertedLeg.put("Intl Override ", dhdata.getIntl_Override());
				divertedFlownLegs.add(divertedLeg);
			}
			DepMatch=0;
			if(normalMap1!=null&&normalMap2!=null){
			if(normalMap1.get("Departure Station").equals(divertedLeg.get("Departure Station"))&&(normalMap1.get("Flight Number").equals(divertedLeg.get("Flight Number")))){
					dhdata.setIntl_Override(1);
					DepMatch = 1;
				}
			
			
				if(normalMap2.get("Arrival Station").equals(divertedLeg.get("Arrival Station"))&&(normalMap2.get("Flight Number").equals(divertedLeg.get("Flight Number")))){
					if(!divertedLeg.get("Departure Station").equals(normalMap2.get("Arrival Station"))){
						dhdata.setIntl_Override(1);
							DepMatch = 1;
					}
				}
			}
	       dhdata.setDepMatch(DepMatch);
	     
		}
//		main.setRawdata(raList);
//		main.setDhdata(dHeadList);
//		System.out.println(divertedFlownLegs);
		//Remove from both lists the records with Flight Number > 9000 when the total records by the key is less than 4 times.
		return main;
		
	}

	@Override
	public void IdentifyandcheckDivertedFlownLegs(FlightAttendantTempModel main) {
		
		
	}

	@Override
	public void IdentifyReturnsToGate(FlightAttendantTempModel main) {
		
		for(RAWDATA rawdata:main.getRawdata()){
			if(rawdata.getEMPNo()==rawdata.getSEQ_EMPNo()&&rawdata.getSEQUENCE_NUMBER()==rawdata.getLEG_SEQUENCE_NUMBER()&&rawdata.getDepMatch()==1){
				if(rawdata.getDepMatch()==1&&rawdata.getARRIVAL_STATION().equals(rawdata.getDEPARTURE_STATION())&&rawdata.getIRREGULAR_LEG_INDICATOR()>0&&rawdata.getIntl_Override()==0){
					rawdata.setIntl_Override(1);
				}
			}
			if(rawdata.getEMPNo()==rawdata.getSEQ_EMPNo()&&rawdata.getSEQUENCE_NUMBER()==rawdata.getLEG_SEQUENCE_NUMBER()&&rawdata.getIntl_Override()==1){
				if(rawdata.getIntl_Override()==1&&rawdata.getARRIVAL_STATION().equals(rawdata.getDEPARTURE_STATION())&&rawdata.getIRREGULAR_LEG_INDICATOR()>0&&rawdata.getIntl_Override()==0){
					rawdata.setIntl_Override(1);
				}
			}
		}
		for(RAWDATA dhdata:main.getDhdata()){
			if(dhdata.getEMPNo()==dhdata.getSEQ_EMPNo()&&dhdata.getSEQUENCE_NUMBER()==dhdata.getLEG_SEQUENCE_NUMBER()&&dhdata.getDepMatch()==1){
				if(dhdata.getDepMatch()==1&&dhdata.getARRIVAL_STATION().equals(dhdata.getDEPARTURE_STATION())&&dhdata.getIRREGULAR_LEG_INDICATOR()>0&&dhdata.getIntl_Override()==0){
					dhdata.setIntl_Override(1);
				}
			}
			if(dhdata.getEMPNo()==dhdata.getSEQ_EMPNo()&&dhdata.getSEQUENCE_NUMBER()==dhdata.getLEG_SEQUENCE_NUMBER()&&dhdata.getIntl_Override()==1){
				if(dhdata.getIntl_Override()==1&&dhdata.getARRIVAL_STATION().equals(dhdata.getDEPARTURE_STATION())&&dhdata.getIRREGULAR_LEG_INDICATOR()>0&&dhdata.getIntl_Override()==0){
					dhdata.setIntl_Override(1);
				}
			}
		}	
		
	}
	
}
