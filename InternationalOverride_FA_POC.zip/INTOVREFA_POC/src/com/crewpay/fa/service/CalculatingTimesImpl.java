package com.crewpay.fa.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.List;

import com.crewpay.fa.model.FlightAttendantTempModel;
import com.crewpay.fa.model.RAWDATA;

public class CalculatingTimesImpl implements CalculatingTimes{

	

	@Override
	public void calculateFlyingTimesbasedonDutyPeriods(FlightAttendantTempModel faTempModel) throws ParseException {
//		System.out.println(faTempModel.getDpdata().size());
		List<RAWDATA> dpdataList=faTempModel.getDpdata();
		Collections.sort(dpdataList, Comparator.comparing(RAWDATA::getEMPNo)
														.thenComparing(RAWDATA::getSEQUENCE_NUMBER)
														.thenComparing(Comparator.comparing(RAWDATA::getXDTYPER)
																				.reversed())
														.thenComparing(RAWDATA::getLEG));
		
		Calendar cal=Calendar.getInstance();
		int empNo=0;
		int seqNo=0;
		int dpNo=0;
		int DP_A_ETIME_OK =0;
		int CO_DP_A_ETIME_OK=0;
		int SEQ_LAST_LEG_OK=0;
		int USED_FCRM_ETIME=0;
		int DATE_15=0;
		String USE_DPDATE=null;
		int S_USE_DPDATE = 0;
		int DP_LCL_ST =0;
		int DP_ACT_LEN =0;
		String USE_TRIPTYPE=null;
		int i=1;
		System.out.println("Dpdata size...."+faTempModel.getDpdata().size());
		for(RAWDATA dpdata:faTempModel.getDpdata()){
			System.out.println("dpList......"+i);
//			�SET UP VARIABLE FOR WHAT E TIME IS OK TO ADD UP�
//			System.out.println(dpdata.getDP_ACTL_DUTY_PER_CR_MNS()+"---"+dpdata.getOTH_ACTL_DUTY_PER_CR_MNS());
			 DP_A_ETIME_OK =dpdata.getDP_ACTL_DUTY_PER_CR_MNS()+dpdata.getOTH_ACTL_DUTY_PER_CR_MNS();
			 
//			�SET UP VARIABLE FOR CARRYOVER SEQ� 
			
			
			CO_DP_A_ETIME_OK = 0 ;
			
			if(dpdata.getSEQ_REMOVAL_CODE()==0){
				USE_DPDATE=dpdata.getDP_ACTUAL_START_DATE();
				if(USE_DPDATE.equals("0")){
					USE_DPDATE=dpdata.getDP_SCHEDULED_START_DATE();
				}
			}
			
			else {
				USE_DPDATE =dpdata.getDP_SCHEDULED_START_DATE();
			}
			if(USE_DPDATE.equals("0")){
				cal.setTime(convertindIntoDateType(dpdata.getDP_SCHEDULED_START_DATE()));
				S_USE_DPDATE=cal.get(Calendar.DATE);
				S_USE_DPDATE=S_USE_DPDATE+(dpdata.getXDTYPER()-1);
			}
			else{
				cal.setTime(convertindIntoDateType(USE_DPDATE));
				S_USE_DPDATE=cal.get(Calendar.DATE);
			}
			
			cal.setTime(convertindIntoDateType(dpdata.getPROCESSING_START_DATE()));
			int startDate=cal.get(Calendar.DATE);
			cal.setTime(convertindIntoDateType(dpdata.getPROCESSING_END_DATE()));
			int endDate=cal.get(Calendar.DATE);
			if(S_USE_DPDATE>=startDate && S_USE_DPDATE<=endDate){
				CO_DP_A_ETIME_OK = DP_A_ETIME_OK;
			}
			
			if(S_USE_DPDATE==(startDate-1)){
				DP_LCL_ST=(dpdata.getDP_ACTUAL_START_TIME()-dpdata.getDP_STR_GMT_ADJMT_MNS())%1440;
				DP_ACT_LEN=dpdata.getDP_ACTUAL_END_TIME()-dpdata.getDP_ACTUAL_START_TIME();
				if((DP_LCL_ST+DP_ACT_LEN)>1440)
					 CO_DP_A_ETIME_OK=DP_A_ETIME_OK;
			}

			if(dpdata.getLast_Leg_Ok()!=null){
				if(dpdata.getLast_Leg_Ok()==0){
					DP_A_ETIME_OK=0;
					CO_DP_A_ETIME_OK=0;
				}
			
//				�IF DUTY PERIOD DOES NOT HAVE ANY INTL FLYING OR A DOM DH LEG 
//				THAT IS OK TO PAY (SPECIAL!) THEN LAST LEG IS NOT OK TO PAY E TIME�
				if(dpdata.getLast_Leg_Ok()==1&&dpdata.getTotalIntlCount()==0&&dpdata.getSpecialFlag()==0){
					DP_A_ETIME_OK=0;
					CO_DP_A_ETIME_OK=0;
				}
				
//				100 
//					1 
//						1
//						2
//						3
//				101 
//					2	 
//						1
//						2
				
			
//				 �IF EMP IS A RSV AND SEQ IS UNPAID AND IS LAST DUTY PERIOD, THEN DON'T 
//				 WANT TO ADD IN THE E TIME, UNLESS SEQ ADD CODE IS OK (L2,OR,RA,CR)�

				int MATCH_OTHREC=1;
			if(dpNo>=dpdata.getXDTYPER()){
//					System.out.println(dpdata.getSEQUENCE_NUMBER()+"-----"+dpdata.getXDTYPER());
					cal.setTime(convertindIntoDateType(dpdata.getDATE()));
				     DATE_15 = (cal.get(Calendar.DATE) * 100) + 15 ; 
				     cal.setTime(convertindIntoDateType(dpdata.getSCHEDULED_START_DATE()));
				     if(cal.get(Calendar.DATE) < DATE_15 && MATCH_OTHREC == 1){
				             USE_TRIPTYPE = dpdata.getOTH_TRIP_TYPE();         
				     }
				     else{
				    	  USE_TRIPTYPE = dpdata.getTRIP_TYPE();         
				     }
				     
				     if(USE_TRIPTYPE.equals("6")||USE_TRIPTYPE.equals("7")){
				    	 if(!dpdata.getSEQ_CNTRTL_PATH_INDR().equals("6")||!dpdata.getSEQ_CNTRTL_PATH_INDR().equals("7")){
				    		 List<Integer> assCodes=new ArrayList<>();
				    		 assCodes.add(78);
				    		 assCodes.add(87);
				    		 assCodes.add(30);
				    		 assCodes.add(93);
				    		 if(!assCodes.contains(dpdata.getASSIGNMENT_REASON_CODE())){
				    			 DP_A_ETIME_OK = 0;         
				                 CO_DP_A_ETIME_OK = 0;      
 
				    		 }
				    	 }
				     }
			}
			SEQ_LAST_LEG_OK=0;
			if(empNo==dpdata.getEMPNo()&&seqNo==dpdata.getSEQUENCE_NUMBER()&&dpNo>=dpdata.getXDTYPER()){
					SEQ_LAST_LEG_OK=dpdata.getLast_Leg_Ok();
				}
			}
//				�NOW DO CHECK TO SEE IF MY CALCULATED DP E TIME IS GTR THAN   
//				WHAT FCRM HAS (FOR THE CARRYOVER IN PARTICULAR). IF SO, THEN   
//				USE WHAT FCRM HAS(IT WILL BE RIGHT BECAUSE OF MIDNIGHT CUTOFF)� 

				
				
				if(CO_DP_A_ETIME_OK <=dpdata.getDP_ACTL_DUTY_PER_CR_MNS()){
					USED_FCRM_ETIME=1;
					CO_DP_A_ETIME_OK=dpdata.getDP_ACTL_DUTY_PER_CR_MNS();
				}
				
//					SDP_A_ETIME, SDP_A_ETIME_OK, SEQ_LAST_LEG_OK, CO_SDP_A_ETIME_OK and USED_FCRM_ETIME 
					dpdata.setSEQ_LAST_LEG_OK(SEQ_LAST_LEG_OK);
					dpdata.setUSED_FCRM_ETIME(USED_FCRM_ETIME);
					dpdata.setDP_A_ETIME_OK(DP_A_ETIME_OK);
					dpdata.setSEQ_LAST_LEG_OK(SEQ_LAST_LEG_OK);
					dpdata.setCO_DP_A_ETIME_OK(CO_DP_A_ETIME_OK);
					dpdata.setUSED_FCRM_ETIME(USED_FCRM_ETIME);
					dpdata.setSDP_A_ETIME(dpdata.getDP_ACTL_DUTY_PER_CR_MNS()+dpdata.getOTM_ACTL_DUTY_PER_CR_MNS());
					dpdata.setSDP_A_ETIME_OK(DP_A_ETIME_OK);
					dpdata.setCO_SDP_A_ETIME_OK(CO_DP_A_ETIME_OK);
					empNo=dpdata.getEMPNo();
					seqNo=dpdata.getSEQUENCE_NUMBER();
					dpNo=dpdata.getXDTYPER();
					i++;
		}
//		o	DP_LEG_GRTR_MNS	
//		o	DP_ACTL_DUTY_PER_CR_MNS	 
//		o	DP_DHD_MIN	
//		o	OTM_LEG_GRTR_MNS	 
//		o	OTM_ACTL_DUTY_PER_CR_MNS	  
//		o	OTM_DHD_MIN	 
//		o	DP_A_ETIME_OK 
//		o	SEQ_LAST_LEG_OK 
//		o	CO_DP_A_ETIME_OK
//		o	USED_FCRM_ETIME 

		
		
		Collections.sort(dpdataList, Comparator.comparing(RAWDATA::getEMPNo)
				 .thenComparing(RAWDATA::getSEQUENCE_NUMBER));

		List<RAWDATA> rawList=faTempModel.getRawdata();
		Collections.sort(rawList,Comparator.comparing(RAWDATA::getEMPNo)
												.thenComparing(RAWDATA::getSEQUENCE_NUMBER));
//		System.out.println(new HashSet<RAWDATA>(rawList));
		i=1;
		for(RAWDATA rawdata:rawList){
			System.out.println("Rawdata...."+i);
			for (RAWDATA dpdata : dpdataList) {
				if (rawdata.getEMPNo() == dpdata.getEMPNo() && rawdata.getSEQUENCE_NUMBER() == dpdata.getSEQUENCE_NUMBER()) {
					rawdata.setSDP_A_ETIME(dpdata.getSDP_A_ETIME());
					rawdata.setSDP_A_ETIME_OK(dpdata.getSDP_A_ETIME_OK());
					rawdata.setCO_SDP_A_ETIME_OK(dpdata.getCO_SDP_A_ETIME_OK());
				}
			}
			i++;
		}
//		System.out.println(new HashSet<RAWDATA>(rawList));
		faTempModel.setRawdata(rawList);
	}

	private Date convertindIntoDateType(String stringDate) throws ParseException {
		SimpleDateFormat sdf=null;
		Date date=null;
		if (stringDate != null) {
			if (stringDate.length() == 6) {
				sdf = new SimpleDateFormat("yyyymm");
				date = sdf.parse(stringDate + "00");
			} else {
				sdf = new SimpleDateFormat("yyyymmdd");
				date = sdf.parse(stringDate);
			}
		}
		
		return date;
	}

	@Override
	public void calculateFlyingTimesforDeadheads(FlightAttendantTempModel faTempModel) throws ParseException {
		List<RAWDATA> dhdataList=faTempModel.getDhdata();
		Collections.sort(dhdataList,Comparator.comparing(RAWDATA::getEMPNo)
											.thenComparing(RAWDATA::getSEQUENCE_NUMBER));
		
		Collections.sort(dhdataList,Comparator.comparing(RAWDATA::getLEG)
												.reversed());
		
		Calendar cal=Calendar.getInstance();
		int INT_DH_MIN = 0;           
		int CO_INT_DH_MIN = 0;                                   
		int	DOM_DH_MIN = 0;                                  
		String USE_LEGDATE = null;;
		int S_USE_LEGDATE = 0;
		int XLCLDEP = 0; 
		int EXTRA_INT_DH    = 0;                                                
		int CO_EXTRA_INT_DH = 0;                                             
		int EXTRA_DOM_DH    = 0;
		int SPLIT_TERM_MON_PD_CRD_DH = 0;                                      
		int	DH_AFT_12MID = 0;
		int DH_XLCLARR=0;
		int DH_XLCLARR_2=0;
		for(RAWDATA dhdata:dhdataList){
			
//			IF this is the first SEQ# of the EMP#
//			THEN DO                                  
//			     LAST_DP_CTR = 0                     
//			     TTL_FG = ACTL_SEQ_CR_MNS + OTH_ACTL_SEQ_CR_MNS
//			     TTL_E = 0                           
//			     END      

			 
			INT_DH_MIN = 0;                               
			CO_INT_DH_MIN = 0;                                   
			DOM_DH_MIN = 0;                                  
			dhdata.setSCH_BLK(dhdata.getLEG_SCHEDULED_END_TIME()-dhdata.getLEG_SCHEDULED_START_TIME());
			dhdata.setSCH_BLK_MIN(dhdata.getSCH_BLK());
			dhdata.setSCH_BLK((dhdata.getSCH_BLK()/60)+((dhdata.getSCH_BLK()%60)/100));
//			�INTERNATIONAL DEADHEAD�
			if(dhdata.getIntl_Override()==1){
					INT_DH_MIN=dhdata.getDH_BLOCK();
					if(dhdata.getSEQ_REMOVAL_CODE()==0){
						USE_LEGDATE=dhdata.getLEG_ACTUAL_START_DATE();
					}
					else{
						USE_LEGDATE=dhdata.getLEG_SCHEDULED_START_DATE();
					}
					cal.setTime(convertindIntoDateType(USE_LEGDATE));
					S_USE_LEGDATE = cal.get(Calendar.DATE);
					cal.setTime(convertindIntoDateType(dhdata.getPROCESSING_START_DATE()));
					
					if(S_USE_LEGDATE==(cal.get(Calendar.DATE)-1)){
//						  �FLIGHT LEFT ON LAST DAY OF LAST MONTH, NEED TO CALC PORTION FOR
//                        THIS MONTH �
						if(dhdata.getLEG_ACTUAL_START_TIME()>0){
							XLCLDEP=dhdata.getLEG_ACTUAL_START_TIME()-dhdata.getSTR_GMT_ADJMT_MNS();
						}
						else{
							XLCLDEP=dhdata.getLEG_SCHEDULED_START_TIME()-dhdata.getSTR_GMT_ADJMT_MNS();
						}
						XLCLDEP=(XLCLDEP%1440);
						XLCLDEP=XLCLDEP+dhdata.getDH_BLOCK();
						if(XLCLDEP>1440){
							CO_INT_DH_MIN =dhdata.getDH_BLOCK()-(1440-XLCLDEP/2);
						}
					}
					if(S_USE_LEGDATE>(cal.get(Calendar.DATE)-1)){
						CO_INT_DH_MIN=dhdata.getDH_BLOCK();
					}
			}
			else{
				DOM_DH_MIN=dhdata.getDH_BLOCK();
			}
//			IF TTL_FG > 0                                                  
//			THEN DO                                                       
//			     �THERE IS F/G TIME, NEED TO SUBTRACT OUT FROM LAST DH� 
//			     IF TTL_FG > LEG_EX_DH                                     
//			     THEN DO                                                   
//			          TTL_FG = TTL_FG - LEG_EX_DH                          
//			          LEG_EX_DH = 0                                       
//			          END                                                 
//			     ELSE DO                                                  
//			          LEG_EX_DH = LEG_EX_DH - TTL_FG                      
//			          TTL_FG = 0                                           
//			          END                                                 
//			     END       

			
//			�NOW CAN SEE IF EXTRA DH IS LEFT, AND IF IT IS DOM OR INTL�  
			EXTRA_INT_DH    = 0 ;                                              
			CO_EXTRA_INT_DH = 0 ;                                           
			EXTRA_DOM_DH    = 0 ;
		
SPLIT_TERM_MON_PD_CRD_DH = 0;                                     
			DH_AFT_12MID = 0;
			
//			�INTERNATIONAL DEADHEAD�
			if(dhdata.getIntl_Override()==1){
				EXTRA_INT_DH= dhdata.getLEG_EX_DH();
				
//				 � IF LEG WAS REMOVED, THEY DONT GET THE EXTRA DH�           
				if(dhdata.getLEG_REMOVAL_CODE()>0){
//			          �YES THEY DO IF SEQ REMOVED WITH CODE WE ARE PAYING�   
					if(dhdata.getREASON_PAY_INDICATOR()!=1){
						EXTRA_INT_DH=0;
					}
				}
//			     �NEED TO CALCULATE THE AMOUNT OF EXTRA_INT_DH THAT IS      
//			      IN THE  C/O MONTH, IF DH LEG CROSSES MIDNIGHT�           

				cal.setTime(convertindIntoDateType(dhdata.getPROCESSING_START_DATE()));
				if(S_USE_LEGDATE>=cal.get(Calendar.DATE)){
					CO_EXTRA_INT_DH=EXTRA_INT_DH;
				}
				
				if(S_USE_LEGDATE==(cal.get(Calendar.DATE)-1)){
					DH_XLCLARR=XLCLDEP+dhdata.getDH_BLOCK()+EXTRA_INT_DH;
					if(DH_XLCLARR > 1440){
						DH_AFT_12MID = 1;
						
//						� NEED TO SPLIT THE PART THAT IS C/O IN TWO: HALF WILL GO TO 
//						SEQ VAL (P&C DH) ,  OTHER HALF WILL BE DH PAY ONLY �                

						CO_EXTRA_INT_DH = (DH_XLCLARR - 1440)/2;
						
//			               �NEED TO ADD TO THE PAID DH TIME IN C/O MONTH �   
						CO_INT_DH_MIN = CO_INT_DH_MIN + ((DH_XLCLARR - 1440) - CO_EXTRA_INT_DH);
						
					}
					DH_XLCLARR_2 = XLCLDEP + dhdata.getSCH_BLK_MIN() ;
					if(DH_XLCLARR_2 > 1440){
					     SPLIT_TERM_MON_PD_CRD_DH =  ((DH_XLCLARR_2 - 1440)/2);      
					}
				}
			}
			else{
				EXTRA_DOM_DH = dhdata.getLEG_EX_DH();
//				LAST_DP_CTR = DP_CTR  ;
			}
			
			dhdata.setINT_DH_MIN(INT_DH_MIN);
			dhdata.setDOM_DH_MIN(DOM_DH_MIN);
			dhdata.setEXTRA_INT_DH(EXTRA_INT_DH);
			dhdata.setEXTRA_DOM_DH(EXTRA_DOM_DH);
			dhdata.setCO_INT_DH_MIN(CO_INT_DH_MIN);
			dhdata.setCO_EXTRA_INT_DH(CO_EXTRA_INT_DH);
			dhdata.setSPLIT_TERM_MON_PD_CRD_DH(SPLIT_TERM_MON_PD_CRD_DH);
			dhdata.setDH_AFT_12MID(DH_AFT_12MID);
			int TTL_DH = 0;
			int EXTRA_DH = 0;
			TTL_DH = dhdata.getDH_SCHED();
			EXTRA_DH =TTL_DH - (dhdata.getDHD_MIN()+dhdata.getOTH_DHD_MIN());
			int TTL_E_FG =dhdata.getACTL_DUTY_PER_CR_MNS() + dhdata.getACTL_SEQ_CR_MNS()   + dhdata.getOTH_ACTL_DUTY_PER_CR_MNS() +	 dhdata.getOTH_ACTL_SEQ_CR_MNS();
			
			EXTRA_DH = Math.max(0,(EXTRA_DH - TTL_E_FG)); 

			   
//			�	Perform also if Seq Removal Code > 0 AND  Reason Pay Indicator <> 1:                                            
//			          EXTRA_DH        = 0                              
//			          EXTRA_INT_DH    = 0                             
//			          CO_EXTRA_INT_DH = 0                              
//			          EXTRA_DOM_DH    = 0                              
//
//
//
			if(dhdata.getSEQ_REMOVAL_CODE()>0 && dhdata.getREASON_PAY_INDICATOR()==1){
			    EXTRA_DH = 0;
				EXTRA_INT_DH = 0;
				CO_EXTRA_INT_DH = 0;
				EXTRA_DOM_DH = 0;
			}
			
			dhdata.setTTL_DH(TTL_DH);
			dhdata.setEXTRA_DH(EXTRA_DH);
			dhdata.setCO_EXTRA_INT_DH(CO_EXTRA_INT_DH);
			dhdata.setEXTRA_DOM_DH(EXTRA_DOM_DH);
		}	
//			�	Sort and Merge by Emp# / Seq# the summarized file above and RAWDATA file, updating the fields of RAWDATA when matching:  
//
//			INT_DH_MIN   
//			DOM_DH_MIN   
//			TTL_DH   
//			EXTRA_DH  
//			EXTRA_INT_DH
//			EXTRA_DOM_DH 
//			CO_EXTRA_INT_DH         
//			CO_INT_DH_MIN DH_AFT_12MID                        
//			SPLIT_TERM_MON_PD_CRD_DH;                         
//		
		Collections.sort(dhdataList,Comparator.comparing(RAWDATA::getEMPNo)
											.thenComparing(RAWDATA::getSEQUENCE_NUMBER));
		
		List<RAWDATA> rawList=faTempModel.getRawdata();
		Collections.sort(rawList,Comparator.comparing(RAWDATA::getEMPNo)
												.thenComparing(RAWDATA::getSEQUENCE_NUMBER));

		for(RAWDATA rawdata:rawList){
			for (RAWDATA dhdata : dhdataList) {
				if (rawdata.getEMPNo() == dhdata.getEMPNo() && rawdata.getSEQUENCE_NUMBER() == dhdata.getSEQUENCE_NUMBER()) {
					rawdata.setINT_DH_MIN(dhdata.getINT_DH_MIN());
					rawdata.setDOM_DH_MIN(dhdata.getDOM_DH_MIN());
					rawdata.setTTL_DH(dhdata.getTTL_DH());
					rawdata.setEXTRA_DH(dhdata.getEXTRA_DH());
					rawdata.setEXTRA_INT_DH(dhdata.getEXTRA_INT_DH());
					rawdata.setCO_EXTRA_INT_DH(dhdata.getCO_EXTRA_INT_DH());
					rawdata.setCO_INT_DH_MIN_DH_AFT_12MID(dhdata.getDH_AFT_12MID());
					rawdata.setSPLIT_TERM_MON_PD_CRD_DH(dhdata.getSPLIT_TERM_MON_PD_CRD_DH());
				}
			}
		}
//			�	After these updates the DH Sequences will be no longer needed. 

//		System.out.println(rawList);
	}
	
	
	
}
