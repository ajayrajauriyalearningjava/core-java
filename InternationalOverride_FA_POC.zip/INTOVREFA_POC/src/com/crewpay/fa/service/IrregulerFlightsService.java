package com.crewpay.fa.service;

import com.crewpay.fa.model.FlightAttendantTempModel;

public interface IrregulerFlightsService {

	public FlightAttendantTempModel listOfNormalFlights(FlightAttendantTempModel main);
	
	public void IdentifyandcheckDivertedFlownLegs(FlightAttendantTempModel main);
	
	public void IdentifyReturnsToGate(FlightAttendantTempModel main);
}
