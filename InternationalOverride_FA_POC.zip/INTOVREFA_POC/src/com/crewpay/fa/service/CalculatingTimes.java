package com.crewpay.fa.service;

import java.text.ParseException;

import com.crewpay.fa.model.FlightAttendantTempModel;

public interface CalculatingTimes {
	
	public void calculateFlyingTimesbasedonDutyPeriods(FlightAttendantTempModel faTempModel) throws ParseException;
	
	public void calculateFlyingTimesforDeadheads(FlightAttendantTempModel faTempModel) throws ParseException;
	
	
}
