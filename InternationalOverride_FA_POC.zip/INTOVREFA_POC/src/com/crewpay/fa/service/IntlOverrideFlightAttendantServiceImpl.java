package com.crewpay.fa.service;

import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Field;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.supercsv.io.CsvBeanWriter;
import org.supercsv.io.ICsvBeanWriter;
import org.supercsv.prefs.CsvPreference;

import com.crewpay.fa.commons.FlightAttendantUtil;
import com.crewpay.fa.model.CITYCODE;
import com.crewpay.fa.model.CrewMembers;
import com.crewpay.fa.model.Dutyperiods;
import com.crewpay.fa.model.FlightAttendantModel;
import com.crewpay.fa.model.FlightAttendantTempModel;
import com.crewpay.fa.model.Legs;
import com.crewpay.fa.model.RAWDATA;
import com.crewpay.fa.model.ReasonGroups;
import com.crewpay.fa.model.Sequences;


public class IntlOverrideFlightAttendantServiceImpl implements IntlOverrideFlightAttendantService{
	@Override
	public FlightAttendantTempModel flightAttendantTempModelScenarios(FlightAttendantModel faModel)
			throws IllegalArgumentException, IllegalAccessException, ParseException, IOException {
		FlightAttendantTempModel faTempModel=gettingAuxiliaryData(faModel);
		processFlownSequences(faTempModel);
//		System.out.println(new HashSet<RAWDATA>(faTempModel.getDhdata()));
		IrregulerFlightsService irService=new IrregulerFlightsServiceImpl();
//		System.out.println(faTempModel.getDpdata());
		irService.listOfNormalFlights(faTempModel);
		irService.IdentifyandcheckDivertedFlownLegs(faTempModel);
		irService.IdentifyReturnsToGate(faTempModel);
//		System.out.println(faTempModel.getRawdata());
		SequenceUpdateService updateSequenceService=new SequenceUpdateServiceImpl();
		updateSequenceService.deleteSequenceWithoutLegs(faTempModel);
		updateSequenceService.specialPayFlag(faTempModel);
		updateSequenceService.domesticDeadheadsAndIrregularFlights(faTempModel);
		System.out.println("updateSequenceService.filterDeadheadSeuences(faTempModel.getDhdata())");
		updateSequenceService.filterDeadheadSeuences(faTempModel.getDhdata());
		UpdatesFromOtherMonthFiles updatesFromOtherMonthFiles=new UpdatesFromOtherMonthFilesImpl();
		updatesFromOtherMonthFiles.DPDATA(faTempModel);
		updatesFromOtherMonthFiles.DHDATA(faTempModel);
		updatesFromOtherMonthFiles.RAWDATA(faTempModel);
		CalculatingTimes calculatingTimes=new CalculatingTimesImpl();
		System.out.println("calculatingTimes.calculateFlyingTimesbasedonDutyPeriods(faTempModel)");
		calculatingTimes.calculateFlyingTimesbasedonDutyPeriods(faTempModel);
		System.out.println("calculatingTimes.calculateFlyingTimesforDeadheads(faTempModel)");
		calculatingTimes.calculateFlyingTimesforDeadheads(faTempModel);
		FinalAdjustmentsOnTimes finalAdjustmentsOnTimes=new FinalAdjustmentsOnTimesImpl();
		System.out.println("finalAdjustmentsOnTimes.fix_GTR_BLK_onReturnstoGates(faTempModel)");
		finalAdjustmentsOnTimes.fix_GTR_BLK_onReturnstoGates(faTempModel);
		System.out.println("finalAdjustmentsOnTimes.calculateTotal_Actual_BLK_Time(faTempModel)");
		finalAdjustmentsOnTimes.calculateTotal_Actual_BLK_Time(faTempModel);
		System.out.println("Compleeted");
		return faTempModel;
	}
	public FlightAttendantTempModel gettingAuxiliaryData(FlightAttendantModel faModel)
			throws ParseException, IllegalArgumentException, IllegalAccessException, IOException {
		System.out.println("gettingAuxiliaryData()...");
		FlightAttendantTempModel flightAttendantTempModel=new FlightAttendantTempModel();
		RAWDATA dpdata = null;
		RAWDATA dhdata1 = null;
		RAWDATA dhdata2 = null;
		RAWDATA rawdata = null;
		RAWDATA alllegs = null;
		RAWDATA dhdata3 = null;
		RAWDATA othmon3=null;
		RAWDATA othmon2=null;
		List<RAWDATA> dpdataList = new ArrayList<>();
		List<RAWDATA> dhdata1List = new ArrayList<>();
		List<RAWDATA> dhdata2List = new ArrayList<>();
		List<RAWDATA> dhdata3List = new ArrayList<>();
		List<RAWDATA> rawdataList = new ArrayList<>();
		List<RAWDATA> alllegsList = new ArrayList<>();
		List<RAWDATA> othmon2List=new ArrayList<>();
		List<RAWDATA> othmon3List=new ArrayList<>();
		int legReasonIndecator=0;
		int seqReasonIndecator=0;
		int seqFlag=0;
		int dpFlag=0;
		int legFlag=0;
		int Last_Leg_Ok=0;
		int z=1;
		
		for (CrewMembers crewMember : faModel.getCrewMember()) {
			System.out.println("CrewMember..."+z);
//			if(z==15){
//				break;
//			}
			seqFlag=0;
			if((crewMember.getEMPNo()!=0)&&(!crewMember.getSAM_INDICATOR().equals("1"))&&(crewMember.getCREW_TYPE()!=8)&&(crewMember.getINACTIVE() != 'S')&& ((crewMember.getINACTIVE() != 'I'))){
//			System.out.println(crewMember.getDATE());
				int Inact_FA_CO_Seq;
				for (Sequences sequences : crewMember.getSequences()) {
					for(Field field:sequences.getClass().getSuperclass().getDeclaredFields()){
						field.set(sequences, field.get(crewMember));
					}
//					othmon2=new RAWDATA();
//					othmon2=setOthmonFields((Dutyperiods) sequences,othmon3);
					
					seqFlag=seqFlag+1;
					dpFlag=0;
					legFlag=0;
//					for(IgnoredStations iStations:faModel.getIgnoredStations()){
//						if(!iStations.getSCH_START_DATE().equals(sequences.getSCHEDULED_START_DATE())&&iStations.getSEQUENCE_NUMBER()!=sequences.getSEQUENCE_NUMBER()){
//					for(PARAMETERS parameters:faModel.getParameters()){
//						System.out.println(parameters);
//						if ((crewMember.getINACTIVE() == 'I')&& (sequences.getSCHEDULED_START_DATE().compareTo(parameters.getSTART_DATE()) < 0)) {
//							Inact_FA_CO_Seq = 1;
//						}
//						if ((parameters.getCO_SEQ_PROCESSING_FLAG()!='Y')&& (sequences.getSCHEDULED_START_DATE().compareTo(parameters.getPROCESSING_START_DATE()) < 0)
//								|| ((parameters.getCO_SEQ_PROCESSING_FLAG()!='Y')&& (sequences.getSCHEDULED_START_DATE().compareTo(parameters.getPROCESSING_START_DATE()) >= 0))) {
								if (((sequences.getSEQ_CREWMEMBER_POSITION() != 0) && (sequences.getSEQUENCE_NUMBER() > 0))|| (sequences.getSEQ_CREWMEMBER_POSITION() < 59)&& (sequences.getASSIGNMENT_REASON_CODE() != 247)) {
									for (Dutyperiods dutyperiods : sequences.getDutyperiods()) {
										for(Field field:dutyperiods.getClass().getSuperclass().getFields()){
											field.set(dutyperiods, field.get(sequences));
										}
										othmon3=new RAWDATA();
										othmon3=(RAWDATA) FlightAttendantUtil.writingIntoDataSets(crewMember, othmon3);
										othmon3=(RAWDATA) FlightAttendantUtil.writingIntoDataSets(sequences, othmon3);
										othmon3=(RAWDATA) FlightAttendantUtil.writingIntoDataSets(dutyperiods, othmon3);
										othmon3.setOTH_ACTL_DUTY_PER_CR_MNS(sequences.getACTL_DUTY_PER_CR_MNS());
										othmon3.setOTH_ACTL_SEQ_CR_MNS(sequences.getACTL_SEQ_CR_MNS());
										othmon3.setOTH_DHD_MIN(sequences.getDHD_MIN());
										othmon3.setOTH_DOM_INTL_CODE(crewMember.getDOM_INTL_CODE());
										othmon3.setOTH_INACTIVE(crewMember.getINACTIVE());
//										othmon3.setOTH_LEG_GRTR_MNS(dutyperiods.getLEG_GRTR_MNS());
										othmon3.setOTH_TRIP_TYPE(crewMember.getTRIP_TYPE());
										othmon3.setOTM_ACTL_DUTY_PER_CR_MNS(dutyperiods.getDP_ACTL_DUTY_PER_CR_MNS());
										othmon3.setOTM_DHD_MIN(dutyperiods.getDP_DHD_MIN());
										othmon3.setOTM_LEG_GRTR_MNS(dutyperiods.getDP_LEG_GRTR_MNS());
										othmon3.setMatch_OthRec(1);
										dpFlag=dpFlag+1;
//										System.out.println(sequences.getSEQ_REMOVAL_CODE()+"---------"+ seqReasonIndecator);
										if ((sequences.getSEQ_REMOVAL_CODE() == 0)&& seqReasonIndecator == 1) {
//											System.out.println("2====>"+sequences.getSEQ_REMOVAL_CODE());
											dpdata=new RAWDATA();
											dpdata=(RAWDATA) FlightAttendantUtil.writingIntoDataSets(crewMember, dpdata);
											dpdata=(RAWDATA) FlightAttendantUtil.writingIntoDataSets(sequences, dpdata);
											dpdata=(RAWDATA) FlightAttendantUtil.writingIntoDataSets(dutyperiods, dpdata);
											//dpdata.setLEG(legFlag);
											dpdataList.add(dpdata);
										}
//										System.out.println(dutyperiods.getLegs());
										if(dutyperiods.getLegs()!=null){
											for(Legs legs:dutyperiods.getLegs()){
												for(Field field:legs.getClass().getSuperclass().getFields()){
													field.set(legs, field.get(dutyperiods));
												}
												legFlag=legFlag+1;
												if((sequences.getSEQ_CREWMEMBER_POSITION()!=0)&&((legs.getLEG_CREWMEMBER_POSITION()!=0)||(sequences.getSEQUENCE_NUMBER()>0)&&legs.getLEG()!=0)){
									
//														if ((sequences.getSCHEDULED_START_DATE().compareTo(parameters.getSTART_DATE())< 0)) {
														for(ReasonGroups reasonGroups:faModel.reasonGroups){
//															System.out.println(reasonGroups.getREASON_CODE()+"-------------"+sequences.getSEQ_REMOVAL_CODE());
															if ((reasonGroups.getREASON_CODE()!=null)&&(reasonGroups.getREASON_CODE().equals(sequences.getSEQ_REMOVAL_CODE()))) {
//																System.out.println("1====>"+sequences.getSEQ_REMOVAL_CODE());
																seqReasonIndecator=reasonGroups.getREASON_PAY_INDICATOR();
															}
															else if(reasonGroups.getREASON_CODE().equals(legs.getLEG_REMOVAL_CODE())){
																legReasonIndecator=reasonGroups.getREASON_PAY_INDICATOR();
															}
														}
//														if(othmon2.getSEQ_REMOVAL_CODE()==0&&seqReasonIndecator==1){
//															othmon2List.add(othmon2);
//														}
														if(othmon3.getSEQ_REMOVAL_CODE()==0&&seqReasonIndecator==1){
															othmon3List.add(othmon3);
														}
//															System.out.println(legs.getLEG()+"-----"+crewMember.getINACTIVE()+"----"+sequences.getSCHEDULED_START_DATE()+"----"+parameters.getSTART_DATE());
														
//															System.out.println(parameters.getCO_SEQ_PROCESSING_FLAG()+"---"+sequences.getSCHEDULED_START_DATE()+"----"+parameters.getPROCESSING_START_DATE());
//														System.out.println(legs.getCANCELLED_LEG_INDICATOR()+"---"+legs.getLEG_REMOVAL_CODE()+"<-------->"+legs.getDEADHEAD_INDICATOR());
														if ((legs.getCANCELLED_LEG_INDICATOR() == 0)|| (legs.getLEG_REMOVAL_CODE() != 0)) {
															if ((legs.getCANCELLED_LEG_INDICATOR() == 0)&& (!legs.getDEADHEAD_INDICATOR().equals("000") )) {
																if ((legs.getLEG_REMOVAL_CODE() == 0)&& (legReasonIndecator == 1)) {
																	dhdata1=new RAWDATA();
																	dhdata1=(RAWDATA) FlightAttendantUtil.writingIntoDataSets(crewMember, dhdata1);
																	dhdata1=(RAWDATA) FlightAttendantUtil.writingIntoDataSets(sequences, dhdata1);
																	dhdata1=(RAWDATA) FlightAttendantUtil.writingIntoDataSets(dutyperiods, dhdata1);
																	dhdata1=(RAWDATA) FlightAttendantUtil.writingIntoDataSets(legs, dhdata1);
																	dhdata1.setREASON_PAY_INDICATOR(legReasonIndecator);
																	dhdata1List.add(dhdata1);
																}
															}
															if ((legs.getCANCELLED_LEG_INDICATOR() != 0)&& (legs.getDEADHEAD_INDICATOR().compareTo("000")>0)) {
																dhdata2=new RAWDATA();
																dhdata2=(RAWDATA) FlightAttendantUtil.writingIntoDataSets(crewMember, dhdata2);
																dhdata2=(RAWDATA) FlightAttendantUtil.writingIntoDataSets(sequences, dhdata2);
																dhdata2=(RAWDATA) FlightAttendantUtil.writingIntoDataSets(dutyperiods, dhdata2);
																dhdata2=(RAWDATA) FlightAttendantUtil.writingIntoDataSets(legs, dhdata2);
																dhdata2.setREASON_PAY_INDICATOR(legReasonIndecator);
																dhdata2List.add(dhdata2);
															}
															if ((legs.getCANCELLED_LEG_INDICATOR() == 0)&& (legs.getDEADHEAD_INDICATOR().equals("000"))) {
																if ((legs.getLEG_REMOVAL_CODE() == 0)&& (legReasonIndecator == 1)) {
																	rawdata = new RAWDATA();
																	rawdata=(RAWDATA) FlightAttendantUtil.writingIntoDataSets(crewMember, rawdata);
																	rawdata=(RAWDATA) FlightAttendantUtil.writingIntoDataSets(sequences, rawdata);
																	rawdata=(RAWDATA) FlightAttendantUtil.writingIntoDataSets(dutyperiods, rawdata);
																	rawdata=(RAWDATA) FlightAttendantUtil.writingIntoDataSets(legs, rawdata);
																	rawdata.setREASON_PAY_INDICATOR(legReasonIndecator);
																	rawdataList.add(rawdata);
																} else if ((sequences.getSEQ_REMOVAL_CODE() == 0)&& (legs.getLEG_REMOVAL_CODE() > 0)) {
																	dhdata3 = new RAWDATA();
																	dhdata3=(RAWDATA) FlightAttendantUtil.writingIntoDataSets(crewMember, dhdata3);
																	dhdata3=(RAWDATA) FlightAttendantUtil.writingIntoDataSets(sequences, dhdata3);
																	dhdata3=(RAWDATA) FlightAttendantUtil.writingIntoDataSets(dutyperiods, dhdata3);
																	dhdata3=(RAWDATA) FlightAttendantUtil.writingIntoDataSets(legs, dhdata3);
																	dhdata3.setREASON_PAY_INDICATOR(legReasonIndecator);
																	dhdata3List.add(dhdata3);
																} else {
															//	discard the record
																}	
															}
														}
													}
													alllegs = new RAWDATA();
													alllegs.setEMPNo(crewMember.getEMPNo());
													alllegs.setSEQUENCE_NUMBER(sequences.getSEQUENCE_NUMBER());
													alllegs.setXDTYPER(dutyperiods.getXDTYPER());
													alllegs.setLEG(legs.getLEG());
													alllegs.setSEQ_REMOVAL_CODE(sequences.getSEQ_REMOVAL_CODE());
													alllegs.setLEG_REMOVAL_CODE(legs.getLEG_REMOVAL_CODE());
													if ((legs.getLEG_REMOVAL_CODE() == 0)&& (legReasonIndecator == 1)) {
														alllegs.setLast_Leg_Ok(Last_Leg_Ok);
													}
													alllegsList.add(alllegs);
												}
											}
										}
										}
									}
//								}
//							}
//						}
//    				}
//				}
			}z++;
		}
		flightAttendantTempModel=internationalCitiesList(faModel);
		flightAttendantTempModel.setDpdata(dpdataList);
		flightAttendantTempModel.setRawdata(rawdataList);
		flightAttendantTempModel.setDhdata1(dhdata1List);
		flightAttendantTempModel.setDhdata2(dhdata2List);
		flightAttendantTempModel.setAlllegs(alllegsList);
		flightAttendantTempModel.setDhdata3(dhdata3List);
		flightAttendantTempModel.setReasonGroups(faModel.getReasonGroups());
		flightAttendantTempModel.setOm2List(othmon2List);
		flightAttendantTempModel.setOm3List(othmon3List);
		return flightAttendantTempModel;
	}
		
	/*private RAWDATA setOthmonFields(Dutyperiods dutyperiods, RAWDATA othmon3) {
		othmon3=(RAWDATA) FlightAttendantUtil.writingIntoDataSets(dutyperiods, othmon3);
		for(Field field:othmon3.getClass().getDeclaredFields()){
			if(field.getName().startsWith("OTH")){
				othmon3.setOTH_ACTL_DUTY_PER_CR_MNS(dutyperiods.getACTL_DUTY_PER_CR_MNS());
				othmon3.setOTH_ACTL_SEQ_CR_MNS(dutyperiods.getACTL_SEQ_CR_MNS());
				othmon3.setOTH_DHD_MIN(dutyperiods.getDHD_MIN());
				othmon3.setOTH_DOM_INTL_CODE(dutyperiods.getDOM_INTL_CODE());
				othmon3.setOTH_INACTIVE(dutyperiods.getINACTIVE());
				othmon3.setOTH_LEG_GRTR_MNS(dutyperiods.getLEG_GRTR_MNS());
				othmon3.setOTH_TRIP_TYPE(dutyperiods.getTRIP_TYPE());
				
			}
			if(field.getName().startsWith("OTM")){
				othmon3.setOTM_ACTL_DUTY_PER_CR_MNS(dutyperiods.getDP_ACTL_DUTY_PER_CR_MNS());
				othmon3.setOTM_DHD_MIN(dutyperiods.getDP_DHD_MIN());
				othmon3.setOTM_LEG_GRTR_MNS(dutyperiods.getDP_LEG_GRTR_MNS());
			}
		}
		return othmon3;
		
	}*/
	public void processFlownSequences(FlightAttendantTempModel flightAttendantTempModel) {
		
		//mergingDpdataAndAlllegs
//		List<RAWDATA> dpdata=mergingDpdataAndAlllegs(flightAttendantTempModel.getDpdata(),flightAttendantTempModel.getAlllegs());
//		flightAttendantTempModel.setDpdata(dpdata);
		List<RAWDATA> dhdatabs=getDHDATABFromDHDATA(flightAttendantTempModel.getDhdata1());
//		System.out.println(dhdatabs.size());
		flightAttendantTempModel.setDhdatabs(dhdatabs);
		List<RAWDATA> activeDhdata=mergeAndDiscardDeadheads(flightAttendantTempModel);
//		System.out.println(activeDhdata.size());
		flightAttendantTempModel.setDhdata(activeDhdata);
		List<RAWDATA> activeRawdata=new ArrayList<>();
		boolean Intlflag = false;
		List<String> citycodes=new ArrayList<>();
		Set<String> stations=new HashSet<>();
		for (CITYCODE cities : flightAttendantTempModel.getCitycode()) {
			citycodes.add(cities.getSTATION().trim());
		}
		for(RAWDATA rawdata:flightAttendantTempModel.getRawdata()){
			stations.add(rawdata.getDEPARTURE_STATION());
			stations.add(rawdata.getARRIVAL_STATION());
		}
		for (RAWDATA rawdata : flightAttendantTempModel.getRawdata()) {
//			System.out.println(rawdata);
			// flagging international station
			if(citycodes.contains(rawdata.getARRIVAL_STATION().trim())){
				rawdata.setIntl_Override(1);
			}
			else if(citycodes.contains(rawdata.getDEPARTURE_STATION().trim())){
				rawdata.setIntl_Override(1);
			}
			else{
				rawdata.setIntl_Override(0);
			}
		
			//B.2 - 	Translate Crewmember Position Code
			int i=22;
			int j=01;
			if(rawdata.getSEQ_CREWMEMBER_POSITION()!=null||(rawdata.getSEQ_CREWMEMBER_POSITION() != null)){
				while(i!=40){
				if(rawdata.getSEQ_CREWMEMBER_POSITION() == i){
					rawdata.setSEQ_CREWMEMBER_POSITION(j);
				}
				if((rawdata.getLEG_CREWMEMBER_POSITION() == i)){
					rawdata.setLEG_CREWMEMBER_POSITION(j);
				}
				i++;
				j++;
				}
			}
			//B.3 - 	Calculate Diversion Times 
			//local Scheduled Departure Time
			int temp=0;
			temp=rawdata.getDP_SCHEDULED_START_TIME()-rawdata.getSTR_GMT_ADJMT_MNS();
			temp=(temp%1440);
			temp=FlightAttendantUtil.mod(temp);
			rawdata.setLCL_SDEP(temp);
			//	Local Actual Departure Time
			temp=0;
//			System.out.println("rawdata.getLEG_ACTUAL_START_TIME()--"+rawdata.getLEG_ACTUAL_START_TIME()+"rawdata.getSTR_GMT_ADJMT_MNS()--"+rawdata.getSTR_GMT_ADJMT_MNS());
			temp=rawdata.getLEG_ACTUAL_START_TIME()-rawdata.getSTR_GMT_ADJMT_MNS();
			temp=(temp%1440);
			temp=FlightAttendantUtil.mod(temp);
			rawdata.setLCL_ADEP(temp);
			
			//�	Scheduled Block Time
			
			temp = 0;
			int temp1 = 0;
			temp = rawdata.getLEG_SCHEDULED_END_TIME() - rawdata.getLEG_SCHEDULED_START_TIME();
			temp1 = temp;
			temp = FlightAttendantUtil.mod(temp);
			rawdata.setSCH_BLK(temp);
			rawdata.setSCH_BLK_MIN(temp1);

			// � Actual Block Time
			temp = 0;
			temp1 = 0;
			temp = rawdata.getLEG_ACTUAL_END_TIME() - rawdata.getLEG_ACTUAL_START_TIME();
			temp1 = temp;
			temp = FlightAttendantUtil.mod(temp);
			rawdata.setACT_BLK(temp);
			rawdata.setACT_BLK_MIN(temp1);

			// Actual TTL Time
			temp = 0;
			temp = rawdata.ACT_BLK_MIN + rawdata.ATC_MINS + rawdata.DEI_MINS + rawdata.RCD_MINS
					+ rawdata.DVR_MINS;
			temp = FlightAttendantUtil.mod(temp);
			rawdata.setTTL_ACT(temp);

			//  GTR Block Time
			temp = 0;
			temp = Math.max(rawdata.SCH_BLK_MIN, rawdata.TTL_ACT);
			temp1 = temp;
			temp = FlightAttendantUtil.mod(temp);
			rawdata.setGTR_BLK(temp);
			rawdata.setGTR_BLK_MIN(temp1);
			activeRawdata.add(rawdata);
		}
		
		//Filter deadHead Data
		for (RAWDATA deadheads :flightAttendantTempModel.getDhdata() ) {
			Intlflag = false;
			// flagging international station
			System.out.println(deadheads.getARRIVAL_STATION()+"-------"+deadheads.getDEPARTURE_STATION());
			if(citycodes.contains(deadheads.getARRIVAL_STATION().trim())||citycodes.contains(deadheads.getDEPARTURE_STATION().trim())){
				deadheads.setIntl_Override(1);
			}
			else{
				deadheads.setIntl_Override(0);
			}
			
			//B.2 - 	Translate Crewmember Position Code
			int i=22;
			int j=01;
			if(deadheads.getSEQ_CREWMEMBER_POSITION()!=null||(deadheads.getSEQ_CREWMEMBER_POSITION() != null)){
				while(i!=40){
				if(deadheads.getSEQ_CREWMEMBER_POSITION() == i){
					deadheads.setSEQ_CREWMEMBER_POSITION(j);
				}
				if((deadheads.getLEG_CREWMEMBER_POSITION() == i)){
					deadheads.setLEG_CREWMEMBER_POSITION(j);
				}
				i++;
				j++;
				}
			}
			//Claculate diversion times for deadheads
			deadheads.setDH_BLOCK(Math.toIntExact(deadheads.getLEG_SCHEDULED_END_TIME()-deadheads.getLEG_SCHEDULED_START_TIME())/2);
			deadheads.setDH_SCHED(Math.toIntExact(deadheads.getLEG_SCHEDULED_END_TIME()-deadheads.getLEG_SCHEDULED_START_TIME()));
		}
	//	flightAttendantTempModel.setRawdata(activeRawdata);
	//	return flightAttendantTempModel;
	}
	
	@SuppressWarnings("unchecked")
	public List<RAWDATA> mergingDpdataAndAlllegs(List<RAWDATA> dpdataList, List<RAWDATA> alllegsList) {
		List<RAWDATA> dutyperiodsList=new ArrayList<>();
		
		Collections.sort(dpdataList, Comparator.comparing(RAWDATA::getEMPNo)
												.thenComparing(RAWDATA::getSEQUENCE_NUMBER)
												.thenComparing(RAWDATA::getXDTYPER)
												.thenComparing(RAWDATA::getLEG));	
		
//		System.out.println(alllegsList.size());
			Collections.sort(alllegsList, Comparator.comparing(RAWDATA::getEMPNo)
													.thenComparing(RAWDATA::getSEQUENCE_NUMBER)
													.thenComparing(RAWDATA::getXDTYPER)
													.thenComparing(RAWDATA::getLEG));
			
//			System.out.println(alllegsList.size());
			for(RAWDATA dpdata:dpdataList){
				for(RAWDATA alllegs:alllegsList){
					if(dpdata.getEMPNo().equals(alllegs.getEMPNo())&&dpdata.getSEQUENCE_NUMBER().equals(alllegs.getSEQUENCE_NUMBER())&&dpdata.getXDTYPER().equals(alllegs.getXDTYPER())){
						dutyperiodsList.add(alllegs);
					}
				}
			}
//		System.out.println(dutyperiodsList.size());
		return dutyperiodsList;
	}
	public List<RAWDATA> getDHDATABFromDHDATA(List<RAWDATA> dhdata) {
		List<RAWDATA> dhdatabs=new ArrayList<>();
		RAWDATA dhdatab=new RAWDATA();
		for(RAWDATA dhdata1:dhdata){
			if(dhdata1.getLEG_REMOVAL_CODE()>0){
				for(Field field:dhdatab.getClass().getFields()){
					try {
//						System.out.println(field.getName()+"----"+dhdata1.getClass().getField(field.getName()).get(dhdata1));
						field.set(dhdatab,  field.get(dhdata1));
					} catch (IllegalArgumentException e) {
						e.printStackTrace();
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
				dhdatabs.add(dhdatab);
			}
		}
		return dhdatabs;
	}
	public FlightAttendantTempModel internationalCitiesList(FlightAttendantModel faModel) {
		FlightAttendantTempModel faTempModel=new FlightAttendantTempModel();
		List<CITYCODE> citypairList = new ArrayList<>();
		List<CITYCODE> citiesList = new ArrayList<>();
		CITYCODE cities = null;
		CITYCODE citypair = null;
		for (CITYCODE citycode : faModel.getCitycode()) {
			if (citycode.getNAME() != null && citycode.getEXCEPTION_INDICATOR() != null) {
				if ((citycode.getNAME().equals("EXCEPTION")) && (citycode.getEXCEPTION_INDICATOR().equals("XXX"))) {
					citypair = new CITYCODE();
					citypair.setSTATION(citycode.getSTATION());
					citypair.setEXCEPTION_INDICATOR(citycode.getEXCEPTION_INDICATOR());
					citypair.setLOCATION(citycode.getLOCATION());
					citypair.setNAME(citycode.getNAME());
					citypair.setSTATE(citycode.getSTATE());
					citypair.setUS_INDICATOR(citycode.getUS_INDICATOR());
					citypairList.add(citypair);
				}else if (citycode.getLOCATION() != null && citycode.getUS_INDICATOR() != null
						&& citycode.getSTATE() != null) {
					if (((citycode.getUS_INDICATOR().equals("NO"))
							&& (!citycode.getLOCATION().equals("CA") || !citycode.getLOCATION().equals("US")))
							|| ((citycode.getUS_INDICATOR().equals("NC") && citycode.getSTATE().equals("HI")))) {
						cities = new CITYCODE();
						cities.setSTATION(citycode.getSTATION());
						cities.setEXCEPTION_INDICATOR(citycode.getEXCEPTION_INDICATOR());
						cities.setLOCATION(citycode.getLOCATION());
						cities.setNAME(citycode.getNAME());
						cities.setSTATE(citycode.getSTATE());
						cities.setUS_INDICATOR(citycode.getUS_INDICATOR());
						citiesList.add(cities);
					}
				}
			} 
		}
		
//		System.out.println(citiesList);
//		System.out.println(citypair);

//		faTempModel.setCitieList(citiesList);
//		faTempModel.setCitypairs(citypairList);
		faTempModel.setCitycode(faModel.getCitycode());
		return faTempModel;

	}

	
	
	public List<RAWDATA> mergeAndDiscardDeadheads(FlightAttendantTempModel flightAttendantTempModel) {
		List<RAWDATA> deadHeadsList=new ArrayList<>();
		RAWDATA deadHeads=new RAWDATA();
		try{
			for (RAWDATA dhdata1 : flightAttendantTempModel.getDhdata1()) {
				deadHeads = new RAWDATA();
				for (Field fields : dhdata1.getClass().getFields()) {
					fields.set(deadHeads, fields.get(dhdata1));
				}
				if(deadHeads!=null)
				deadHeadsList.add(deadHeads);
			}
			
			for (RAWDATA dhdata2 : flightAttendantTempModel.getDhdata2()) {
				deadHeads = new RAWDATA();
				for (Field fields : dhdata2.getClass().getFields()) {
					fields.set(deadHeads, fields.get(dhdata2));
				}
				if(deadHeads!=null)
				deadHeadsList.add(deadHeads);
			}for (RAWDATA dhdata3 : flightAttendantTempModel.getDhdata3()) {
				deadHeads = new RAWDATA();
				for (Field fields : dhdata3.getClass().getFields()) {
					fields.set(deadHeads, dhdata3.getClass().getField(fields.getName()).get(dhdata3));
				}
				if(deadHeads!=null)
				deadHeadsList.add(deadHeads);
			}
			for (RAWDATA dhdatab : flightAttendantTempModel.getDhdatabs()) {
				deadHeads = new RAWDATA();
				for (Field fields : dhdatab.getClass().getFields()) {
					fields.set(deadHeads, dhdatab.getClass().getField(fields.getName()).get(dhdatab));
				}
				if(deadHeads!=null)
				deadHeadsList.add(deadHeads);
				
			}
//			System.out.println("deadHeadsList----> "+deadHeadsList.size());
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return deadHeadsList;
	}
	

}
