package com.crewpay.fa.service;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;

import com.crewpay.fa.model.FlightAttendantModel;
import com.crewpay.fa.model.FlightAttendantTempModel;

public interface IntlOverrideFlightAttendantService {
	
	public FlightAttendantTempModel flightAttendantTempModelScenarios(FlightAttendantModel faModel) throws IllegalArgumentException, IllegalAccessException, ParseException, IOException;
	
}
