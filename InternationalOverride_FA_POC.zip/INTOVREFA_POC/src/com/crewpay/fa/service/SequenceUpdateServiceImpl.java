package com.crewpay.fa.service;


import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Set;

import com.crewpay.fa.commons.FlightAttendantUtil;
import com.crewpay.fa.model.FlightAttendantTempModel;
import com.crewpay.fa.model.RAWDATA;

public class SequenceUpdateServiceImpl implements SequenceUpdateService{

	@Override
	public void deleteSequenceWithoutLegs(FlightAttendantTempModel faTempModel) {
		System.out.println("updateSequenceService.deleteSequenceWithoutLegs(faTempModel)");
		List<RAWDATA> activeRawdata=new ArrayList<>();
		List<RAWDATA> rawList=faTempModel.getRawdata();
		Collections.sort( rawList,Comparator.comparing(RAWDATA::getEMPNo)
											.thenComparing(RAWDATA::getSEQUENCE_NUMBER)
											.thenComparing(RAWDATA::getLEG));
		int countOfIntl=0;
		int totalLegs=0;
		
		
		for (RAWDATA rawdata : rawList) {
			
		}
		for(RAWDATA rawdata2:rawList){
//			System.out.println(rawdata2.getEMPNo()+"=="+rawdata2.getSEQ_EMPNo()+"----"+rawdata2.getSEQUENCE_NUMBER()+"=="+rawdata2.getLEG_SEQUENCE_NUMBER());
			if(rawdata2.getEMPNo().equals(rawdata2.getSEQ_EMPNo())&&rawdata2.getSEQUENCE_NUMBER().equals(rawdata2.getLEG_SEQUENCE_NUMBER())){
				if(rawdata2.getIntl_Override()!=0){
					countOfIntl=countOfIntl+1;
				}
				totalLegs=totalLegs+1;
			}
		}
		for(Iterator<RAWDATA> it=rawList.iterator();it.hasNext();){
			RAWDATA rawdata=it.next();
				if (rawdata.getDOM_INTL_CODE().equals("D") && countOfIntl == 0) {
					it.remove();
				}else{
					activeRawdata.add(rawdata);
					rawdata.setTotalIntlCount(countOfIntl);
					rawdata.setTotalFlights(totalLegs);
				}
		}
		faTempModel.setRawdata(activeRawdata);
	}
	@Override
	public void specialPayFlag(FlightAttendantTempModel main) {
		List<RAWDATA> tempFile=new ArrayList<>();
		RAWDATA temp=null;
		for(RAWDATA rawdata:main.getRawdata()){
			for(RAWDATA dhdata:main.getDhdata()){
				if(rawdata.getEMPNo()==dhdata.getEMPNo()&&rawdata.getSEQUENCE_NUMBER()==dhdata.getSEQUENCE_NUMBER()&&rawdata.getXDTYPER()==dhdata.getXDTYPER()&&rawdata.getLEG()==dhdata.getLEG()){
				temp=new RAWDATA();
				temp=writingIntoDataSets(dhdata, temp);
				tempFile.add(temp);
				}
			}
		}
		Collections.sort( tempFile, Comparator.comparing(RAWDATA::getEMPNo)
				                              .thenComparing(RAWDATA::getSEQUENCE_NUMBER)
				                              .thenComparing(RAWDATA::getXDTYPER)
				                              .thenComparing(RAWDATA::getLEG));
//			System.out.println(tempFile.size());
		List<RAWDATA> tempFile2=new ArrayList<>();
		int specialFlag=0;
		int i=1;
//		for(RAWDATA temp1:tempFile){
//			System.out.println("temp1...."+i);
//			for(RAWDATA temp2:tempFile){
////				System.out.println(temp1.getXDTYPER()+"----"+temp2.getXDTYPER()+"-----"+temp2.getIntl_Override()+"----"+temp2.getIRREGULAR_LEG_INDICATOR()+"----"+temp1.getDEADHEAD_INDICATOR());
//				if(temp1.getXDTYPER()>temp2.getXDTYPER()){
//					if(temp2.getIntl_Override()==1){
//						if(temp2.getIRREGULAR_LEG_INDICATOR()==3){
//							if(!temp2.getDEADHEAD_INDICATOR().equals("000")){
//								specialFlag=1;
//							}
//						}
//					}
//				}
//			}
//			temp1.setSpecialFlag(specialFlag);
//			tempFile2.add(temp1);
//			i++;
//		}
////		System.out.println(tempFile2.size());
//		tempFile=tempFile2;
		List<RAWDATA> DpList=main.getDpdata();
		Collections.sort(DpList, Comparator.comparing(RAWDATA::getEMPNo)
											.thenComparing(RAWDATA::getSEQUENCE_NUMBER)
											.thenComparing(RAWDATA::getXDTYPER)
											.thenComparing(RAWDATA::getLEG));
		
		Collections.sort(tempFile, Comparator.comparing(RAWDATA::getEMPNo)
											.thenComparing(RAWDATA::getSEQUENCE_NUMBER)
											.thenComparing(RAWDATA::getXDTYPER)
											.thenComparing(RAWDATA::getLEG));

		
		for(RAWDATA dpdata:DpList){
			for(RAWDATA tempfile:tempFile){
//				System.out.println(tempfile.getIntl_Override()+"-----"+tempfile.getSpecialFlag());
				if(tempfile.getIntl_Override()!=0&&tempfile.getSpecialFlag()!=0){
					if(tempfile.getEMPNo()==dpdata.getEMPNo()&&tempfile.getSEQUENCE_NUMBER()==dpdata.getSEQUENCE_NUMBER()&&tempfile.getXDTYPER()==dpdata.getXDTYPER()){
						dpdata.setSpecialFlag(temp.getSpecialFlag());
					}
				}
			}
		}
		main.setDpdata(DpList);
	}

	public static RAWDATA writingIntoDataSets(RAWDATA rawList,RAWDATA temp){
		
		try{
			Set<String> keys=new HashSet<>();
			for(Field key:rawList.getClass().getFields()){
				keys.add(key.getName());
			}
			for (Field field : temp.getClass().getFields()) {
					try {
						if (keys.contains(field.getName())) {
							if (field.getType().getCanonicalName().contains("Date")) {
								field.set(temp, rawList.getClass().getField(field.getName()).get(rawList));
							} else if (field.getType().getCanonicalName().contains("Integer")) {
								if (rawList.getClass().getField(field.getName()).get(rawList) == null) {
									field.set(temp, rawList.getClass().getField(field.getName()).get(rawList));
								} else {
									field.set(temp, rawList.getClass().getField(field.getName()).get(rawList));
								}
							} else if (field.getType().getCanonicalName().contains("Character")) {
								if (rawList.getClass().getField(field.getName()).get(rawList) == null) {
									field.set(temp, rawList.getClass().getField(field.getName()).get(rawList));
								} else {
									field.set(temp, rawList.getClass().getField(field.getName()).get(rawList));
								}
							} else {
								field.set(temp, rawList.getClass().getField(field.getName()).get(rawList));
							}
						}
					} catch (SecurityException e) {
						e.printStackTrace();
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
		
	}catch(Exception e){
		e.printStackTrace();
	}
		return temp;
		
	}
	@Override
	public void filterDeadheadSeuences(List<RAWDATA> dhdataList) {
		System.out.println("updateSequenceService.filterDeadheadSeuences()...");
		System.out.println(dhdataList.size());
		for(Iterator<RAWDATA> it = dhdataList.iterator(); it.hasNext();){
			RAWDATA dhdata=it.next();
			
			if((dhdata.getDEADHEAD_INDICATOR().equals("000")||dhdata.getDEADHEAD_INDICATOR().equals("RPT")||dhdata.getDEADHEAD_INDICATOR().equals("SUR"))||(dhdata.getLEG_REMOVAL_CODE()!=0&&dhdata.getREASON_PAY_INDICATOR()!=1)){
				it.remove();
			}
			else
			{
				dhdata.setLEG_EX_DH(dhdata.getDH_SCHED()-dhdata.getDH_BLOCK());
			}
		}
//		System.out.println(dhdataList.size());
	}

	@Override
	public void domesticDeadheadsAndIrregularFlights(FlightAttendantTempModel faTempModel) {
		System.out.println("updateSequenceService.domesticDeadheadsAndIrregularFlights()...");
		List<RAWDATA> tempFile=new ArrayList<>();
		RAWDATA temp=null;
//		for(RAWDATA rawdata:faTempModel.getRawdata()){
//			temp=new RAWDATA();
//			temp=writingIntoDataSets(rawdata, temp);
//			tempFile.add(temp);
//		}
		for(RAWDATA dhdata:faTempModel.getDhdata()){
			temp=new RAWDATA();
			temp=writingIntoDataSets(dhdata, temp);
			tempFile.add(temp);
		}
		
		Collections.sort( tempFile, Comparator.comparing(RAWDATA::getEMPNo)
				                              .thenComparing(RAWDATA::getSEQUENCE_NUMBER)
				                              .thenComparing(RAWDATA::getXDTYPER)
				                              .thenComparing(RAWDATA::getLEG));
		
		for(ListIterator<RAWDATA> tempIterator=faTempModel.getDhdata().listIterator();tempIterator.hasNext();){
			
			RAWDATA curr=tempIterator.next();
			if(tempIterator.hasPrevious()){
				RAWDATA prev=tempIterator.previous();
				if(prev.getIRREGULAR_LEG_INDICATOR()>0&&prev.getIntl_Override()==1&&curr.getIntl_Override()==0){
					curr.setIntl_Override(1);
				}
				
			}
			tempIterator.next();
		}
		
	}
	
}
