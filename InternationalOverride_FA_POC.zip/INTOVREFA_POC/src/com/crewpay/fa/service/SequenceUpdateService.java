package com.crewpay.fa.service;

import java.util.List;

import com.crewpay.fa.model.FlightAttendantTempModel;
import com.crewpay.fa.model.RAWDATA;

public interface SequenceUpdateService {

	public void deleteSequenceWithoutLegs(FlightAttendantTempModel faTempModel);
	
	public void specialPayFlag(FlightAttendantTempModel main);
	
	public void filterDeadheadSeuences(List<RAWDATA> dhdataList);
	
	public void domesticDeadheadsAndIrregularFlights(FlightAttendantTempModel faTempModel);
}
