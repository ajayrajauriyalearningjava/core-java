package com.crewpay.fa.service;

import com.crewpay.fa.model.FlightAttendantTempModel;

public interface UpdatesFromOtherMonthFiles {

	public void DPDATA(FlightAttendantTempModel faTempModel);
	
	public void DHDATA(FlightAttendantTempModel faTempModel);

	public void RAWDATA(FlightAttendantTempModel faTempModel);
	
}
