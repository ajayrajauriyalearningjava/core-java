package com.crewpay.fa.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;

import com.crewpay.fa.model.FlightAttendantTempModel;
import com.crewpay.fa.model.RAWDATA;

public class UpdatesFromOtherMonthFilesImpl implements UpdatesFromOtherMonthFiles {

	@Override
	public void DPDATA(FlightAttendantTempModel faTempModel) {
		System.out.println("UpdatesFromOtherMonthFilesImpl.DPDATA()...");
//		Sort and merge DPDATA and OTHMON3 files by Emp# / Scheduled Start Date / Sequence Number / Seq Reason Code / Seq Removal Code 
//		/ Seq Level Number / DP# 
		List<RAWDATA> othmon3List=faTempModel.getOm3List();
		List<RAWDATA> dpList=faTempModel.getDpdata();
		Collections.sort(dpList, Comparator.comparing(RAWDATA::getEMPNo)
															.thenComparing(RAWDATA::getXDTYPER));
		Collections.sort(othmon3List,Comparator.comparing(RAWDATA::getEMPNo)
															.thenComparing(RAWDATA::getSEQUENCE_NUMBER)
															.thenComparing(RAWDATA::getXDTYPER));
		
		List<RAWDATA> dpdataList=new ArrayList<>();
		for(RAWDATA dpdata:dpList){
			for(RAWDATA otmon3:othmon3List){
				if(dpdata.getEMPNo().equals(otmon3.getEMPNo())&&dpdata.getSEQUENCE_NUMBER().equals(otmon3.getSEQUENCE_NUMBER())&&dpdata.getXDTYPER().equals(otmon3.getXDTYPER())){
					dpdata.setOTH_ACTL_DUTY_PER_CR_MNS(otmon3.getACTL_DUTY_PER_CR_MNS());
					dpdata.setOTH_ACTL_SEQ_CR_MNS(otmon3.getOTH_ACTL_SEQ_CR_MNS());
					dpdata.setOTH_DHD_MIN(otmon3.getOTH_DHD_MIN());
					dpdata.setOTH_DOM_INTL_CODE(otmon3.getOTH_DOM_INTL_CODE());
					dpdata.setOTH_INACTIVE(otmon3.getOTH_INACTIVE());
					dpdata.setOTH_LEG_GRTR_MNS(otmon3.getOTH_LEG_GRTR_MNS());
					dpdata.setOTH_TRIP_TYPE(otmon3.getOTH_TRIP_TYPE());
					dpdata.setOTM_ACTL_DUTY_PER_CR_MNS(otmon3.getOTM_ACTL_DUTY_PER_CR_MNS());
					dpdata.setOTM_DHD_MIN(otmon3.getOTM_DHD_MIN());
					dpdata.setOTM_LEG_GRTR_MNS(otmon3.getOTM_LEG_GRTR_MNS());
					
				}
				
			}
			
		}
		
		faTempModel.setDpdata(dpList);
	}

	@Override
	public void DHDATA(FlightAttendantTempModel faTempModel) {
		System.out.println("UpdatesFromOtherMonthFilesImpl.DHDATA()...");
		List<RAWDATA> dhdataList=new ArrayList<>();
		List<RAWDATA> dhList=faTempModel.getDhdata();
//		System.out.println(new HashSet<RAWDATA>(dhList));
		List<RAWDATA> othmon3List=faTempModel.getOm3List();
		Collections.sort(dhList, Comparator.comparing(RAWDATA::getEMPNo)
															.thenComparing(RAWDATA::getDP_NO));
		Collections.sort(othmon3List,Comparator.comparing(RAWDATA::getEMPNo)
															.thenComparing(RAWDATA::getDP_NO));		

//		System.out.println(dhList.size());
		for(RAWDATA dhdata:dhList){
			for(RAWDATA otmon3:othmon3List){
				if(dhdata.getEMPNo().equals(otmon3.getEMPNo())&&dhdata.getSEQUENCE_NUMBER().equals(otmon3.getSEQUENCE_NUMBER())&&dhdata.getXDTYPER().equals(otmon3.getXDTYPER())){
					dhdata.setOTH_ACTL_DUTY_PER_CR_MNS(otmon3.getOTH_ACTL_DUTY_PER_CR_MNS());
					dhdata.setOTH_ACTL_SEQ_CR_MNS(otmon3.getOTH_ACTL_SEQ_CR_MNS());
					dhdata.setOTH_DHD_MIN(otmon3.getOTH_DHD_MIN());
					dhdata.setOTH_DOM_INTL_CODE(otmon3.getOTH_DOM_INTL_CODE());
					dhdata.setOTH_INACTIVE(otmon3.getOTH_INACTIVE());
					dhdata.setOTH_LEG_GRTR_MNS(otmon3.getOTH_LEG_GRTR_MNS());
					dhdata.setOTH_TRIP_TYPE(otmon3.getOTH_TRIP_TYPE());
					dhdata.setOTM_ACTL_DUTY_PER_CR_MNS(otmon3.getOTM_ACTL_DUTY_PER_CR_MNS());
					dhdata.setOTM_DHD_MIN(otmon3.getOTM_DHD_MIN());
					dhdata.setOTM_LEG_GRTR_MNS(otmon3.getOTM_LEG_GRTR_MNS());
					dhdataList.add(dhdata);
				}
			}
		}
//		System.out.println(dhdataList.size());
		faTempModel.setDhdata(dhdataList);
	}

	@Override
	public void RAWDATA(FlightAttendantTempModel faTempModel) {
		System.out.println("UpdatesFromOtherMonthFilesImpl.RAWDATA()...");
		List<RAWDATA> rawdataList=new ArrayList<>();
		List<RAWDATA> rawList=faTempModel.getRawdata();
		List<RAWDATA> othmon2List=faTempModel.getOm3List();
		Collections.sort(rawList, Comparator.comparing(RAWDATA::getEMPNo)
															.thenComparing(RAWDATA::getDP_NO));
		Collections.sort(othmon2List,Comparator.comparing(RAWDATA::getEMPNo)
															.thenComparing(RAWDATA::getDP_NO));		

//		System.out.println(rawList.size());
		for(RAWDATA rawdata:rawList){
			for(RAWDATA otmon2:othmon2List){
				if(rawdata.getEMPNo().equals(otmon2.getEMPNo())&&rawdata.getSEQUENCE_NUMBER().equals(otmon2.getSEQUENCE_NUMBER())){
					rawdata.setOTH_ACTL_DUTY_PER_CR_MNS(otmon2.getOTH_ACTL_DUTY_PER_CR_MNS());
					rawdata.setOTH_ACTL_SEQ_CR_MNS(otmon2.getOTH_ACTL_SEQ_CR_MNS());
					rawdata.setOTH_DHD_MIN(otmon2.getOTH_DHD_MIN());
					rawdata.setOTH_DOM_INTL_CODE(otmon2.getOTH_DOM_INTL_CODE());
					rawdata.setOTH_INACTIVE(otmon2.getOTH_INACTIVE());
					rawdata.setOTH_LEG_GRTR_MNS(otmon2.getOTH_LEG_GRTR_MNS());
					rawdata.setOTH_TRIP_TYPE(otmon2.getOTH_TRIP_TYPE());
					rawdata.setOTM_ACTL_DUTY_PER_CR_MNS(otmon2.getOTM_ACTL_DUTY_PER_CR_MNS());
					rawdata.setOTM_DHD_MIN(otmon2.getOTM_DHD_MIN());
					rawdata.setOTM_LEG_GRTR_MNS(otmon2.getOTM_LEG_GRTR_MNS());
				}
			}
		}
		faTempModel.setRawdata(rawList);
	}

}
