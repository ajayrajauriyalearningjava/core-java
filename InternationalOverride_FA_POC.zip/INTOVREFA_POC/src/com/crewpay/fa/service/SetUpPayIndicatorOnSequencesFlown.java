package com.crewpay.fa.service;

import com.crewpay.fa.model.FlightAttendantTempModel;

public interface SetUpPayIndicatorOnSequencesFlown {
	
	public void getAssignmentReasonCodes(FlightAttendantTempModel faTempModel);
	
	public void setupPayMiscIndicator(FlightAttendantTempModel faTempModel);
	
	public void checkListing1RemoveSequences(FlightAttendantTempModel faTempModel);
	
}
