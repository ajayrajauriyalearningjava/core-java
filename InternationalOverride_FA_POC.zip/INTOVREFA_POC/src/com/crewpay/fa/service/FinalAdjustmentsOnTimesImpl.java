package com.crewpay.fa.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import com.crewpay.fa.model.FlightAttendantTempModel;
import com.crewpay.fa.model.RAWDATA;

public class FinalAdjustmentsOnTimesImpl implements FinalAdjustmentsOnTimes {

	@Override
	public void fix_GTR_BLK_onReturnstoGates(FlightAttendantTempModel faTempModel) {
		List<RAWDATA> rawList=faTempModel.getRawdata();
//		�	Sort RAWDATA file by Emp#/Seq#/DP#/Leg#
		Collections.sort(rawList, Comparator.comparing(RAWDATA::getEMPNo)
											.thenComparing(RAWDATA::getSEQUENCE_NUMBER)
											.thenComparing(RAWDATA::getXDTYPER)
											.thenComparing(RAWDATA::getLEG)
											.reversed());
		
		
		int empNo=rawList.get(0).getEMPNo();
		int seqNo=rawList.get(0).getSEQUENCE_NUMBER();
		int dpNo=rawList.get(0).getXDTYPER();
		int Add_Up =0;
		int TTL_ACT_MIN=0;
		int BLK_TO_ADD=0;
		for(RAWDATA rawdata:rawList){
			if(rawdata.getEMPNo()==empNo&&rawdata.getSEQUENCE_NUMBER()==seqNo&&dpNo>rawdata.getXDTYPER()){
				if(rawdata.getIRREGULAR_LEG_INDICATOR()==1||rawdata.getIRREGULAR_LEG_INDICATOR()==2){
					Add_Up =1;
				}
			}
			TTL_ACT_MIN=rawdata.getACT_BLK_MIN()+rawdata.getATC_MINS()+rawdata.getRCD_MINS();
			TTL_ACT_MIN=TTL_ACT_MIN+rawdata.getDVR_MINS();
			BLK_TO_ADD=TTL_ACT_MIN;
			
			rawdata.setGTR_BLK_MIN(rawdata.getGTR_BLK_MIN()+BLK_TO_ADD);
			rawdata.setGTR_BLK(Math.abs(rawdata.getGTR_BLK_MIN()/60)+((rawdata.getGTR_BLK_MIN()%60)/100));
			empNo=rawdata.getEMPNo();
			seqNo=rawdata.getSEQUENCE_NUMBER();
			dpNo=rawdata.getXDTYPER();
		}
	}
	@Override
	public void calculateTotal_Actual_BLK_Time(FlightAttendantTempModel faTempModel) throws ParseException {

		List<RAWDATA> rawList=faTempModel.getRawdata();
//		�	Sort RAWDATA file by Emp#/Seq#/DP#/Leg#
		Collections.sort(rawList, Comparator.comparing(RAWDATA::getEMPNo)
											.thenComparing(RAWDATA::getSEQUENCE_NUMBER)
											.thenComparing(RAWDATA::getXDTYPER)
											.thenComparing(RAWDATA::getLEG));
		

//		� SET UP VARIABLE TO HOLD TOTAL ACTUAL BLK TIME WHEN FLIGHT HAD A RETURN 
//		TO GATE THAT WE NEED TO ADD UP �         
		Calendar cal=Calendar.getInstance();
		String SS_CON_START =null;
		String SS_CON_END  =null;
		int CO_GTR_BLK_MIN = 0 ;
		String USE_LEGDATE = null;
		int S_USE_LEGDATE =0;
		int XLCLDEP  = 0;
		int BACKUP =0;
		int XLCLARR = 0;
//		System.out.println(rawList);
		for (RAWDATA rawdata : rawList) {
			SS_CON_START = rawdata.getPROCESSING_START_DATE();
			SS_CON_END = rawdata.getPROCESSING_END_DATE();
			
//			�NEED TO FIGURE HOW MUCH OF GTR BLK IS IN THIS MONTH FOR EACH FLT�                                           
			CO_GTR_BLK_MIN = 0 ;
			if(rawdata.getSEQ_REMOVAL_CODE()==0){
				USE_LEGDATE = rawdata.getLEG_ACTUAL_START_DATE();
				if(rawdata.getLEG_ACTUAL_START_DATE()==null){
					if(rawdata.getLEG_ACTUAL_START_DATE().equals("0")){ 
						    USE_LEGDATE = rawdata.getLEG_SCHEDULED_START_DATE();
					}
				}
			}
			else{
				USE_LEGDATE=rawdata.getLEG_ACTUAL_START_DATE();
			}
			cal.setTime(convertindIntoDateType(USE_LEGDATE));
			S_USE_LEGDATE = cal.get(Calendar.DATE);
			
			if(rawdata.getSEQ_REMOVAL_CODE()==0){
				if(rawdata.getLEG_ACTUAL_START_TIME()>0){
					XLCLDEP=rawdata.getLEG_ACTUAL_START_TIME()-rawdata.getSTR_GMT_ADJMT_MNS();
				}
				else{
					XLCLDEP=rawdata.getLEG_SCHEDULED_START_TIME()-rawdata.getSTR_GMT_ADJMT_MNS();
				}
				XLCLDEP=XLCLDEP%1440;
				cal.setTime(convertindIntoDateType(SS_CON_START));
				if(S_USE_LEGDATE==(cal.get(Calendar.DATE)-1)){
					if(rawdata.getGTR_BLK_MIN()==rawdata.getSCH_BLK_MIN()){
						BACKUP =rawdata.getATC_MINS()+rawdata.getDEI_MINS()+rawdata.getRCD_MINS();
						XLCLARR = (XLCLDEP - BACKUP) +rawdata.getSCH_BLK_MIN();
						if(XLCLARR > 1440){
							CO_GTR_BLK_MIN = XLCLARR - 1440;
						}
					}
					else{
						XLCLARR = XLCLDEP + rawdata.getACT_BLK_MIN();
						if(XLCLARR > 1440){
							CO_GTR_BLK_MIN = XLCLARR - 1440;
						}
					}
					if(S_USE_LEGDATE > cal.get(Calendar.DATE) - 1){
				          CO_GTR_BLK_MIN = rawdata.getGTR_BLK_MIN();
				          if(S_USE_LEGDATE ==cal.get(Calendar.DATE) && (rawdata.getATC_MINS() + rawdata.getDEI_MINS() + rawdata.getRCD_MINS()) > XLCLDEP) {
				        	  BACKUP = (rawdata.getATC_MINS() + rawdata.getDEI_MINS() + rawdata.getRCD_MINS())-XLCLDEP ;
				        	  CO_GTR_BLK_MIN = rawdata.getGTR_BLK_MIN() - BACKUP;     
				          }
					}
					cal.setTime(convertindIntoDateType(SS_CON_END));
					if(S_USE_LEGDATE == cal.get(Calendar.DATE)){
						XLCLARR = XLCLDEP + rawdata.getGTR_BLK_MIN();
						if(XLCLARR > 1440){
							CO_GTR_BLK_MIN = rawdata.getGTR_BLK_MIN() - (XLCLARR-1440);
				                    CO_GTR_BLK_MIN = CO_GTR_BLK_MIN + (rawdata.getATC_MINS() + rawdata.getDEI_MINS() + rawdata.getRCD_MINS());        

						}
					}
				}
			}
			else{
				XLCLDEP = rawdata.getLEG_SCHEDULED_START_TIME() - rawdata.getSTR_GMT_ADJMT_MNS();
				XLCLDEP = (XLCLDEP%1440);
				cal.setTime(convertindIntoDateType(SS_CON_START));
				if(S_USE_LEGDATE==cal.get(Calendar.DATE)-1){
					XLCLARR = XLCLDEP + rawdata.getSCH_BLK_MIN();
					if(XLCLARR > 1440){
						CO_GTR_BLK_MIN = XLCLARR - 1440;
					}
				}
				if(S_USE_LEGDATE > cal.get(Calendar.DATE) - 1){
					CO_GTR_BLK_MIN = rawdata.getGTR_BLK_MIN();
					cal.setTime(convertindIntoDateType(SS_CON_END));
				     if(S_USE_LEGDATE == cal.get(Calendar.DATE)){
				          XLCLARR = XLCLDEP + rawdata.getSCH_BLK_MIN();                      
				          if(XLCLARR > 1440){
				          CO_GTR_BLK_MIN = rawdata.getSCH_BLK_MIN() - (XLCLARR - 1440);
				          }
				     }
				}
			}
		}
	}

	private Date convertindIntoDateType(String stringDate) throws ParseException {
		SimpleDateFormat sdf=null;
		Date date=null;
		if (stringDate != null) {
			if (stringDate.length() == 6) {
				sdf = new SimpleDateFormat("yyyymm");
				date = sdf.parse(stringDate + "00");
			} else {
				sdf = new SimpleDateFormat("yyyymmdd");
				date = sdf.parse(stringDate);
			}
		}
		return date;
	}

}
