package com.crewpay.fa.text;

import java.io.FileNotFoundException;
import java.io.IOException;

import com.crewpay.fa.commons.FlightAttendantUtil;
import com.crewpay.fa.model.FlightAttendantModel;
import com.crewpay.fa.model.FlightAttendantTempModel;
import com.crewpay.fa.service.IntlOverrideFlightAttendantService;
import com.crewpay.fa.service.IntlOverrideFlightAttendantServiceImpl;
public class FlightAttendant {
	
	public static void main(String[] args) {
		try{
			FlightAttendantModel FAModel=FlightAttendantUtil.getInputFilesFromFlatFile();
			FlightAttendantUtil.reportGenerate(FAModel.getCrewMember(), "crewmembers.txt");
			IntlOverrideFlightAttendantService faService=new IntlOverrideFlightAttendantServiceImpl();
			FlightAttendantTempModel faTempModel=faService.flightAttendantTempModelScenarios(FAModel);
			FlightAttendantUtil.reportGenerate1(faTempModel.getDhdata(),"FinalReportForDHDATA.csv");
			FlightAttendantUtil.reportGenerate1(faTempModel.getRawdata(),"FinalReportForRAWDATA.csv");
//			System.out.println(FAModel.getFcrm_Model());
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
