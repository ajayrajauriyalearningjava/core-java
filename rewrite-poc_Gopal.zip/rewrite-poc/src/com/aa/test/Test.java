package com.aa.test;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.aa.crewpay.rewrite.poc.pbr.SequenceDTO;

public class Test {

	private final static DateFormat fmt = new SimpleDateFormat("yyyyMMdd");
	public static void main(String[] args) throws ParseException {
		String conStart = "20160702";
		String conEnd = "20160731";
		String start ="20160707"; 
		String end ="20160709"; 
		Date consd =  (Date) fmt.parse(conStart);
		Date coned =  (Date) fmt.parse(conEnd);
		Date startDate =  (Date) fmt.parse(start);
		Date endDate =  (Date) fmt.parse(end);
		//System.out.println(sd+ ""+ed);
		
		if(startDate.after(consd)  && endDate.before(coned)  ) {
			System.out.println(startDate+ "           "+endDate);
		}
		
		
		
		
		
		
		//String line = "02020160702001040000000000000000002016070203790000000379002016070400000000002016070407070000000704000300003000304AFI000200020202000000201659016300163500000000000000000000000000000000704000000177066N0000000000000000000000000029032500000000000000000000000000000000000AA0000000000 00000000000000000000000000";
//		int len = 541;
//		line = line.substring(2, line.length());
//		for(int i=1;i<=31;i++) {
//			String st = line.substring(len, len+4);
//			System.out.println(st.substring(0, 2) + " " +st.substring(2, 4));
//			len = len +28;
//		}
		
//		if(line.startsWith("02")){
//			System.out.println(line);
//		     line = line.substring(2, line.length());
//			
//			System.out.println("seq no :" +line.substring(9, 14)+" SeqRmvCde :" +line.substring(17, 20)+ ", seqStartDate :" +line.substring(32, 40)+ //"," +line.substring(43, 47)+","+line.substring(58, 66)+
//					", SEQ_GFLY :" +line.substring(134, 138)+", E_TIME :" +line.substring(154, 158)+", F_TIME :" +line.substring(164, 168)+", DM_MINS :" +line.substring(169, 173)+", SPOSNUM :"+line.substring(132, 134));
//		}
		
		
		
		
		
		
//		System.out.println(len);
//		System.out.println(line.substring(len, len+4));
//		len = len +28;
//		System.out.println(len);
//		System.out.println(line.substring(len, len+4));
//		
		
		
		
//		20160824	20160827
//		20170209	20170215
//		20160829	20160830
//		20170223	20170301
//		20160719	20160801
//		20160817	20160830
//		20160817	20160830
//		20170110	20170116
//		20160818	20160818
//		20160818	20160818
//		20170117	20170123
//		20160617	20160621
//		20170216	20170222
//		20170216	20170222
//		20161225	20161231
//		20160818	20160820
//		20161211	20161217
//		20161218	20161225
//		20161218	20161225

		
		
		
		
		
		
		
		
		/*Map<Integer,Map<Integer,Dto>> map = new HashMap<Integer, Map<Integer,Dto>>();
		Map<Integer,Dto> innerMap = null;
		for(Dto dto : getList()){
			
			if(map.containsKey(dto.getSeqNum())){
				innerMap = map.get(dto.getSeqNum());
				innerMap.put(dto.getEmpNo(), dto);
				map.put(dto.getSeqNum(), innerMap);
				System.out.println(dto.toString());
			}
			else{
				innerMap = new HashMap<Integer, Dto>();
				innerMap.put(dto.getEmpNo(), dto);
				map.put(dto.getSeqNum(), innerMap);
				System.out.println(dto.toString());
			}
		}
		Dto dto = null;
		innerMap = map.get(123);
		System.out.println(innerMap);
		 dto = innerMap.get(111);
		innerMap.remove(111);
		System.out.println(dto);
		System.out.println(innerMap);
		dto = innerMap.get(112);
		innerMap.remove(112);
		System.out.println(dto);
		System.out.println(innerMap);
		dto = innerMap.get(113);
		innerMap.remove(113);
		System.out.println(dto);
		System.out.println(innerMap.size());*/
		
	}
	
	private static List<Dto> getList(){
		List<Dto> list = new ArrayList<Dto>();
		Dto dt = null;
		dt = new Dto();
		dt.setEmpNo(111);
		dt.setSeqNum(123);
		list.add(dt);
		dt = new Dto();
		dt.setEmpNo(112);
		dt.setSeqNum(123);
		list.add(dt);
		dt = new Dto();
		dt.setEmpNo(113);
		dt.setSeqNum(123);
		list.add(dt);
		dt = new Dto();
		dt.setEmpNo(102);
		dt.setSeqNum(143);
		list.add(dt);
		dt = new Dto();
		dt.setEmpNo(105);
		dt.setSeqNum(167);
		list.add(dt);
		dt = new Dto();
		dt.setEmpNo(105);
		dt.setSeqNum(175);
		list.add(dt);
		dt = new Dto();
		dt.setEmpNo(105);
		dt.setSeqNum(145);
		list.add(dt);
		
		return list;
	}

}
