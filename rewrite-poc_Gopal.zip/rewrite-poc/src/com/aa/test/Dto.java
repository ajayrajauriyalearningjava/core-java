package com.aa.test;

public class Dto {
	
	private int empNo;
	private int seqNum;
	
	
	public int getEmpNo() {
		return empNo;
	}
	
	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}
	
	public int getSeqNum() {
		return seqNum;
	}
	
	public void setSeqNum(int seqNum) {
		this.seqNum = seqNum;
	}
	
	public String toString(){
		return "DTO [ EMP : " +empNo+ " SEQ : " +seqNum+ "]";
	}

}
