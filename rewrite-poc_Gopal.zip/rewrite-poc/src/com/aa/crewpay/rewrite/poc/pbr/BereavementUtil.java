package com.aa.crewpay.rewrite.poc.pbr;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BereavementUtil {
	
	public Map<Integer ,String> getCbaseCodes(){
		Map<Integer ,String> baseMap = null;
		BufferedReader br = null;
		String line = "";
		try {
			baseMap = new HashMap<Integer ,String>();
			br = new BufferedReader(new FileReader("resources\\basetocbase.txt"));
		    while((line = br.readLine()) != null) {
		    	if(line != null && !line.isEmpty()){
		    		String [] base = line.split("  ");
		    		if(base[0].equals("other")){
		    			base[0] = "0";
		    		}
		    		int bs = new Integer(base[0]) ;
		    		baseMap.put(bs, base[1]);
		    	}
		    }

		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		finally {
		    try {
				br.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return baseMap;
	}
	
	public Map<String ,String> getEquipmentCodes(){
		Map<String ,String> equipMap = null;
		BufferedReader br = null;
		String line = "";
		try {
			equipMap = new HashMap<String ,String>();
			br = new BufferedReader(new FileReader("resources\\equiptoeqp.txt"));
		    while((line = br.readLine()) != null) {
		    	if(line != null && !line.isEmpty()){
		    		String [] equip = line.split("  ");
		    		equipMap.put(equip[0], equip[1]);
		    	}
		    }
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		finally {
		    try {
				br.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return equipMap;
	}

	public List<String> getPayStatusCountList(){
		String [] arr = {"01","11","41","04","14", "54","58","08","18","16","48"};
		List<String> countList = new ArrayList<String>(Arrays.asList(arr));
		return countList;
		
		
	}
}
