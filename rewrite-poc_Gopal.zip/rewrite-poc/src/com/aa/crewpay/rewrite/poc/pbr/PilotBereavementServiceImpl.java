package com.aa.crewpay.rewrite.poc.pbr;

import java.io.FileNotFoundException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;


public class PilotBereavementServiceImpl {
	private final static DateFormat fmt = new SimpleDateFormat("yyyyMMdd");
	
	public void filterMap(Map<Integer,List<String>> map,ContractualDatesDTO month) throws ParseException, FileNotFoundException {
		List<String> innerList = null;
		List<SequenceDTO> seqList = null;
		List<PlannedAbsenceDTO> absList = null;
		CrewMemberDTO crewDto = null;
		SequenceDTO seqDto = null;
		PlannedAbsenceDTO absDto = null;
		List<CrewMemberDTO> empInfo = new ArrayList<CrewMemberDTO>();
		List<String> absCodeList = null;
		List<String> payStatusList = null;
		int len = 0;
		
		for(Map.Entry<Integer, List<String>> entry : map.entrySet()) {
			System.out.println(entry.getKey());
			innerList = entry.getValue();
			seqList = new ArrayList<SequenceDTO>();
			absList = new ArrayList<PlannedAbsenceDTO>();
			
			for(String line : innerList){
				if(line.startsWith("01")) {
					String line1 = line.substring(2, line.length());
					crewDto = new CrewMemberDTO();
					seqList = new ArrayList<SequenceDTO>();
					absList = new ArrayList<PlannedAbsenceDTO>();
					crewDto.setEMPNO(line1.substring(13, 19)); 
					crewDto.setEQUIP(line1.substring(19,21)); 
					crewDto.setDATE(line1.substring(114,122)); 
					crewDto.setACTPROJ(line1.substring(424, 428)); 
					crewDto.setSCHPROJ(line1.substring(429, 433)); 
					crewDto.setPAYPROJ(line1.substring(439, 443)); 
					crewDto.setDIV(line1.substring(144, 145)); 
					crewDto.setBASE(line1.substring(133, 134)); 
					crewDto.setCURRAIR(line1.substring(1735, 1737)); 
					crewDto.setTRIPTYPE(line1.substring(517, 518)); 
					int triptype = new Integer(line1.substring(517, 518));
					if(triptype == 1){
						crewDto.setTYPEPI("RSV");
					}
					else{
						crewDto.setTYPEPI("REG");
					}
					
					absCodeList = new ArrayList<String>();
					payStatusList = new ArrayList<String>();
					len =  543;
					for(int i=1;i<=31;i++) {
						String st = line.substring(len, len+4);
						absCodeList.add(st.substring(0, 2));
						payStatusList.add(st.substring(2, 4));
						len = len +28;
					}
					
					crewDto.setABS01TO31(absCodeList); 
					crewDto.setPAYST01TO31(payStatusList); 

				}
			  if(line.startsWith("02")){
					//System.out.println(line);
					String line02 = line.substring(2, line.length());
					seqDto = new SequenceDTO();
					seqDto.setSEQN(line02.substring(9, 14)); 
					seqDto.setSEQSDATE(line02.substring(32, 40)); 
					seqDto.setSEQEDATE(line02.substring(74, 82)); 
					seqDto.setSEQPOSN(line02.substring(132, 134)); 
					seqDto.setSEQRMVCODE(line02.substring(17, 20)); 
					int tripVal = new Integer(line02.substring(134, 138))+new Integer(line02.substring(154, 158))+new Integer(line02.substring(164, 168))+new Integer(line02.substring(169, 173)); //
					seqDto.setTRIPVAL(String.valueOf(tripVal));
					seqList.add(seqDto);
					//System.out.println("SEQ_RMV_CODE : "+line02.substring(17, 20));
			  }
				if(line.startsWith("25")){
					//System.out.println(line);
					String line25 = line.substring(2, line.length());
					absDto = new PlannedAbsenceDTO();
					absDto.setABSSTARTDATE(line25.substring(1, 9)); 
					absDto.setABSENDDATE(line25.substring(13, 21)); 
					absDto.setABSCODE(line25.substring(10, 12));  
					absList.add(absDto);
				}
			}
			crewDto.setABSLIST(absList);
			crewDto.setSEQLIST(seqList);
			empInfo.add(crewDto);
			System.out.println(".....................................................................................................................................");
		}
		System.out.println("No of pilots parsed from FCRM : " +empInfo.size());
		
		if(empInfo != null) {
			calculateBereavement(empInfo, month);
		}
	}
	
	public void calculateBereavement(List<CrewMemberDTO> empInfo,ContractualDatesDTO con) throws ParseException, FileNotFoundException{
		
		BereavementUtil utl = new BereavementUtil();
		Map<Integer ,String> baseMap = utl.getCbaseCodes();
		//Map<String ,String> equipMap = utl.getEquipmentCodes();
		List<String> payList = utl.getPayStatusCountList();
		BereavementInfoReport info = null;
		Set<BereavementInfoReport> infoList = new HashSet<BereavementInfoReport>();
		int rsvPE = 0;
		for(CrewMemberDTO dto : empInfo){
			if(dto.getEMPNO() != null && dto.getEQUIP() != null && dto.getBASE() != null ){
					info = new BereavementInfoReport();
					
					for(PlannedAbsenceDTO plan : dto.getABSLIST()){
						Date startDate = fmt.parse(plan.getABSSTARTDATE());
						Date endDate = fmt.parse(plan.getABSENDDATE());
						if((startDate.after(con.getStartDate()) || startDate.equals(con.getStartDate())) 
								&& (endDate.before(con.getEndDate()) || endDate.equals(con.getEndDate()))) {
							info.setABSSDATE(plan.getABSSTARTDATE());
							info.setABSEDATE(plan.getABSENDDATE());
						}
					}
					if (info.getABSSDATE() != null && info.getABSEDATE() != null ) {
						info.setEMP(dto.getEMPNO());
						int base = new Integer(dto.getBASE());
						info.setCBASE(baseMap.get(base));
						info.setCURR_AIR(dto.getCURRAIR());
						int act = new Integer(dto.getACTPROJ());
						double actProj = (act/60) + (act % 60)/100;
						info.setACTPROJ(String.valueOf(actProj));
						int schP = new Integer(dto.getSCHPROJ());
						double sProj = (schP/60) + (schP % 60)/100;
						info.setSPROJ(String.valueOf(sProj));
						int payP = new Integer(dto.getPAYPROJ());
						double pProj = (payP/60) + (payP % 60)/100;
						info.setPPROJ(String.valueOf(pProj));
						for(int i = 0,j = 0 ; i <= dto.getABS01TO31().size()-1 && j <= dto.getPAYST01TO31().size()-1 ; i++,j++){
							int absCode = new Integer(dto.getABS01TO31().get(i));
							if(!payList.contains(dto.getPAYST01TO31().get(j)) && absCode == 6)
								rsvPE = rsvPE + 1;
						}
						info.setRSV_PE(String.valueOf(rsvPE));	
					}						
					
						double tripValue = 0.0;
						double dailyValue = 0.0;
						if(dto.getSEQLIST() != null ) {
							for(SequenceDTO seq : dto.getSEQLIST()){
								int seqRmvCode = new Integer(seq.getSEQRMVCODE());
								if(seq.getSEQN() != null && seq.getSEQPOSN() != null && seqRmvCode == 6){
									int numDays = getNoOfDays(fmt.parse(seq.getSEQEDATE()),fmt.parse(seq.getSEQSDATE())) ;
									int tripVal = new Integer(seq.getTRIPVAL());
									int dailyVal = (int) (tripVal/numDays);
									tripValue = (int)(tripVal/60) + (tripVal % 60)/ 100;
									dailyVal = (int) (dailyVal);
									dailyValue = (int)(dailyVal/60) + (dailyVal % 60)/ 100;
									info.setSEQNO(seq.getSEQN());
									info.setSEQSDATE(seq.getSEQSDATE());
									info.setSEQEDATE(seq.getSEQEDATE());
									info.setTRIP_VAL(String.valueOf(tripValue));
									info.setDAILYVAL(String.valueOf(dailyValue));
								}
							}
						}
				
						
			} else {
				System.out.println("CHECKED LIST OR EXCEPTION CASE");
			}
			
			if(info != null && info.getEMP() != null && info.getABSSDATE() != null) {
				infoList.add(info);
			}
		}
		
		//write in csv
		System.out.println("No of pilots Qualified for Bereavemnt----------------------------------> ::: " +infoList.size());
		if(infoList != null)
			new CSVWriterUtil().writeInCsv(infoList);
	}
	
	private int getNoOfDays(Date sd,Date ed) {
		 int num = 0;
		 Calendar cal1 = new GregorianCalendar();
	     Calendar cal2 = new GregorianCalendar();
	     cal1.setTime(sd);
	     cal2.setTime(ed);
	     num = (int) Math.round((sd.getTime() - ed.getTime()) / (double) 86400000);
		 return num > 0 ? num : num +1;
	}
	
	
	/*public void calculateBereavement(ContractualDatesDTO type31,CrewMemberDTO type01,SequenceDTO type02,PlannedAbsenceDTO type25) throws FileNotFoundException {
		PlannedAbsenceDTO pa = null;
		if(type25.getAbsSDate().after(type31.getStartDate()) && type25.getAbsEDate().before(type31.getEndDate())) {
			pa = type25;
			System.out.println("absent dates are with in the contractual dates ");
		}
		
		System.out.println("*********************************************Crew member data calculation******************************************");
		double actProj = (int)(type01.getActProj()/60) +(type01.getActProj()%60)/100;
		System.out.println(actProj);
		double pProj = (int)(type01.getpProj()/60) + (type01.getpProj()%60)/100;
		System.out.println(pProj);
		double sProj = (int)(type01.getsProj()/60) + (type01.getsProj()%60)/100;
		System.out.println(sProj);
		
		System.out.println("*********************************************Sequence data calculation ******************************************");
		int numDays = getNoOfDays(type02.getSeqEDate(),type02.getSeqSDate()) ;
		System.out.println(numDays);
		int dailyVal = (int) (type02.getTripVal()/numDays);
		System.out.println(dailyVal);
		int tripVal = (int) type02.getTripVal();
		tripVal = (int)(tripVal/60) + (tripVal%60)/ 100;
		System.out.println(tripVal);
		dailyVal = (int)(dailyVal/60) + (dailyVal%60)/ 100;
		System.out.println(tripVal);
		CrewMemberDTO dto = checkPayStatusAndAbsCode(type01);
		
		System.out.println("********************************Merge crewmember,sequence and plannedAbsence data by Emp number**********************************");
		BereavementInfoReport report = null;
		if(true){
			report = new BereavementInfoReport(); 
			report.setEMP(String.valueOf(type01.getEmp()));
			report.setSEQNO(String.valueOf(type02.getSeqNo()));
			report.setCURR_AIR(type01.getCurrAir());
			report.setCBASE(type01.getcBase());
			report.setSEQSDATE(fmt.format(type02.getSeqSDate()));
			report.setSEQEDATE(fmt.format(type02.getSeqEDate()));
			report.setDAILYVAL(String.valueOf(dailyVal));
			report.setTRIP_VAL(String.valueOf(tripVal));
			report.setRSV_PE(String.valueOf(dto.getRsvPe()));
			report.setPPROJ(String.valueOf(pProj));
			report.setACTPROJ(String.valueOf(actProj));
			report.setSPROJ(String.valueOf(sProj));
		}
		
		if(pa != null && true) {
			report.setABSEDATE(fmt.format(pa.getAbsEDate()));
			report.setABSSDATE(fmt.format(pa.getAbsEDate()));
		}
		new CSVWriterUtil().writeInCsv(report);
	} 
	*/
	
	
	//System.out.println("base : "+line1.substring(133, 134));
    //	System.out.println("emp no : "+line1.substring(13, 19) + ",equipment: " +line1.substring(19,21)+",Date : "+line1.substring(114,122)+",actProj :"+line1.substring(424, 428)+",schProj :"
   //			+line1.substring(429, 433)+",payProj :"+line1.substring(439, 443)+",base :"+line1.substring(133, 134)+",Div :"+line1.substring(144, 145)+",triptype :"
  //			+line1.substring(517, 518)+",AirLineCode :"+line1.substring(1735, 1737)+",abscode : "+line1.substring(541, 543)+",paycode :"+line1.substring(543, 545));
	
	
//	3993
//	5697
//	13778
//	361

	
	
	//System.out.println("absStartDate :"+line25.substring(1, 9)+", absCode :"+line25.substring(10, 12)+", absEndDate :"+line25.substring(13, 21));
	
//	System.out.println("seq no :" +line02.substring(9, 14)+" SeqRmvCde :" +line02.substring(16, 19)+ ", seqStartDate :" +line02.substring(32, 40)+ ", seqEndDate : " +line02.substring(74, 82)+//","+line02.substring(58, 66)+
//	", SEQ_GFLY :" +line02.substring(134, 138)+", E_TIME :" +line02.substring(154, 158)+", F_TIME :" +line02.substring(164, 168)+", DM_MINS :" +line02.substring(169, 173)+", SPOSNUM :"+line02.substring(132, 134));

	
	/*private CrewMemberDTO checkPayStatusAndAbsCode(CrewMemberDTO dto){
		CrewMemberDTO info = null;
		List<String> countList = new BereavementUtil().getPayStatusCountList();
		int rsvPe = 0;
		for(String str : countList){
			if((!dto.getAbs01to31().contains(str) || !dto.getPaySt01to31().contains(str)) && dto.getAdsCode() == 6){
			    rsvPe = rsvPe+1;
			}
		}
		dto.setRsvPe(rsvPe);
		info = dto;
		return info;
	}*/

}
