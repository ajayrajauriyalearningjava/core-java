package com.aa.crewpay.rewrite.poc.eotopvd;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class RecType01InfoDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private int emp;
	private String equip;
	private String tripType;
	private Date date;
	private int actProj;
	private int sProj;
	private int pProj;
	private String cBase;
	private String div;
	private String mSeat;
	private List<String> abs01to31;
	private List<String> paySt01to31;
	private String currAir;
	private String typePi;
	private int adsCode;
	private int rsvEo;
	private String eqp;
	
	//Emp,  Date,   ActProj,   SProj ,  PProj,   Base,   Div,   Equip,   M_Seat, TripType,   
	//Abs01-Abs31,  PaySt01-PaySt31,  Curr_Air,  Type_Pi, CBase, Eqp
	 


	public RecType01InfoDTO() {

	}

	public int getEmp() {
		return emp;
	}

	public void setEmp(int emp) {
		this.emp = emp;
	}

	public String getEquip() {
		return equip;
	}

	public void setEquip(String equip) {
		this.equip = equip;
	}
	
	public String getTripType() {
		return tripType;
	}

	public void setTripType(String tripType) {
		this.tripType = tripType;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public int getActProj() {
		return actProj;
	}

	public void setActProj(int actProj) {
		this.actProj = actProj;
	}

	public int getsProj() {
		return sProj;
	}

	public void setsProj(int sProj) {
		this.sProj = sProj;
	}

	public int getpProj() {
		return pProj;
	}

	public void setpProj(int pProj) {
		this.pProj = pProj;
	}

	public String getcBase() {
		return cBase;
	}
	
	public void setcBase(String cBase) {
		this.cBase = cBase;
	}

	public String getDiv() {
		return div;
	}

	public void setDiv(String div) {
		this.div = div;
	}
	
	public String getMSeat() {
		return mSeat;
	}
	
	public void setMSeat(String mSeat) {
		this.mSeat = mSeat;
	}

	public List<String> getAbs01to31() {
		return abs01to31;
	}

	public void setAbs01to31(List<String> abs01to31) {
		this.abs01to31 = abs01to31;
	}

	public List<String> getPaySt01to31() {
		return paySt01to31;
	}

	public void setPaySt01to31(List<String> paySt01to31) {
		this.paySt01to31 = paySt01to31;
	}

	public String getCurrAir() {
		return currAir;
	}

	public void setCurrAir(String currAir) {
		this.currAir = currAir;
	}

	public String getTypePi() {
		return typePi;
	}

	public void setTypePi(String typePi) {
		this.typePi = typePi;
	}
	
	public int getAdsCode() {
		return adsCode;
	}
	
	public void setAdsCode(int adsCode) {
		this.adsCode = adsCode;
	}

	public int getRsvEo() {
		return rsvEo;
	}
	
	public void setRsvEo(int rsvEo) {
		this.rsvEo = rsvEo;
	}
	
	public String getEqp() {
		return eqp;
	}
	
	public void setEqp(String eqp) {
		this.eqp = eqp;
	}
		
}
