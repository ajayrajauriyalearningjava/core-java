package com.aa.crewpay.rewrite.poc.eotopvd;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;

public class RecType02InfoDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private int emp;
	private BigInteger seqNo;
	private int seqPosN;
	private Date seqSDate;
	private Date seqEDate;
	private String seqRmvCd;
	private double tripVal;

	public RecType02InfoDTO() {

	}

	public int getEmp() {
		return emp;
	}

	public void setEmp(int emp) {
		this.emp = emp;
	}

	public BigInteger getSeqNo() {
		return seqNo;
	}

	public void setSeqNo(BigInteger seqNo) {
		this.seqNo = seqNo;
	}

	public int getSeqPosN() {
		return seqPosN;
	}

	public void setSeqPosN(int seqPosN) {
		this.seqPosN = seqPosN;
	}

	public Date getSeqSDate() {
		return seqSDate;
	}

	public void setSeqSDate(Date seqSDate) {
		this.seqSDate = seqSDate;
	}

	public Date getSeqEDate() {
		return seqEDate;
	}

	public void setSeqEDate(Date seqEDate) {
		this.seqEDate = seqEDate;
	}

	public String getSeqRmvCd() {
		return seqRmvCd;
	}

	public void setSeqRmvCd(String seqRmvCd) {
		this.seqRmvCd = seqRmvCd;
	}

	public double getTripVal() {
		return tripVal;
	}

	public void setTripVal(double tripVal) {
		this.tripVal = tripVal;
	}
	
	
	

}
