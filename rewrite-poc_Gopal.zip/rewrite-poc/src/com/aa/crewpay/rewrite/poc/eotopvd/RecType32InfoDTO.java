package com.aa.crewpay.rewrite.poc.eotopvd;

import java.io.Serializable;
import java.util.List;

public class RecType32InfoDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String BASENO;
	private String CBASE;
	private String DATE;
	private String DDIV;
	private String IDIV;
	private List<String> DCAEQPList;
	private List<String> DCAREGList;
	private List<String> DCARSVList;
	private List<String> DFOEQPList;
	private List<String> DFOREGList;
	private List<String> DFORSVList;
	private List<String> ICAEQPList;
	private List<String> ICAREGList;
	private List<String> ICARSVList;
	private List<String> IFOEQPList;
	private List<String> IFOREGList;
	private List<String> IFORSVList;
	
	
	public String getBASENO() {
		return BASENO;
	}
	public void setBASENO(String bASENO) {
		BASENO = bASENO;
	}
	public String getCBASE() {
		return CBASE;
	}
	public void setCBASE(String cBASE) {
		CBASE = cBASE;
	}
	public String getDATE() {
		return DATE;
	}
	public void setDATE(String dATE) {
		DATE = dATE;
	}
	public String getDDIV() {
		return DDIV;
	}
	public void setDDIV(String dDIV) {
		DDIV = dDIV;
	}
	public String getIDIV() {
		return IDIV;
	}
	public void setIDIV(String iDIV) {
		IDIV = iDIV;
	}
	public List<String> getDCAEQPList() {
		return DCAEQPList;
	}
	public void setDCAEQPList(List<String> dCAEQPList) {
		DCAEQPList = dCAEQPList;
	}
	public List<String> getDCAREGList() {
		return DCAREGList;
	}
	public void setDCAREGList(List<String> dCAREGList) {
		DCAREGList = dCAREGList;
	}
	public List<String> getDCARSVList() {
		return DCARSVList;
	}
	public void setDCARSVList(List<String> dCARSVList) {
		DCARSVList = dCARSVList;
	}
	public List<String> getDFOEQPList() {
		return DFOEQPList;
	}
	public void setDFOEQPList(List<String> dFOEQPList) {
		DFOEQPList = dFOEQPList;
	}
	public List<String> getDFOREGList() {
		return DFOREGList;
	}
	public void setDFOREGList(List<String> dFOREGList) {
		DFOREGList = dFOREGList;
	}
	public List<String> getDFORSVList() {
		return DFORSVList;
	}
	public void setDFORSVList(List<String> dFORSVList) {
		DFORSVList = dFORSVList;
	}
	public List<String> getICAEQPList() {
		return ICAEQPList;
	}
	public void setICAEQPList(List<String> iCAEQPList) {
		ICAEQPList = iCAEQPList;
	}
	public List<String> getICAREGList() {
		return ICAREGList;
	}
	public void setICAREGList(List<String> iCAREGList) {
		ICAREGList = iCAREGList;
	}
	public List<String> getICARSVList() {
		return ICARSVList;
	}
	public void setICARSVList(List<String> iCARSVList) {
		ICARSVList = iCARSVList;
	}
	public List<String> getIFOEQPList() {
		return IFOEQPList;
	}
	public void setIFOEQPList(List<String> iFOEQPList) {
		IFOEQPList = iFOEQPList;
	}
	public List<String> getIFOREGList() {
		return IFOREGList;
	}
	public void setIFOREGList(List<String> iFOREGList) {
		IFOREGList = iFOREGList;
	}
	public List<String> getIFORSVList() {
		return IFORSVList;
	}
	public void setIFORSVList(List<String> iFORSVList) {
		IFORSVList = iFORSVList;
	}
	
	

	
	

}
