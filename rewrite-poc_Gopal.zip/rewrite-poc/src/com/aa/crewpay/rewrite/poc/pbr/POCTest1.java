package com.aa.crewpay.rewrite.poc.pbr;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class POCTest1 {
	private static DateFormat fmt = new SimpleDateFormat("yyyyMMdd");    

	public static void main(String[] args) throws IOException, ParseException {
		List<String> list = null;
		BufferedReader br = new BufferedReader(new FileReader("resources\\FCRM_PI.txt"));
		
		try {
		    String line = "";
		    int count = 1;
		    ContractualDatesDTO conMonth = null;
		    list = new ArrayList<String>();
            Map<Integer,List<String>> outList = new HashMap<Integer,List<String>>();
		    boolean flag = false;
		    while((line = br.readLine()) != null) {
		    	if(line.startsWith("31")){
		    		conMonth = new ContractualDatesDTO();
		    		conMonth.setAirLine(line.substring(8, 10));
		    		conMonth.setStartDate(fmt.parse(line.substring(13, 21)));
		    		conMonth.setEndDate(fmt.parse(line.substring(22, 30)));
		    	}
		    	
                if(line.startsWith("01") || line.startsWith("02") || line.startsWith("25")){
                	
                	if(flag && line.startsWith("01")){
                         outList.put(count,list);
                         count++;
                         list = new ArrayList<String>();
                	}
                	list.add(line);
                	flag = true;
                }
            }   
		     outList.put(count, list);
		     new PilotBereavementServiceImpl().filterMap(outList,conMonth);
		} finally {
		    br.close();
		}
	}
}
