/*package com.aa.crewpay.rewrite.poc.pbr;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigInteger;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Map;
import java.util.Properties;

public class BereavementPOCTest {
	private static DateFormat fmt = new SimpleDateFormat("yyyyMMdd");

	public static void main(String[] args) throws FileNotFoundException, ParseException {
		System.out.println("CREWPAY REWRITE - POC");
		Properties prop = new Properties();
		InputStream input = null;
		try {
			input = new FileInputStream("resources\\bereavement.properties");
			prop.load(input);
			System.out.println("********************************** Processing RecType = �31� *******************************");
			Date sd = fmt.parse(prop.getProperty("Con_Start"));
			Date ed = fmt.parse(prop.getProperty("Con_End"));
			ContractualDatesDTO type31 = new ContractualDatesDTO();
			type31.setStartDate(sd);
			type31.setEndDate(ed);
			type31.setAirLine(prop.getProperty("AirLine"));
			
			System.out.println("********************************** Processing RecType = �01� *******************************");
			BereavementUtil utl = new BereavementUtil();
			Map<String ,String> baseMap = utl.getCbaseCodes();
			Map<String ,String> equipMap = utl.getEquipmentCodes();
			
			CrewMemberDTO type01 = null;
			int emp = new Integer(prop.getProperty("EMP"));
			String equip = prop.getProperty("Equip").trim();
			if(emp != 0 && equip != null && !equip.isEmpty()){
				type01 = new CrewMemberDTO();
				type01.setEmp(emp);
				type01.setEquip(equipMap.get(equip));
				if(prop.getProperty("TripType").trim().equals("1")){
					type01.setTypePi("RSV");
				}
				else{
					type01.setTypePi("REG");
				}
				Date date = fmt.parse(prop.getProperty("Date"));
				type01.setDate(date);
				type01.setActProj(Integer.valueOf(prop.getProperty("ActProj").trim()));
				type01.setsProj(new Integer(prop.getProperty("SProj")));
				type01.setpProj(new Integer(prop.getProperty("PProj")));
				type01.setcBase(baseMap.get(prop.getProperty("Base").trim()));
				type01.setDiv(prop.getProperty("Division"));
				String [] abscodes = prop.getProperty("Abs01-Abs31").split(" ");
				type01.setAbs01to31(Arrays.asList(abscodes));
				String [] payCodes = prop.getProperty("PaySt01-PaySt31").split(" ");
				type01.setPaySt01to31(Arrays.asList(payCodes));
				type01.setAdsCode(new Integer(prop.getProperty("AbsCode")));
				type01.setCurrAir(prop.getProperty("Curr_Air"));
			}
			
			if(type01.getcBase() == null || type01.getEquip().equals("XXX")) {
				System.out.println("********************************** Exceptional case *******************************");
			}
			
			System.out.println("********************************** Processing RecType = �02� *******************************");
			SequenceDTO type2 = null;
			int empNo = Integer.valueOf(prop.getProperty("EMP"));
			BigInteger seq = new BigInteger(prop.getProperty("SeqNo").trim());
			int pos = Integer.valueOf(prop.getProperty("SeqPosN"));
			String rmCd = prop.getProperty("S_RmvCd");
			
			if(empNo != 0 && seq != BigInteger.ZERO && pos != 0 && rmCd.equals("6")) {
				type2 = new SequenceDTO();
				type2.setSeqNo(seq);
				type2.setSeqPosN(pos);
				Date sqsd = fmt.parse(prop.getProperty("SeqSDate"));
				type2.setSeqSDate(sqsd);
				Date sqed = fmt.parse(prop.getProperty("SeqEDate"));
				type2.setSeqEDate(sqed);
				type2.setSeqRmvCd(rmCd);
				double tripval = Integer.valueOf(prop.getProperty("Seq_GFly"))+Integer.valueOf(prop.getProperty("E_Time"))+
						         Integer.valueOf(prop.getProperty("F_Time"))+Integer.valueOf(prop.getProperty("DH_Min"));
				type2.setTripVal(tripval);
			}
			
			System.out.println("********************************** Processing RecType = �25� *******************************");
			PlannedAbsenceDTO type25 = null;
			int empNum = Integer.valueOf(prop.getProperty("EMP"));
			String absCode = prop.getProperty("S_RmvCd").trim();
			
			if(empNum != 0 && absCode.equals("6") ) {
				type25 = new PlannedAbsenceDTO();
				Date abssd = fmt.parse(prop.getProperty("AbsSDate"));
				type25.setAbsSDate(abssd);
				Date absed = fmt.parse(prop.getProperty("AbsEDate"));
				type25.setAbsEDate(absed);
				type25.setAbsCode(absCode);
			}
			
			new PilotBereavementServiceImpl().calculateBereavement(type31, type01, type2, type25);

		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		
		
		
	}

}
*/