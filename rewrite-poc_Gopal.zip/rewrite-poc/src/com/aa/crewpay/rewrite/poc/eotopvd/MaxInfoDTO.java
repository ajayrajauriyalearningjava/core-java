package com.aa.crewpay.rewrite.poc.eotopvd;

public class MaxInfoDTO {
	
	private String typePI;
	private String cBase;
	private String div;
	private String equip;
	private String mSeat;
	private double mMax;
	
	
	public String getTypePI() {
		return typePI;
	}
	public void setTypePI(String typePI) {
		this.typePI = typePI;
	}
	public String getcBase() {
		return cBase;
	}
	public void setcBase(String cBase) {
		this.cBase = cBase;
	}
	public String getDiv() {
		return div;
	}
	public void setDiv(String div) {
		this.div = div;
	}
	public String getEquip() {
		return equip;
	}
	public void setEquip(String equip) {
		this.equip = equip;
	}
	public String getmSeat() {
		return mSeat;
	}
	public void setmSeat(String mSeat) {
		this.mSeat = mSeat;
	}
	public double getmMax() {
		return mMax;
	}
	public void setmMax(double mMax) {
		this.mMax = mMax;
	}
	
	

}
