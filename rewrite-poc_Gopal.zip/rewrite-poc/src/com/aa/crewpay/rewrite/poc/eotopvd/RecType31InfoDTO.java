package com.aa.crewpay.rewrite.poc.eotopvd;

import java.io.Serializable;
import java.util.Date;

public class RecType31InfoDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Date startDate;
	private Date endDate;
	private String airLine;
	

	public RecType31InfoDTO() {
		
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	
	public String getAirLine() {
		return airLine;
	}
	
	public void setAirLine(String airLine) {
		this.airLine = airLine;
	}
	

}
