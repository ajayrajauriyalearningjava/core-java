package com.aa.crewpay.rewrite.poc.pbr;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;

public class SequenceDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String SEQN;
	private String SEQPOSN;
	private String SEQSDATE;
	private String SEQEDATE;
	private String SEQRMVCODE;
	private String TRIPVAL;

	public SequenceDTO() {

	}

	public String getSEQN() {
		return SEQN;
	}

	public void setSEQN(String sEQN) {
		SEQN = sEQN;
	}

	public String getSEQPOSN() {
		return SEQPOSN;
	}

	public void setSEQPOSN(String sEQPOSN) {
		SEQPOSN = sEQPOSN;
	}

	public String getSEQSDATE() {
		return SEQSDATE;
	}

	public void setSEQSDATE(String sEQSDATE) {
		SEQSDATE = sEQSDATE;
	}

	public String getSEQEDATE() {
		return SEQEDATE;
	}

	public void setSEQEDATE(String sEQEDATE) {
		SEQEDATE = sEQEDATE;
	}

	public String getSEQRMVCODE() {
		return SEQRMVCODE;
	}

	public void setSEQRMVCODE(String sEQRMVCODE) {
		SEQRMVCODE = sEQRMVCODE;
	}

	public String getTRIPVAL() {
		return TRIPVAL;
	}

	public void setTRIPVAL(String tRIPVAL) {
		TRIPVAL = tRIPVAL;
	}

	
}
