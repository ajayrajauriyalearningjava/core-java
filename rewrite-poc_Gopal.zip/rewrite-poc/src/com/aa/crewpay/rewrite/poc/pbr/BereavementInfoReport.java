package com.aa.crewpay.rewrite.poc.pbr;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Bereavement_Info_Report")
public class BereavementInfoReport implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -6347288839006542285L;
	
	
	private long id;
	
	@Column(name="CURR_AIR")
	private String CURR_AIR;  
	@Column(name="CBASE")
	private String CBASE;
	@Column(name="EMP")
	private String EMP;
	@Column(name="ABSSDATE")
	private String ABSSDATE;
	@Column(name="ABSEDATE")
	private String ABSEDATE; 
	@Column(name="SEQNO")
	private String SEQNO ;
	@Column(name="SEQSDATE")
	private String SEQSDATE;
	@Column(name="SEQEDATE")
	private String SEQEDATE;
	@Column(name="TRIP_VAL")
	private String TRIP_VAL;
	@Column(name="DAILY_VAL")
	private String DAILY_VAL;
	@Column(name="RSV_PE")
	private String RSV_PE;
	@Column(name="PPROJ")
	private String PPROJ;
	@Column(name="ACTPROJ")
	private String ACTPROJ;
	@Column(name="SPROJ")
	private String SPROJ;
	
	
	public BereavementInfoReport() {
		
	}
	
	@Id
	@GeneratedValue
	@Column(name = "PBR_ID", unique = true, nullable = false)
	public long getId() {
		return id;
	}
	
	public void setId(long id) {
		this.id = id;
	}
	
	public String getCURR_AIR() {
		return CURR_AIR;
	}
	
	public void setCURR_AIR(String cURR_AIR) {
		CURR_AIR = cURR_AIR;
	}
	
	public String getCBASE() {
		return CBASE;
	}
	
	public void setCBASE(String cBASE) {
		CBASE = cBASE;
	}
	
	public String getEMP() {
		return EMP;
	}
	
	public void setEMP(String eMP) {
		EMP = eMP;
	}
	
	public String getABSSDATE() {
		return ABSSDATE;
	}
	
	public void setABSSDATE(String aBSSDATE) {
		ABSSDATE = aBSSDATE;
	}
	
	public String getABSEDATE() {
		return ABSEDATE;
	}
	
	public void setABSEDATE(String aBSEDATE) {
		ABSEDATE = aBSEDATE;
	}
	
	public String getSEQNO() {
		return SEQNO==null?".":SEQNO;
	}
	
	public void setSEQNO(String sEQNO) {
		SEQNO = sEQNO;
	}
	
	public String getSEQSDATE() {
		return SEQSDATE==null?".":SEQSDATE;
	}
	
	public void setSEQSDATE(String sEQSDATE) {
		SEQSDATE = sEQSDATE;
	}
	
	public String getSEQEDATE() {
		return SEQEDATE==null?".":SEQEDATE;
	}
	
	public void setSEQEDATE(String sEQEDATE) {
		SEQEDATE = sEQEDATE;
	}
	
	public String getTRIP_VAL() {
		return TRIP_VAL==null?".":TRIP_VAL;
	}
	
	public void setTRIP_VAL(String tRIP_VAL) {
		TRIP_VAL = tRIP_VAL;
	}
	
	public String getDAILYVAL() {
		return DAILY_VAL==null?".":DAILY_VAL;
	}
	
	public void setDAILYVAL(String dAILYVAL) {
		DAILY_VAL = dAILYVAL;
	}
	
	public String getRSV_PE() {
		return RSV_PE;
	}
	
	public void setRSV_PE(String rSV_PE) {
		RSV_PE = rSV_PE;
	}
	
	public String getPPROJ() {
		return PPROJ;
	}
	
	public void setPPROJ(String pPROJ) {
		PPROJ = pPROJ;
	}
	
	public String getACTPROJ() {
		return ACTPROJ;
	}
	
	public void setACTPROJ(String aCTPROJ) {
		ACTPROJ = aCTPROJ;
	}
	
	public String getSPROJ() {
		return SPROJ;
	}
	
	public void setSPROJ(String sPROJ) {
		SPROJ = sPROJ;
	}
	

}
