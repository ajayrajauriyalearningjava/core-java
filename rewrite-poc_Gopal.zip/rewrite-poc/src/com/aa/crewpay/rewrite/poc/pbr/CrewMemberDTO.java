package com.aa.crewpay.rewrite.poc.pbr;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class CrewMemberDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String EMPNO;
	private String EQUIP;
	private String TRIPTYPE;
	private String DATE;
	private String ACTPROJ;
	private String SCHPROJ;
	private String PAYPROJ;
	private String BASE;
	private String DIV;
	private List<String> ABS01TO31;
	private List<String> PAYST01TO31;
	private String CURRAIR;
	private String TYPEPI;
	private String ABSCODE;
	private String RSVPE;
	private List<SequenceDTO> SEQLIST;
	private List<PlannedAbsenceDTO> ABSLIST;
	
	public CrewMemberDTO() {

	}

	public String getEMPNO() {
		return EMPNO;
	}

	public void setEMPNO(String eMPNO) {
		EMPNO = eMPNO;
	}

	public String getEQUIP() {
		return EQUIP;
	}

	public void setEQUIP(String eQUIP) {
		EQUIP = eQUIP;
	}

	public String getTRIPTYPE() {
		return TRIPTYPE;
	}

	public void setTRIPTYPE(String tRIPTYPE) {
		TRIPTYPE = tRIPTYPE;
	}

	public String getDATE() {
		return DATE;
	}

	public void setDATE(String dATE) {
		DATE = dATE;
	}

	public String getACTPROJ() {
		return ACTPROJ;
	}

	public void setACTPROJ(String aCTPROJ) {
		ACTPROJ = aCTPROJ;
	}

	public String getSCHPROJ() {
		return SCHPROJ;
	}

	public void setSCHPROJ(String sCHPROJ) {
		SCHPROJ = sCHPROJ;
	}

	public String getPAYPROJ() {
		return PAYPROJ;
	}

	public void setPAYPROJ(String pAYPROJ) {
		PAYPROJ = pAYPROJ;
	}

	public String getBASE() {
		return BASE;
	}

	public void setBASE(String bASE) {
		BASE = bASE;
	}

	public String getDIV() {
		return DIV;
	}

	public void setDIV(String dIV) {
		DIV = dIV;
	}

	public List<String> getABS01TO31() {
		return ABS01TO31;
	}

	public void setABS01TO31(List<String> aBS01TO31) {
		ABS01TO31 = aBS01TO31;
	}

	public List<String> getPAYST01TO31() {
		return PAYST01TO31;
	}

	public void setPAYST01TO31(List<String> pAYST01TO31) {
		PAYST01TO31 = pAYST01TO31;
	}

	public String getCURRAIR() {
		return CURRAIR;
	}

	public void setCURRAIR(String cURRAIR) {
		CURRAIR = cURRAIR;
	}

	public String getTYPEPI() {
		return TYPEPI;
	}

	public void setTYPEPI(String tYPEPI) {
		TYPEPI = tYPEPI;
	}

	public String getABSCODE() {
		return ABSCODE;
	}

	public void setABSCODE(String aBSCODE) {
		ABSCODE = aBSCODE;
	}

	public String getRSVPE() {
		return RSVPE;
	}

	public void setRSVPE(String rSVPE) {
		RSVPE = rSVPE;
	}

	public List<SequenceDTO> getSEQLIST() {
		return SEQLIST;
	}

	public void setSEQLIST(List<SequenceDTO> sEQLIST) {
		SEQLIST = sEQLIST;
	}

	public List<PlannedAbsenceDTO> getABSLIST() {
		return ABSLIST;
	}

	public void setABSLIST(List<PlannedAbsenceDTO> aBSLIST) {
		ABSLIST = aBSLIST;
	}

	
			
}
