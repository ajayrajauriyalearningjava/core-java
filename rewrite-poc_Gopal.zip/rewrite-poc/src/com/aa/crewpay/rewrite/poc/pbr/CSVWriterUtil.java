package com.aa.crewpay.rewrite.poc.pbr;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class CSVWriterUtil {
	
	private static final String heading = "                        PILOTS WITH PE ON PLAN ABS, SEQ RMVL, OR RSV DAY RMVL                                             \n";
	
	public void writeInCsv(Set<BereavementInfoReport> reportList) throws FileNotFoundException{
		BereavementInfoReport rpt = new BereavementInfoReport();
		Field[] headers = rpt.getClass().getDeclaredFields();
		FileOutputStream fout = null;
		try {
			fout = new FileOutputStream("resources\\pilot_bereavement_report.csv");
			fout.write(heading.getBytes());
			String header = headers[2].getName()+","+
							headers[3].getName()+","+
							headers[4].getName()+","+
							headers[5].getName()+","+
							headers[6].getName()+","+
							headers[7].getName()+","+
							headers[8].getName()+","+
							headers[9].getName()+","+
							headers[10].getName()+","+
							headers[11].getName()+","+
							headers[12].getName()+","+
							headers[13].getName()+","+
							headers[14].getName()+","+
							headers[15].getName()+"\n";
			fout.write(header.getBytes());
			System.out.println(header);
			System.out.println("******************************************************************************************************************************");
			 Session session=DBUtil.getSessionFactory().openSession();  
			 Transaction tx=session.beginTransaction();  
			for(BereavementInfoReport report :reportList) {
				session.save(report);
				String value = report.getCURR_AIR()+","+
							   report.getCBASE()+","+
							   report.getEMP()+","+
							   report.getABSSDATE()+","+
							   report.getABSEDATE()+","+
							   report.getSEQNO() +","+
							   report.getSEQSDATE()+","+
							   report.getSEQEDATE() +","+
							   report.getTRIP_VAL()+","+
							   report.getDAILYVAL()+","+
							   report.getRSV_PE()+","+
							   report.getPPROJ()+","+
							   report.getACTPROJ()+","+
							   report.getSPROJ()+"\n";
						fout.write(value.getBytes());
						System.out.println(value);
			}
			
			tx.commit();	//transaction is commited  
		    session.close(); 
		    DBUtil.shutdown();
			
			
		} catch (IOException e) {
			e.printStackTrace();
		} 
	}
}
