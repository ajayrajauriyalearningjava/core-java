package com.aa.crewpay.rewrite.poc.pbr;

import java.util.Map;

public class POCTest2 {

	public static void main(String[] args) {
		
		/*BereavementUtil utl = new BereavementUtil();
		
		Map<String ,String> baseMap = utl.getCbaseCodes();
		Map<String ,String> equipMap = utl.getEquipmentCodes();
		System.out.println(baseMap.get("02"));
		System.out.println(equipMap.get("17"));*/
		
		//double actProj = (int)(type01.getActProj()/60) +(type01.getActProj()%60)/100;
		
		//System.out.println(23/60 + ((23%60)/100));

	}

}
