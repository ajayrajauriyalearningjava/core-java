package com.aa.crewpay.rewrite.poc.eotopvd;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class EoToPvdUtil {
	
	public Map<String ,String> getCbaseCodes(){
		Map<String ,String> baseMap = null;
		BufferedReader br = null;
		String line = "";
		try {
			baseMap = new HashMap<String ,String>();
			br = new BufferedReader(new FileReader("resources\\basetocbase.txt"));
		    while((line = br.readLine()) != null) {
		    	if(line != null && !line.isEmpty()){
		    		String [] base = line.split("  ");
		    		baseMap.put(base[0], base[1]);
		    	}
		    }

		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		finally {
		    try {
				br.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return baseMap;
	}
	
	public Map<String ,String> getEquipmentCodes(){
		Map<String ,String> equipMap = null;
		BufferedReader br = null;
		String line = "";
		try {
			equipMap = new HashMap<String ,String>();
			br = new BufferedReader(new FileReader("resources\\equiptoeqp.txt"));
		    while((line = br.readLine()) != null) {
		    	if(line != null && !line.isEmpty()){
		    		String [] equip = line.split("  ");
		    		equipMap.put(equip[0], equip[1]);
		    	}
		    }
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		finally {
		    try {
				br.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return equipMap;
	}

	public List<String> getPayStatusCountList(){
		String [] arr = {"01","11","41","04","14","54","58","08","18","16","48"};
		List<String> countList = new ArrayList<String>(Arrays.asList(arr));
		return countList;
	}
	
	public Map<Integer,String> getSeatByMonSeatId(){
		Map<Integer,String> seatMap = new HashMap<Integer, String>();
		seatMap.put(1, "CA");
		seatMap.put(2, "FO");
		seatMap.put(3, "FE");
		seatMap.put(6, "FB");
		seatMap.put(7, "FC");
		seatMap.put(8, "RC");
		seatMap.put(0, "XX");
		return seatMap;
	}
}
