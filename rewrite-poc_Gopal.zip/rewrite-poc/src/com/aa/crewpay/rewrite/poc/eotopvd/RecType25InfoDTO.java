package com.aa.crewpay.rewrite.poc.eotopvd;

import java.io.Serializable;
import java.util.Date;

public class RecType25InfoDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private int emp;
	private Date absSDate; 
	private Date absEDate;
	private String absCode;
	
	
	public RecType25InfoDTO(){
		
	}


	public int getEmp() {
		return emp;
	}


	public void setEmp(int emp) {
		this.emp = emp;
	}


	public Date getAbsSDate() {
		return absSDate;
	}


	public void setAbsSDate(Date absSDate) {
		this.absSDate = absSDate;
	}


	public Date getAbsEDate() {
		return absEDate;
	}


	public void setAbsEDate(Date absEDate) {
		this.absEDate = absEDate;
	}


	public String getAbsCode() {
		return absCode;
	}


	public void setAbsCode(String absCode) {
		this.absCode = absCode;
	}
	
	
	
	

}
