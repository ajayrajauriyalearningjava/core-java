package com.aa.crewpay.rewrite.poc.pbr;

import java.io.Serializable;
import java.util.Date;

public class PlannedAbsenceDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String ABSSTARTDATE; 
	private String ABSENDDATE;
	private String ABSCODE;
	
	
	public PlannedAbsenceDTO(){
		
	}


	public String getABSSTARTDATE() {
		return ABSSTARTDATE;
	}


	public void setABSSTARTDATE(String aBSSTARTDATE) {
		ABSSTARTDATE = aBSSTARTDATE;
	}


	public String getABSENDDATE() {
		return ABSENDDATE;
	}


	public void setABSENDDATE(String aBSENDDATE) {
		ABSENDDATE = aBSENDDATE;
	}


	public String getABSCODE() {
		return ABSCODE;
	}


	public void setABSCODE(String aBSCODE) {
		ABSCODE = aBSCODE;
	}


}
