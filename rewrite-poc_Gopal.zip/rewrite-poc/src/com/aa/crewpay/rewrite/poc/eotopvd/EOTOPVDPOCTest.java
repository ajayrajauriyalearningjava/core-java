package com.aa.crewpay.rewrite.poc.eotopvd;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigInteger;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Map;
import java.util.Properties;


public class EOTOPVDPOCTest {
	private static DateFormat fmt = new SimpleDateFormat("yyyyMMdd");

	public static void main(String[] args) throws FileNotFoundException, ParseException {
		System.out.println("CREWPAY REWRITE - POC");
		Properties prop = new Properties();
		InputStream input = null;
		try {
			input = new FileInputStream("resources\\eotopvd.properties");
			prop.load(input);
			
			Date sd = fmt.parse(prop.getProperty("Con_Start"));
			Date ed = fmt.parse(prop.getProperty("Con_End"));
			RecType31InfoDTO type31 = new RecType31InfoDTO();
			type31.setAirLine(prop.getProperty("AirLine"));
			type31.setStartDate(sd);
			type31.setEndDate(ed);
			System.out.println("********************************** Processing RecType = �31� *******************************");
			RecType32InfoDTO type32 = new RecType32InfoDTO();
			type32.setBASENO(prop.getProperty("BASE_NO"));
			type32.setCBASE(prop.getProperty("CBASE"));
			type32.setDATE(prop.getProperty("DATE"));
			type32.setDDIV(prop.getProperty("DDIV"));
			type32.setIDIV(prop.getProperty("IDIV"));
			String [] dcaEqp = prop.getProperty("DCAEQP01-30").split(" ");
			type32.setDCAEQPList(Arrays.asList(dcaEqp));
			String [] dcaReg = prop.getProperty("DCAREG01-30").split(" ");
			type32.setDCAREGList(Arrays.asList(dcaReg));
			String [] dcaRsv = prop.getProperty("DCARSV01-30").split(" ");
			type32.setDCARSVList(Arrays.asList(dcaRsv));
			String [] dfoEqp = prop.getProperty("DFOEQP01-30").split(" ");
			type32.setDFOEQPList(Arrays.asList(dfoEqp));
			String [] dfoReg = prop.getProperty("DFOREG01-30").split(" ");
			type32.setDFOREGList(Arrays.asList(dfoReg));
			String [] dfoRsv = prop.getProperty("DFORSV01-30").split(" ");
			type32.setDFORSVList(Arrays.asList(dfoRsv));
			String [] icaEqp = prop.getProperty("ICAEQP01-30").split(" ");
			type32.setICAEQPList(Arrays.asList(icaEqp));
			String [] icaReg = prop.getProperty("ICAREG01-30").split(" ");
			type32.setICAREGList(Arrays.asList(icaReg));
			String [] icaRsv = prop.getProperty("ICARSV01-30").split(" ");
			type32.setICARSVList(Arrays.asList(icaRsv));
			String [] ifoEqp = prop.getProperty("IFOEQP01-30").split(" ");
			type32.setIFOEQPList(Arrays.asList(ifoEqp));
			String [] ifoReg = prop.getProperty("IFOREG01-30").split(" ");
			type32.setIFOREGList(Arrays.asList(ifoReg));
			String [] ifoRsv = prop.getProperty("IFORSV01-30").split(" ");
			type32.setIFORSVList(Arrays.asList(ifoRsv));
			
			System.out.println("********************************** Processing RecType = �32� *******************************");
			
			EoToPvdUtil utl = new EoToPvdUtil();
			Map<String ,String> baseMap = utl.getCbaseCodes();
			Map<String ,String> equipMap = utl.getEquipmentCodes();
			Map<Integer ,String> seatMap = utl.getSeatByMonSeatId();
			RecType01InfoDTO type01 = null;
			int emp = new Integer(prop.getProperty("EMP"));
			String equip = prop.getProperty("Equip").trim();
			if(emp != 0 && equip != null && !equip.isEmpty()){
				type01 = new RecType01InfoDTO();
				type01.setEmp(emp);
				type01.setEquip(equip);
				type01.setEqp(equipMap.get(equip));
				if(prop.getProperty("TripType").trim().equals("1")){
					type01.setTypePi("RSV");
				}
				else{
					type01.setTypePi("REG");
				}
				Date date = fmt.parse(prop.getProperty("Date"));
				type01.setDate(date);
				type01.setActProj(Integer.valueOf(prop.getProperty("ActProj").trim()));
				type01.setsProj(new Integer(prop.getProperty("SProj")));
				type01.setpProj(new Integer(prop.getProperty("PProj")));
				type01.setcBase(baseMap.get(prop.getProperty("Base").trim()));
				type01.setDiv(prop.getProperty("Division"));
				int monSeat = new Integer(prop.getProperty("Mon_Seat"));
				String seat = seatMap.get(monSeat);
				if(seat.equals("FB") || seat.equals("FC") ){
					type01.setMSeat("FO");
				}
				else if(seat.equals("RC")){
					type01.setMSeat("CA");
				}
				else{
					type01.setMSeat(seat);
				}
				String [] abscodes = prop.getProperty("Abs01-Abs31").split(" ");
				type01.setAbs01to31(Arrays.asList(abscodes));
				String [] payCodes = prop.getProperty("PaySt01-PaySt31").split(" ");
				type01.setPaySt01to31(Arrays.asList(payCodes));
				type01.setCurrAir(prop.getProperty("Curr_Air"));
			}
			System.out.println("********************************** Processing RecType = �01� *******************************");
			
			if(type01.getcBase() == null || type01.getEqp().equals("XXX")) {
				System.out.println("********************************** Exceptional case *******************************");
			}
			
			RecType02InfoDTO type2 = null;
			int empNo = Integer.valueOf(prop.getProperty("EMP"));
			BigInteger seq = new BigInteger(prop.getProperty("SeqNo").trim());
			int pos = Integer.valueOf(prop.getProperty("SeqPosN"));
			String rmCd = prop.getProperty("S_RmvCd");
			
			if(empNo != 0 && seq != BigInteger.ZERO && pos != 0 && rmCd.equals("87")) {
				type2 = new RecType02InfoDTO();
				type2.setEmp(empNo);
				type2.setSeqNo(seq);
				type2.setSeqPosN(pos);
				Date sqsd = fmt.parse(prop.getProperty("SeqSDate"));
				type2.setSeqSDate(sqsd);
				Date sqed = fmt.parse(prop.getProperty("SeqEDate"));
				type2.setSeqEDate(sqed);
				type2.setSeqRmvCd(rmCd);
				double tripval = Integer.valueOf(prop.getProperty("Seq_GFly"))+Integer.valueOf(prop.getProperty("E_Time"))+
						         Integer.valueOf(prop.getProperty("F_Time"))+Integer.valueOf(prop.getProperty("DH_Min"));
				type2.setTripVal(tripval);
			}
			System.out.println("********************************** Processing RecType = �02� *******************************");
			RecType25InfoDTO type25 = null;
			int empNum = Integer.valueOf(prop.getProperty("EMP"));
			String absCode = prop.getProperty("S_RmvCd").trim();
			
			if(empNum != 0 && absCode.equals("87") ) {
				type25 = new RecType25InfoDTO();
				type25.setEmp(empNum);
				Date abssd = fmt.parse(prop.getProperty("AbsSDate"));
				type25.setAbsSDate(abssd);
				Date absed = fmt.parse(prop.getProperty("AbsEDate"));
				type25.setAbsEDate(absed);
				type25.setAbsCode(absCode);
			}
			System.out.println("********************************** Processing RecType = �25� *******************************");
			
			//new PilotBereavementServiceImpl().process(type31, type01, type2, type25);

		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		
		
		
	}

}
