package com.aa.crewpay.rewrite.poc.eotopvd;

import java.io.Serializable;

public class EotoPvdInfoReport implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -6347288839006542285L;
	
	private String CURR_AIR;  
	private String CBASE;
	private String EMP;
	private String ABSSDATE;
	private String ABSEDATE;  
	private String SEQNO ;
	private String SEQSDATE;
	private String SEQEDATE;
	private String TRIP_VAL;
	private String DAILY_VAL;
	private String RSV_EO;
	private String PPROJ;
	private String ACTPROJ;
	private String SPROJ;
	
	
	
	public EotoPvdInfoReport() {
		
	}
	
	public String getCURR_AIR() {
		return CURR_AIR;
	}
	
	public void setCURR_AIR(String cURR_AIR) {
		CURR_AIR = cURR_AIR;
	}
	
	public String getCBASE() {
		return CBASE;
	}
	
	public void setCBASE(String cBASE) {
		CBASE = cBASE;
	}
	
	public String getEMP() {
		return EMP;
	}
	
	public void setEMP(String eMP) {
		EMP = eMP;
	}
	
	public String getABSSDATE() {
		return ABSSDATE;
	}
	
	public void setABSSDATE(String aBSSDATE) {
		ABSSDATE = aBSSDATE;
	}
	
	public String getABSEDATE() {
		return ABSEDATE;
	}
	
	public void setABSEDATE(String aBSEDATE) {
		ABSEDATE = aBSEDATE;
	}
	
	public String getSEQNO() {
		return SEQNO;
	}
	
	public void setSEQNO(String sEQNO) {
		SEQNO = sEQNO;
	}
	
	public String getSEQSDATE() {
		return SEQSDATE;
	}
	
	public void setSEQSDATE(String sEQSDATE) {
		SEQSDATE = sEQSDATE;
	}
	
	public String getSEQEDATE() {
		return SEQEDATE;
	}
	
	public void setSEQEDATE(String sEQEDATE) {
		SEQEDATE = sEQEDATE;
	}
	
	public String getTRIP_VAL() {
		return TRIP_VAL;
	}
	
	public void setTRIP_VAL(String tRIP_VAL) {
		TRIP_VAL = tRIP_VAL;
	}
	
	public String getDAILYVAL() {
		return DAILY_VAL;
	}
	
	public void setDAILYVAL(String dAILYVAL) {
		DAILY_VAL = dAILYVAL;
	}
	
	public String getRSV_EO() {
		return RSV_EO;
	}
	
	public void setRSV_EO(String rSV_EO) {
		RSV_EO = rSV_EO;
	}
	
	public String getPPROJ() {
		return PPROJ;
	}
	
	public void setPPROJ(String pPROJ) {
		PPROJ = pPROJ;
	}
	
	public String getACTPROJ() {
		return ACTPROJ;
	}
	
	public void setACTPROJ(String aCTPROJ) {
		ACTPROJ = aCTPROJ;
	}
	
	public String getSPROJ() {
		return SPROJ;
	}
	
	public void setSPROJ(String sPROJ) {
		SPROJ = sPROJ;
	}
	

}
