package com.crewpay.fa.text;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Scanner;

public class test {

	public static void main(String[] args) throws IOException {
		Scanner sc=new Scanner(new FileInputStream("src/com/crewpay/fa/properties/'Z577915.FCRM.FCW020.A03.S1.A1'.txt"));
		int count=0;
		while(sc.hasNext()){
			String line=sc.nextLine();
			if(line.startsWith("0")){
				System.out.println(line);
				count++;
			}
		}
		System.out.println(count);
//		List<Student> studentList=new ArrayList<>();
//		studentList.add(new Student(1,1,1,1));
//		studentList.add(new Student(1,1,2,2));
//		studentList.add(new Student(1,1,3,3));
//		studentList.add(new Student(1,2,1,1));
//		studentList.add(new Student(1,2,2,2));
//		studentList.add(new Student(1,2,3,3));
//		studentList.add(new Student(2,1,1,1));
//		studentList.add(new Student(2,1,3,2));
//		studentList.add(new Student(2,2,1,1));
//		studentList.add(new Student(2,2,2,1));
//		studentList.add(new Student(2,2,3,1));
//		studentList.add(new Student(3,1,1,1));
//		studentList.add(new Student(3,1,2,2));
//		studentList.add(new Student(3,1,3,3));
//		studentList.add(new Student(3,2,1,1));
//		studentList.add(new Student(3,2,2,2));
//		studentList.add(new Student(3,2,3,3));
//		studentList.add(new Student(4,1,1,1));
//		studentList.add(new Student(4,1,3,2));
//		studentList.add(new Student(4,2,1,1));
//		studentList.add(new Student(4,2,2,1));
//		studentList.add(new Student(4,2,3,1));
//		Collections.sort(studentList,Comparator.comparing(Student::getEid)
//												.thenComparing(Student::getSid)
//												.thenComparing(Comparator.comparing(Student::getDid)
//																			.reversed()));
//		System.out.println(studentList);
		
		
		
	}
}
