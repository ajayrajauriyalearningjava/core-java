package com.crewpay.fa.text;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;

import com.crewpay.fa.model.CrewMembers;
import com.crewpay.fa.model.Dutyperiods;
import com.crewpay.fa.model.FlightAttendantModel;
import com.crewpay.fa.model.Legs;
import com.crewpay.fa.model.Sequences;
public class FlightAttendant {
	
	public static void main(String[] args) {
		FileInputStream fis;
		try {
			fis = new FileInputStream("src/com/crewpay/fa/resources/FCRM.properties");
			
			Properties MyProps = new Properties();
			MyProps.load(fis);
			Scanner scanner=new Scanner(new File("src/com/crewpay/fa/resources/FCRM_FA.txt"));
			List<Sequences> sequencesList=new ArrayList<>();
			List<Dutyperiods> dutyperiodsList=new ArrayList<>();;
			List<Legs> legsList=new ArrayList<>();
			FlightAttendantModel FAModel=new FlightAttendantModel();
			List<CrewMembers> crewMembersList=new ArrayList<>();
			CrewMembers crewMembers=null;
			Sequences sequences=null;
			Dutyperiods dutyperiods=null;
			Legs legs=null;
			
			//Setting values for dto's from fcrm file 
			while(scanner.hasNextLine()){
				String recordTypeNoLine=scanner.nextLine();
				
//				sending the parameters to parsingFCRMDumpFileIntoDTO() for parsing
//				parsingFCRMDumpFileIntoDTO(properties file with start index and end index, DTO .class, recordType line)
				if(recordTypeNoLine.startsWith("01")){
//					System.out.println(line);
					recordTypeNoLine=recordTypeNoLine.substring(2);
					crewMembers=(CrewMembers) FlightAttendantUtil.parsingFCRMDumpFileIntoDTO(MyProps.getProperty("FCRM.Rec_Type01"), CrewMembers.class,recordTypeNoLine);
					crewMembersList.add(crewMembers );;
					//System.out.println(crewMembersList);
				}
				else if(recordTypeNoLine.startsWith("02")){
//					System.out.println(line);
					recordTypeNoLine=recordTypeNoLine.substring(2);
					sequences=(Sequences) FlightAttendantUtil.parsingFCRMDumpFileIntoDTO(MyProps.getProperty("FCRM.Rec_Type02"), Sequences.class,recordTypeNoLine);
					sequences.setSEQ_EMPNo(crewMembers.getEMPNo());
					sequencesList.add(sequences);
//					System.out.println(sequencesList);
				}
				else if(recordTypeNoLine.startsWith("03")){
//					System.out.println(line);
					recordTypeNoLine=recordTypeNoLine.substring(2);
					dutyperiods=(Dutyperiods) FlightAttendantUtil.parsingFCRMDumpFileIntoDTO(MyProps.getProperty("FCRM.Rec_Type03"), Dutyperiods.class,recordTypeNoLine);
					dutyperiods.setDP_SEQUENCE_NUMBER(sequences.getSEQUENCE_NUMBER());
					dutyperiods.setDP_EMPNo(crewMembers.getEMPNo());
					dutyperiodsList.add(dutyperiods );
//					System.out.println(dutyperiodsList);
				}
				else if(recordTypeNoLine.startsWith("04")){
//					System.out.println(line);
					recordTypeNoLine=recordTypeNoLine.substring(2);
					legs= (Legs) FlightAttendantUtil.parsingFCRMDumpFileIntoDTO(MyProps.getProperty("FCRM.Rec_Type04"), Legs.class,recordTypeNoLine);
					legs.setLEG_EMPNo(crewMembers.getEMPNo());
					legs.setLEG_SEQUENCE_NUMBER(sequences.getSEQUENCE_NUMBER());
					legsList.add( legs);
//					System.out.println(legsList);
				}
				
			}
			System.out.println(crewMembersList.size());
			System.out.println(sequencesList.size());
			System.out.println(dutyperiodsList.size());
			System.out.println(legsList.size());
			
			FAModel.setCrewMember(crewMembersList);
			FAModel.setSequences(sequencesList);
			FAModel.setDutyperiods(dutyperiodsList);
			FAModel.setLegs(legsList);
			
			
//			Setting all records in a relationship like Crewmembers-->Sequences-->Dutyperiods-->Legs 
			crewMembersList=new ArrayList<>();
			for (CrewMembers crewMember2 : FAModel.getCrewMember()) {
				sequencesList = new ArrayList<>();
				for (Sequences sequences2 : FAModel.getSequences())
				{
					if (crewMember2.getEMPNo().equals(sequences2.getSEQ_EMPNo())) {
						dutyperiodsList = new ArrayList<>();
						for (Dutyperiods dutyperiods1 : FAModel.getDutyperiods()) {
							if ((crewMember2.getEMPNo().equals(dutyperiods1.getDP_EMPNo()))&& (sequences2.getSEQUENCE_NUMBER().equals(dutyperiods1.getDP_SEQUENCE_NUMBER()))) {
								legsList=new ArrayList<>();
								int i=0;
								for(Legs legs1:FAModel.getLegs()){
									if(legs1.getLEG_DP_NO()!=null){
//										System.out.println(dutyperiods1.getDP_EMPNo()+"----"+(legs1.getLEG_EMPNo())+"----"+(dutyperiods1.getDP_SEQUENCE_NUMBER())+"----"+legs1.getLEG_SEQUENCE_NUMBER()+"-----"+dutyperiods1.getXDTYPER()+"----"+legs1.getLEG_DP_NO());
										if((dutyperiods1.getDP_EMPNo().equals(legs1.getLEG_EMPNo()))&& (dutyperiods1.getDP_SEQUENCE_NUMBER().equals(legs1.getLEG_SEQUENCE_NUMBER()))&&(legs1.getLEG_DP_NO().equals(dutyperiods1.getXDTYPER()))){
//											if((!FAModel.getFcrm_Model().get(i).getIPD_STATION().contains(legs1.getARRIVAL_STATION()))||(!FAModel.getFcrm_Model().get(i).getIPD_STATION().contains(legs1.getDEPARTURE_STATION()))){
												legsList.add(legs1);
//											}
										}
									}
									i++;
								}
								if (legsList .size()!=0) {
									dutyperiods1.setLegs(legsList);
									dutyperiodsList.add(dutyperiods1);
								}
							}
						}
						if (dutyperiodsList.size() != 0) {
							sequences2.setDutyperiods(dutyperiodsList);
							sequencesList.add(sequences2);
						}
					}
					
				}
				if (sequencesList.size()!=0 ) {
					crewMember2.setSequences(sequencesList);
					crewMembersList.add(crewMember2);
				}
			}
			FAModel.setCrewMember(crewMembersList);
			FAModel.setCrewMember(crewMembersList);
			
//			Finding the Size of each employee records size
			int i=1;
			for(CrewMembers crewMembers2:FAModel.getCrewMember()){
				System.out.println("CrewMembrs----"+i);
				for(Sequences sequences2:crewMembers2.getSequences()){
					for(Dutyperiods dutyperiods2:sequences2.getDutyperiods()){
						System.out.println("legs---"+dutyperiods2.getLegs().size());
					}
					System.out.println("dutyperiods----"+sequences2.getDutyperiods().size());
				}
				System.out.println("sequences-----"+crewMembers2.getSequences().size());
				i++;
			}
			// Generate Reports for Record type 01,02,03,04 files
			FlightAttendantUtil.reportGenerate(FAModel.getCrewMember(), "RecordType 01.csv");
			FlightAttendantUtil.reportGenerate(FAModel.getSequences(), "RecordType 02.csv");
			FlightAttendantUtil.reportGenerate(FAModel.getDutyperiods(), "RecordType 04.csv");
			FlightAttendantUtil.reportGenerate(FAModel.getLegs(), "RecordType 04.csv");
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {

			e.printStackTrace();
		}
	}
}
