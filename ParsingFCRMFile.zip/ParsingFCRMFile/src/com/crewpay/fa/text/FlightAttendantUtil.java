package com.crewpay.fa.text;

import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;
import java.util.StringTokenizer;

import org.supercsv.io.CsvBeanWriter;
import org.supercsv.io.ICsvBeanWriter;
import org.supercsv.prefs.CsvPreference;

public class FlightAttendantUtil {

	static FileInputStream fis;

	public static Object parsingFCRMDumpFileIntoDTO(String path, Class<?> clazz,String line)
			throws IOException, ClassNotFoundException, InstantiationException, IllegalAccessException {
		fis = new FileInputStream(path);
		ResourceBundle resources = new PropertyResourceBundle(fis);
		String delims = ",";
		List<Integer> list = null;
		Map<String, List<Integer>> map = new HashMap<String, List<Integer>>();
		// convert ResourceBundle to Map
		Enumeration<String> keys = resources.getKeys();
		int index=0;
		while (keys.hasMoreElements()) {
			String key = (String) keys.nextElement();
			String value = resources.getString(key);
			StringTokenizer st = new StringTokenizer(value, delims);
			list = new ArrayList<>();
			while (st.hasMoreTokens()) {
				String str = st.nextToken();
				index=Integer.parseInt(str.trim());
				list.add(index);
			}
			map.put(key, list);
//			System.out.println(key+"------"+list.size());
		}
		Object obj=clazz.newInstance();
	//	System.out.println("J--->"+j);
			for(Field field : clazz.getDeclaredFields()) {
				Object field1 = field;
				// convert ResourceBundle to Map
//				System.out.println(field.getName());
				if (!field.getName().equalsIgnoreCase("sequences") ) {
//						System.out.println(field.getName());
//						System.out.println(map);
						if(map.size()!=0&&map.get(field.getName())!=null){
							if(map.get(field.getName()).size()!=0){
//							System.out.println(map.get(field.getName()).get(0)+"----"+map.get(field.getName()).get(1));
//							System.out.println(line.substring(map.get(field.getName()).get(0),map.get(field.getName()).get(1)));
//							System.out.println(field.getName() + "<------->" + line.substring(map.get(field.getName()).get(0),map.get(field.getName()).get(1)));
						   if (field.getType().getCanonicalName().contains("Date")) {
								field.set(obj, line.substring(map.get(field.getName()).get(0),map.get(field.getName()).get(1)));
							} else if (field.getType().getCanonicalName().contains("Integer")) {
								field.set(obj, Integer.parseInt(line.substring(map.get(field.getName()).get(0),map.get(field.getName()).get(1))));
							} else if (field.getType().getCanonicalName().contains("Character")) {
								field.set(obj, line.substring(map.get(field.getName()).get(0),map.get(field.getName()).get(1)).charAt(0));
							} else {
								field.set(obj, line.substring(map.get(field.getName()).get(0),map.get(field.getName()).get(1)));
							}
						}
					}
				}
//						if(field.getName().endsWith("XDTYPER"))
//						System.out.println(field.getName() + "<------->" + field.get(obj));
					}
			System.out.println(obj);
		return obj;

	}
	
	public static void reportGenerate(List<?> objectList,String fileName) {
		if(objectList!=null&&objectList.size()!=0){
			System.out.println(objectList.size());
			try(ICsvBeanWriter writer=new CsvBeanWriter(new FileWriter(fileName), CsvPreference.STANDARD_PREFERENCE);){
				String headers[]=new String[200];
				int flag=0;
				for(Field field:objectList.get(0).getClass().getFields()){
					headers[flag]=field.getName();
					flag++;
				}
				writer.writeHeader(headers);
					for (Object object :objectList ) {
						writer.write(object, headers);
					}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
	
		}
		
		
	}
	
}
