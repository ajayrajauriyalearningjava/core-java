package com.crewpay.fa.model;

import java.util.ArrayList;
import java.util.List;

public class FlightAttendantModel {

	public List<CrewMembers> crewMember;
	public List<Sequences> sequences;
	public List<Dutyperiods> dutyperiods;
	public List<Legs> legs;
	public List<CrewMembers> getCrewMember() {
		return crewMember;
	}
	public void setCrewMember(List<CrewMembers> crewMember) {
		this.crewMember = crewMember;
	}
	public List<Sequences> getSequences() {
		return sequences;
	}
	public void setSequences(List<Sequences> sequences) {
		this.sequences = sequences;
	}
	public List<Dutyperiods> getDutyperiods() {
		return dutyperiods;
	}
	public void setDutyperiods(List<Dutyperiods> dutyperiods) {
		this.dutyperiods = dutyperiods;
	}
	public List<Legs> getLegs() {
		return legs;
	}
	public void setLegs(List<Legs> legs) {
		this.legs = legs;
	}
	
	@Override
	public String toString() {
		return "FlightAttendantModel [crewMember=" + crewMember + ", sequences=" + sequences + ", dutyperiods="
				+ dutyperiods + ", legs=" + legs + "]";
	}
	
	
}
