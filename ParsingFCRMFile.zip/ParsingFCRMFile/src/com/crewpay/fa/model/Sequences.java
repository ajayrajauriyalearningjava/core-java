package com.crewpay.fa.model;

import java.util.Date;
import java.util.List;

public class Sequences extends CrewMembers{
	
	public Integer SEQ_EMPNo;
	public String SCHEDULED_START_DATE;
	public Integer SEQUENCE_NUMBER;
	public Integer SEQ_REASON_CODE;
	public Integer SEQ_REMOVAL_CODE;
	public Integer SEQ_LEVEL_NUMBER;
	public String ACTUAL_START_DATE;
	public Integer SCHEDULED_START_TIME;
	public String SCHEDULED_END_DATE;
	public String ACTUAL_END_DATE;
	public Integer SCHEDULED_END_TIME;
	public Integer RSCHEDULED_END_TIME;
	public String SEQ_DOM_INTL_CODE;
	public String CARRY_OVER_INDICATOR;
	public Integer SEQ_CREWMEMBER_POSITION;
	public Integer LEG_GRTR_MNS;
	public Integer ACTL_DUTY_PER_CR_MNS;
	public Integer ACTL_SEQ_CR_MNS;
	public Integer DHD_MIN;
	public String SEQ_CNTRTL_PATH_INDR;
	public Integer ASSIGNMENT_REASON_CODE;
	public Integer SEQ_TAFB_MINS;
	public List<Dutyperiods> dutyperiods;
	
	public Integer getSEQ_EMPNo() {
		return SEQ_EMPNo;
	}

	public void setSEQ_EMPNo(Integer sEQ_EMPNo) {
		SEQ_EMPNo = sEQ_EMPNo;
	}

	public String getSCHEDULED_START_DATE() {
		return SCHEDULED_START_DATE;
	}

	public void setSCHEDULED_START_DATE(String sCHEDULED_START_DATE) {
		SCHEDULED_START_DATE = sCHEDULED_START_DATE;
	}

	public Integer getSEQUENCE_NUMBER() {
		return SEQUENCE_NUMBER;
	}

	public void setSEQUENCE_NUMBER(Integer sEQUENCE_NUMBER) {
		SEQUENCE_NUMBER = sEQUENCE_NUMBER;
	}

	public Integer getSEQ_REASON_CODE() {
		return SEQ_REASON_CODE;
	}

	public void setSEQ_REASON_CODE(Integer sEQ_REASON_CODE) {
		SEQ_REASON_CODE = sEQ_REASON_CODE;
	}

	public Integer getSEQ_REMOVAL_CODE() {
		return SEQ_REMOVAL_CODE;
	}

	public void setSEQ_REMOVAL_CODE(Integer sEQ_REMOVAL_CODE) {
		SEQ_REMOVAL_CODE = sEQ_REMOVAL_CODE;
	}

	public Integer getSEQ_LEVEL_NUMBER() {
		return SEQ_LEVEL_NUMBER;
	}

	public void setSEQ_LEVEL_NUMBER(Integer sEQ_LEVEL_NUMBER) {
		SEQ_LEVEL_NUMBER = sEQ_LEVEL_NUMBER;
	}

	public String getACTUAL_START_DATE() {
		return ACTUAL_START_DATE;
	}

	public void setACTUAL_START_DATE(String aCTUAL_START_DATE) {
		ACTUAL_START_DATE = aCTUAL_START_DATE;
	}

	public Integer getSCHEDULED_START_TIME() {
		return SCHEDULED_START_TIME;
	}

	public void setSCHEDULED_START_TIME(Integer sCHEDULED_START_TIME) {
		SCHEDULED_START_TIME = sCHEDULED_START_TIME;
	}

	public String getSCHEDULED_END_DATE() {
		return SCHEDULED_END_DATE;
	}

	public void setSCHEDULED_END_DATE(String sCHEDULED_END_DATE) {
		SCHEDULED_END_DATE = sCHEDULED_END_DATE;
	}

	public String getACTUAL_END_DATE() {
		return ACTUAL_END_DATE;
	}

	public void setACTUAL_END_DATE(String aCTUAL_END_DATE) {
		ACTUAL_END_DATE = aCTUAL_END_DATE;
	}

	public Integer getSCHEDULED_END_TIME() {
		return SCHEDULED_END_TIME;
	}

	public void setSCHEDULED_END_TIME(Integer sCHEDULED_END_TIME) {
		SCHEDULED_END_TIME = sCHEDULED_END_TIME;
	}

	public Integer getRSCHEDULED_END_TIME() {
		return RSCHEDULED_END_TIME;
	}

	public void setRSCHEDULED_END_TIME(Integer rSCHEDULED_END_TIME) {
		RSCHEDULED_END_TIME = rSCHEDULED_END_TIME;
	}

	public String getSEQ_DOM_INTL_CODE() {
		return SEQ_DOM_INTL_CODE;
	}

	public void setSEQ_DOM_INTL_CODE(String sEQ_DOM_INTL_CODE) {
		SEQ_DOM_INTL_CODE = sEQ_DOM_INTL_CODE;
	}

	public String getCARRY_OVER_INDICATOR() {
		return CARRY_OVER_INDICATOR;
	}

	public void setCARRY_OVER_INDICATOR(String cARRY_OVER_INDICATOR) {
		CARRY_OVER_INDICATOR = cARRY_OVER_INDICATOR;
	}

	public Integer getSEQ_CREWMEMBER_POSITION() {
		return SEQ_CREWMEMBER_POSITION;
	}

	public void setSEQ_CREWMEMBER_POSITION(Integer sEQ_CREWMEMBER_POSITION) {
		SEQ_CREWMEMBER_POSITION = sEQ_CREWMEMBER_POSITION;
	}

	public Integer getLEG_GRTR_MNS() {
		return LEG_GRTR_MNS;
	}

	public void setLEG_GRTR_MNS(Integer lEG_GRTR_MNS) {
		LEG_GRTR_MNS = lEG_GRTR_MNS;
	}

	public Integer getACTL_DUTY_PER_CR_MNS() {
		return ACTL_DUTY_PER_CR_MNS;
	}

	public void setACTL_DUTY_PER_CR_MNS(Integer aCTL_DUTY_PER_CR_MNS) {
		ACTL_DUTY_PER_CR_MNS = aCTL_DUTY_PER_CR_MNS;
	}

	public Integer getACTL_SEQ_CR_MNS() {
		return ACTL_SEQ_CR_MNS;
	}

	public void setACTL_SEQ_CR_MNS(Integer aCTL_SEQ_CR_MNS) {
		ACTL_SEQ_CR_MNS = aCTL_SEQ_CR_MNS;
	}

	public Integer getDHD_MIN() {
		return DHD_MIN;
	}

	public void setDHD_MIN(Integer dHD_MIN) {
		DHD_MIN = dHD_MIN;
	}

	public String getSEQ_CNTRTL_PATH_INDR() {
		return SEQ_CNTRTL_PATH_INDR;
	}

	public void setSEQ_CNTRTL_PATH_INDR(String sEQ_CNTRTL_PATH_INDR) {
		SEQ_CNTRTL_PATH_INDR = sEQ_CNTRTL_PATH_INDR;
	}

	public Integer getASSIGNMENT_REASON_CODE() {
		return ASSIGNMENT_REASON_CODE;
	}

	public void setASSIGNMENT_REASON_CODE(Integer aSSIGNMENT_REASON_CODE) {
		ASSIGNMENT_REASON_CODE = aSSIGNMENT_REASON_CODE;
	}

	public Integer getSEQ_TAFB_MINS() {
		return SEQ_TAFB_MINS;
	}

	public void setSEQ_TAFB_MINS(Integer sEQ_TAFB_MINS) {
		SEQ_TAFB_MINS = sEQ_TAFB_MINS;
	}

	public List<Dutyperiods> getDutyperiods() {
		return dutyperiods;
	}

	public void setDutyperiods(List<Dutyperiods> dutyperiods) {
		this.dutyperiods = dutyperiods;
	}

	@Override
	public String toString() {
		return "SEQUENCES [SEQ_EMPNo=" + SEQ_EMPNo + ", SCHEDULED_START_DATE=" + SCHEDULED_START_DATE
				+ ", SEQUENCE_NUMBER=" + SEQUENCE_NUMBER + ", SEQ_REASON_CODE=" + SEQ_REASON_CODE
				+ ", SEQ_REMOVAL_CODE=" + SEQ_REMOVAL_CODE + ", SEQ_LEVEL_NUMBER=" + SEQ_LEVEL_NUMBER
				+ ", ACTUAL_START_DATE=" + ACTUAL_START_DATE + ", SCHEDULED_START_TIME=" + SCHEDULED_START_TIME
				+ ", SCHEDULED_END_DATE=" + SCHEDULED_END_DATE + ", ACTUAL_END_DATE=" + ACTUAL_END_DATE
				+ ", SCHEDULED_END_TIME=" + SCHEDULED_END_TIME + ", RSCHEDULED_END_TIME=" + RSCHEDULED_END_TIME
				+ ", SEQ_DOM_INTL_CODE=" + SEQ_DOM_INTL_CODE + ", CARRY_OVER_INDICATOR=" + CARRY_OVER_INDICATOR
				+ ", SEQ_CREWMEMBER_POSITION=" + SEQ_CREWMEMBER_POSITION + ", LEG_GRTR_MNS=" + LEG_GRTR_MNS
				+ ", ACTL_DUTY_PER_CR_MNS=" + ACTL_DUTY_PER_CR_MNS + ", ACTL_SEQ_CR_MNS=" + ACTL_SEQ_CR_MNS
				+ ", DHD_MIN=" + DHD_MIN + ", SEQ_CNTRTL_PATH_INDR=" + SEQ_CNTRTL_PATH_INDR
				+ ", ASSIGNMENT_REASON_CODE=" + ASSIGNMENT_REASON_CODE + ", SEQ_TAFB_MINS=" + SEQ_TAFB_MINS
				+ ", dutyperiods=" + dutyperiods + "]\n";
	}

	
	
}
