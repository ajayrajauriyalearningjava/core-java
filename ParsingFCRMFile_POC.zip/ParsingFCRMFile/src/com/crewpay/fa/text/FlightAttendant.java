package com.crewpay.fa.text;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import com.crewpay.fa.commons.FlightAttendantUtil;
import com.crewpay.fa.model.CrewMembers;
public class FlightAttendant {
	
	public static void main(String[] args) {
		try {
			List<CrewMembers> crewMembers=FlightAttendantUtil.getInputFilesFromFlatFile();
			FlightAttendantUtil.reportGenerate(crewMembers, "crewmembers.txt");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
