package com.crewpay.fa.commons;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;

public class CrewMapperUtil {

	public static List<String> mappingDTOsWithIndexfile(Integer recordNumber,Map<Integer,String[]> fcrmFile){
		List<String> list=new ArrayList<>();
		if(recordNumber!=0){	
			if(fcrmFile.containsKey(recordNumber)){
				String[] values= (String[]) fcrmFile.get(recordNumber);
				if(values.length!=1){
					list.add(values[0]);
					list.add(values[1]);
				}
			}
		}
		return list;
	}
	
	public static Map<Integer,String[]> fetchingRecordNameAndClassName() throws IOException{
		InputStream fis = new FileInputStream("src\\com\\crewpay\\fa\\resources\\FCRMInputFiles.properties");
		ResourceBundle resources = new PropertyResourceBundle(fis);
		Enumeration<String> keys = resources.getKeys();
		Map<Integer,String[]> fcrmFile=new HashMap<Integer, String[]>();
			// convert ResourceBundle to Map
			while (keys.hasMoreElements()) {
				String key = (String) keys.nextElement();
				 String value=resources.getString(key);
				String[] valuesList=value.trim().split(",");
				int activeKey=Integer.parseInt(key);
				fcrmFile.put(activeKey, valuesList);
			}
		return fcrmFile;
	}
	
}
