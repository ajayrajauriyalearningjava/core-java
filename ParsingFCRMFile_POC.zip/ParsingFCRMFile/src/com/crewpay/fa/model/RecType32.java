package com.crewpay.fa.model;

public class RecType32 {

}
