package com.crewpay.fa.model;

public class Legs {
	
	public Integer LEG_EMPNo;
	public Integer LEG_SEQUENCE_NUMBER;
	public Integer LEG_DP_NO;
	public String LEG_SEQ_REMOVAL_CODE;
	public Integer LEG;
	public String LEG_SCHEDULED_START_DATE;
	public String LEG_ACTUAL_START_DATE;
	public Integer LEG_SCHEDULED_START_TIME;
	public Integer RSCHEDULED_START_TIME;
	public Integer LEG_ACTUAL_START_TIME;
	public Integer LEG_SCHEDULED_END_TIME;
	public Integer LEG_ACTUAL_END_TIME;
	public Integer FLIGHT_NUMBER;
	public String DEPARTURE_STATION;
	public Integer STR_GMT_ADJMT_MNS;
	public String ARRIVAL_STATION;
	public String SCHEDULED_EQUIPMENT_CODE;
	public String ACTUAL_EQUIP_CODE;
	public Integer ATC_MINS;
	public Integer CANCELLED_LEG_INDICATOR;
	public Integer FLT_LEG_STUB_INDR;
	public Integer IRREGULAR_LEG_INDICATOR;
	public String DEADHEAD_INDICATOR;
	public String RMVD_CRD_ACTY_INDR;
	public Integer LEG_CREWMEMBER_POSITION;
	public Integer LEG_ADD_CODE;
	public Integer LEG_REMOVAL_CODE;
	public Integer DEI_MINS;
	public Integer RCD_MINS;
	public Integer DVR_MINS;
	
	
	
	
	

	public Integer getLEG_DP_NO() {
		return LEG_DP_NO;
	}


	public void setLEG_DP_NO(Integer lEG_DP_NO) {
		LEG_DP_NO = lEG_DP_NO;
	}


	public String getLEG_SEQ_REMOVAL_CODE() {
		return LEG_SEQ_REMOVAL_CODE;
	}


	public void setLEG_SEQ_REMOVAL_CODE(String lEG_SEQ_REMOVAL_CODE) {
		LEG_SEQ_REMOVAL_CODE = lEG_SEQ_REMOVAL_CODE;
	}


	


	public Integer getLEG_EMPNo() {
		return LEG_EMPNo;
	}


	public void setLEG_EMPNo(Integer lEG_EMPNo) {
		LEG_EMPNo = lEG_EMPNo;
	}


	public Integer getLEG_SEQUENCE_NUMBER() {
		return LEG_SEQUENCE_NUMBER;
	}


	public void setLEG_SEQUENCE_NUMBER(Integer lEG_SEQUENCE_NUMBER) {
		LEG_SEQUENCE_NUMBER = lEG_SEQUENCE_NUMBER;
	}


	

	public Integer getDVR_MINS() {
		return DVR_MINS;
	}
	public void setDVR_MINS(Integer dVR_MINS) {
		DVR_MINS = dVR_MINS;
	}
	public Integer getLEG() {
		return LEG;
	}
	public void setLEG(Integer lEG) {
		LEG = lEG;
	}
	public String getLEG_SCHEDULED_START_DATE() {
		return LEG_SCHEDULED_START_DATE;
	}
	public void setLEG_SCHEDULED_START_DATE(String lEG_SCHEDULED_START_DATE) {
		LEG_SCHEDULED_START_DATE = lEG_SCHEDULED_START_DATE;
	}
	public String getLEG_ACTUAL_START_DATE() {
		return LEG_ACTUAL_START_DATE;
	}
	public void setLEG_ACTUAL_START_DATE(String lEG_ACTUAL_START_DATE) {
		LEG_ACTUAL_START_DATE = lEG_ACTUAL_START_DATE;
	}
	public Integer getLEG_SCHEDULED_START_TIME() {
		return LEG_SCHEDULED_START_TIME;
	}
	public void setLEG_SCHEDULED_START_TIME(Integer lEG_SCHEDULED_START_TIME) {
		LEG_SCHEDULED_START_TIME = lEG_SCHEDULED_START_TIME;
	}
	public Integer getRSCHEDULED_START_TIME() {
		return RSCHEDULED_START_TIME;
	}
	public void setRSCHEDULED_START_TIME(Integer rSCHEDULED_START_TIME) {
		RSCHEDULED_START_TIME = rSCHEDULED_START_TIME;
	}
	public Integer getLEG_ACTUAL_START_TIME() {
		return LEG_ACTUAL_START_TIME;
	}
	public void setLEG_ACTUAL_START_TIME(Integer lEG_ACTUAL_START_TIME) {
		LEG_ACTUAL_START_TIME = lEG_ACTUAL_START_TIME;
	}
	public Integer getLEG_SCHEDULED_END_TIME() {
		return LEG_SCHEDULED_END_TIME;
	}
	public void setLEG_SCHEDULED_END_TIME(Integer lEG_SCHEDULED_END_TIME) {
		LEG_SCHEDULED_END_TIME = lEG_SCHEDULED_END_TIME;
	}
	public Integer getLEG_ACTUAL_END_TIME() {
		return LEG_ACTUAL_END_TIME;
	}
	public void setLEG_ACTUAL_END_TIME(Integer lEG_ACTUAL_END_TIME) {
		LEG_ACTUAL_END_TIME = lEG_ACTUAL_END_TIME;
	}
	public Integer getFLIGHT_NUMBER() {
		return FLIGHT_NUMBER;
	}
	public void setFLIGHT_NUMBER(Integer fLIGHT_NUMBER) {
		FLIGHT_NUMBER = fLIGHT_NUMBER;
	}
	public String getDEPARTURE_STATION() {
		return DEPARTURE_STATION;
	}
	public void setDEPARTURE_STATION(String dEPARTURE_STATION) {
		DEPARTURE_STATION = dEPARTURE_STATION;
	}
	public Integer getSTR_GMT_ADJMT_MNS() {
		return STR_GMT_ADJMT_MNS;
	}
	public void setSTR_GMT_ADJMT_MNS(Integer sTR_GMT_ADJMT_MNS) {
		STR_GMT_ADJMT_MNS = sTR_GMT_ADJMT_MNS;
	}
	public String getARRIVAL_STATION() {
		return ARRIVAL_STATION;
	}
	public void setARRIVAL_STATION(String aRRIVAL_STATION) {
		ARRIVAL_STATION = aRRIVAL_STATION;
	}
	public String getSCHEDULED_EQUIPMENT_CODE() {
		return SCHEDULED_EQUIPMENT_CODE;
	}
	public void setSCHEDULED_EQUIPMENT_CODE(String sCHEDULED_EQUIPMENT_CODE) {
		SCHEDULED_EQUIPMENT_CODE = sCHEDULED_EQUIPMENT_CODE;
	}
	public String getACTUAL_EQUIP_CODE() {
		return ACTUAL_EQUIP_CODE;
	}
	public void setACTUAL_EQUIP_CODE(String aCTUAL_EQUIP_CODE) {
		ACTUAL_EQUIP_CODE = aCTUAL_EQUIP_CODE;
	}
	public Integer getATC_MINS() {
		return ATC_MINS;
	}
	public void setATC_MINS(Integer aTC_MINS) {
		ATC_MINS = aTC_MINS;
	}
	public Integer getCANCELLED_LEG_INDICATOR() {
		return CANCELLED_LEG_INDICATOR;
	}
	public void setCANCELLED_LEG_INDICATOR(Integer cANCELLED_LEG_INDICATOR) {
		CANCELLED_LEG_INDICATOR = cANCELLED_LEG_INDICATOR;
	}
	public Integer getFLT_LEG_STUB_INDR() {
		return FLT_LEG_STUB_INDR;
	}
	public void setFLT_LEG_STUB_INDR(Integer fLT_LEG_STUB_INDR) {
		FLT_LEG_STUB_INDR = fLT_LEG_STUB_INDR;
	}
	public Integer getIRREGULAR_LEG_INDICATOR() {
		return IRREGULAR_LEG_INDICATOR;
	}
	public void setIRREGULAR_LEG_INDICATOR(Integer iRREGULAR_LEG_INDICATOR) {
		IRREGULAR_LEG_INDICATOR = iRREGULAR_LEG_INDICATOR;
	}
	public String getDEADHEAD_INDICATOR() {
		return DEADHEAD_INDICATOR;
	}
	public void setDEADHEAD_INDICATOR(String dEADHEAD_INDICATOR) {
		DEADHEAD_INDICATOR = dEADHEAD_INDICATOR;
	}
	public String getRMVD_CRD_ACTY_INDR() {
		return RMVD_CRD_ACTY_INDR;
	}
	public void setRMVD_CRD_ACTY_INDR(String rMVD_CRD_ACTY_INDR) {
		RMVD_CRD_ACTY_INDR = rMVD_CRD_ACTY_INDR;
	}
	public Integer getLEG_CREWMEMBER_POSITION() {
		return LEG_CREWMEMBER_POSITION;
	}
	public void setLEG_CREWMEMBER_POSITION(Integer lEG_CREWMEMBER_POSITION) {
		LEG_CREWMEMBER_POSITION = lEG_CREWMEMBER_POSITION;
	}
	public Integer getLEG_ADD_CODE() {
		return LEG_ADD_CODE;
	}
	public void setLEG_ADD_CODE(Integer lEG_ADD_CODE) {
		LEG_ADD_CODE = lEG_ADD_CODE;
	}
	public Integer getLEG_REMOVAL_CODE() {
		return LEG_REMOVAL_CODE;
	}
	public void setLEG_REMOVAL_CODE(Integer lEG_REMOVAL_CODE) {
		LEG_REMOVAL_CODE = lEG_REMOVAL_CODE;
	}
	public Integer getDEI_MINS() {
		return DEI_MINS;
	}
	public void setDEI_MINS(Integer dEI_MINS) {
		DEI_MINS = dEI_MINS;
	}
	public Integer getRCD_MINS() {
		return RCD_MINS;
	}
	public void setRCD_MINS(Integer rCD_MINS) {
		RCD_MINS = rCD_MINS;
	}

	

	
	@Override
	public String toString() {
		return "LEGS [LEG=" + LEG + ", LEG_SCHEDULED_START_DATE="
				+ LEG_SCHEDULED_START_DATE + ", LEG_ACTUAL_START_DATE=" + LEG_ACTUAL_START_DATE
				+ ", LEG_SCHEDULED_START_TIME=" + LEG_SCHEDULED_START_TIME + ", RSCHEDULED_START_TIME="
				+ RSCHEDULED_START_TIME + ", LEG_ACTUAL_START_TIME=" + LEG_ACTUAL_START_TIME
				+ ", LEG_SCHEDULED_END_TIME=" + LEG_SCHEDULED_END_TIME + ", LEG_ACTUAL_END_TIME=" + LEG_ACTUAL_END_TIME
				+ ", FLIGHT_NUMBER=" + FLIGHT_NUMBER + ", DEPARTURE_STATION=" + DEPARTURE_STATION
				+ ", STR_GMT_ADJMT_MNS=" + STR_GMT_ADJMT_MNS + ", ARRIVAL_STATION=" + ARRIVAL_STATION
				+ ", SCHEDULED_EQUIPMENT_CODE=" + SCHEDULED_EQUIPMENT_CODE + ", ACTUAL_EQUIP_CODE=" + ACTUAL_EQUIP_CODE
				+ ", ATC_MINS=" + ATC_MINS + ", CANCELLED_LEG_INDICATOR=" + CANCELLED_LEG_INDICATOR
				+ ", FLT_LEG_STUB_INDR=" + FLT_LEG_STUB_INDR + ", IRREGULAR_LEG_INDICATOR=" + IRREGULAR_LEG_INDICATOR
				+ ", DEADHEAD_INDICATOR=" + DEADHEAD_INDICATOR + ", RMVD_CRD_ACTY_INDR=" + RMVD_CRD_ACTY_INDR
				+ ", LEG_CREWMEMBER_POSITION=" + LEG_CREWMEMBER_POSITION + ", LEG_ADD_CODE=" + LEG_ADD_CODE
				+ ", LEG_REMOVAL_CODE=" + LEG_REMOVAL_CODE + ", DEI_MINS=" + DEI_MINS + ", RCD_MINS=" + RCD_MINS
				+ ", DVR_MINS=" + DVR_MINS + ", LEG_SEQ_REMOVAL_CODE=" + LEG_SEQ_REMOVAL_CODE + "]\n";
	}



	
	
	
	

	
	

}
