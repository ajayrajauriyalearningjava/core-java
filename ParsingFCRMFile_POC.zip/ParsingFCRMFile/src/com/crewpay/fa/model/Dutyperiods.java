package com.crewpay.fa.model;

import java.util.List;

public class Dutyperiods {
	
	public Integer DP_NO;
	public Integer DP_EMPNo;
	public Integer DP_SEQUENCE_NUMBER;
	public Integer XDTYPER;
	public String DP_SCHEDULED_START_DATE;
	public String DP_ACTUAL_START_DATE;
	public Integer DP_SCHEDULED_START_TIME;
	public Integer DP_ACTUAL_START_TIME;
	public String DP_SCHEDULED_END_DATE;
	public String DP_ACTUAL_END_DATE;
	public Integer DP_SCHEDULED_END_TIME ; 
	public Integer DP_ACTUAL_END_TIME;  
	public Integer DP_STR_GMT_ADJMT_MNS;
	public Integer DP_END_GMT_ADJMT_MNS;
	public Integer DP_LEG_GRTR_MNS;
	public Integer DP_ACTL_DUTY_PER_CR_MNS;
	public Integer DP_DHD_MIN;

	public List<Legs> legs;
	
	
	public Integer getDP_NO() {
		return DP_NO;
	}

	public void setDP_NO(Integer dP_NO) {
		DP_NO = dP_NO;
	}

	public Integer getDP_EMPNo() {
		return DP_EMPNo;
	}

	public void setDP_EMPNo(Integer dP_EMPNo) {
		DP_EMPNo = dP_EMPNo;
	}

	public Integer getDP_SEQUENCE_NUMBER() {
		return DP_SEQUENCE_NUMBER;
	}

	public void setDP_SEQUENCE_NUMBER(Integer dP_SEQUENCE_NUMBER) {
		DP_SEQUENCE_NUMBER = dP_SEQUENCE_NUMBER;
	}

	public Integer getXDTYPER() {
		return XDTYPER;
	}

	public void setXDTYPER(Integer xDTYPER) {
		XDTYPER = xDTYPER;
	}

	public String getDP_SCHEDULED_START_DATE() {
		return DP_SCHEDULED_START_DATE;
	}

	public void setDP_SCHEDULED_START_DATE(String dP_SCHEDULED_START_DATE) {
		DP_SCHEDULED_START_DATE = dP_SCHEDULED_START_DATE;
	}

	public String getDP_ACTUAL_START_DATE() {
		return DP_ACTUAL_START_DATE;
	}

	public void setDP_ACTUAL_START_DATE(String dP_ACTUAL_START_DATE) {
		DP_ACTUAL_START_DATE = dP_ACTUAL_START_DATE;
	}

	public Integer getDP_SCHEDULED_START_TIME() {
		return DP_SCHEDULED_START_TIME;
	}

	public void setDP_SCHEDULED_START_TIME(Integer dP_SCHEDULED_START_TIME) {
		DP_SCHEDULED_START_TIME = dP_SCHEDULED_START_TIME;
	}

	public Integer getDP_ACTUAL_START_TIME() {
		return DP_ACTUAL_START_TIME;
	}

	public void setDP_ACTUAL_START_TIME(Integer dP_ACTUAL_START_TIME) {
		DP_ACTUAL_START_TIME = dP_ACTUAL_START_TIME;
	}

	public String getDP_SCHEDULED_END_DATE() {
		return DP_SCHEDULED_END_DATE;
	}

	public void setDP_SCHEDULED_END_DATE(String dP_DP_SCHEDULED_END_DATE) {
		DP_SCHEDULED_END_DATE = dP_DP_SCHEDULED_END_DATE;
	}

	public String getDP_ACTUAL_END_DATE() {
		return DP_ACTUAL_END_DATE;
	}

	public void setDP_ACTUAL_END_DATE(String dP_ACTUAL_END_DATE) {
		DP_ACTUAL_END_DATE = dP_ACTUAL_END_DATE;
	}

	public Integer getDP_SCHEDULED_END_TIME() {
		return DP_SCHEDULED_END_TIME;
	}

	public void setDP_SCHEDULED_END_TIME(Integer dP_SCHEDULED_END_TIME) {
		DP_SCHEDULED_END_TIME = dP_SCHEDULED_END_TIME;
	}

	public Integer getDP_ACTUAL_END_TIME() {
		return DP_ACTUAL_END_TIME;
	}

	public void setDP_ACTUAL_END_TIME(Integer dP_ACTUAL_END_TIME) {
		DP_ACTUAL_END_TIME = dP_ACTUAL_END_TIME;
	}

	public Integer getDP_STR_GMT_ADJMT_MNS() {
		return DP_STR_GMT_ADJMT_MNS;
	}

	public void setDP_STR_GMT_ADJMT_MNS(Integer dP_STR_GMT_ADJMT_MNS) {
		DP_STR_GMT_ADJMT_MNS = dP_STR_GMT_ADJMT_MNS;
	}

	public Integer getDP_END_GMT_ADJMT_MNS() {
		return DP_END_GMT_ADJMT_MNS;
	}

	public void setDP_END_GMT_ADJMT_MNS(Integer dP_END_GMT_ADJMT_MNS) {
		DP_END_GMT_ADJMT_MNS = dP_END_GMT_ADJMT_MNS;
	}

	public Integer getDP_LEG_GRTR_MNS() {
		return DP_LEG_GRTR_MNS;
	}

	public void setDP_LEG_GRTR_MNS(Integer dP_LEG_GRTR_MNS) {
		DP_LEG_GRTR_MNS = dP_LEG_GRTR_MNS;
	}

	public Integer getDP_ACTL_DUTY_PER_CR_MNS() {
		return DP_ACTL_DUTY_PER_CR_MNS;
	}

	public void setDP_ACTL_DUTY_PER_CR_MNS(Integer dP_ACTL_DUTY_PER_CR_MNS) {
		DP_ACTL_DUTY_PER_CR_MNS = dP_ACTL_DUTY_PER_CR_MNS;
	}

	public Integer getDP_DHD_MIN() {
		return DP_DHD_MIN;
	}

	public void setDP_DHD_MIN(Integer dP_DHD_MIN) {
		DP_DHD_MIN = dP_DHD_MIN;
	}

	public List<Legs> getLegs() {
		return legs;
	}

	public void setLegs(List<Legs> legs) {
		this.legs = legs;
	}

	@Override
	public String toString() {
		return "DUTYPERIODS [XDTYPER=" + XDTYPER + ", DP_SCHEDULED_START_DATE=" + DP_SCHEDULED_START_DATE
				+ ", DP_ACTUAL_START_DATE=" + DP_ACTUAL_START_DATE + ", DP_SCHEDULED_START_TIME="
				+ DP_SCHEDULED_START_TIME + ", DP_ACTUAL_START_TIME=" + DP_ACTUAL_START_TIME
				+ ", DP_SCHEDULED_END_DATE=" + DP_SCHEDULED_END_DATE + ", DP_ACTUAL_END_DATE=" + DP_ACTUAL_END_DATE
				+ ", DP_SCHEDULED_END_TIME=" + DP_SCHEDULED_END_TIME + ", DP_ACTUAL_END_TIME=" + DP_ACTUAL_END_TIME
				+ ", DP_STR_GMT_ADJMT_MNS=" + DP_STR_GMT_ADJMT_MNS + ", DP_END_GMT_ADJMT_MNS=" + DP_END_GMT_ADJMT_MNS
				+ ", DP_LEG_GRTR_MNS=" + DP_LEG_GRTR_MNS + ", DP_ACTL_DUTY_PER_CR_MNS=" + DP_ACTL_DUTY_PER_CR_MNS
				+ ", DP_DHD_MIN=" + DP_DHD_MIN + "\n \t\t " + legs + "]\n";
	}

	

	
	
	
	
	
	
	
	


	
}
